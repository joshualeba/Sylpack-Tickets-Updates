/* Sylpack Tickets · Sonidos del sistema (WebAudio, sin archivos)
   Un timbre distinto por evento, sintetizado en tiempo real para mantener la
   app ligera. Silenciable desde la campana; el estado se recuerda. */
(() => {
  "use strict";
  const KEY = "sylpack-sound-muted";
  let ctx = null, master = null, muted = false;
  const lastPlay = {};
  let unlocked = false;

  try { muted = localStorage.getItem(KEY) === "1"; } catch {}

  function ensureCtx() {
    if (ctx) return ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    try {
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = 0.17;
      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -18; comp.knee.value = 12; comp.ratio.value = 6;
      comp.attack.value = 0.003; comp.release.value = 0.25;
      master.connect(comp); comp.connect(ctx.destination);
    } catch { ctx = null; }
    return ctx;
  }

  function unlock() {
    if (unlocked) return;
    const c = ensureCtx();
    if (!c) return;
    if (c.state === "suspended") c.resume().catch(() => {});
    unlocked = true;
  }
  document.addEventListener("pointerdown", unlock, { once: true, capture: true });
  document.addEventListener("keydown", unlock, { once: true, capture: true });

  function tone(freq, t0, dur, type, peak) {
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type || "sine";
    o.frequency.setValueAtTime(freq, t0);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak || 0.4), t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(master);
    o.start(t0); o.stop(t0 + dur + 0.03);
  }

  // [frecuencia, retardo, duración]
  const PATCHES = {
    ticket:  { type: "triangle", peak: .5,  notes: [[880, 0, .18], [1108, .07, .2], [1318, .15, .34]] },
    message: { type: "sine",     peak: .45, notes: [[740, 0, .14], [988, .09, .26]] },
    reply:   { type: "sine",     peak: .45, notes: [[988, 0, .13], [740, .09, .28]] },
    sent:    { type: "sine",     peak: .3,  notes: [[1046, 0, .1]] },
    // Sonidos exclusivos del chat: campanita al recibir, tono corto al enviar.
    chat_in:  { type: "sine",    peak: .5,  notes: [[880, 0, .13], [1174, .08, .2], [1568, .18, .34]] },
    chat_out: { type: "triangle",peak: .34, notes: [[1046, 0, .09], [1318, .06, .17]] },
    success: { type: "triangle", peak: .45, notes: [[659, 0, .16], [784, .08, .18], [988, .16, .36]] },
    close:   { type: "sine",     peak: .4,  notes: [[587, 0, .16], [440, .1, .34]] },
    reopen:  { type: "triangle", peak: .42, notes: [[440, 0, .14], [587, .08, .16], [784, .17, .3]] },
    notif:   { type: "sine",     peak: .3,  notes: [[1174, 0, .18]] },
    error:   { type: "sawtooth", peak: .2,  notes: [[220, 0, .2], [196, .14, .36]] },
  };
  const GAP = { ticket: 450, message: 300, reply: 300, sent: 150, chat_in: 350, chat_out: 150, success: 700, close: 400, reopen: 400, notif: 550, error: 600 };

  function play(name) {
    if (muted) return;
    const p = PATCHES[name] || PATCHES.notif;
    const now = Date.now();
    if (lastPlay[name] && now - lastPlay[name] < (GAP[name] || 300)) return;
    lastPlay[name] = now;
    unlock();
    const c = ensureCtx();
    if (!c) return;
    if (c.state === "suspended") c.resume().catch(() => {});
    const t = c.currentTime + 0.01;
    for (const [f, off, dur] of p.notes) tone(f, t + off, dur, p.type, p.peak);
  }

  function setMuted(v) {
    muted = !!v;
    try { localStorage.setItem(KEY, muted ? "1" : "0"); } catch {}
    if (!muted) play("notif");
  }

  window.SylpackSound = {
    play, unlock, setMuted,
    isMuted: () => muted,
    toggleMuted: () => setMuted(!muted),
    kinds: Object.keys(PATCHES),
  };
})();
