/* Sylpack Tickets · Módulo de compras - MODIFIED
   Solicitudes -> revisión -> requisición -> orden de compra -> recepción -> devolución.
   Se usa tanto en el panel de administración como en la vista de la persona usuaria. */
(() => {
  "use strict";

  const API = () => String((typeof API_BASE !== "undefined" ? API_BASE : (window.API_BASE || ""))).replace(/\/$/, "");
  const token = () => localStorage.getItem("access") || sessionStorage.getItem("access");
  const role = () => localStorage.getItem("role") || "user";
  const username = () => localStorage.getItem("username") || "";
  const myArea = () => (localStorage.getItem("area") || "").trim();
  const AREAS_CATALOGO = ["Producción", "Embarques", "Almacén", "Calidad", "Mantenimiento",
    "Administración", "Ventas", "Compras", "Otra"];
  const ESTADO_CATALOGO = {
    pendiente: ["Pendiente de revisión", "warn"],
    aprobado: ["Aprobado", "ok"],
    rechazado: ["Rechazado", "danger"],
  };

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const nl2br = (s) => esc(s).replace(/\n/g, "<br>");
  const money = (n) => new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN", minimumFractionDigits: 2 }).format(Number(n) || 0);
  const qty = (n) => new Intl.NumberFormat("es-MX", { maximumFractionDigits: 3 }).format(Number(n) || 0);
  const ORDINALES = ["Primera", "Segunda", "Tercera", "Cuarta", "Quinta", "Sexta", "Séptima", "Octava", "Novena", "Décima"];
  const opcionOrden = (idx) => `${ORDINALES[idx] || `Opción ${idx + 1}`} opción`;
  // Las opciones deben tener nombre propio; si el registro viejo solo tenía el
  // proveedor como etiqueta, se muestra un nombre ordinal legible.
  function opcionNombre(op, idx) {
    const etiqueta = String(op?.etiqueta || "").trim();
    const proveedor = String(op?.proveedor || "").trim();
    if (etiqueta && etiqueta.toLowerCase() !== proveedor.toLowerCase()) return etiqueta;
    return opcionOrden(idx);
  }
  function firmadoLabel(f) {
    const tipo = String(f?.tipo || "firmado");
    if (tipo === "requisicion_firmada") return "Requisición firmada";
    if (tipo === "orden_compra_firmada") return "OC firmada por la jefatura";
    if (tipo === "orden_compra_firmada_calidad") return "OC firmada por Calidad";
    if (tipo === "orden_compra_firmada_sandra") return "OC firmada por Sandra Limones";
    if (tipo === "orden_compra_firmada_lucio") return "OC firmada por Lucío Limones";
    if (tipo === "orden_compra_firmada_final") return "OC final con todas las firmas";
    return "Documento firmado";
  }
  // Un firmado reemplazado sigue en el historial, pero nunca habilita pasos.
  const esFirmaVigente = (f) => !!f && f.vigente !== false && f.vigente !== 0;
  const tieneFirmaVigente = (firmados, tipo) =>
    (firmados || []).some(f => f.tipo === tipo && esFirmaVigente(f));
  const tituloDesdeItems = (items) => {
    const nombres = (items || []).map(i => String(i.nombre || "").trim()).filter(Boolean);
    if (!nombres.length) return "";
    if (nombres.length === 1) return nombres[0].slice(0, 160);
    const extra = nombres.length - 1;
    return `${nombres[0]} + ${extra} producto${extra === 1 ? "" : "s"} más`.slice(0, 160);
  };
  const PROCESS_STEPS = [
    ["Creas tu solicitud", "Tú · punto de partida", "Elige cada producto, la cantidad, para qué lo necesitas y el orden de prioridad. Puedes agregar enlaces, especificaciones y varias opciones de tienda o proveedor. Si no conoces el precio final, déjalo en blanco."],
    ["Firmas la requisición", "Jefatura de tu área", "El sistema genera la requisición. Descárgala, recaba la firma de la jefatura de tu área y súbela en PDF. Esta firma autoriza internamente la compra y es indispensable para que Compras avance."],
    ["Calidad revisa (si aplica)", "Solo compras con Calidad", "Si elegiste “Compra con Calidad”, Calidad revisa y aprueba las opciones o proveedores propuestos. Si tu compra es normal, este paso se omite."],
    ["Compras prepara la OC", "Gestor de Compras", "Compras valida cantidades, confirma precios y proveedor, y genera la orden de compra oficial con los datos fiscales de la empresa."],
    ["Firmas la orden de compra", "Jefatura de área", "Descarga la OC y recaba únicamente la firma del jefe de tu área. Súbela en “OC firmada por el jefe de área”. Las firmas de Sandra, Lucío y Calidad las completa Compras."],
    ["Firmas de gestión y cierre", "Compras y almacén", "Compras recaba las firmas restantes y sube el documento final con todas las firmas. Cuando llegue el producto se registra la recepción y se cierra la compra. Si algo llega dañado o incompleto, se registra una devolución."],
  ];
  const fdate = (s) => {
    if (!s) return "—";
    const m = String(s).match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) return `${m[3]}/${m[2]}/${m[1]}`;
    const d = new Date(s);
    return isNaN(d) ? String(s) : d.toLocaleDateString("es-MX", { day: "2-digit", month: "2-digit", year: "numeric" });
  };
  const fdt = (s) => {
    if (!s) return "—";
    // Una fecha sin hora (YYYY-MM-DD) no debe convertirse a UTC: en México
    // se mostraría el día anterior.
    const plain = String(s).match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (plain) return `${plain[3]}/${plain[2]}/${plain[1]}`;
    const d = new Date(s);
    if (isNaN(d)) return String(s);
    return d.toLocaleString("es-MX", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
  };
  const fhora = (s) => {
    if (!s) return "";
    const d = new Date(s);
    return isNaN(d) ? "" : d.toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" });
  };
  const todayISO = () => {
    // Fecha local del equipo (no UTC): después de las 18:00 en México
    // new Date().toISOString() devolvía el día siguiente.
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  };
  const plusDaysISO = (days = 0) => {
    const d = new Date();
    d.setDate(d.getDate() + (Number(days) || 0));
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  };
  const MESES_CORTOS = ["ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC"];
  function fileSlug(value, limit = 48) {
    return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(/[^A-Za-z0-9]+/g, "_").replace(/^_+|_+$/g, "").slice(0, limit).replace(/_+$/g, "");
  }
  function docFileName(d = {}) {
    const raw = String(d.fecha || todayISO()).slice(0, 10);
    const [y, m, day] = raw.split("-");
    const fecha = y && m && day ? `${day}${MESES_CORTOS[Number(m) - 1] || m}${y}` : "";
    const folio = String(d.folio || "");
    const area = fileSlug(d.solicitud?.user_area || d.area || d.user_area, 28);
    const titulo = fileSlug(d.solicitud?.titulo || d.titulo, 48);
    if (d.tipo === "requisicion" || /^REQ/i.test(folio)) {
      const hit = folio.match(/^REQ[-_]?(\d{4})[-_]?(\d+)/i);
      const anio = hit ? hit[1] : (y || new Date().getFullYear());
      const seq = hit ? String(hit[2]).padStart(4, "0") : String(d.id || "").padStart(4, "0");
      return ["REQ", anio, seq, fecha, area, titulo].filter(Boolean).join("_") + ".pdf";
    }
    const hit = folio.match(/^(?:OC|ORDEN[-_ ]?COMPRA)[-_]?(\d{4})?[-_]?(\d+)/i);
    const anio = hit && hit[1] ? hit[1] : (y || new Date().getFullYear());
    const seq = hit ? String(hit[2]).padStart(4, "0") : String(d.id || "").padStart(4, "0");
    const prov = fileSlug(d.proveedor_nombre, 32) || "CompraEnLinea";
    return ["OC", anio, seq, fecha, area, prov, titulo].filter(Boolean).join("_") + ".pdf";
  }
  const safeUrl = (u) => /^https?:\/\//i.test(String(u || "")) ? String(u) : "";
  const safeImg = (u) => {
    const s = String(u || "").trim();
    return /^https?:\/\//i.test(s) || /^\/api\/compras\/imagen\?url=/i.test(s) ? s : "";
  };
  const LINK_SITE_NAMES = {
    amazon: "Amazon", mercadolibre: "Mercado Libre", temu: "Temu", aliexpress: "AliExpress",
    walmart: "Walmart", liverpool: "Liverpool", homedepot: "Home Depot", officedepot: "Office Depot",
    coppel: "Coppel", sears: "Sears", costco: "Costco", sams: "Sam's Club", ebay: "eBay",
    sodimac: "Sodimac", shopify: "Shopify",
  };
  function linkSiteName(url) {
    const clean = safeUrl(url);
    if (!clean) return "";
    try {
      const host = new URL(clean).hostname.toLowerCase().replace(/^www\./, "");
      const parts = host.split(".");
      for (const part of parts) {
        if (LINK_SITE_NAMES[part]) return LINK_SITE_NAMES[part];
      }
      const base = parts.length > 1 ? parts[parts.length - 2] : parts[0];
      return base ? base.charAt(0).toUpperCase() + base.slice(1) : "";
    } catch { return ""; }
  }
  function productLinkText(url, fallback = "") {
    const site = linkSiteName(url) || String(fallback || "").trim();
    return site ? `Producto de ${site}` : "Ver producto";
  }
  function productLinkHTML(url, fallback = "") {
    const clean = safeUrl(url);
    if (!clean) return "";
    return `<a class="cp-product-link" href="${esc(clean)}" target="_blank" rel="noopener">${esc(productLinkText(clean, fallback))}</a>`;
  }
  const RFC_RE = /^[A-Z\u00d1&]{3,4}\d{6}[A-Z0-9]{3}$/;
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  const normalizeRfc = (v) => String(v || "").toUpperCase().replace(/[^A-Z\u00d1&0-9]/g, "").slice(0, 13);
  const normalizeDigits = (v, max = 10) => String(v || "").replace(/\D/g, "").slice(0, max);
  const validRfc = (v) => RFC_RE.test(normalizeRfc(v));
  const validEmail = (v) => EMAIL_RE.test(String(v || "").trim());
  const fieldValue = (sel) => ($(sel, S.root)?.value || "").trim();

  function maskInput(el) {
    if (!el || !el.dataset || !el.dataset.fmt) return;
    const fmt = el.dataset.fmt;
    if (fmt === "rfc" || fmt === "digits" || fmt === "upper") {
      const pos = el.selectionStart ?? el.value.length;
      if (fmt === "rfc") el.value = normalizeRfc(el.value);
      else if (fmt === "digits") el.value = normalizeDigits(el.value, Number(el.dataset.max) || 10);
      else el.value = String(el.value || "").toUpperCase();
      try { el.setSelectionRange(pos, pos); } catch (_) { /* input type number */ }
    }
  }

  function tidyInput(el) {
    if (!el || !el.dataset) return;
    if (el.dataset.fmt === "email") el.value = String(el.value || "").trim().toLowerCase();
    if (el.type === "number" && el.value !== "") {
      let n = Number(el.value);
      const min = el.min !== "" ? Number(el.min) : null;
      const max = el.max !== "" ? Number(el.max) : null;
      if (!Number.isFinite(n)) n = min ?? 0;
      if (min !== null && n < min) n = min;
      if (max !== null && n > max) n = max;
      el.value = String(n);
    }
  }

  const EST_SOL = {
    pendiente: ["Pendiente", "warn"], en_revision: ["En revisión", "info"],
    cambios_solicitados: ["Cambios solicitados", "warn"],
    aprobada: ["Aprobada", "ok"], rechazada: ["Rechazada", "danger"],
    en_compra: ["En compra", "info"], recibida: ["Recibida", "ok"],
    con_incidencias: ["Con incidencias", "warn"], devuelta: ["En devolución", "danger"],
    cerrada: ["Cerrada", "muted"], cancelada: ["Cancelada", "muted"],
  };
  const SOL_STEPS = [
    ["pendiente", "Solicitada"],
    ["en_revision", "Revisión"],
    ["aprobada", "Aprobada"],
    ["en_compra", "En compra"],
    ["recibida", "Recibida"],
    ["cerrada", "Cerrada"],
  ];
  const SOL_STEP_INDEX = {
    pendiente: 0, cambios_solicitados: 1, en_revision: 1, aprobada: 2,
    en_compra: 3, recibida: 4, con_incidencias: 4, devuelta: 4,
    cerrada: 5, rechazada: 0, cancelada: 0,
  };
  const imgCache = new Map();
  const previewCache = new Map();
  let mediaObserver = null;
  const EST_DOC = {
    borrador: ["Borrador", "muted"], emitida: ["Emitida", "warn"],
    autorizada: ["Autorizada", "ok"], enviada: ["Enviada", "info"],
    recibida: ["Recibida", "ok"], cerrada: ["Cerrada", "muted"], cancelada: ["Cancelada", "muted"],
  };
  const EST_DEV = {
    solicitada: ["Solicitada", "warn"], aprobada: ["Aprobada", "ok"],
    rechazada: ["Rechazada", "danger"], enviada: ["Enviada", "info"],
    reembolsada: ["Reembolsada", "ok"], cerrada: ["Cerrada", "muted"],
  };
  const EST_REC = { completa: ["Completa", "ok"], parcial: ["Parcial", "warn"], con_incidencias: ["Con incidencias", "danger"] };
  const PRIO = { baja: ["Baja", "muted"], media: ["Normal", "info"], alta: ["Urgente", "warn"], urgente: ["Crítico", "danger"] };

  const TIPO_COMPRA = {
    normal: ["Compra normal", "info"],
    calidad: ["Con Calidad", "warn"],
  };
  const ETAPA = {
    requisicion: "Preparando requisición",
    firma_requisicion: "Firma de requisición",
    calidad_pendiente: "Pendiente de Calidad",
    calidad_en_revision: "Calidad en revisión",
    calidad_aprobada: "Aprobada por Calidad",
    revision_compras: "Revisión de Compras",
    orden_compra: "Orden de compra",
    ajuste_oc: "Ajuste de orden de compra",
    firma_orden: "Firma del jefe de área",
    firma_orden_calidad: "Firma de Calidad",
    firma_orden_sandra: "Firma de Sandra Limones",
    firma_orden_lucio: "Firma de Lucío Limones",
    firma_orden_final: "Documento final con todas las firmas",
    recepcion: "Recepción",
    cerrada: "Cerrada", cancelada: "Cancelada", rechazada: "Rechazada",
    cambios_solicitados: "Cambios solicitados", devuelta: "En devolución",
  };
  const badge = (map, key) => {
    const [label, tone] = map[key] || [key || "—", "muted"];
    return `<span class="cp-badge ${tone}">${esc(label)}</span>`;
  };
  const etapaBadge = (s) => s?.etapa_actual
    ? `<span class="cp-badge muted" title="Etapa actual">${esc(ETAPA[s.etapa_actual] || s.etapa_actual)}</span>` : "";

  // Versión compacta del avance, para las tarjetas de la lista: una barra fina
  // con la etapa concreta en la que va la solicitud (no solo el número).
  function miniStepperHTML(sol) {
    const s = typeof sol === "string" ? { estado: sol } : (sol || {});
    const estado = s.estado || "pendiente";
    const idx = SOL_STEP_INDEX[estado] ?? 0;
    const step = Math.min(idx + 1, SOL_STEPS.length);
    const special = ["rechazada", "cancelada", "cambios_solicitados", "con_incidencias", "devuelta"].includes(estado);
    const tone = estado === "rechazada" || estado === "cancelada" || estado === "devuelta"
      ? "danger" : estado === "cambios_solicitados" || estado === "con_incidencias" ? "warn" : "";
    const hechos = estado === "cerrada" ? SOL_STEPS.length : step;
    const pct = Math.round((hechos / SOL_STEPS.length) * 100);
    const actual = (EST_SOL[estado] || [estado])[0];
    const pasoGenerico = SOL_STEPS[Math.min(idx, SOL_STEPS.length - 1)][1];
    // Etapa concreta del flujo (incluye firmas, calidad, recepción…).
    const etapa = s.etapa_actual ? (ETAPA[s.etapa_actual] || s.etapa_actual) : "";
    const titulo = etapa || pasoGenerico;
    const detalle = [`Paso ${step} de ${SOL_STEPS.length}`];
    if (etapa && etapa !== pasoGenerico) detalle.push(pasoGenerico);
    if (special) detalle.push(actual);
    return `<div class="cp-mini-step ${tone}" role="progressbar" aria-label="Etapa del proceso"
      aria-valuemin="1" aria-valuemax="${SOL_STEPS.length}" aria-valuenow="${step}"
      aria-valuetext="${esc(titulo)} (paso ${step} de ${SOL_STEPS.length})">
      <div class="cp-mini-step-bar"><i style="width:${pct}%"></i></div>
      <div class="cp-mini-step-txt">
        <b>${esc(titulo)}</b>
        <span>${esc(detalle.join(" · "))}</span>
      </div>
    </div>`;
  }

  function stepperHTML(estado) {
    const idx = SOL_STEP_INDEX[estado] ?? 0;
    const special = ["rechazada", "cancelada", "cambios_solicitados", "con_incidencias", "devuelta"].includes(estado);
    const tone = estado === "rechazada" || estado === "cancelada" || estado === "devuelta"
      ? "danger" : estado === "cambios_solicitados" || estado === "con_incidencias" ? "warn" : "";
    const step = Math.min(idx + 1, SOL_STEPS.length);
    return `<div class="cp-stepper ${tone}" role="progressbar" aria-label="Etapa del proceso"
      aria-valuemin="1" aria-valuemax="${SOL_STEPS.length}" aria-valuenow="${step}"
      aria-valuetext="Etapa ${step} de ${SOL_STEPS.length}: ${esc((EST_SOL[estado] || [estado])[0])}">
      ${SOL_STEPS.map(([key, label], i) => {
        const done = i < idx || (estado === "cerrada" && i <= idx);
        const current = i === idx && !(estado === "cerrada" && i < idx);
        return `<span class="cp-st${done ? " done" : ""}${current ? " current" : ""}">
          <i>${done ? "✓" : i + 1}</i><b>${esc(label)}</b></span>`;
      }).join("")}
      ${special ? `<em class="cp-st-note">${esc((EST_SOL[estado] || [estado])[0])}</em>` : ""}
    </div>`;
  }

  function imageSrc(url) {
    const clean = safeImg(url);
    if (!clean) return Promise.resolve("");
    if (imgCache.has(clean)) return imgCache.get(clean);
    const endpoint = clean.startsWith("/api/compras/imagen?")
      ? API() + clean
      : API() + "/api/compras/imagen?url=" + encodeURIComponent(clean);
    const p = fetch(endpoint, {
      headers: { Authorization: "Bearer " + token() }, cache: "force-cache",
    }).then(r => {
      if (!r.ok) throw new Error("sin imagen");
      return r.blob();
    }).then(b => URL.createObjectURL(b)).catch(() => {
      // Si el proxy falla (bloqueo de la tienda/CDN), solo se intenta la
      // imagen directa cuando es estática; los GIF nunca se cargan animados.
      if (clean.startsWith("/api/compras/imagen?") || /\.gif(?:[?#]|$)/i.test(clean)) return "";
      imgCache.set(clean, Promise.resolve(clean));
      return clean;
    });
    imgCache.set(clean, p);
    return p;
  }

  function linkPreview(url) {
    const clean = safeUrl(url);
    if (!clean) return Promise.reject(new Error("Enlace no válido"));
    if (previewCache.has(clean)) return previewCache.get(clean);
    const p = api("/api/compras/link-preview?url=" + encodeURIComponent(clean)).catch(e => {
      previewCache.delete(clean);
      throw e;
    });
    previewCache.set(clean, p);
    return p;
  }

  function mediaPlaceholder() {
    return `<span class="cp-media-ph" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.6"/><path d="m21 15-5-5L5 21"/></svg></span>`;
  }

  function imgTag(src, alt) {
    return `<img src="${esc(src)}" alt="${esc(alt || "Imagen del producto")}" loading="lazy" referrerpolicy="no-referrer"
      onerror="this.onerror=null;this.style.display='none';var b=this.closest('[data-cpmedia],.cp-linkprev-card');if(b)b.classList.add('empty');">`;
  }

  async function hydrateBox(box) {
    if (box.dataset.cpLoading === "1" || box.dataset.cpDone === "1") return;
    box.dataset.cpLoading = "1";
    let remote = safeImg(box.dataset.cpimg || "");
    const link = safeUrl(box.dataset.cplink || "");
    try {
      if (!remote && link) {
        const info = await linkPreview(link);
        remote = safeImg(info.image || "");
        if (info.title) box.title = info.title;
        if (info.site) box.dataset.site = info.site;
      }
      if (!remote) {
        box.innerHTML = mediaPlaceholder();
        box.classList.add("empty");
        box.dataset.cpDone = "1";
        return;
      }
      const src = await imageSrc(remote);
      if (!src) {
        box.innerHTML = mediaPlaceholder();
        box.classList.add("empty");
      } else {
        box.innerHTML = imgTag(src, "Imagen del producto");
        box.classList.remove("empty");
      }
    } catch {
      box.innerHTML = mediaPlaceholder();
      box.classList.add("empty");
    } finally {
      box.dataset.cpLoading = "";
      box.dataset.cpDone = "1";
    }
  }

  function hydrateMedia(scope = document) {
    const boxes = [...scope.querySelectorAll("[data-cpmedia]")]
      .filter(b => b.dataset.cpLoading !== "1" && b.dataset.cpDone !== "1");
    if (!boxes.length) return Promise.resolve();
    if (!("IntersectionObserver" in window)) {
      return Promise.all(boxes.map(hydrateBox));
    }
    // Las imágenes se cargan al acercarse a la vista; así abrir una solicitud
    // con muchos productos no bloquea el scroll mientras descarga todo.
    if (!mediaObserver) {
      mediaObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (!entry.isIntersecting) return;
          mediaObserver.unobserve(entry.target);
          hydrateBox(entry.target);
        });
      }, { rootMargin: "320px 0px" });
    }
    boxes.forEach(box => mediaObserver.observe(box));
    return Promise.resolve();
  }

  async function refreshLinkPreview(holder, linkInput, hidden, box) {
    if (!linkInput || !box || !hidden) return;
    const link = safeUrl(linkInput.value.trim());
    if (!link) {
      hidden.value = "";
      box.innerHTML = `<span class="cp-linkprev-hint">Pega el enlace del producto y aquí verás su imagen.</span>`;
      return;
    }
    if (holder.dataset.prevLink === link && (hidden.value || box.dataset.tried === "1")) return;
    holder.dataset.prevLink = link;
    box.dataset.tried = "";
    box.innerHTML = `<span class="cp-linkprev-load"><span class="cp-spin"></span>Buscando imagen del producto…</span>`;
    try {
      const info = await linkPreview(link);
      if (safeUrl(linkInput.value.trim()) !== link) return;
      if (info.image) {
        hidden.value = info.image;
        const src = await imageSrc(info.image);
        if (src) {
          box.innerHTML = `<a class="cp-linkprev-card" href="${esc(link)}" target="_blank" rel="noopener">
            ${imgTag(src, info.title || "Producto")}
            <span><b>${esc(info.title || productLinkText(link))}</b><small>${esc(info.site || productLinkText(link))}</small></span></a>`;
        } else {
          box.innerHTML = `<a class="cp-linkprev-card textonly" href="${esc(link)}" target="_blank" rel="noopener">
            <span><b>${esc(info.title || productLinkText(link))}</b><small>${esc(info.site || productLinkText(link))} · Sin imagen disponible</small></span></a>`;
        }
      } else {
        hidden.value = "";
        box.innerHTML = `<a class="cp-linkprev-card textonly" href="${esc(link)}" target="_blank" rel="noopener">
          <span><b>${esc(info.title || productLinkText(link))}</b><small>${esc(info.site || productLinkText(link))} · Sin imagen disponible</small></span></a>`;
      }
      box.dataset.tried = "1";
    } catch (e) {
      hidden.value = "";
      box.innerHTML = `<span class="cp-linkprev-hint">No se pudo leer ese enlace. Revisa que sea público o continúa sin imagen.</span>`;
    }
  }

  async function refreshRowPreview(row) {
    return refreshLinkPreview(
      row,
      row.querySelector('[data-f="link"]'),
      row.querySelector('[data-f="imagen"]'),
      row.querySelector("[data-linkprev]")
    );
  }

  async function refreshOptionPreview(opt) {
    return refreshLinkPreview(
      opt,
      opt.querySelector('[data-of="link"]'),
      opt.querySelector('[data-of="imagen"]'),
      opt.querySelector("[data-optprev]")
    );
  }

  async function hydrateFormPreviews(form) {
    const rows = [...form.querySelectorAll(".cp-itemrow")];
    await Promise.all(rows.map(async row => {
      const box = row.querySelector("[data-linkprev]");
      const img = safeImg(row.querySelector('[data-f="imagen"]')?.value || "");
      const link = safeUrl(row.querySelector('[data-f="link"]')?.value.trim() || "");
      if (!box) return;
      if (img) {
        const src = await imageSrc(img);
        if (src) {
          box.innerHTML = `<a class="cp-linkprev-card" href="${esc(link)}" target="_blank" rel="noopener">
            ${imgTag(src, "Producto")}<span><b>${esc(link ? productLinkText(link) : "Vista previa del producto")}</b><small>${esc(link ? "Vista previa del producto" : "Imagen guardada")}</small></span></a>`;
          return;
        }
      }
      if (link) refreshRowPreview(row);
      else box.innerHTML = `<span class="cp-linkprev-hint">Pega el enlace del producto y aquí verás su imagen.</span>`;
    }));
    const opts = [...form.querySelectorAll(".cp-optrow")];
    await Promise.all(opts.map(async opt => {
      const box = opt.querySelector("[data-optprev]");
      const img = safeImg(opt.querySelector('[data-of="imagen"]')?.value || "");
      const link = safeUrl(opt.querySelector('[data-of="link"]')?.value.trim() || "");
      const fallback = opt.querySelector('[data-of="etiqueta"]')?.value || "";
      if (!box) return;
      if (img) {
        const src = await imageSrc(img);
        if (src) {
          box.innerHTML = `<a class="cp-linkprev-card" href="${esc(link)}" target="_blank" rel="noopener">
            ${imgTag(src, "Producto")}<span><b>${esc(link ? productLinkText(link, fallback) : "Vista previa del producto")}</b><small>${esc(link ? "Vista previa del producto" : "Imagen guardada")}</small></span></a>`;
          return;
        }
      }
      if (link) refreshOptionPreview(opt);
      else box.innerHTML = `<span class="cp-linkprev-hint">Pega el enlace del producto y aquí verás su imagen.</span>`;
    }));
  }
  const toast = (title, body, kind = "success") => {
    if (window.SylpackToast) window.SylpackToast[kind] ? window.SylpackToast[kind](title, body) : window.SylpackToast.show({ title, body, kind });
    else console.log(title, body);
  };
  const confirmar = async (title, msg, danger = false) => {
    if (!window.Modal) return window.confirm(msg || title);
    const r = await window.Modal.show({
      title, msg, type: danger ? "error" : "info", buttons: [
        { label: "Cancelar", value: false },
        { label: danger ? "Continuar" : "Aceptar", value: true, primary: true, danger }
      ]
    });
    // Modal.show devuelve el valor del botón cuando no hay campos,
    // o { button, values } cuando el diálogo incluye formulario.
    return r === true || !!(r && r.button);
  };

  async function api(path, opts = {}) {
    const tk = token();
    if (!tk) throw new Error("Sesión expirada");
    const headers = Object.assign({ Authorization: "Bearer " + tk }, opts.headers || {});
    if (opts.body && !(opts.body instanceof FormData)) headers["Content-Type"] = "application/json";
    const method = String(opts.method || "GET").toUpperCase();
    const attempts = (method === "GET" || method === "HEAD") ? 3 : 1;
    let r;
    for (let i = 0; i < attempts; i++) {
      try {
        r = await fetch(API() + path, Object.assign({}, opts, { headers }));
      } catch (e) {
        if (i + 1 < attempts) { await new Promise(ok => setTimeout(ok, 180)); continue; }
        throw new Error("No hay conexión con el servidor. Revisa la red local.");
      }
      if (i + 1 < attempts && [502, 503, 504].includes(r.status)) {
        await new Promise(ok => setTimeout(ok, 180));
        continue;
      }
      break;
    }
    if (r.status === 401) {
      if (window.SylpackAuth?.fail) window.SylpackAuth.fail();
      throw new Error("Sesión expirada");
    }
    const data = await r.json().catch(() => ({}));
    if (!r.ok) {
      const err = new Error(data.msg || "No se pudo completar la operación");
      err.data = data;
      err.status = r.status;
      throw err;
    }
    return data;
  }

  const S = {
    root: null, mode: "user", view: "solicitudes", estado: "", calidad: "", q: "", catalogTab: "productos",
    catalogEstado: "", catalogArea: "", catalogSort: "prioridad",
    catalogCat: "", catalogPrecioMin: "", catalogPrecioMax: "",
    invItems: [], invArea: "", invCat: "", invLow: false,
    kpis: {}, list: [], proveedores: [], certificados: [], empresa: null,
    currentSol: null, currentDoc: null, docTipo: null, docBase: null,
    ocSelections: {},
    timer: 0, busy: false,
  };

  // El modo define la interfaz, no el rol. En una misma página el gestor puede
  // alternar su vista de usuario y su vista de gestión sin mezclar permisos.
  const canManage = () => S.mode === "manager";
  const viewAll = () => S.mode === "manager" || S.mode === "admin" || S.mode === "quality";
  const isAdminView = () => S.mode === "admin";
  const isQualityView = () => S.mode === "quality";
  // Calidad y administración autorizan el catálogo de todas las áreas.
  const isCatalogAdmin = () => role() === "calidad" || ["admin", "super"].includes(role()) ||
    S.mode === "admin" || S.mode === "quality";
  const canCreateCatalog = () => isCatalogAdmin() || !!myArea();
  const canEditCatalog = (rec) => isCatalogAdmin() || (!!rec && String(rec.area || "") === myArea());
  const OC_FIRMAS = [
    ["orden_compra_firmada", "Firma del jefe de área", "Jefatura de área"],
    ["orden_compra_firmada_calidad", "Firma de Calidad", "Calidad"],
    ["orden_compra_firmada_sandra", "Firma de Sandra Limones", "Sandra Limones"],
    ["orden_compra_firmada_lucio", "Firma de Lucío Limones", "Lucío Limones"],
  ];
  const OC_FINAL = ["orden_compra_firmada_final", "OC completa con todas las firmas", "Compras"];
  const firmaTipoLabel = (tipo) => {
    if (tipo === "requisicion_firmada") return "Requisición firmada";
    if (tipo === "firmado") return "Documento firmado";
    return [...OC_FIRMAS, OC_FINAL].find(x => x[0] === tipo)?.[1] || "Documento firmado";
  };
  const ocFirmaDefs = (s) => OC_FIRMAS.filter(([tipo]) =>
    tipo !== "orden_compra_firmada_calidad" || (s.tipo_compra || "normal") === "calidad");
  const ocFirmaVigente = (s, tipo) => tieneFirmaVigente(s.firmados, tipo);
  const ocFirmasCompletas = (s) => ocFirmaDefs(s).every(([tipo]) => ocFirmaVigente(s, tipo));
  const ocFirmaSiguiente = (s) => {
    for (const [tipo] of [...ocFirmaDefs(s), OC_FINAL]) {
      if (!ocFirmaVigente(s, tipo)) return tipo;
    }
    return OC_FINAL[0];
  };
  const ocFirmaAnteriorFaltante = (s, tipo) => {
    const req = ocFirmaDefs(s).map(x => x[0]);
    const previos = tipo === OC_FINAL[0] ? req : req.slice(0, Math.max(0, req.indexOf(tipo)));
    const falta = previos.find(t => !ocFirmaVigente(s, t));
    return falta ? firmaTipoLabel(falta) : "";
  };
  const esCompras = () => canManage();
  const esCalidad = () => role() === "calidad" || S.mode === "quality";
  // Inventario: administración ve y edita todo; cada área administra lo suyo
  // y puede consultar los artículos de las áreas involucradas.
  const isInvAdmin = () => ["admin", "super"].includes(role()) || S.mode === "admin";
  const canCreateInv = () => isInvAdmin() || !!myArea();
  const canEditInv = (item) => isInvAdmin() || (!!item && String(item.area || "") === myArea());
  const badgeCatalogo = (estado) => {
    const [label, tone] = ESTADO_CATALOGO[estado] || ESTADO_CATALOGO.pendiente;
    return `<span class="cp-badge ${tone}">${esc(label)}</span>`;
  };

  function shellHTML() {
    const mgr = canManage();
    const admin = isAdminView();
    const quality = isQualityView();
    // Sección independiente: solo el catálogo del área (sin el resto de compras).
    if (S.solo === "catalogo") {
      return `
  <div class="cp cp-solo-cat">
    <div class="cp-head">
      <div class="cp-head-txt">
        <h2>Catálogo del área</h2>
        <p>Productos y proveedores ${quality || admin ? "de <b>todas las áreas</b>" : `de <b>${esc(myArea() || "tu área")}</b>`}.
          Los productos normales se guardan aprobados; Calidad solo revisa los que fueron enviados a revisión.</p>
      </div>
      <div class="cp-head-actions">
        <button class="cp-btn ghost" data-act="refresh" title="Actualizar">Actualizar</button>
      </div>
    </div>
    <div id="cpFiscalWarn"></div>
    <div class="cp-kpis" id="cpKpis" hidden></div>
    <select id="cpEstado" class="cp-select" hidden aria-hidden="true"></select>
    <div id="cpList" class="cp-list"><div class="cp-empty">Cargando…</div></div>
  </div>
  <div id="cpOverlay" class="cp-overlay" hidden></div>`;
    }
    const title = quality ? "Compras con Calidad" : admin ? "Supervisión de compras" : mgr ? "Gestión de abastecimiento" : "Centro de compras";
    const subtitle = mgr
      ? "Revisa solicitudes, autoriza, genera la orden de compra y controla recepciones y devoluciones."
      : quality
        ? "Revisa solo los productos y proveedores enviados a revisión de todas las áreas, atiende las compras con Calidad y solicita como cualquier usuario."
        : admin
          ? "Consulta el avance de todas las compras y administra el catálogo de productos y proveedores de todas las áreas."
          : "Pide material o equipo, mantén el catálogo de tu área al día y sigue el avance de tus solicitudes en tiempo real.";
    return `
  <div class="cp">
    <div class="cp-head">
      <div class="cp-head-txt">
        <h2>${title}</h2>
        <p>${subtitle}</p>
      </div>
      <div class="cp-head-actions">
        ${!mgr && !admin && !quality ? `<button class="cp-btn primary" data-act="new-sol">+ Nueva solicitud</button>` : ""}
        ${mgr ? `<button class="cp-btn" data-act="company">Datos de la empresa</button>` : ""}
        <button class="cp-btn ghost" data-act="refresh" title="Actualizar">Actualizar</button>
      </div>
    </div>
    ${admin ? `<div class="cp-readonly"><b>Solo lectura en solicitudes.</b> El gestor de compras opera el flujo. En <b>Catálogo del área</b> sí tienes control total de productos y proveedores.</div>` : ""}
    ${quality ? `<div class="cp-readonly"><b>Calidad.</b> Revisa la requisición firmada, aprueba opciones y atiende solo los productos/proveedores que las áreas enviaron a revisión.</div>` : ""}
    <div id="cpFiscalWarn"></div>
    <div class="cp-kpis" id="cpKpis"></div>
    <div class="cp-bar">
      <div class="cp-tabs" id="cpTabs">
        <button data-view="solicitudes" class="on">${mgr || admin || quality ? "Solicitudes" : "Mis solicitudes"}</button>
        ${!quality ? `<button data-view="documentos">${mgr || admin ? "Documentos" : "Mis documentos"}</button>` : ""}
        ${!quality ? `<button data-view="devoluciones">Devoluciones</button>` : ""}
        ${mgr || admin ? `<button data-view="proveedores">Proveedores</button>` : ""}
      </div>
      <div class="cp-filters">
        <div class="cp-search">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
          <input id="cpQ" placeholder="Buscar folio, producto, área…" autocomplete="off" aria-label="Buscar solicitudes, documentos o productos">
        </div>
        <select id="cpEstado" class="cp-select" aria-label="Filtrar por estado"><option value="">Todos los estados</option></select>
      </div>
    </div>
    <div id="cpList" class="cp-list"><div class="cp-empty">Cargando…</div></div>
  </div>
  <div id="cpOverlay" class="cp-overlay" hidden></div>`;
  }

  function setEstadoOptions() {
    const sel = $("#cpEstado", S.root);
    if (!sel) return;
    let map = S.view === "solicitudes" ? EST_SOL : S.view === "documentos" ? EST_DOC : S.view === "devoluciones" ? EST_DEV : {};
    let extras = "";
    if (S.view === "solicitudes") {
      extras = `<option value="pendiente,en_revision">Por atender (pendientes y en revisión)</option>
        <option value="recibida,con_incidencias">Recibidas</option>`;
    } else if (S.view === "devoluciones") {
      extras = `<option value="solicitada,aprobada,enviada">Devoluciones abiertas</option>`;
    }
    sel.innerHTML = `<option value="">Todos los estados</option>` + extras +
      Object.entries(map).map(([k, v]) => `<option value="${k}">${esc(v[0])}</option>`).join("");
    sel.value = S.estado || "";
  }

  function renderKpis() {
    const k = S.kpis || {};
    const sol = k.solicitudes || {};
    const docs = k.documentos || {};
    const devs = k.devoluciones || {};
    const sum = (m, keys) => keys.reduce((a, x) => a + (Number(m[x]) || 0), 0);
    if (isQualityView()) {
      const c = k.calidad || {};
      const cards = [
        { key: "pendiente", label: "Pendientes de Calidad", value: Number(c.pendientes) || 0, tone: "warn", view: "solicitudes", estado: "", calidad: "pendiente,en_revision" },
        { key: "aprobada", label: "Aprobadas por Calidad", value: Number(c.aprobadas) || 0, tone: "ok", view: "solicitudes", estado: "", calidad: "aprobada" },
        { key: "firma", label: "Esperando requisición firmada", value: Number(c.sin_firma) || 0, tone: "muted", view: "solicitudes", estado: "pendiente,en_revision", calidad: "pendiente,en_revision" },
        { key: "cambios", label: "Con cambios solicitados", value: Number(sol.cambios_solicitados) || 0, tone: "danger", view: "solicitudes", estado: "cambios_solicitados", calidad: "" },
      ];
      const box = $("#cpKpis", S.root);
      box.innerHTML = cards.map(c => {
        const on = S.view === c.view && S.estado === c.estado && S.calidad === (c.calidad || "");
        return `<button class="cp-kpi ${c.tone}${on ? " on" : ""}" data-kpi-view="${c.view}" data-kpi-estado="${c.estado}" data-kpi-calidad="${c.calidad || ""}" aria-pressed="${on}">
          <span class="cp-kpi-ico">${icoKpi(c.key)}</span>
          <span class="cp-kpi-txt"><b>${c.value}</b><small>${esc(c.label)}</small></span>
        </button>`;
      }).join("");
      return;
    }
    const cards = viewAll() ? [
      { key: "pendiente", label: "Por atender", value: sum(sol, ["pendiente", "en_revision"]), tone: "warn", view: "solicitudes", estado: "pendiente,en_revision" },
      { key: "aprobada", label: "Aprobadas", value: Number(sol.aprobada) || 0, tone: "ok", view: "solicitudes", estado: "aprobada" },
      { key: "en_compra", label: "En compra", value: Number(sol.en_compra) || 0, tone: "info", view: "solicitudes", estado: "en_compra" },
      { key: "por_autorizar", label: "Órdenes por autorizar", value: Number(k.por_autorizar) || 0, tone: "danger", view: "documentos", estado: "emitida" },
      { key: "recibida", label: "Recibidas", value: sum(sol, ["recibida", "con_incidencias"]), tone: "ok", view: "solicitudes", estado: "recibida,con_incidencias" },
      { key: "dev", label: "Devoluciones abiertas", value: sum(devs, ["solicitada", "aprobada", "enviada"]), tone: "warn", view: "devoluciones", estado: "solicitada,aprobada,enviada" },
    ] : [
      { key: "all", label: "Mis solicitudes", value: sum(sol, Object.keys(EST_SOL)), tone: "info", view: "solicitudes", estado: "" },
      { key: "pendiente", label: "Pendientes", value: sum(sol, ["pendiente", "en_revision"]), tone: "warn", view: "solicitudes", estado: "pendiente,en_revision" },
      { key: "aprobada", label: "Aprobadas", value: Number(sol.aprobada) || 0, tone: "ok", view: "solicitudes", estado: "aprobada" },
      { key: "recibida", label: "Recibidas", value: sum(sol, ["recibida", "con_incidencias"]), tone: "ok", view: "solicitudes", estado: "recibida,con_incidencias" },
      { key: "dev", label: "Devoluciones", value: sum(devs, Object.keys(EST_DEV)), tone: "warn", view: "devoluciones", estado: "" },
    ];
    const box = $("#cpKpis", S.root);
    box.innerHTML = cards.map(c => {
      const on = S.view === c.view && S.estado === c.estado && !S.calidad;
      return `<button class="cp-kpi ${c.tone}${on ? " on" : ""}" data-kpi-view="${c.view}" data-kpi-estado="${c.estado}" data-kpi-calidad="" aria-pressed="${on}">
        <span class="cp-kpi-ico">${icoKpi(c.key)}</span>
        <span class="cp-kpi-txt"><b>${c.value}</b><small>${esc(c.label)}</small></span>
      </button>`;
    }).join("");
  }

  function renderFiscalWarn() {
    const box = $("#cpFiscalWarn", S.root);
    if (!box || !viewAll() || isQualityView() || S.solo) return;
    const e = S.empresa || {};
    if ((e.rfc || "").trim() && (e.razon_social || "").trim()) {
      box.innerHTML = "";
      return;
    }
    box.innerHTML = `<div class="cp-alert warn">
      <div><b>Faltan los datos fiscales de la empresa.</b>
      <p>El gestor de compras debe capturar el RFC y la razón social antes de generar requisiciones y órdenes de compra.</p></div>
      ${canManage() ? `<button class="cp-btn primary" data-act="company">Capturar ahora</button>` : ""}
    </div>`;
  }

  function icoKpi(k) {
    const icons = {
      pendiente: '<path d="M12 8v5l3 2"/><circle cx="12" cy="12" r="9"/>',
      aprobada: '<path d="m5 12 4.5 4.5L19 7"/>',
      en_compra: '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M3 4h2l2.5 11h11L21 7H6"/>',
      por_autorizar: '<path d="M12 3 2.5 20h19z"/><path d="M12 9v5M12 17v.2"/>',
      recibida: '<path d="M3 7h18v12H3z"/><path d="M3 7l9-4 9 4"/><path d="M12 11v4"/>',
      dev: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/>',
      all: '<path d="M4 6h16M4 12h16M4 18h10"/>',
    };
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${icons[k] || icons.all}</svg>`;
  }

  function empty(msg, extra = "") {
    return `<div class="cp-empty"><div class="cp-empty-ico">${icoKpi("all")}</div><b>${esc(msg)}</b>${extra ? `<span>${esc(extra)}</span>` : ""}</div>`;
  }

  function catalogDate(value, withTime = false) {
    if (!value) return "—";
    return withTime ? fdt(value) : fdate(value);
  }

  function renderCatalogo(box) {
    const tab = S.catalogTab === "proveedores" ? "proveedores" : "productos";
    const productos = S.certificados || [];
    const proveedores = S.proveedores || [];
    const base = tab === "proveedores" ? proveedores : productos;
    const quality = isCatalogAdmin();
    const estadoFilter = S.catalogEstado || "";
    const areaFilter = S.catalogArea || "";
    const catFilter = S.catalogCat || "";
    const precioMin = S.catalogPrecioMin === "" ? null : Number(S.catalogPrecioMin);
    const precioMax = S.catalogPrecioMax === "" ? null : Number(S.catalogPrecioMax);
    const sort = S.catalogSort || "prioridad";
    const q = (S.q || "").toLowerCase();
    const counts = {
      todos: base.length,
      pendiente: base.filter(x => (x.calidad_estado || "pendiente") === "pendiente").length,
      aprobado: base.filter(x => x.calidad_estado === "aprobado").length,
      rechazado: base.filter(x => x.calidad_estado === "rechazado").length,
      inactivo: base.filter(x => !x.activo).length,
    };
    const areas = [...new Set(base.map(x => x.area).filter(Boolean))].sort((a, b) => a.localeCompare(b, "es"));
    const cats = [...new Set(productos.map(x => x.categoria).filter(Boolean))].sort((a, b) => a.localeCompare(b, "es"));
    const precioDe = (p) => Number(p.costo_promedio) || Number(p.ultimo_costo) || 0;
    let items = base.filter(p => {
      if (estadoFilter === "inactivo" && p.activo) return false;
      if (estadoFilter && estadoFilter !== "inactivo" && (p.calidad_estado || "pendiente") !== estadoFilter) return false;
      if (areaFilter && String(p.area || "") !== areaFilter) return false;
      if (tab === "productos" && catFilter && String(p.categoria || "") !== catFilter) return false;
      if (tab === "productos" && (precioMin != null || precioMax != null)) {
        const precio = precioDe(p);
        if (precioMin != null && precio < precioMin) return false;
        if (precioMax != null && precio > precioMax) return false;
      }
      if (q) {
        const hay = [p.nombre, p.descripcion, p.categoria, p.area, p.rfc, p.contacto, p.email,
          p.requisitos_calidad, p.proveedor_nombre, ...(p.productos_nombres || [])]
          .join(" ").toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
    const order = { pendiente: 0, rechazado: 1, aprobado: 2 };
    items = items.slice().sort((a, b) => {
      if (sort === "usados") return (Number(b.usos || b.compras_count || 0) - Number(a.usos || a.compras_count || 0)) || String(a.nombre || "").localeCompare(String(b.nombre || ""), "es");
      if (sort === "recientes") return String(b.created_at || "").localeCompare(String(a.created_at || ""));
      if (sort === "nombre") return String(a.nombre || "").localeCompare(String(b.nombre || ""), "es");
      return (order[a.calidad_estado || "pendiente"] ?? 3) - (order[b.calidad_estado || "pendiente"] ?? 3) ||
        Number(b.activo) - Number(a.activo) || String(a.nombre || "").localeCompare(String(b.nombre || ""), "es");
    });

    const productCard = p => {
      const puede = canEditCatalog(p);
      const prov = p.proveedor_nombre ? { nombre: p.proveedor_nombre, calidad_estado: p.proveedor_calidad_estado } : null;
      const acciones = [
        puede ? `<button class="cp-mini" data-catedit="${p.id}" data-kind="producto">Editar</button>` : "",
        puede && p.activo ? `<button class="cp-mini danger" data-catoff="producto" data-id="${p.id}">Desactivar</button>` : "",
        quality && p.calidad_estado !== "aprobado" ? `<button class="cp-mini ok" data-catqa="aprobar" data-kind="producto" data-id="${p.id}">Aprobar</button>` : "",
        quality && p.calidad_estado !== "rechazado" ? `<button class="cp-mini danger" data-catqa="rechazar" data-kind="producto" data-id="${p.id}">Rechazar</button>` : "",
      ].filter(Boolean).join("");
      const usos = Number(p.usos) || 0;
      const link = safeUrl(p.link);
      const img = p.imagen || "";
      return `<article class="cp-cert-card cp-cat-card cp-cat-visual${p.activo ? "" : " off"}" data-catopen="producto" data-id="${p.id}" tabindex="0" role="button" aria-label="Ver detalle de ${esc(p.nombre)}">
        <div class="cp-cat-thumb${img || link ? "" : " empty"}" data-cpmedia data-cpimg="${esc(img)}" data-cplink="${esc(link)}">${mediaPlaceholder()}</div>
        <div class="cp-cat-body">
          <div class="cp-cat-topline">
            <span class="cp-cat-state-ico" aria-hidden="true">${p.activo ? "✓" : "×"}</span>
            ${badgeCatalogo(p.calidad_estado)}
          </div>
          <b class="cp-cat-name">${esc(p.nombre)}</b>
          <small class="cp-cat-sub">${esc(p.unidad || "pza")}${p.id_fabricacion ? ` · ${esc(p.id_fabricacion)}` : ""}</small>
          <div class="cp-cat-meta">
            <span class="cp-chip">${esc(p.area || "Sin área")}</span>
            ${p.categoria ? `<span class="cp-chip">${esc(p.categoria)}</span>` : ""}
            ${prov ? `<span class="cp-chip" title="Proveedor vinculado">${esc(prov.nombre)}${prov.calidad_estado === "aprobado" ? " ✓" : ""}</span>` : `<span class="cp-chip">Sin proveedor</span>`}
          </div>
          ${p.descripcion ? `<p class="cp-cat-desc">${nl2br(p.descripcion)}</p>` : ""}
          <div class="cp-cat-figures">
            <div><b>${money(p.costo_promedio)}</b><span>costo promedio</span></div>
            <div><b>${qty(usos)}</b><span>solicitud(es)</span></div>
            ${p.ultimo_costo != null ? `<div><b>${money(p.ultimo_costo)}</b><span>último costo</span></div>` : ""}
          </div>
          ${link ? `<div class="cp-cat-linkrow">${productLinkHTML(link)}</div>` : ""}
          <div class="cp-cat-cardfoot">
            <span class="cp-cat-open">Ver detalle</span>
            <div class="cp-cat-btns">${acciones}</div>
          </div>
        </div>
      </article>`;
    };

    const providerCard = p => {
      const puede = canEditCatalog(p);
      const acciones = [
        puede ? `<button class="cp-mini" data-catedit="${p.id}" data-kind="proveedor">Editar</button>` : "",
        puede && p.activo ? `<button class="cp-mini danger" data-catoff="proveedor" data-id="${p.id}">Desactivar</button>` : "",
        quality && p.calidad_estado !== "aprobado" ? `<button class="cp-mini ok" data-catqa="aprobar" data-kind="proveedor" data-id="${p.id}">Aprobar</button>` : "",
        quality && p.calidad_estado !== "rechazado" ? `<button class="cp-mini danger" data-catqa="rechazar" data-kind="proveedor" data-id="${p.id}">Rechazar</button>` : "",
      ].filter(Boolean).join("");
      return `<article class="cp-cert-card cp-cat-card cp-prov-card${p.activo ? "" : " off"}" data-catopen="proveedor" data-id="${p.id}" tabindex="0" role="button" aria-label="Ver detalle de ${esc(p.nombre)}">
        <div class="cp-cert-top">
          <span class="cp-cert-ico cp-prov-ico">P</span>
          <div><b>${esc(p.nombre)}</b><small>${esc(p.rfc || "Sin RFC")}${p.razon_social && p.razon_social !== p.nombre ? ` · ${esc(p.razon_social)}` : ""}</small></div>
          ${badgeCatalogo(p.calidad_estado)}
        </div>
        <div class="cp-cat-meta">
          <span class="cp-chip">${esc(p.area || "Global")}</span>
          ${p.activo ? `<span class="cp-chip cp-chip-ok">Activo</span>` : `<span class="cp-chip">Inactivo</span>`}
          ${p.condiciones_pago ? `<span class="cp-chip">${esc(p.condiciones_pago)}</span>` : ""}
        </div>
        <div class="cp-cat-facts">
          <div><span>Contacto</span><b>${esc(p.contacto || "—")}</b></div>
          <div><span>Correo</span><b>${esc(p.email || "—")}</b></div>
          <div><span>Teléfono</span><b>${esc(p.telefono || "—")}</b></div>
          <div><span>Domicilio</span><b>${esc(p.domicilio || "—")}</b></div>
        </div>
        <div class="cp-cat-usage">
          <div><b>${qty(p.productos_count || 0)}</b><span>productos vinculados</span></div>
          <div><b>${qty(p.productos_aprobados || 0)}</b><span>productos aprobados</span></div>
          <div><b>${qty(p.compras_count || 0)}</b><span>compras / OC</span></div>
          <div><b>${money(p.total_comprado)}</b><span>comprado</span></div>
        </div>
        ${(p.productos_nombres || []).length ? `<p class="cp-cat-usage-note">Productos: ${p.productos_nombres.map(n => `<b>${esc(n)}</b>`).join(" · ")}${Number(p.productos_count) > p.productos_nombres.length ? ` · +${Number(p.productos_count) - p.productos_nombres.length} más` : ""}</p>` : ""}
        <p class="cp-cat-usage-note">${p.ultima_compra ? `Última compra: <b>${esc(catalogDate(p.ultima_compra))}</b>` : "Aún no tiene órdenes de compra registradas."}</p>
        ${p.calidad_nota ? `<div class="cp-cat-note ${p.calidad_estado === "rechazado" ? "danger" : ""}"><b>Observación de Calidad</b><p>${nl2br(p.calidad_nota)}</p></div>` : ""}
        <div class="cp-cert-foot">
          <small>Alta: ${esc(p.created_by || "—")} · ${fdate(p.created_at)}${p.calidad_por ? ` · Calidad: ${esc(p.calidad_por)}` : ""}</small>
          <div class="cp-cat-btns">${acciones || `<small class="cp-muted">Solo lectura</small>`}</div>
        </div>
      </article>`;
    };

    const cards = items.map(tab === "proveedores" ? providerCard : productCard).join("");
    const statBtn = (key, label, tone = "") => `<button class="cp-cat-stat ${tone}${(estadoFilter || "todos") === key ? " on" : ""}" data-catstat="${key}">
      <b>${counts[key]}</b><span>${label}</span></button>`;
    const areaFilterHTML = (quality || areas.length > 1) ? `<label class="cp-cat-filter"><span>Área</span>
      <select data-catfilter="area"><option value="">Todas</option>${areas.map(a => `<option value="${esc(a)}"${areaFilter === a ? " selected" : ""}>${esc(a)}</option>`).join("")}</select></label>` : "";
    const catFilterHTML = tab === "productos" ? `<label class="cp-cat-filter"><span>Categoría</span>
      <select data-catfilter="categoria"><option value="">Todas</option>${cats.map(c => `<option value="${esc(c)}"${catFilter === c ? " selected" : ""}>${esc(c)}</option>`).join("")}</select></label>` : "";
    const priceOpts = [
      ["", "Cualquier precio", "", ""],
      ["0-100", "Hasta $100", "0", "100"],
      ["100-500", "$100 a $500", "100", "500"],
      ["500-1000", "$500 a $1,000", "500", "1000"],
      ["1000-", "Más de $1,000", "1000", ""],
    ];
    const priceKey = (S.catalogPrecioMin === "" && S.catalogPrecioMax === "") ? "" : `${S.catalogPrecioMin || ""}-${S.catalogPrecioMax || ""}`;
    const priceFilterHTML = tab === "productos" ? `<label class="cp-cat-filter"><span>Precio</span>
      <select data-catfilter="precio">${priceOpts.map(([v, label, min, max]) =>
        `<option value="${v}" data-min="${min}" data-max="${max}"${priceKey === v ? " selected" : ""}>${label}</option>`).join("")}</select></label>` : "";
    const hasFilters = !!(estadoFilter || areaFilter || catFilter || precioMin != null || precioMax != null || q);
    const soloCatalogo = S.solo === "catalogo";
    box.innerHTML = `<div class="cp-cert-head cp-cat-head${soloCatalogo ? " solo-tools" : ""}">
      ${soloCatalogo ? "" : `<div class="cp-cat-head-copy"><h3>Catálogo del área</h3><p>Productos y proveedores ${quality ? "de <b>todas las áreas</b>"
        : `de <b>${esc(myArea() || "tu área")}</b>`}.
      Los productos de compras normales se guardan aprobados; solo los enviados a revisión esperan a Calidad.
      ${quality ? " Aquí puedes revisar el uso real antes de aprobar." : ""}</p></div>`}
      <div class="cp-cat-tools">
        <div class="cp-cat-tabs">
          <button data-cattab="productos" class="${tab === "productos" ? "on" : ""}">Productos · ${productos.length}</button>
          <button data-cattab="proveedores" class="${tab === "proveedores" ? "on" : ""}">Proveedores · ${proveedores.length}</button>
        </div>
        ${canCreateCatalog() ? `<button class="cp-btn primary" data-catnew="${tab === "proveedores" ? "proveedor" : "producto"}">+ ${tab === "proveedores" ? "Proveedor" : "Producto"}</button>` : ""}
      </div>
    </div>
    <div class="cp-cat-stats">
      ${statBtn("todos", "Total")}
      ${statBtn("pendiente", "Pendientes", "warn")}
      ${statBtn("aprobado", "Aprobados", "ok")}
      ${statBtn("rechazado", "Rechazados", "danger")}
      ${statBtn("inactivo", "Inactivos", "muted")}
    </div>
    <div class="cp-cat-filters">
      <label class="cp-cat-filter"><span>Estado</span>
        <select data-catfilter="estado">
          <option value="">Todos</option>
          <option value="pendiente"${estadoFilter === "pendiente" ? " selected" : ""}>Pendientes</option>
          <option value="aprobado"${estadoFilter === "aprobado" ? " selected" : ""}>Aprobados</option>
          <option value="rechazado"${estadoFilter === "rechazado" ? " selected" : ""}>Rechazados</option>
          <option value="inactivo"${estadoFilter === "inactivo" ? " selected" : ""}>Inactivos</option>
        </select></label>
      ${areaFilterHTML}
      ${catFilterHTML}
      ${priceFilterHTML}
      <label class="cp-cat-filter"><span>Ordenar por</span>
        <select data-catfilter="sort">
          <option value="prioridad"${sort === "prioridad" ? " selected" : ""}>Pendientes primero</option>
          <option value="usados"${sort === "usados" ? " selected" : ""}>Más usados</option>
          <option value="recientes"${sort === "recientes" ? " selected" : ""}>Más recientes</option>
          <option value="nombre"${sort === "nombre" ? " selected" : ""}>Nombre A–Z</option>
        </select></label>
      <span class="cp-cat-result">Mostrando <b>${items.length}</b> de <b>${base.length}</b></span>
      ${hasFilters ? `<button class="cp-mini" data-catclear>Limpiar filtros</button>` : ""}
    </div>
    ${cards ? `<div class="${tab === "proveedores" ? "cp-prov-grid cp-cat-grid" : "cp-cert-grid cp-cat-grid"}">${cards}</div>`
      : empty(items.length ? "Sin resultados con esos filtros" : (tab === "proveedores" ? "Aún no hay proveedores en esta área" : "Aún no hay productos en esta área"),
        hasFilters ? "Cambia el estado o el área para ver otros registros." : `Usa “+ ${tab === "proveedores" ? "Proveedor" : "Producto"}” para dar de alta el primero.`)}`;
    hydrateMedia(box);
  }

  // Detalle del catálogo: se abre al tocar una tarjeta (producto o proveedor).
  function openCatalogoDetalle(kind, id) {
    const esProv = kind === "proveedor";
    const fuente = esProv ? (S.proveedores || []) : (S.certificados || []);
    const r = fuente.find(x => String(x.id) === String(id));
    if (!r) return toast("No se encontró el registro", "Actualiza el catálogo e intenta de nuevo.", "warning");
    const puede = canEditCatalog(r);
    const link = safeUrl(r.link);
    const img = r.imagen || "";
    const dato = (label, valor) => (valor || valor === 0)
      ? `<div><span>${esc(label)}</span><b>${esc(String(valor))}</b></div>` : "";
    const facts = esProv ? [
      dato("RFC", r.rfc || "Sin RFC"),
      dato("Razón social", r.razon_social && r.razon_social !== r.nombre ? r.razon_social : ""),
      dato("Contacto", r.contacto || "—"),
      dato("Correo", r.email || "—"),
      dato("Teléfono", r.telefono || "—"),
      dato("Domicilio", r.domicilio || "—"),
      dato("Condiciones de pago", r.condiciones_pago || ""),
      dato("Productos vinculados", qty(r.productos_count || 0)),
      dato("Compras / OC", qty(r.compras_count || 0)),
      dato("Comprado", money(r.total_comprado)),
      dato("Última compra", r.ultima_compra ? catalogDate(r.ultima_compra) : ""),
      dato("Alta", `${r.created_by || "—"} · ${fdate(r.created_at)}`),
    ].join("") : [
      dato("Unidad", r.unidad || "pza"),
      dato("ID fabricación", r.id_fabricacion || ""),
      dato("Categoría", r.categoria || ""),
      dato("Proveedor", r.proveedor_nombre || "Sin proveedor"),
      dato("Costo promedio", money(r.costo_promedio)),
      dato("Último costo", r.ultimo_costo != null ? money(r.ultimo_costo) : ""),
      dato("Última solicitud", r.ultimo_uso ? catalogDate(r.ultimo_uso, true) : "Todavía sin uso"),
      dato("Solicitudes", qty(r.usos || 0)),
      dato("Unidades pedidas", qty(r.unidades_solicitadas || 0)),
      dato("Alta", `${r.created_by || "—"} · ${fdate(r.created_at)}`),
    ].join("");
    showOverlay(`<div class="cp-veil" data-close></div>
      <div class="cp-modal cp-cat-modal" role="dialog" aria-label="Detalle de ${esc(r.nombre)}">
        <header class="cp-modal-head">
          <div>
            <span class="cp-kicker">${esProv ? "Proveedor del catálogo" : "Producto del catálogo"}</span>
            <h2>${esc(r.nombre)}</h2>
            <p>${esc(r.area || "Sin área")}${r.categoria ? ` · ${esc(r.categoria)}` : ""}</p>
          </div>
          <button class="cp-x" data-close aria-label="Cerrar">&times;</button>
        </header>
        <div class="cp-modal-body cp-cat-modal-body">
          <div class="cp-cat-detail-top">
            ${(img || link) ? `<div class="cp-cat-detail-media" data-cpmedia data-cpimg="${esc(img)}" data-cplink="${esc(link)}">${mediaPlaceholder()}</div>` : ""}
            <div class="cp-cat-detail-main">
              <div class="cp-cat-detail-badges">
                ${badgeCatalogo(r.calidad_estado)}
                ${r.activo ? `<span class="cp-chip cp-chip-ok">Activo</span>` : `<span class="cp-chip">Inactivo</span>`}
                ${esProv ? "" : `<span class="cp-chip">${esc(r.area || "Sin área")}</span>`}
              </div>
              ${r.descripcion ? `<p class="cp-cat-detail-desc">${nl2br(r.descripcion)}</p>` : ""}
              ${r.motivo ? `<p class="cp-cat-detail-desc"><b>Para qué se usa:</b> ${nl2br(r.motivo)}</p>` : ""}
              ${link ? `<div class="cp-cat-detail-link"><a class="cp-btn subtle" href="${esc(link)}" target="_blank" rel="noopener">Abrir enlace del producto</a><small>${esc(productLinkText(link))}</small></div>` : ""}
            </div>
          </div>
          <div class="cp-cat-detail-facts">${facts}</div>
          ${!esProv && r.requisitos_calidad ? `<div class="cp-cat-note"><b>Requisitos de Calidad</b><p>${nl2br(r.requisitos_calidad)}</p></div>` : ""}
          ${r.calidad_nota ? `<div class="cp-cat-note ${r.calidad_estado === "rechazado" ? "danger" : ""}"><b>Observación de Calidad</b><p>${nl2br(r.calidad_nota)}</p>${r.calidad_por ? `<small>por ${esc(r.calidad_por)}${r.calidad_at ? ` · ${fdt(r.calidad_at)}` : ""}</small>` : ""}</div>` : ""}
        </div>
        <footer class="cp-modal-foot">
          ${puede ? `<button class="cp-mini" data-catedit="${r.id}" data-kind="${esProv ? "proveedor" : "producto"}">Editar</button>` : ""}
          <button class="cp-btn ghost" data-close>Cerrar</button>
        </footer>
      </div>`);
    hydrateMedia($(".cp-cat-modal", S.root) || S.root);
  }

  function certificadoForm(id = null) {
    if (!canCreateCatalog()) return toast("Sin área", "Tu cuenta no tiene un área asignada. Pide a administración que la capture.", "warning");
    const p = id ? (S.certificados || []).find(x => Number(x.id) === Number(id)) : null;
    if (id && !p) return toast("No se pudo abrir", "Vuelve a cargar la lista de productos.", "error");
    if (p && !canEditCatalog(p)) return toast("Sin permiso", "Este producto pertenece a otra área.", "warning");
    const identLocked = !!p && p.calidad_estado === "aprobado" && !isCatalogAdmin();
    const proveedores = (S.proveedores || []).filter(x =>
      x.activo && (isCatalogAdmin() || x.calidad_estado === "aprobado") &&
      (isCatalogAdmin() || String(x.area || "") === String(p?.area || myArea())));
    if (p?.proveedor_id && !proveedores.some(x => Number(x.id) === Number(p.proveedor_id))) {
      const actual = (S.proveedores || []).find(x => Number(x.id) === Number(p.proveedor_id));
      if (actual) proveedores.push(actual);
    }
    const provOpts = `<option value="">— Sin proveedor vinculado —</option>` + proveedores.map(x =>
      `<option value="${x.id}"${Number(p?.proveedor_id) === Number(x.id) ? " selected" : ""}>${esc(x.nombre)}${x.area ? ` · ${esc(x.area)}` : ""}</option>`).join("");
    const cats = [...new Set((S.certificados || []).map(x => x.categoria).filter(Boolean))].sort((a, b) => a.localeCompare(b, "es"));
    showOverlay(`<div class="cp-veil"></div>
      <div class="cp-modal cp-cert-modal" role="dialog" aria-label="Producto del catálogo">
        <header class="cp-modal-head"><div><span class="cp-kicker">${p ? "Editar" : "Nuevo"} · Catálogo</span><h2>Producto</h2>
          <p>${isCatalogAdmin()
            ? "Si lo dejas en <b>pendiente</b>, Calidad deberá autorizarlo. Los productos de compras normales se guardan aprobados."
            : "El producto se guarda <b>aprobado</b> de inmediato. Solo los productos enviados a revisión de Calidad quedan pendientes."}</p></div>
          <button class="cp-x" data-close aria-label="Cerrar">&times;</button></header>
        <form id="cpCertForm" class="cp-modal-body" autocomplete="off">
          <div class="cp-formgrid">
            ${areaField(p)}
            ${estadoField(p)}
            <label class="cp-f"><span>Categoría</span><input id="cpCertCategoria" list="cpCertCats" maxlength="80" value="${esc(p?.categoria || "")}" placeholder="Ej. Empaque, limpieza, refacciones…"></label>
            <datalist id="cpCertCats">${cats.map(c => `<option value="${esc(c)}"></option>`).join("")}</datalist>
            <label class="cp-f span2"><span>Nombre del producto <b class="cp-req">*</b></span><input id="cpCertNombre" minlength="3" maxlength="180" value="${esc(p?.nombre || "")}" placeholder="Ej. Bolsa kraft de 250 g" required ${identLocked ? "readonly aria-readonly=true" : ""}></label>
            <label class="cp-f"><span>Unidad</span><input id="cpCertUnidad" maxlength="20" minlength="1" value="${esc(p?.unidad || "pza")}" placeholder="pza, kg, litro…" ${identLocked ? "readonly aria-readonly=true" : ""}></label>
            <label class="cp-f"><span>ID de fabricación</span><input id="cpCertFabricacion" maxlength="120" value="${esc(p?.id_fabricacion || "")}" placeholder="Código interno" ${identLocked ? "readonly aria-readonly=true" : ""}></label>
            <label class="cp-f span2"><span>Proveedor vinculado <small>(opcional, debe estar aprobado)</small></span><select id="cpCertProveedor">${provOpts}</select></label>
            <label class="cp-f span2"><span>Descripción <small>(opcional)</small></span><textarea id="cpCertDescripcion" rows="2" maxlength="1000" placeholder="Medidas, material, presentación…">${esc(p?.descripcion || "")}</textarea></label>
            <label class="cp-f span2"><span>Requisitos de Calidad <small>(opcional)</small></span><textarea id="cpCertRequisitos" rows="3" maxlength="1000" placeholder="Norma, certificados, tolerancias, empaque…" ${identLocked ? "readonly aria-readonly=true" : ""}>${esc(p?.requisitos_calidad || "")}</textarea></label>
            ${p ? `<label class="cp-f span2 cp-check"><input type="checkbox" id="cpCertActivo"${p.activo ? " checked" : ""}> Producto activo (disponible al solicitar)</label>` : ""}
          </div>
          ${identLocked ? `<p class="cp-guide sm"><b>Identidad bloqueada:</b> el producto ya fue aprobado. Pide a Calidad o administración que modifique nombre, unidad, ID o requisitos.</p>` : ""}
          <p class="cp-ferrbox" id="cpCertErr" hidden></p>
        </form>
        <footer class="cp-modal-foot"><button class="cp-btn ghost" data-close>Cancelar</button><button class="cp-btn primary" id="cpCertSave" form="cpCertForm" type="submit">${p ? "Guardar cambios ✓" : "Guardar producto ✓"}</button></footer>
      </div>`);
    const form = $("#cpCertForm", S.root);
    form.addEventListener("submit", async e => {
      e.preventDefault();
      const err = $("#cpCertErr", form);
      const nombre = $("#cpCertNombre", form).value.trim();
      const unidad = $("#cpCertUnidad", form).value.trim() || "pza";
      const idFab = $("#cpCertFabricacion", form).value.trim();
      const requisitos = $("#cpCertRequisitos", form).value.trim();
      if (nombre.length < 3) { err.textContent = "El nombre debe tener al menos 3 caracteres."; err.hidden = false; return; }
      if (nombre.length > 180) { err.textContent = "El nombre no puede exceder 180 caracteres."; err.hidden = false; return; }
      if (unidad.length < 1 || unidad.length > 20) { err.textContent = "La unidad debe tener entre 1 y 20 caracteres."; err.hidden = false; return; }
      err.hidden = true;
      const btn = $("#cpCertSave", S.root);
      btn.disabled = true;
      try {
        const body = {
          nombre,
          categoria: $("#cpCertCategoria", form).value.trim(),
          unidad,
          id_fabricacion: idFab,
          descripcion: $("#cpCertDescripcion", form).value.trim(),
          requisitos_calidad: requisitos,
          proveedor_id: $("#cpCertProveedor", form).value || null,
        };
        const areaInput = $("#cpCatArea", S.root);
        if (areaInput) body.area = areaInput.value.trim();
        if (!body.area && isCatalogAdmin()) throw new Error("Selecciona el área dueña del producto.");
        if (p) body.activo = $("#cpCertActivo", form).checked;
        if (isCatalogAdmin()) {
          body.calidad_estado = $("#cpCatEstado", S.root)?.value || "pendiente";
          body.calidad_nota = $("#cpCatNota", S.root)?.value.trim() || "";
        }
        await api("/api/compras/productos-certificados" + (p ? "/" + p.id : ""), {
          method: p ? "PATCH" : "POST", body: JSON.stringify(body),
        });
        hideOverlay();
        if (S.view === "catalogo") S.catalogTab = "productos";
        await refresh(true);
        toast("Catálogo de productos", p ? "Los cambios se guardaron."
          : "Producto guardado en el catálogo.", "success");
      } catch (ex) {
        err.textContent = ex.message || "No se pudo guardar el producto.";
        err.hidden = false;
      } finally { btn.disabled = false; }
    });
    setTimeout(() => $("#cpCertNombre", form)?.focus(), 40);
  }

  async function catalogQuality(kind, id, accion) {
    const esProv = kind === "proveedor";
    const source = esProv ? S.proveedores : S.certificados;
    const rec = (source || []).find(x => String(x.id) === String(id));
    if (!rec) return toast("No se encontró el registro", "Actualiza el catálogo e inténtalo de nuevo.", "error");
    const aprobar = accion === "aprobar";
    const motivos = aprobar
      ? ["Cumple los requisitos documentales.", "Muestra aprobada y vigente."]
      : ["Falta documentación o certificado vigente.", "No cumple las especificaciones solicitadas.", "Los datos fiscales o de contacto están incompletos."];
    showOverlay(`<div class="cp-veil" data-close></div>
      <div class="cp-modal cp-catqa-modal" role="dialog" aria-label="${aprobar ? "Aprobar" : "Rechazar"} registro del catálogo">
        <header class="cp-modal-head"><div><span class="cp-kicker">Revisión de Calidad</span>
          <h2>${aprobar ? "Aprobar" : "Rechazar"} ${esProv ? "proveedor" : "producto"}</h2>
          <p>${esc(rec.nombre)} · Área ${esc(rec.area || "Global")}. ${aprobar
            ? "Al aprobarlo podrá usarse en solicitudes de compra del área."
            : "Explica qué debe corregir el área antes de volver a enviarlo."}</p></div>
          <button class="cp-x" data-close aria-label="Cerrar">&times;</button></header>
        <form id="cpCatQAForm" class="cp-modal-body" autocomplete="off">
          <div class="cp-catqa-summary">
            <div><span>Estado actual</span>${badgeCatalogo(rec.calidad_estado)}</div>
            <div><span>Área</span><b>${esc(rec.area || "Global")}</b></div>
            <div><span>${esProv ? "RFC" : "Unidad"}</span><b>${esc(esProv ? (rec.rfc || "—") : (rec.unidad || "pza"))}</b></div>
            <div><span>Alta</span><b>${esc(rec.created_by || "—")} · ${fdate(rec.created_at)}</b></div>
          </div>
          <div class="cp-catqa-reasons">${motivos.map(m => `<button type="button" class="cp-chip cp-catqa-reason" data-catqareason="${esc(m)}">${esc(m)}</button>`).join("")}</div>
          <label class="cp-f"><span>Observación para el área ${aprobar ? "<small>(opcional)</small>" : `<b class="cp-req">*</b>`}</span>
            <textarea id="cpCatQANota" rows="4" maxlength="1000" placeholder="${aprobar ? "Condiciones, vigencia o nota de aprobación…" : "Describe claramente qué falta o debe corregirse…"}"></textarea></label>
          <p class="cp-ferrbox" id="cpCatQAErr" hidden></p>
        </form>
        <footer class="cp-modal-foot"><button class="cp-btn ghost" data-close>Cancelar</button>
          <button class="cp-btn ${aprobar ? "ok" : "danger"}" id="cpCatQASave" form="cpCatQAForm" type="submit">${aprobar ? "Aprobar registro" : "Rechazar registro"}</button></footer>
      </div>`);
    const form = $("#cpCatQAForm", S.root);
    $$("[data-catqareason]", form).forEach(btn => btn.addEventListener("click", () => {
      const ta = $("#cpCatQANota", form);
      ta.value = btn.dataset.catqareason;
      ta.focus();
    }));
    form.addEventListener("submit", async e => {
      e.preventDefault();
      const nota = $("#cpCatQANota", form).value.trim();
      const err = $("#cpCatQAErr", form);
      if (!aprobar && !nota) {
        err.textContent = "Escribe el motivo del rechazo para que el área pueda corregirlo.";
        err.hidden = false;
        return;
      }
      err.hidden = true;
      const btn = $("#cpCatQASave", S.root);
      btn.disabled = true;
      try {
        const base = esProv ? "/api/compras/proveedores/" : "/api/compras/productos-certificados/";
        await api(base + id + "/calidad", { method: "POST", body: JSON.stringify({ accion, nota }) });
        hideOverlay();
        toast("Calidad", aprobar ? "Registro aprobado y disponible para compras." : "Registro rechazado; el área ya puede corregirlo.", "success");
        await refresh(true);
      } catch (ex) {
        err.textContent = ex.message || "No se pudo actualizar el registro.";
        err.hidden = false;
        btn.disabled = false;
      }
    });
    setTimeout(() => $("#cpCatQANota", form)?.focus(), 50);
  }

  async function catalogToggle(kind, id) {
    const esProv = kind === "proveedor";
    if (!confirm(`¿Desactivar este ${esProv ? "proveedor" : "producto"}? Ya no podrá usarse en solicitudes nuevas.`)) return;
    const base = esProv ? "/api/compras/proveedores/" : "/api/compras/productos-certificados/";
    try {
      await api(base + id, { method: "DELETE" });
      toast("Catálogo", "Registro desactivado.", "success");
      await refresh(true);
    } catch (e) { toast("No se pudo desactivar", e.message, "error"); }
  }

  function renderInventario(box) {
    const items = S.invItems || [];
    const admin = isInvAdmin();
    const catFilter = S.invCat || "";
    const areaFilter = S.invArea || "";
    const low = !!S.invLow;
    const cats = [...new Set(items.map(x => x.categoria).filter(Boolean))].sort((a, b) => a.localeCompare(b, "es"));
    const areas = [...new Set(items.map(x => x.area).filter(Boolean))].sort((a, b) => a.localeCompare(b, "es"));
    const shown = items.filter(x => {
      if (catFilter && String(x.categoria || "") !== catFilter) return false;
      if (areaFilter && String(x.area || "") !== areaFilter) return false;
      if (low && !x.bajo_stock) return false;
      return true;
    });
    const agotados = items.filter(x => x.agotado).length;
    const bajos = items.filter(x => x.bajo_stock && !x.agotado).length;
    const valor = items.reduce((a, x) => a + (Number(x.valor) || 0), 0);
    const ico = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>`;
    const card = (it) => {
      const puede = canEditInv(it);
      const tone = it.agotado ? " out" : it.bajo_stock ? " low" : "";
      const estado = it.agotado ? `<span class="cp-badge danger">Agotado</span>`
        : it.bajo_stock ? `<span class="cp-badge warn">Bajo mínimo</span>`
        : `<span class="cp-badge ok">Disponible</span>`;
      const extras = (it.areas_extra || []).filter(a => a !== it.area);
      return `<article class="cp-inv-card${tone}" data-invcard="${it.id}">
        <div class="cp-inv-card-head">
          <span class="cp-inv-ico">${ico}</span>
          <div class="cp-inv-card-title"><b>${esc(it.nombre)}</b>
            <small>${esc(it.categoria || "Sin categoría")} · ${esc(it.area || "Sin área")}</small></div>
          ${estado}
        </div>
        <div class="cp-inv-figures"><b>${qty(it.cantidad)}</b><span>${esc(it.unidad || "pza")}</span>
          <small>mín. ${qty(it.minimo)}</small></div>
        ${it.descripcion ? `<p class="cp-inv-desc">${nl2br(it.descripcion)}</p>` : ""}
        <div class="cp-inv-chips">
          ${it.ubicacion ? `<span class="cp-chip">${esc(it.ubicacion)}</span>` : ""}
          ${it.lote ? `<span class="cp-chip">Lote ${esc(it.lote)}</span>` : ""}
          ${it.caducidad ? `<span class="cp-chip">Cad. ${fdate(it.caducidad)}</span>` : ""}
          ${extras.map(a => `<span class="cp-chip cp-inv-involved">${esc(a)}</span>`).join("")}
        </div>
        <div class="cp-inv-meta">
          <span><b>Costo unitario</b>${money(it.costo_unitario)}</span>
          <span><b>Valor</b>${money(it.valor)}</span>
          <span><b>Proveedor</b>${esc(it.proveedor || "—")}</span>
          <span><b>Actualizado</b>${fdt(it.updated_at || it.created_at)}</span>
        </div>
        ${it.notas ? `<p class="cp-inv-desc">${nl2br(it.notas)}</p>` : ""}
        <div class="cp-inv-foot">
          <span>${it.updated_by ? `por <b>${esc(it.updated_by)}</b>` : "Sin movimientos"}</span>
          <div class="cp-inv-actions">
            ${puede ? `<button class="cp-mini" data-invedit="${it.id}">Editar</button>
              <button class="cp-mini danger" data-invdel="${it.id}">Eliminar</button>` : `<span class="cp-inv-readonly">Solo lectura</span>`}
          </div>
        </div>
      </article>`;
    };
    const hasFilters = !!(catFilter || areaFilter || low);
    box.innerHTML = `<div class="cp-inv-head">
      <div><h3>Inventario por área</h3>
        <p>${admin ? "Consulta y administra el inventario de todas las áreas. Las áreas involucradas solo pueden consultar."
          : `Artículos de <b>${esc(myArea() || "tu área")}</b> y de las áreas donde te involucraron. Solo el área dueña puede editar.`}</p></div>
      <div class="cp-inv-tools">
        <select class="cp-select cp-inv-select" data-invfilter="categoria" aria-label="Filtrar por categoría">
          <option value="">Todas las categorías</option>
          ${cats.map(c => `<option value="${esc(c)}"${catFilter === c ? " selected" : ""}>${esc(c)}</option>`).join("")}
        </select>
        ${admin && areas.length > 1 ? `<select class="cp-select cp-inv-select" data-invfilter="area" aria-label="Filtrar por área">
          <option value="">Todas las áreas</option>
          ${areas.map(a => `<option value="${esc(a)}"${areaFilter === a ? " selected" : ""}>${esc(a)}</option>`).join("")}
        </select>` : ""}
        <label class="cp-inv-lowtoggle"><input type="checkbox" data-invfilter="bajo"${low ? " checked" : ""}> Solo bajo mínimo</label>
        ${hasFilters ? `<button class="cp-mini" data-invclear>Limpiar</button>` : ""}
        ${canCreateInv() ? `<button class="cp-btn primary" data-invnew>+ Artículo</button>` : ""}
      </div>
    </div>
    <div class="cp-inv-kpis">
      <div class="cp-inv-kpi"><b>${items.length}</b><span>Artículos</span></div>
      <div class="cp-inv-kpi warn"><b>${bajos + agotados}</b><span>Bajo mínimo</span></div>
      <div class="cp-inv-kpi"><b>${agotados}</b><span>Agotados</span></div>
      <div class="cp-inv-kpi"><b>${money(valor)}</b><span>Valor estimado</span></div>
    </div>
    ${shown.length ? `<div class="cp-inv-grid">${shown.map(card).join("")}</div>`
      : empty(hasFilters ? "Sin resultados con esos filtros" : "Aún no hay artículos en el inventario",
        hasFilters ? "Cambia la categoría, el área o el filtro de mínimo." : `Usa “+ Artículo” para registrar el primero de ${esc(myArea() || "tu área")}.`)}`;
  }

  function inventoryForm(id = null) {
    if (!canCreateInv()) return toast("Sin área", "Tu cuenta no tiene un área asignada. Pide a administración que la capture.", "warning");
    const item = id ? (S.invItems || []).find(x => String(x.id) === String(id)) : null;
    if (id && !item) return toast("No se encontró", "Actualiza el inventario e inténtalo de nuevo.", "error");
    if (item && !canEditInv(item)) return toast("Sin permiso", "Este artículo pertenece a otra área.", "warning");
    const admin = isInvAdmin();
    const area = item?.area || (admin ? (S.invArea || myArea() || "") : myArea());
    const cats = [...new Set((S.invItems || []).map(x => x.categoria).filter(Boolean))].sort((a, b) => a.localeCompare(b, "es"));
    const areas = [...new Set([...AREAS_CATALOGO, ...(S.invItems || []).map(x => x.area), area].filter(Boolean))].sort((a, b) => a.localeCompare(b, "es"));
    const extras = new Set(item?.areas_extra || []);
    const areaField = admin
      ? `<label class="cp-f"><span>Área dueña <b class="cp-req">*</b></span><select id="cpInvArea" required>
          <option value="">Selecciona…</option>${areas.map(a => `<option value="${esc(a)}"${area === a ? " selected" : ""}>${esc(a)}</option>`).join("")}</select></label>`
      : `<label class="cp-f"><span>Área dueña</span><input value="${esc(area)}" readonly aria-readonly="true"></label>`;
    showOverlay(`<div class="cp-veil" data-close></div>
      <div class="cp-modal cp-inv-modal" role="dialog" aria-label="${item ? "Editar" : "Nuevo"} artículo de inventario">
        <header class="cp-modal-head"><div><span class="cp-kicker">${item ? "Editar" : "Nuevo"} · Inventario</span>
          <h2>Artículo</h2><p>El área dueña puede editarlo. Las áreas involucradas solo podrán consultarlo.</p></div>
          <button class="cp-x" data-close aria-label="Cerrar">&times;</button></header>
        <form id="cpInvForm" class="cp-modal-body" autocomplete="off">
          <div class="cp-formgrid">
            ${areaField}
            <label class="cp-f"><span>Categoría</span><input id="cpInvCat" list="cpInvCats" maxlength="80" value="${esc(item?.categoria || "")}" placeholder="Ej. Empaque, limpieza, refacciones…"></label>
            <datalist id="cpInvCats">${cats.map(c => `<option value="${esc(c)}"></option>`).join("")}</datalist>
            <label class="cp-f span2"><span>Nombre del artículo <b class="cp-req">*</b></span><input id="cpInvNombre" minlength="2" maxlength="160" value="${esc(item?.nombre || "")}" placeholder="Ej. Bolsa kraft 250 g" required></label>
            <label class="cp-f"><span>Cantidad actual</span><input id="cpInvCantidad" type="number" min="0" step="0.001" value="${item ? Number(item.cantidad) || 0 : "0"}"></label>
            <label class="cp-f"><span>Unidad</span><input id="cpInvUnidad" maxlength="20" value="${esc(item?.unidad || "pza")}" placeholder="pza, kg, litro…"></label>
            <label class="cp-f"><span>Mínimo</span><input id="cpInvMinimo" type="number" min="0" step="0.001" value="${item ? Number(item.minimo) || 0 : "0"}"></label>
            <label class="cp-f"><span>Costo unitario</span><input id="cpInvCosto" type="number" min="0" step="0.01" value="${item ? Number(item.costo_unitario) || 0 : "0"}"></label>
            <label class="cp-f"><span>Ubicación</span><input id="cpInvUbicacion" maxlength="120" value="${esc(item?.ubicacion || "")}" placeholder="Estante, almacén, pasillo…"></label>
            <label class="cp-f"><span>Lote</span><input id="cpInvLote" maxlength="80" value="${esc(item?.lote || "")}" placeholder="Lote o identificación"></label>
            <label class="cp-f"><span>Caducidad</span><input id="cpInvCaducidad" type="date" value="${esc(item?.caducidad || "")}"></label>
            <label class="cp-f"><span>Proveedor</span><input id="cpInvProveedor" maxlength="160" value="${esc(item?.proveedor || "")}" placeholder="Proveedor habitual"></label>
            <label class="cp-f span2"><span>Descripción</span><textarea id="cpInvDescripcion" rows="2" maxlength="1000" placeholder="Presentación, medidas, material…">${esc(item?.descripcion || "")}</textarea></label>
            <div class="cp-f span2"><span>Áreas involucradas <small>(solo consulta)</small></span>
              <div class="cp-inv-areas">${areas.filter(a => a !== area).map(a => `<label><input type="checkbox" data-invextra value="${esc(a)}"${extras.has(a) ? " checked" : ""}> ${esc(a)}</label>`).join("")}</div></div>
            <label class="cp-f span2"><span>Notas</span><textarea id="cpInvNotas" rows="2" maxlength="1000" placeholder="Observaciones del inventario…">${esc(item?.notas || "")}</textarea></label>
          </div>
          <p class="cp-ferrbox" id="cpInvErr" hidden></p>
        </form>
        <footer class="cp-modal-foot"><button class="cp-btn ghost" data-close>Cancelar</button>
          <button class="cp-btn primary" id="cpInvSave" form="cpInvForm" type="submit">${item ? "Guardar cambios ✓" : "Registrar artículo ✓"}</button></footer>
      </div>`);
    const form = $("#cpInvForm", S.root);
    form.addEventListener("submit", async e => {
      e.preventDefault();
      const err = $("#cpInvErr", form);
      const nombre = $("#cpInvNombre", form).value.trim();
      const areaSel = $("#cpInvArea", form);
      const areaVal = admin ? (areaSel?.value || "").trim() : area;
      if (nombre.length < 2) { err.textContent = "El nombre debe tener al menos 2 caracteres."; err.hidden = false; return; }
      if (!areaVal) { err.textContent = "Selecciona el área dueña del artículo."; err.hidden = false; return; }
      const body = {
        area: areaVal,
        nombre,
        categoria: $("#cpInvCat", form).value.trim(),
        cantidad: Number($("#cpInvCantidad", form).value) || 0,
        unidad: $("#cpInvUnidad", form).value.trim() || "pza",
        minimo: Number($("#cpInvMinimo", form).value) || 0,
        costo_unitario: Number($("#cpInvCosto", form).value) || 0,
        ubicacion: $("#cpInvUbicacion", form).value.trim(),
        lote: $("#cpInvLote", form).value.trim(),
        caducidad: $("#cpInvCaducidad", form).value || "",
        proveedor: $("#cpInvProveedor", form).value.trim(),
        descripcion: $("#cpInvDescripcion", form).value.trim(),
        notas: $("#cpInvNotas", form).value.trim(),
        areas_extra: $$("[data-invextra]", form).filter(x => x.checked).map(x => x.value),
      };
      if (body.cantidad < 0 || body.minimo < 0 || body.costo_unitario < 0) {
        err.textContent = "Cantidad, mínimo y costo no pueden ser negativos."; err.hidden = false; return;
      }
      err.hidden = true;
      const btn = $("#cpInvSave", S.root);
      btn.disabled = true;
      try {
        await api("/api/inventario" + (item ? "/" + item.id : ""), {
          method: item ? "PATCH" : "POST", body: JSON.stringify(body),
        });
        hideOverlay();
        await refresh(true);
        toast("Inventario", item ? "Artículo actualizado." : "Artículo registrado.", "success");
      } catch (ex) {
        err.textContent = ex.message || "No se pudo guardar el artículo.";
        err.hidden = false;
      } finally { btn.disabled = false; }
    });
    setTimeout(() => $("#cpInvNombre", form)?.focus(), 40);
  }

  async function deleteInventario(id) {
    const item = (S.invItems || []).find(x => String(x.id) === String(id));
    if (!item || !canEditInv(item)) return;
    if (!confirm(`¿Eliminar “${item.nombre}” del inventario de ${item.area || "el área"}? Esta acción no se puede deshacer.`)) return;
    try {
      await api("/api/inventario/" + id, { method: "DELETE" });
      toast("Inventario", "Artículo eliminado.", "success");
      await refresh(true);
    } catch (e) { toast("No se pudo eliminar", e.message, "error"); }
  }

  function renderList() {
    const box = $("#cpList", S.root);
    const isCatalog = S.view === "catalogo" || S.view === "certificados";
    const isInventory = S.view === "inventario";
    const kpis = $("#cpKpis", S.root);
    if (kpis) kpis.hidden = isCatalog || isInventory;
    const est = $("#cpEstado", S.root);
    if (est) est.hidden = isCatalog || isInventory;
    const search = $("#cpQ", S.root);
    if (search) search.placeholder = isCatalog
      ? "Buscar producto, proveedor, área…"
      : isInventory ? "Buscar artículo, categoría, lote, ubicación…" : "Buscar folio, producto, área…";
    if (isCatalog) return renderCatalogo(box);
    if (isInventory) return renderInventario(box);
    if (!S.list.length) {
      box.innerHTML = S.view === "solicitudes"
        ? empty("Todavía no hay solicitudes", viewAll() ? "Cuando alguien pida una compra aparecerá aquí." : "Usa “Nueva solicitud” para pedir un producto o material.")
        : S.view === "documentos" ? empty("Todavía no hay documentos", "Las requisiciones y órdenes de compra aparecerán aquí.")
          : S.view === "devoluciones" ? empty("Sin devoluciones", "Aquí se controlan los productos que llegan mal o incompletos.")
            : empty("Sin proveedores", "Agrega proveedores para generar órdenes de compra.");
      return;
    }
    if (S.view === "solicitudes") {
      box.innerHTML = S.list.map(s => {
        const docsHtml = (s.documentos || []).map(d => `<span class="cp-chip" title="${esc(d.folio)}">${esc(d.folio)}</span>`).join("");
        const hasMedia = !!(s.imagen || s.primer_link);
        const cambio = s.estado === "cambios_solicitados" && s.motivo_cambios
          ? `<div class="cp-card-change warn"><b>Se pidieron cambios</b><span>${esc(s.motivo_cambios).slice(0, 150)}${s.motivo_cambios.length > 150 ? "…" : ""}</span></div>`
          : s.estado === "rechazada" && s.motivo_rechazo
          ? `<div class="cp-card-change danger"><b>Rechazada: por qué</b><span>${esc(s.motivo_rechazo).slice(0, 150)}${s.motivo_rechazo.length > 150 ? "…" : ""}</span></div>` : "";
        return `<article class="cp-card cp-card--rediseño cp-card--${s.estado}" data-sol="${s.id}" tabindex="0" role="button" aria-label="Solicitud ${esc(s.folio)} · ${esc((EST_SOL[s.estado] || [s.estado])[0])}">
          <div class="cp-card-header">
            <div class="cp-card-folio-row">
              <span class="cp-folio">${esc(s.folio || "SOL")}</span>
              <div class="cp-badges-row">
                ${badge(EST_SOL, s.estado)}
                ${badge(PRIO, s.prioridad)}
              </div>
            </div>
            <div class="cp-card-meta-row">
              <span class="cp-fecha">${fdt(s.created_at)}</span>
              ${viewAll() ? `<span class="cp-solicitante">Solicita <b>${esc(s.username || "-")}</b> · ${esc(s.user_area || s.area || "Sin área")}</span>` : ""}
            </div>
          </div>
          <div class="cp-card-body">
            <div class="cp-card-main">
              <div class="cp-card-copy">
                <h3 class="cp-titulo">${esc(s.titulo)}</h3>
                ${s.justificacion ? `<p class="cp-justificacion">${esc(s.justificacion).slice(0, 190)}${s.justificacion.length > 190 ? "…" : ""}</p>` : ""}
              </div>
              ${hasMedia ? `<div class="cp-card-thumb" data-cpmedia data-cpimg="${esc(s.imagen || "")}" data-cplink="${esc(s.primer_link || "")}">${mediaPlaceholder()}</div>` : ""}
            </div>
            ${miniStepperHTML(s)}
            ${cambio}
            <div class="cp-card-stats">
              <span class="cp-stat"><b>${s.n_items || 0}</b> <span>producto(s)</span></span>
              <span class="cp-stat cp-stat--tipo">${esc((TIPO_COMPRA[s.tipo_compra || "normal"] || ["Compra normal"])[0])}</span>
              ${(s.flujo || "legado") === "nuevo" ? `<span class="cp-stat">${(s.tipo_compra || "normal") === "calidad" ? (s.calidad_estado === "aprobada" ? "Calidad aprobó" : s.requisicion_firmada ? "Pendiente de Calidad" : "Falta requisición firmada") : (s.requisicion_firmada ? "Requisición firmada" : "Falta requisición firmada")}</span>` : ""}
              ${s.gestor_por ? `<span class="cp-stat">En proceso por <b>${esc(s.gestor_por)}</b></span>` : ""}
              <span class="cp-stat cp-stat--total">Estimado <b>${money(s.total_estimado)}</b></span>
            </div>
            ${(s.documentos || []).length ? `<div class="cp-docs-row">${docsHtml}</div>` : ""}
          </div>
        </article>`;
      }).join("");
      hydrateMedia(box);
    } else if (S.view === "documentos") {
      box.innerHTML = S.list.map(d => {
        const firmados = (d.firmados || []);
        const vigentes = firmados.filter(f => f.vigente !== false && f.vigente !== 0);
        const firmadosHTML = firmados.length ? `<div class="cp-doc-signed">
          <div class="cp-doc-signed-head"><b>Documentos firmados por el usuario</b><span>${firmados.length}</span></div>
          ${firmados.map(f => `<div class="cp-doc-signed-row${f.vigente === false || f.vigente === 0 ? " off" : ""}">
            <span class="cp-doc-signed-ico">PDF</span>
            <div class="cp-doc-signed-txt">
              <b>${esc(firmadoLabel(f))}</b>
              <small>${esc(f.subido_por || "Usuario")} · ${fdt(f.created_at)}${f.vigente === false || f.vigente === 0 ? " · Reemplazado" : ""}</small>
            </div>
            <button type="button" class="cp-mini" data-firmopen="${esc(f.path || "")}" data-name="${esc(f.nombre || "documento.pdf")}">Ver PDF</button>
          </div>`).join("")}
        </div>` : "";
        return `<article class="cp-card" data-doc="${d.id}" tabindex="0" role="button" aria-label="Documento ${esc(d.folio)}">
        <div class="cp-card-top">
          <span class="cp-folio">${esc(d.folio || "—")}</span>
          ${badge(EST_DOC, d.estado)}
          <span class="cp-chip ${d.tipo}">${d.tipo === "requisicion" ? "Requisición" : "Orden de compra"}</span>
          <span class="cp-chip muted">Generada por la app</span>
          ${vigentes.length ? `<span class="cp-badge ok">Firmada</span>` : ""}
        </div>
        <h3>${esc(d.solicitud_titulo || "Documento de compra")}</h3>
        <p class="cp-meta">${d.proveedor_nombre ? `Proveedor <b>${esc(d.proveedor_nombre)}</b> · ` : ""}Solicitud ${esc(d.solicitud_folio || "")} · ${fdate(d.fecha)}</p>
        ${firmadosHTML}
        <div class="cp-card-foot">
          <span>Total <b>${money(d.total)}</b></span>
          <span>${esc(d.username || "")}</span>
        </div>
      </article>`;
      }).join("");
    } else if (S.view === "devoluciones") {
      box.innerHTML = S.list.map(d => `<article class="cp-card" data-dev="${d.id}" tabindex="0" role="button" aria-label="Devolución ${esc(d.folio)}">
        <div class="cp-card-top"><span class="cp-folio">${esc(d.folio || "DEV")}</span>${badge(EST_DEV, d.estado)}</div>
        <h3>${esc(d.solicitud_titulo || d.motivo || "Devolución")}</h3>
        <p class="cp-meta">${esc(d.documento_folio || "")} · ${esc(d.solicitud_folio || "")} · ${fdt(d.created_at)}</p>
        <p class="cp-desc">${esc(d.motivo || "").slice(0, 170)}</p>
        <div class="cp-card-foot"><span><b>${(d.items || []).length}</b> partida(s)</span><span>${esc(d.username || "")}</span></div>
      </article>`).join("");
    } else {
      box.innerHTML = `<div class="cp-prov-grid">${S.list.map(p => `<article class="cp-prov ${p.activo ? "" : "off"}" data-prov="${p.id}">
        <div class="cp-prov-top"><b>${esc(p.nombre)}</b><span class="cp-badge ${p.activo ? "ok" : "muted"}">${p.activo ? "Activo" : "Inactivo"}</span></div>
        <p>${p.rfc ? `RFC <b>${esc(p.rfc)}</b>` : "Sin RFC"}${p.contacto ? ` · ${esc(p.contacto)}` : ""}</p>
        <p class="cp-meta">${esc(p.email || "")}${p.telefono ? ` · ${esc(p.telefono)}` : ""}</p>
        <div class="cp-card-foot"><span>${esc(p.condiciones_pago || "Sin condiciones")}</span>${canManage() ? `<button class="cp-mini" data-editprov="${p.id}">Editar</button>` : ""}</div>
      </article>`).join("")}</div>`;
    }
  }

  async function loadList() {
    const modeAt = S.mode;
    const qs = new URLSearchParams();
    if (modeAt === "user") qs.set("mine", "1");
    if (S.estado) qs.set("estado", S.estado);
    if (S.calidad) qs.set("calidad", S.calidad);
    if (S.q) qs.set("q", S.q);
    if (S.view === "inventario") {
      if (S.invCat) qs.set("categoria", S.invCat);
      if (S.invArea) qs.set("area", S.invArea);
      if (S.invLow) qs.set("bajo", "1");
      const rows = await api("/api/inventario" + (qs.toString() ? "?" + qs.toString() : ""));
      if (S.mode !== modeAt) return;
      S.invItems = rows || [];
      S.list = S.invItems;
      renderList();
      return;
    }
    if (S.view === "catalogo" || S.view === "certificados") {
      const suffix = qs.toString() ? "?" + qs.toString() : "";
      const productos = await api("/api/compras/productos-certificados" + suffix);
      const proveedores = await api("/api/compras/proveedores" + suffix);
      if (S.mode !== modeAt) return;
      S.certificados = productos || [];
      S.proveedores = proveedores || [];
      S.list = S.catalogTab === "proveedores" ? S.proveedores : S.certificados;
      renderList();
      return;
    }
    let path = "/api/compras/solicitudes";
    if (S.view === "documentos") path = "/api/compras/documentos";
    else if (S.view === "devoluciones") path = "/api/compras/devoluciones";
    else if (S.view === "proveedores") path = "/api/compras/proveedores";
    const rows = await api(path + (qs.toString() ? "?" + qs.toString() : ""));
    if (S.mode !== modeAt) return;
    S.list = rows;
    renderList();
  }

  async function refresh(silent = false) {
    if (S.busy) return;
    S.busy = true;
    const modeAt = S.mode;
    try {
      // Secuencial a propósito: algunos antivirus/proxies locales devuelven 502
      // cuando se abren varias conexiones a la vez contra la red local.
      const summaryPath = "/api/compras/resumen" + (modeAt === "user" ? "?mine=1" : "");
      S.kpis = await api(summaryPath);
      if (S.mode !== modeAt) return;
      renderKpis();
      await loadList();
      if (S.mode !== modeAt) return;
      if (viewAll()) S.proveedores = (await api("/api/compras/proveedores")) || [];
      if (viewAll()) S.empresa = await api("/api/compras/empresa");
      renderFiscalWarn();
    } catch (e) {
      if (S.mode !== modeAt) return;
      if (!silent) toast("No se pudo cargar", e.message, "error");
      $("#cpList", S.root).innerHTML = empty("No se pudo cargar la información", e.message);
    } finally { S.busy = false; }
  }

  function showOverlay(html, cls = "") {
    const ov = $("#cpOverlay", S.root);
    ov.className = "cp-overlay " + cls;
    ov.innerHTML = html;
    applyPlaceholders(ov);
    updateMoveButtons(ov);
    ov.hidden = false;
    document.body.classList.add("cp-lock");
    // Auto-liberar si hay error crítico
    setTimeout(() => {
      if (ov.hidden && document.body.classList.contains("cp-lock")) {
        document.body.classList.remove("cp-lock");
      }
    }, 5000);
  }
  function hideOverlay() {
    const ov = $("#cpOverlay", S.root);
    if (!ov) return;
    ov.hidden = true;
    ov.innerHTML = "";
    ov.className = "cp-overlay";
    document.body.classList.remove("cp-lock");
    S.currentSol = S.currentDoc = null;
  }
  // Los modales con captura de datos solo se cierran con la X (o con sus
  // botones explícitos). Ni el clic en el velo ni Escape los cierran.
  function overlayHasFormModal() {
    const ov = $("#cpOverlay", S.root);
    return !!ov?.querySelector(".cp-modal input, .cp-modal select, .cp-modal textarea, .cp-modal form");
  }

  /* =====================  SOLICITUD: DETALLE  ===================== */
  function calidadPanel(s) {
    if (S.mode !== "quality" || (s.tipo_compra || "normal") !== "calidad") return "";
    if (s.estado !== "pendiente" && s.estado !== "en_revision") return "";
    if (["aprobada", "rechazada"].includes(s.calidad_estado)) return "";
    if (!s.requisicion_firmada) return `<div class="cp-alert warn"><b>Requisición pendiente de firma.</b><p>Cuando el solicitante suba la requisición firmada, podrás aprobar las opciones.</p></div>`;
    const rows = (s.items || []).map(it => {
      const ops = (it.opciones || []).map(o => {
        const optLink = safeUrl(o.link);
        const optImg = safeImg(o.imagen || "");
        return `<label class="cp-qopt">
        <input type="checkbox" data-qopt="${o.id}"${o.calidad_aprobada ? " checked" : ""}>
        <span class="cp-prodthumb cp-optthumb${optImg || optLink ? "" : " empty"}" data-cpmedia data-cpimg="${esc(optImg)}" data-cplink="${esc(optLink)}">${mediaPlaceholder()}</span>
        <span><b>${esc(o.etiqueta || "Opción")}</b>
          ${o.diferencia ? `<small>${esc(o.diferencia)}</small>` : ""}
          <small>${o.proveedor ? esc(o.proveedor) + " · " : ""}${money(o.costo_unitario)}${o.precio_incluye_iva ? " IVA incluido" : " + IVA"}</small>
          ${optLink ? productLinkHTML(optLink, o.etiqueta) : ""}
        </span>
      </label>`;
      }).join("");
      return `<div class="cp-qitem"><div class="cp-qhead"><b>${esc(it.nombre)}</b><span>${qty(it.cantidad)} ${esc(it.unidad)}</span></div>
        ${it.descripcion ? `<p class="cp-muted">${esc(it.descripcion)}</p>` : ""}
        ${it.motivo ? `<p class="cp-muted"><b>Para qué:</b> ${esc(it.motivo)}</p>` : ""}
        ${it.requisitos_calidad ? `<p class="cp-qreq"><b>Requisitos de Calidad:</b> ${nl2br(it.requisitos_calidad)}</p>` : ""}
        <div class="cp-qopts">${ops || `<p class="cp-muted">Este producto no tiene opciones capturadas.</p>`}</div></div>`;
    }).join("");
    return `<section class="cp-sec cp-qualitybox">
      <div class="cp-chat-head"><h3>Revisión de Calidad</h3>${badge({ pendiente: ["Pendiente", "warn"], en_revision: ["En revisión", "info"], aprobada: ["Aprobada", "ok"], rechazada: ["Rechazada", "danger"] }, s.calidad_estado)}</div>
      <p class="cp-muted">Marca una o varias opciones por producto. Después, Compras solo podrá elegir las opciones aprobadas.</p>
      ${rows}
      ${s.calidad_nota ? `<div class="cp-alert info"><b>Observación de Calidad</b><p>${nl2br(s.calidad_nota)}</p></div>` : ""}
      <div class="cp-qactions">
        <button class="cp-btn primary" data-qact="aprobar" data-id="${s.id}">Aprobar opciones seleccionadas</button>
        <button class="cp-btn" data-qact="solicitar_cambios" data-id="${s.id}">Pedir cambios</button>
        <button class="cp-btn danger" data-qact="rechazar" data-id="${s.id}">Rechazar compra</button>
      </div>
    </section>`;
  }

  function signAlertHTML(s) {
    if ((s.flujo || "legado") !== "nuevo" || S.mode !== "user") return "";
    const estado = s.estado || "";
    const firmados = s.firmados || [];
    const reqFirmada = !!s.requisicion_firmada;
    const ocUserFirmada = !!s.orden_compra_firmada;
    const oc = (s.documentos || []).find(d => d.tipo === "orden_compra");
    const reqInvalida = firmados.some(f => f.tipo === "requisicion_firmada" &&
      (f.vigente === false || f.vigente === 0));
    const editada = (s.eventos || []).some(e => ["editada", "reenviada"].includes(e.tipo));
    if (!reqFirmada && ["pendiente", "en_revision", "cambios_solicitados"].includes(estado)) {
      const titulo = reqInvalida || editada
        ? "La requisición anterior ya no es válida: fírmala de nuevo"
        : "Falta firmar la requisición";
      const desc = reqInvalida || editada
        ? "Tu solicitud cambió. Descarga la requisición actualizada, fírmala con el jefe de área y súbela de nuevo antes de que Compras continúe."
        : "Descarga la requisición, fírmala con el jefe de área y súbela para que Compras pueda revisar tu solicitud.";
      return `<div class="cp-alert warn cp-signalert" data-signalert="req">
        <b>${esc(titulo)}</b>
        <p>${desc}</p>
        ${s.motivo_cambios ? `<p><b>Cambios solicitados:</b> ${nl2br(s.motivo_cambios)}</p>` : ""}
        <button class="cp-btn primary" data-guide-action="Firmados" data-sol="${s.id}">Ir a firmar la requisición</button>
      </div>`;
    }
    if (oc && !ocUserFirmada && !s.cambios_oc_motivo && ["aprobada", "en_compra", "recibida", "con_incidencias", "devuelta"].includes(estado)) {
      return `<div class="cp-alert warn cp-signalert" data-signalert="oc">
        <b>Falta firmar la orden de compra</b>
        <p>Descarga la OC ${esc(oc.folio || "")}, recaba la firma del jefe de área y súbela. Compras completará después las firmas de Sandra, Lucío y el documento final.</p>
        <div class="cp-signalert-actions">
          <button class="cp-btn primary" data-guide-action="Firmados" data-sol="${s.id}">Ir a firmar la OC</button>
          ${S.mode === "user" && !s.cambios_oc_motivo ? `<button class="cp-btn ghost" data-solact="solicitar_cambios_oc" data-id="${s.id}">Solicitar cambios en la OC</button>` : ""}
        </div>
      </div>`;
    }
    return "";
  }

  function checklistHTML(s) {
    const esNuevo = (s.flujo || "legado") === "nuevo";
    const docs = s.documentos || [];
    const reqDoc = docs.find(d => d.tipo === "requisicion");
    const oc = docs.find(d => d.tipo === "orden_compra");
    const reqFirmada = !!s.requisicion_firmada;
    const ocUserFirmada = !!s.orden_compra_firmada;
    const ocFinalFirmada = !!s.orden_compra_firmada_final;
    const recibida = (s.recepciones || []).length > 0;
    const cerrada = s.estado === "cerrada";
    const items = [];
    if (esNuevo) {
      items.push(["Requisición generada", !!reqDoc]);
      items.push(["Requisición firmada", reqFirmada]);
      if ((s.tipo_compra || "normal") === "calidad") {
        items.push(["Opciones aprobadas por Calidad", s.calidad_estado === "aprobada"]);
      }
      items.push(["Orden de compra generada", !!oc]);
      ocFirmaDefs(s).forEach(([tipo, label]) => items.push([label, ocFirmaVigente(s, tipo)]));
      items.push(["Documento final con todas las firmas", ocFinalFirmada]);
    } else {
      items.push(["Documentos generados", docs.length > 0]);
      items.push(["Documentos firmados", reqFirmada || ocUserFirmada || ocFinalFirmada]);
    }
    items.push(["Recepción registrada", recibida]);
    items.push(["Compra cerrada", cerrada]);
    const done = items.filter(x => x[1]).length;
    const pct = Math.round((done / Math.max(1, items.length)) * 100);
    const row = ([label, ok]) => `<li class="${ok ? "done" : "pending"}">
        <span class="cp-check-ico" aria-hidden="true">${ok ? "✓" : "•"}</span>
        <span>${esc(label)}</span>
        <em>${ok ? "Listo" : "Pendiente"}</em>
      </li>`;
    const completados = items.filter(x => x[1]);
    const pendientes = items.filter(x => !x[1]);
    return `<section class="cp-sec cp-checklist">
      <div class="cp-checklist-head"><h3>Lista de control</h3><span>${done} de ${items.length} completados</span></div>
      <div class="cp-checklist-bar" role="progressbar" aria-label="Lista de control"
        aria-valuemin="0" aria-valuemax="${items.length}" aria-valuenow="${done}"
        aria-valuetext="${done} de ${items.length} completados"><i style="width:${pct}%"></i></div>
      ${completados.length ? `<details class="cp-check-done"${pendientes.length ? "" : " open"}>
        <summary>
          <span class="cp-check-ico" aria-hidden="true">✓</span>
          <span>${completados.length} ${completados.length === 1 ? "paso completado" : "pasos completados"}</span>
          <em>Ver</em>
        </summary>
        <ul>${completados.map(row).join("")}</ul>
      </details>` : ""}
      ${pendientes.length ? `<ul class="cp-check-pending">${pendientes.map(row).join("")}</ul>` : ""}
    </section>`;
  }

  // Aviso sutil cuando el rail no cabe (pantallas muy bajas): se puede
  // desplazar con la rueda sin mostrar una barra de scroll.
  function syncRailScroll() {
    const rail = document.querySelector(".cp-sol-layout .cp-rail");
    if (!rail) return;
    rail.classList.toggle("cp-rail-scroll", rail.scrollHeight > rail.clientHeight + 2);
  }

  function focusFirmados(alertOnly = false) {
    const firmasTab = document.querySelector('.cp-sol-layout [data-rail-tab="firmas"]');
    if (firmasTab && !firmasTab.classList.contains("on")) firmasTab.click();
    const alert = document.querySelector(".cp-sol-layout .cp-signalert") || document.querySelector(".cp-signalert");
    const sec = document.querySelector(".cp-sol-layout .cp-firmados") || document.querySelector(".cp-firmados");
    const rail = document.querySelector(".cp-sol-layout .cp-rail");
    const target = alertOnly && alert ? alert : (sec || rail);
    if (!target) return;
    target.scrollIntoView({ behavior: "smooth", block: "center" });
    [alert, sec].filter(Boolean).forEach(el => {
      el.classList.add("cp-flash");
      setTimeout(() => el.classList.remove("cp-flash"), 1800);
    });
  }

  // Lleva al documento correcto y hace evidente que hay que pulsar «Ver PDF».
  function traceResumenHTML(s) {
    const docs = s.documentos || [];
    const oc = docs.find(d => d.tipo === "orden_compra");
    const req = docs.find(d => d.tipo === "requisicion");
    const totalFirmas = oc ? ocFirmaDefs(s).length + 1 : 0;
    const firmasListas = oc
      ? ocFirmaDefs(s).filter(([t]) => ocFirmaVigente(s, t)).length + (ocFirmaVigente(s, OC_FINAL[0]) ? 1 : 0)
      : 0;
    const ultimo = (s.eventos || [])[0];
    const entrega = oc?.fecha_entrega ? fdate(oc.fecha_entrega) : "";
    const pendientes = oc && firmasListas < totalFirmas;
    return `<div class="cp-trace-summary">
      <div class="cp-trace-grid">
        <div><span>Estado</span><b>${badge(EST_SOL, s.estado)}</b></div>
        <div><span>Etapa actual</span><b>${esc(ETAPA[s.etapa_actual] || "Solicitud recibida")}</b></div>
        <div><span>Requisición</span><b>${req ? esc(req.folio || "Generada") : "Pendiente"}</b></div>
        <div><span>Orden de compra</span><b>${oc ? esc(oc.folio || "Generada") : "Pendiente"}</b></div>
        <div><span>Total de la OC</span><b>${oc ? money(oc.total) : "—"}</b></div>
        <div><span>Entrega comprometida</span><b>${entrega || "Sin fecha"}</b></div>
        <div><span>Firmas de la OC</span><b>${oc ? `${firmasListas} de ${totalFirmas}` : "—"}</b></div>
        <div><span>Recepciones</span><b>${(s.recepciones || []).length}</b></div>
        <div><span>Devoluciones</span><b>${(s.devoluciones || []).length}</b></div>
      </div>
      ${pendientes ? `<div class="cp-alert warn compact"><b>Faltan firmas de la orden de compra.</b><p>Consulta la pestaña Firmas para ver qué falta y quién debe subirlo.</p></div>` : ""}
      ${ultimo ? `<div class="cp-trace-last"><span>Último movimiento</span><b>${esc(eventLabel(ultimo.tipo))}</b><small>${fdt(ultimo.created_at)} · ${esc(ultimo.por || "Sistema")}</small>${ultimo.nota ? `<p>${nl2br(ultimo.nota)}</p>` : ""}</div>` : `<p class="cp-muted">Sin movimientos registrados.</p>`}
    </div>`;
  }

  function traceDocumentosHTML(s) {
    const docs = s.documentos || [];
    if (!docs.length) return `<p class="cp-muted">Aún no hay documentos generados.</p>`;
    return `<div class="cp-trace-list">${docs.map(d => `<article class="cp-trace-doc">
      <div class="cp-trace-doc-head"><div><span class="cp-folio">${esc(d.folio || "")}</span><b>${d.tipo === "requisicion" ? "Requisición" : "Orden de compra"}</b></div>${badge(EST_DOC, d.estado)}</div>
      <div class="cp-trace-doc-meta"><span>${fdate(d.fecha)}</span><span>${money(d.total)}</span>${d.proveedor_nombre ? `<span>${esc(d.proveedor_nombre)}</span>` : ""}${d.tipo === "orden_compra" && d.fecha_entrega ? `<span>Entrega ${fdate(d.fecha_entrega)}</span>` : ""}</div>
      <div class="cp-trace-actions"><button class="cp-mini" data-doc="${d.id}">Abrir detalle</button><button class="cp-mini" data-opendoc="${d.id}">Ver PDF</button></div>
    </article>`).join("")}</div>`;
  }

  function traceFirmasHTML(s) {
    const rows = s.firmados || [];
    const oc = (s.documentos || []).find(d => d.tipo === "orden_compra");
    const reqVigente = rows.find(f => f.tipo === "requisicion_firmada" && f.vigente !== false && f.vigente !== 0);
    const defs = oc ? [...ocFirmaDefs(s), OC_FINAL] : [];
    const item = (tipo, label, hint) => {
      const versiones = rows.filter(f => f.tipo === tipo);
      const vigente = versiones.find(f => f.vigente !== false && f.vigente !== 0);
      return `<div class="cp-trace-sign${vigente ? " ok" : ""}">
        <span class="cp-trace-sign-ico" aria-hidden="true">${vigente ? "✓" : "○"}</span>
        <div class="cp-trace-sign-main"><b>${esc(label)}</b><small>${vigente ? `${fdt(vigente.created_at)}${vigente.subido_por ? ` · ${esc(vigente.subido_por)}` : ""}` : esc(hint || "Pendiente")}</small>
          ${versiones.length > 1 ? `<small>${versiones.length} versiones · ${versiones.filter(f => f.vigente === false || f.vigente === 0).length} reemplazadas</small>` : ""}
        </div>
        ${vigente ? `<button class="cp-mini" data-firmopen="${esc(vigente.path || "")}" data-name="${esc(vigente.nombre || "documento.pdf")}">Ver PDF</button>` : ""}
      </div>`;
    };
    const otros = rows.filter(f => !["requisicion_firmada", ...defs.map(x => x[0])].includes(f.tipo));
    // Los PDF que genera el sistema no son firmas: se muestran con nombre claro.
    const adjuntoLabel = (tipo) => ({
      requisicion_generada: "PDF de la requisición (generado por el sistema)",
      orden_compra_generada: "PDF de la orden de compra (generado por el sistema)",
    })[tipo] || tipo;
    return `<div class="cp-trace-signs">
      ${item("requisicion_firmada", "Requisición firmada", "Jefatura de área")}
      ${defs.map(([tipo, label, hint]) => item(tipo, label, hint)).join("")}
      ${otros.length ? `<div class="cp-trace-other"><span>Otros archivos</span>${otros.map(f => `<div class="cp-trace-sign${f.vigente !== false && f.vigente !== 0 ? " ok" : ""}"><span class="cp-trace-sign-ico">${f.vigente !== false && f.vigente !== 0 ? "✓" : "×"}</span><div class="cp-trace-sign-main"><b>${esc(adjuntoLabel(f.tipo))}</b><small>${fdt(f.created_at)} · ${esc(f.subido_por || "")}${f.vigente === false || f.vigente === 0 ? " · Reemplazado" : ""}</small></div><button class="cp-mini" data-firmopen="${esc(f.path || "")}" data-name="${esc(f.nombre || "documento.pdf")}">Ver</button></div>`).join("")}</div>` : ""}
      ${!oc ? `<p class="cp-muted">Las firmas de la OC aparecerán cuando se genere la orden.</p>` : ""}
      ${reqVigente ? "" : `<p class="cp-firm-note">La requisición firmada aún no está cargada.</p>`}
    </div>`;
  }

  function traceMovimientosHTML(s) {
    const recs = s.recepciones || [];
    const devs = s.devoluciones || [];
    const evs = s.eventos || [];

    const partidas = (items) => (items || []).length ? `<ul class="cp-mv-items">${items.map(x => `
      <li>
        <span class="cp-mv-item-name">${esc(x.item_nombre || "Partida")}</span>
        <b>${qty(x.cantidad)}${x.item_unidad ? ` ${esc(x.item_unidad)}` : ""}</b>
        ${x.estado && x.estado !== "ok" ? `<em class="cp-mv-tag">${esc(x.estado)}</em>` : ""}
      </li>`).join("")}</ul>` : "";

    const recCards = recs.map(r => `<article class="cp-mv-card">
      <header class="cp-mv-head">
        <div><span class="cp-folio">${esc(r.folio || "Recepción")}</span>${badge(EST_REC, r.estado)}</div>
        <small>${fdate(r.fecha)}${r.recibido_por ? ` · Recibió ${esc(r.recibido_por)}` : ""}</small>
      </header>
      ${partidas(r.items)}
      ${r.notas ? `<p class="cp-mv-note">${nl2br(r.notas)}</p>` : ""}
    </article>`).join("");

    const devCards = devs.map(x => `<article class="cp-mv-card is-danger">
      <header class="cp-mv-head">
        <div><span class="cp-folio">${esc(x.folio || "Devolución")}</span>${badge(EST_DEV, x.estado)}</div>
        <small>${fdt(x.created_at)}</small>
      </header>
      ${x.motivo ? `<p class="cp-mv-note">${nl2br(x.motivo)}</p>` : ""}
      ${partidas(x.items)}
    </article>`).join("");

    const histRows = evs.map(e => `<li class="cp-hist-row">
      <div class="cp-hist-when"><b>${fdate(e.created_at)}</b><small>${fhora(e.created_at)}</small></div>
      <span class="cp-hist-rail" aria-hidden="true"><i></i><s></s></span>
      <div class="cp-hist-body">
        <b>${esc(eventLabel(e.tipo))}</b>
        <small>${esc(e.por || "Sistema")}</small>
        ${e.nota ? `<p>${nl2br(e.nota)}</p>` : ""}
      </div>
    </li>`).join("");

    return `<div class="cp-mv">
      <div class="cp-mv-stats">
        <div><b>${recs.length}</b><span>${recs.length === 1 ? "Recepción" : "Recepciones"}</span></div>
        <div><b>${devs.length}</b><span>${devs.length === 1 ? "Devolución" : "Devoluciones"}</span></div>
        <div><b>${evs.length}</b><span>${evs.length === 1 ? "Movimiento" : "Movimientos"}</span></div>
      </div>
      <div class="cp-mv-grid">
        <section class="cp-mv-col">
          <h3>Recepciones</h3>
          ${recCards || `<p class="cp-mv-empty">Aún no se registra la llegada del producto.</p>`}
        </section>
        <section class="cp-mv-col">
          <h3>Devoluciones</h3>
          ${devCards || `<p class="cp-mv-empty">Sin devoluciones: todo llegó en orden.</p>`}
        </section>
      </div>
      <section class="cp-mv-col cp-mv-hist">
        <h3>Historial</h3>
        ${histRows ? `<ol class="cp-hist">${histRows}</ol>` : `<p class="cp-mv-empty">Sin movimientos registrados.</p>`}
      </section>
    </div>`;
  }

  async function loadTraceChat(sid) {
    const layer = document.querySelector(".cp-trace-layer");
    const box = layer?.querySelector("[data-trace-chat]");
    if (!box || box.dataset.loaded === "1") return;
    box.innerHTML = `<p class="cp-muted">Cargando conversación…</p>`;
    try {
      const rows = await api(`/api/compras/solicitudes/${sid}/mensajes`);
      box.dataset.loaded = "1";
      box.innerHTML = rows.length ? rows.map(m => {
        const mine = String(m.username || "") === username();
        return `<div class="cp-trace-msg${mine ? " mine" : ""}">
          <div class="cp-trace-msg-head"><b>${esc(m.username || "Cuenta eliminada")}</b>${m.area ? `<span>${esc(m.area)}</span>` : ""}<small>${fdt(m.created_at)}</small></div>
          <p>${nl2br(m.mensaje || "")}</p>
        </div>`;
      }).join("") : `<p class="cp-muted">Sin mensajes en esta solicitud.</p>`;
    } catch (e) {
      box.innerHTML = `<p class="cp-muted">No se pudo cargar la conversación.</p>`;
    }
  }

  async function openTrace(id) {
    try {
      const s = S.currentSol && String(S.currentSol.id) === String(id) ? S.currentSol : await api("/api/compras/solicitudes/" + id);
      const overlay = $("#cpOverlay", S.root);
      if (!overlay) return;
      overlay.querySelector(".cp-trace-layer")?.remove();
      overlay.insertAdjacentHTML("beforeend", `<div class="cp-trace-layer" data-trace-sid="${s.id}">
        <div class="cp-veil" data-trace-close></div>
        <section class="cp-modal cp-trace-modal" role="dialog" aria-label="Detalles de ${esc(s.folio || "")}">
          <header class="cp-modal-head"><div><span class="cp-kicker">Detalles de la solicitud</span><h2>${esc(s.folio || "")} · ${esc(s.titulo || "")}</h2><p>${esc(s.username || "")}${s.user_area ? ` · ${esc(s.user_area)}` : ""} · ${fdt(s.created_at)}</p></div><button class="cp-x" data-trace-close aria-label="Cerrar">&times;</button></header>
          <nav class="cp-trace-tabs" role="tablist">
            <button type="button" role="tab" class="on" data-trace-tab="resumen" aria-selected="true">Resumen</button>
            <button type="button" role="tab" data-trace-tab="documentos" aria-selected="false">Documentos</button>
            <button type="button" role="tab" data-trace-tab="firmas" aria-selected="false">Firmas</button>
            <button type="button" role="tab" data-trace-tab="chat" aria-selected="false">Chat</button>
            <button type="button" role="tab" data-trace-tab="movimientos" aria-selected="false">Movimientos</button>
          </nav>
          <div class="cp-modal-body cp-trace-body">
            <div class="cp-trace-pane" data-trace-pane="resumen">${traceResumenHTML(s)}</div>
            <div class="cp-trace-pane" data-trace-pane="documentos" hidden>${traceDocumentosHTML(s)}</div>
            <div class="cp-trace-pane" data-trace-pane="firmas" hidden>${traceFirmasHTML(s)}</div>
            <div class="cp-trace-pane" data-trace-pane="chat" hidden><div class="cp-trace-chat" data-trace-chat><p class="cp-muted">Cargando conversación…</p></div></div>
            <div class="cp-trace-pane" data-trace-pane="movimientos" hidden>${traceMovimientosHTML(s)}</div>
          </div>
          <footer class="cp-modal-foot"><button class="cp-btn ghost" data-trace-close>Cerrar</button></footer>
        </section>
      </div>`);
    } catch (e) {
      toast("No se pudieron abrir los detalles", e.message, "error");
    }
  }

  function highlightPdfButton(tipo = "requisicion") {
    // El botón «Ver PDF» vive en la sección Proceso del panel derecho: si la
    // persona está en la pestaña Firmas hay que cambiarla o el aviso no se ve.
    const procesoTab = document.querySelector('.cp-sol-layout [data-rail-tab="proceso"]');
    if (procesoTab && !procesoTab.classList.contains("on")) procesoTab.click();
    const layout = document.querySelector(".cp-sol-layout");
    const row = layout?.querySelector(`.cp-docrow[data-doctipo="${tipo}"]`);
    const btn = row?.querySelector("[data-opendoc]");
    if (!row || !btn) return focusFirmados();
    layout.querySelectorAll(".cp-docrow.cp-pdf-attn").forEach(r => {
      r.classList.remove("cp-pdf-attn");
      r.querySelector(".cp-pdf-callout")?.remove();
    });
    row.scrollIntoView({ behavior: "smooth", block: "center" });
    row.classList.add("cp-pdf-attn");
    const callout = document.createElement("div");
    callout.className = "cp-pdf-callout";
    callout.innerHTML = tipo === "orden_compra"
      ? `<b>Da clic en «Ver PDF» (OC)</b><span>Descarga la orden, fírmala con la jefatura de área y súbela en Firmados.</span>`
      : `<b>Da clic en «Ver PDF» (requisición)</b><span>Descarga la requisición, fírmala con la jefatura de área y súbela en Firmados.</span>`;
    row.appendChild(callout);
    try { btn.focus({ preventScroll: true }); } catch (e) { /* navegador sin focus options */ }
    clearTimeout(highlightPdfButton._t);
    highlightPdfButton._t = setTimeout(() => {
      row.classList.remove("cp-pdf-attn");
      callout.remove();
    }, 6500);
    toast(
      tipo === "orden_compra" ? "Descarga la orden de compra" : "Descarga la requisición",
      "Da clic en el botón «Ver PDF» que está resaltado.",
      "info");
  }

  // El botón «Ir a firmar…» debe apuntar al PDF que toca firmar.
  function guideToSignature(action = "Firmados") {
    const s = S.currentSol || {};
    const docs = s.documentos || [];
    const firmados = s.firmados || [];
    const oc = docs.find(d => d.tipo === "orden_compra");
    const req = docs.find(d => d.tipo === "requisicion");
    const ocFirmada = tieneFirmaVigente(firmados, "orden_compra_firmada");
    let tipo = "requisicion";
    if (oc && (!ocFirmada || ["Firmar final", "Firmar"].includes(action))) tipo = "orden_compra";
    else if (!req && oc) tipo = "orden_compra";
    highlightPdfButton(tipo);
  }

  async function openSolicitud(id, opts = {}) {
    try {
      const s = await api("/api/compras/solicitudes/" + id);
      S.currentSol = s;
      const puedeReenviar = ["cambios_solicitados", "rechazada"].includes(s.estado);
      const esNuevo = (s.flujo || "legado") === "nuevo";
      const gestorOk = !s.gestor_por || String(s.gestor_por) === username();
      const canManageThis = canManage() && gestorOk;
      const canEdit = S.mode === "user" && ["pendiente", "cambios_solicitados", "rechazada"].includes(s.estado);
      const canChat = S.mode !== "admin" && (
        ["user", "compras"].includes(role()) ||
        (role() === "calidad" && (s.tipo_compra || "normal") === "calidad")
      ) && s.estado !== "cancelada" && (role() !== "compras" || gestorOk);
      const ocDocPre = (s.documentos || []).find(d => d.tipo === "orden_compra" && d.estado !== "cancelada");
      let ocDet = null;
      if (ocDocPre) {
        try { ocDet = await api("/api/compras/documentos/" + ocDocPre.id); } catch { ocDet = null; }
      }
      const ocLines = ocDet?.items || [];
      const calidad = (s.tipo_compra || "normal") === "calidad";
      const seleccionPrevia = S.ocSelections?.[s.id] || {};
      const items = (s.items || []).map((it, i) => {
        const ops = it.opciones || [];
        const lineasOc = ocLines.filter(x => String(x.item_id) === String(it.id));
        const comprado = lineasOc.reduce((acc, x) => acc + (Number(x.cantidad) || 0), 0);
        const opcionComprada = lineasOc.map(x => x.opcion_etiqueta).filter(Boolean).join(" · ");
        const prev = seleccionPrevia[it.id] || {};
        let elegida = prev.opcion_id != null ? String(prev.opcion_id) : "";
        if (calidad && !ops.some(o => String(o.id) === elegida && o.calidad_aprobada)) {
          elegida = String(ops.find(o => o.calidad_aprobada)?.id || "");
        }
        const incluir = prev.include !== false;
        const baseElegida = !calidad && (!elegida || !ops.some(o => String(o.id) === elegida));
        const nOpciones = ops.length;
        const chipOpciones = nOpciones
          ? `<span class="cp-badge muted cp-opt-chip" title="Opciones alternativas de este producto">${nOpciones} opci${nOpciones === 1 ? "ón" : "ones"}</span>`
          : "";
        const pickRow = (o, idx, esBase = false) => {
          const oid = esBase ? "" : String(o.id);
          const nombre = esBase ? opcionOrden(0) : opcionNombre(o, idx + 1);
          const prov = esBase ? (it.proveedor || "") : (o.proveedor || "");
          const costo = esBase ? Number(it.costo_unitario) || 0 : Number(o.costo_unitario) || 0;
          const link = safeUrl(esBase ? it.link : o.link);
          const marcada = esBase ? baseElegida : elegida === oid;
          const aprobada = !esBase && o.calidad_aprobada;
          const disabled = (esBase && calidad) || (!esBase && calidad && !aprobada);
          return `<label class="cp-pick${marcada ? " on" : ""}${disabled ? " off" : ""}">
            <input type="radio" name="cpPick-${s.id}-${it.id}" value="${esBase ? "base" : oid}" data-pick data-pick-cost="${costo}" data-pick-opcion="${esBase ? "" : oid}"${marcada ? " checked" : ""}${disabled ? " disabled" : ""}>
            <span class="cp-pick-main">
              <b>${esc(nombre)}${aprobada ? ` <span class="cp-badge ok">Calidad ✓</span>` : ""}</b>
              ${prov ? `<small>${esc(prov)}</small>` : ""}
              ${!esBase && o.diferencia ? `<small>${esc(o.diferencia)}</small>` : ""}
              ${link ? productLinkHTML(link, nombre) : ""}
            </span>
            <span class="cp-pick-cost">${money(costo)}</span>
          </label>`;
        };
        const pickOptions = canManageThis && !ocDocPre ? `<div class="cp-picklist">
          <div class="cp-pick-head"><b>Elige una opción</b><span>Solo puedes seleccionar una por producto.</span></div>
          ${pickRow({}, 0, true)}${ops.map((o, k) => pickRow(o, k + 1)).join("")}
        </div>` : "";
        const ocBadge = ocDet
          ? (comprado > 0
            ? `<span class="cp-badge ok cp-oc-badge">En OC: ${qty(comprado)} ${esc(it.unidad)}</span>`
            : `<span class="cp-badge muted cp-oc-badge">No incluido en la OC</span>`)
          : "";
        const ocPicked = ocDet && comprado > 0 && opcionComprada
          ? `<p class="cp-oc-picked">Opción comprada: <b>${esc(opcionComprada)}</b></p>` : "";
        return `<tr data-item-id="${it.id}" data-base-cost="${Number(it.costo_unitario) || 0}" data-qty="${Number(it.cantidad) || 0}" class="${ocDet ? (comprado > 0 ? "cp-prod-bought" : "cp-prod-notbought") : ""}">
        <td class="cp-selcol">${canManageThis && !ocDocPre ? `<input type="checkbox" data-prodsel="${it.id}" aria-label="Incluir ${esc(it.nombre)} en la OC"${incluir ? " checked" : ""}>` : ""}</td>
        <td class="cp-numcol">${i + 1}</td>
        <td class="cp-prodcol"><div class="cp-prodcell">
          <div class="cp-prodthumb${it.imagen || it.link ? "" : " empty"}" data-cpmedia data-cpimg="${esc(it.imagen || "")}" data-cplink="${esc(it.link || "")}">${mediaPlaceholder()}</div>
          <div class="cp-prodinfo">
            <b class="cp-prodname">${esc(it.nombre)}${chipOpciones}${ocBadge}</b>
            ${it.certificado ? `<div class="cp-prodmeta"><span class="cp-badge ok">✓ Producto certificado</span></div>` : ""}
            ${it.descripcion ? `<p class="cp-proddesc">${nl2br(it.descripcion)}</p>` : ""}
            ${it.motivo ? `<p class="cp-proddesc cp-prodreason"><b>Para qué:</b> ${nl2br(it.motivo)}</p>` : ""}
            ${(it.id_fabricacion || safeUrl(it.link)) ? `<div class="cp-prodmeta">
              ${it.id_fabricacion ? `<span class="cp-code">${esc(it.id_fabricacion)}</span>` : ""}
              ${safeUrl(it.link) ? productLinkHTML(it.link) : ""}
            </div>` : ""}
            ${it.requisitos_calidad ? `<p class="cp-proddesc"><b>Requisitos de Calidad:</b> ${nl2br(it.requisitos_calidad)}</p>` : ""}
            ${ocPicked}
            ${pickOptions}
          </div>
        </div></td>
        <td class="num">${qty(it.cantidad)} ${esc(it.unidad)}</td>
        <td class="num">${money(it.costo_unitario)}<small class="cp-costiva">${Number(it.precio_incluye_iva) ? "IVA incl." : "+ IVA"}</small></td>
        <td class="num"><b>${money(it.importe)}</b></td>
      </tr>`;
      }).join("");
      const docs = (s.documentos || []).map(d => {
        const genTipo = d.tipo === "requisicion" ? "requisicion_generada" : "orden_compra_generada";
        const gen = (s.firmados || []).find(f => f.tipo === genTipo && esFirmaVigente(f));
        return `<div class="cp-docrow" data-doctipo="${esc(d.tipo)}" data-docid="${d.id}">
        <div><span class="cp-folio">${esc(d.folio)}</span><b>${d.tipo === "requisicion" ? "Requisición" : "Orden de compra"}</b>
          <small>${fdate(d.fecha)} · ${money(d.total)}</small></div>
        <div class="cp-docrow-actions">${badge(EST_DOC, d.estado)}
          <button class="cp-pdf-btn" data-opendoc="${d.id}"${gen ? ` data-name="${esc(gen.nombre || "documento.pdf")}"` : ""}><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M9 15h6"/><path d="M9 18h4"/></svg>Ver PDF</button>
          ${canManageThis && d.tipo === "orden_compra" ? docActions(d, s) : ""}
        </div>
      </div>`;
      }).join("");
      const recs = (s.recepciones || []).map(r => `<div class="cp-timeline-row">
        <span class="cp-dot ok"></span><div><b>Recepción ${esc(r.folio || "")}</b> ${badge(EST_REC, r.estado)}
        <small>${fdate(r.fecha)} · ${esc(r.recibido_por || "")}</small>${r.notas ? `<p>${nl2br(r.notas)}</p>` : ""}</div></div>`).join("");
      const devs = (s.devoluciones || []).map(d => `<div class="cp-timeline-row">
        <span class="cp-dot danger"></span><div><b>Devolución ${esc(d.folio || "")}</b> ${badge(EST_DEV, d.estado)}
        <small>${fdt(d.created_at)}</small><p>${nl2br(d.motivo || "")}</p></div></div>`).join("");
      const evs = (s.eventos || []).map(e => `<div class="cp-timeline-row">
        <span class="cp-dot"></span><div><b>${esc(eventLabel(e.tipo))}</b><small>${fdt(e.created_at)} · ${esc(e.por || "")}</small>
        ${e.nota ? `<p>${nl2br(e.nota)}</p>` : ""}</div></div>`).join("");

      const acts = [];
      const firmados = s.firmados || [];
      const ocDoc = (s.documentos || []).find(d => d.tipo === "orden_compra");
      const reqFirmada = tieneFirmaVigente(firmados, "requisicion_firmada") || s.requisicion_firmada;
      const ocUserFirmada = tieneFirmaVigente(firmados, "orden_compra_firmada");
      const reqOk = !esNuevo || reqFirmada;
      const qOk = (s.tipo_compra || "normal") !== "calidad" || s.calidad_estado === "aprobada";
      const bloqueo = !reqOk ? "Falta la requisición firmada por la jefatura de área"
        : !qOk ? "Calidad todavía no aprobó las opciones" : "";
      if (canManageThis) {
        if (s.estado === "pendiente" && !bloqueo && !s.gestor_por) acts.push(`<button class="cp-btn" data-solact="tomar" data-id="${s.id}">Tomar para revisión</button>`);
        if (["pendiente", "en_revision"].includes(s.estado)) {
          if (bloqueo) {
            acts.push(`<span class="cp-blockhint">${esc(bloqueo)}</span>`);
          } else if (esNuevo && !reqFirmada) {
            // En flujo nuevo, no mostrar "Autorizar compra" hasta que se firme la requisición
            acts.push(`<span class="cp-blockhint">Pendiente: requisición firmada por la jefatura de área</span>`);
          } else {
            acts.push(`<button class="cp-btn primary" data-solact="aprobar" data-id="${s.id}">${esNuevo ? "Autorizar compra" : "Aprobar"}</button>`);
          }
          acts.push(`<button class="cp-btn" data-solact="solicitar_cambios" data-id="${s.id}">Pedir cambios</button>`);
          acts.push(`<button class="cp-btn danger" data-solact="rechazar" data-id="${s.id}">Rechazar</button>`);
        }
        if (["aprobada", "en_compra"].includes(s.estado)) {
          const req = (s.documentos || []).find(d => d.tipo === "requisicion");
          const oc = ocDoc;
          if (!oc) {
            const tipo = esNuevo ? "orden_compra" : (req ? "orden_compra" : "ambos");
            acts.push(`<button class="cp-btn primary" data-newdoc="${s.id}" data-tipo="${tipo}">${s.cambios_oc_motivo ? "Ajustar orden de compra" : (!esNuevo && !req ? "Generar requisición + orden de compra" : "Generar orden de compra")}</button>`);
          }
        }
        if (["recibida", "con_incidencias", "devuelta"].includes(s.estado)) {
          const puedeCerrar = esNuevo ? (ocFirmasCompletas(s) && !!s.orden_compra_firmada_final) : firmados.length;
          // Sin disabled: un botón inerte parece "roto". Al pulsar sin firma
          // se muestra exactamente qué falta.
          acts.push(`<button class="cp-btn primary" data-solact="cerrar" data-id="${s.id}" data-needfirma="${puedeCerrar ? "" : "1"}">Cerrar compra</button>`);
        }
        if (["rechazada", "cancelada", "cerrada"].includes(s.estado)) acts.push(`<button class="cp-btn" data-solact="reabrir" data-id="${s.id}">Reabrir</button>`);
      } else if (canManage() && !gestorOk) {
        acts.push(`<span class="cp-blockhint">En proceso por ${esc(s.gestor_por)} · solo lectura</span>`);
      } else if (canEdit) {
        acts.push(`<button class="cp-btn ghost" data-editsol="${s.id}">${puedeReenviar ? "Corregir y reenviar" : "Editar solicitud"}</button>`);
        acts.push(`<button class="cp-btn danger" data-solact="cancelar" data-id="${s.id}">Cancelar</button>`);
      } else if (S.mode === "user" && ocDoc && !ocUserFirmada && !s.cambios_oc_motivo &&
        ["aprobada", "en_compra"].includes(s.estado)) {
        acts.push(`<button class="cp-btn ghost" data-solact="solicitar_cambios_oc" data-id="${s.id}">Solicitar cambios en la OC</button>`);
      }

      const signAlert = signAlertHTML(s);
      const firmasPendientes = esNuevo && !!ocDoc && !ocFirmasCompletas(s);
      const railTab = firmasPendientes ? "firmas" : "proceso";
      // Progreso de firmas para la pestaña: "2/4" mientras falten, "✓" al terminar.
      const firmaDefsAll = [...ocFirmaDefs(s), OC_FINAL];
      const firmasHechas = firmaDefsAll.filter(([t]) => ocFirmaVigente(s, t)).length;
      const firmasTotal = firmaDefsAll.length;
      const badgeFirmas = esNuevo && ocDoc
        ? (firmasPendientes
          ? `<span class="cp-tab-badge warn">${firmasHechas}/${firmasTotal}</span>`
          : `<span class="cp-tab-badge ok" title="Firmas completas">✓</span>`)
        : "";
      showOverlay(`
        <div class="cp-veil" data-close></div>
        <div class="cp-sol-layout">
        <aside class="cp-drawer" data-drawer="sol" role="dialog" aria-label="Solicitud ${esc(s.folio)}">
          <header class="cp-drawer-head">
            <div class="cp-drawer-title">
              <div class="cp-statusbar">${badge(EST_SOL, s.estado)}${etapaBadge(s)}</div>
              <div class="cp-drawer-folio"><span class="cp-folio">${esc(s.folio || "")}</span><span class="cp-drawer-prio">Prioridad ${esc(PRIO[s.prioridad]?.[0] || "Normal")}</span></div>
              <h2>${esc(s.titulo)}</h2>
              <p>${s.username ? `Solicita <b>${esc(s.username)}</b> · ` : ""}${esc(s.user_area || s.area || "")} · ${fdt(s.created_at)}</p>
            </div>
            <button class="cp-x" data-close aria-label="Cerrar">&times;</button>
          </header>
          <div class="cp-drawer-body">
            <div class="cp-detail-top">
              ${signAlert}
              ${signAlert ? "" : nextStepGuide(s)}
              ${s.gestor_por && viewAll() ? `<div class="cp-alert info compact"><b>En proceso por ${esc(s.gestor_por)}.</b><p>${canManageThis ? "Tienes asignada esta solicitud." : "Solo lectura: la persona asignada puede modificarla."}</p></div>` : ""}
              ${(s.tipo_compra || "normal") === "calidad" && s.calidad_estado !== "aprobada" ? `<div class="cp-alert info compact"><b>Calidad: ${esc(({ pendiente: "pendiente", en_revision: "en revisión", rechazada: "rechazada" })[s.calidad_estado] || s.calidad_estado || "pendiente")}.</b><p>Debe aprobar las opciones antes de generar la OC.</p></div>` : ""}
              ${s.motivo_rechazo ? `<div class="cp-alert danger compact"><b>Motivo del rechazo</b><p>${nl2br(s.motivo_rechazo)}</p>${S.mode === "user" ? `<small>Corrige y reenvía; volverá a Pendiente.</small>` : ""}</div>` : ""}
              ${s.motivo_cambios ? `<div class="cp-alert warn compact"><b>La persona solicitante debe corregir</b><p>${nl2br(s.motivo_cambios)}</p>${S.mode === "user" ? `<small>Corrige y reenvía para nueva revisión.</small>` : ""}</div>` : ""}
              ${s.cambios_oc_motivo ? `<div class="cp-alert ${canManageThis ? "warn" : "info"} compact" data-occhange>
                <b>${canManageThis ? "Ajusta la orden de compra" : "Solicitaste cambios en la orden de compra"}</b>
                <p>${nl2br(s.cambios_oc_motivo)}</p>
                <small>${canManageThis ? "La OC anterior quedó cancelada. Genera una nueva orden con la selección corregida." : "Compras generará una nueva orden con los cambios. No firmes ni subas la OC anterior."}</small>
              </div>` : ""}
              <div class="cp-progresscard">
                <div class="cp-progresscard-head">
                  <div><b>Etapa del proceso</b><small>${esc((ETAPA[s.etapa_actual] || "Solicitud recibida"))}</small></div>
                  <span class="cp-progress-count">Etapa ${Math.min((SOL_STEP_INDEX[s.estado] ?? 0) + 1, SOL_STEPS.length)} de ${SOL_STEPS.length}</span>
                </div>
                ${stepperHTML(s.estado)}
              </div>
              <div class="cp-facts">
                <div><span>Prioridad</span><b>${esc(PRIO[s.prioridad]?.[0] || "Normal")}</b></div>
                <div><span>Tipo de compra</span><b>${esc(TIPO_COMPRA[s.tipo_compra || "normal"]?.[0] || "Compra normal")}</b></div>
                <div><span>Total estimado</span><b>${money(s.total_estimado)}</b></div>
                <div><span>Jefatura de área</span><b>${esc(s.jefe_area || (s.username ? `${s.username} (la misma persona)` : "Sin configurar"))}</b></div>
              </div>
            </div>
            <div class="cp-wide-block">
              ${s.justificacion ? `<section class="cp-sec cp-brief"><h3>Contexto general</h3><p>${nl2br(s.justificacion)}</p></section>` : ""}
              <section class="cp-sec cp-products-sec"><h3>Productos y materiales</h3>
                <div class="cp-panel-totals" id="cpPanelTotals" style="display:none;">
                  <div class="cp-panel-total principales" title="Suma de todos los productos solicitados">
                    <span class="cp-panel-total-label">Total solicitado</span>
                    <span class="cp-panel-total-value principales" data-total-principales>$0.00</span>
                    <small class="cp-panel-total-hint" data-hint-principales></small>
                  </div>
                  ${canManageThis ? `<div class="cp-panel-total seleccion" title="Suma de los productos y opciones seleccionados para la OC">
                    <span class="cp-panel-total-label">Total seleccionado</span>
                    <span class="cp-panel-total-value seleccion" data-total-seleccion>—</span>
                    <small class="cp-panel-total-hint" data-hint-seleccion>Ningún producto marcado</small>
                  </div>` : ""}
                </div>
                <div class="cp-tablewrap"><table class="cp-table cp-products${canManageThis ? "" : " nosel"}"><thead><tr><th class="cp-selcol">${canManageThis ? `<input type="checkbox" id="cpSelAllProds" aria-label="Seleccionar todos los productos">` : ""}</th><th>#</th><th>Producto</th><th class="num">Cantidad</th><th class="num">Costo unit.</th><th class="num">Importe</th></tr></thead>                <tbody>${items || `<tr><td colspan="6">Sin productos</td></tr>`}</tbody></table></div>
              </section>
            </div>
            <div class="cp-detail-grid">
              <div class="cp-detail-main">
                <section class="cp-sec cp-chat-sec">
                  <div class="cp-chat-head"><h3>Conversación</h3><span class="cp-chat-live">Actualización en vivo</span></div>
                  <div class="cp-chat-msgs" id="cpChatMsgs"><p class="cp-muted">Cargando conversación…</p></div>
                  ${canChat ? `<form class="cp-chat-form" id="cpChatForm" autocomplete="off">
                    <input id="cpChatInput" maxlength="800" placeholder="Escribe una observación o pregunta…" aria-label="Mensaje para la solicitud">
                    <button type="submit" class="cp-btn primary" id="cpChatSend">Enviar</button>
                  </form>` : `<p class="cp-chat-readonly">${S.mode === "admin" ? "Vista de solo lectura: administración puede consultar la conversación." : (role() === "compras" && !gestorOk ? `En proceso por ${esc(s.gestor_por)}; solo la persona asignada puede escribir.` : "La conversación está cerrada.")}</p>`}
                </section>
                ${(s.proveedor_propuesto?.nombre || s.proveedor_sugerido || s.notas) ? `<details class="cp-sec cp-fold"><summary>Más datos de la solicitud</summary><div class="cp-more-data">
                  ${(s.proveedor_propuesto?.nombre || s.proveedor_sugerido) ? `<div><h4>Proveedor propuesto</h4><p><b>${esc(s.proveedor_propuesto?.nombre || s.proveedor_sugerido)}</b>
                    ${s.proveedor_propuesto?.contacto ? ` · ${esc(s.proveedor_propuesto.contacto)}` : ""}
                    ${s.proveedor_propuesto?.email ? ` · ${esc(s.proveedor_propuesto.email)}` : ""}
                    ${s.proveedor_propuesto?.telefono ? ` · ${esc(s.proveedor_propuesto.telefono)}` : ""}</p></div>` : ""}
                  ${s.notas ? `<div><h4>Notas</h4><p>${nl2br(s.notas)}</p></div>` : ""}
                </div></details>` : ""}
                ${calidadPanel(s)}
              </div>
              <aside class="cp-detail-side">
                ${recs ? `<details class="cp-sec cp-fold"><summary>Recepciones (${(s.recepciones || []).length})</summary><div class="cp-timeline">${recs}</div></details>` : ""}
                ${devs ? `<details class="cp-sec cp-fold"><summary>Devoluciones (${(s.devoluciones || []).length})</summary><div class="cp-timeline">${devs}</div></details>` : ""}
                <details class="cp-sec cp-fold">
                  <summary>Historial de movimientos</summary>
                  <div class="cp-timeline">${evs || `<p class="cp-muted">Sin movimientos.</p>`}</div>
                </details>
              </aside>
            </div>
          </div>
          <footer class="cp-drawer-foot"><button class="cp-btn subtle" data-trace="${s.id}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>Ver detalles</button>${acts.join("") || `<span class="cp-muted">Sin acciones disponibles</span>`}<button class="cp-btn ghost" data-close>Cerrar panel</button></footer>
        </aside>
        <aside class="cp-rail" aria-label="Proceso y documentos de la solicitud">
          <div class="cp-rail-title"><span>Proceso de compra</span><button class="cp-mini cp-detail-btn" data-trace="${s.id}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>Ver detalles</button></div>
          <div class="cp-rail-tabs" role="tablist" aria-label="Secciones del proceso">
            <button type="button" role="tab" data-rail-tab="proceso" class="${railTab === "proceso" ? "on" : ""}" aria-selected="${railTab === "proceso"}"><span class="cp-tab-label">Proceso</span></button>
            <button type="button" role="tab" data-rail-tab="firmas" class="${railTab === "firmas" ? "on" : ""}" aria-selected="${railTab === "firmas"}"><span class="cp-tab-label">Firmas</span>${badgeFirmas}</button>
          </div>
          <div class="cp-rail-pane" data-rail-pane="proceso"${railTab === "proceso" ? "" : " hidden"}>
            ${checklistHTML(s)}
            <section class="cp-sec"><h3>Documentos</h3>${docs || `<p class="cp-muted">Aún no hay requisición ni orden de compra.</p>`}</section>
          </div>
          <div class="cp-rail-pane" data-rail-pane="firmas"${railTab === "firmas" ? "" : " hidden"}>
            ${firmadosRailHTML(s)}
          </div>
        </aside>
        </div>`);
      hydrateMedia($(".cp-drawer", S.root) || S.root);
      syncRailScroll();
      // Totales de productos: los ve cualquiera; la selección solo el gestor.
      const drawer = $(".cp-drawer", S.root);
      const table = drawer?.querySelector(".cp-products");
      if (table) {
        const selAll = table.querySelector("#cpSelAllProds");
        const rows = table.querySelectorAll("tbody tr[data-item-id]");
        const totalsBox = drawer.querySelector("#cpPanelTotals");
        S.ocSelections = S.ocSelections || {};
        const store = S.ocSelections[s.id] = S.ocSelections[s.id] || {};
        const calcTotals = () => {
          let princ = 0, selec = 0;
          let marcados = 0, conOpcion = 0;
          rows.forEach(row => {
            const cant = Number(row.dataset.qty) || 0;
            const costoBase = Number(row.dataset.baseCost) || 0;
            const cb = row.querySelector("[data-prodsel]");
            const pick = row.querySelector("[data-pick]:checked");
            const costo = pick ? (Number(pick.dataset.pickCost) || 0) : costoBase;
            princ += costoBase * cant;
            if (cb ? cb.checked : true) {
              selec += costo * cant;
              marcados++;
              if (pick?.dataset.pickOpcion) conOpcion++;
            }
          });
          if (selAll) {
            selAll.checked = rows.length > 0 && [...rows].every(row => row.querySelector("[data-prodsel]")?.checked);
          }
          if (totalsBox) {
            totalsBox.style.display = "flex";
            const set = (sel, val) => {
              const el = totalsBox.querySelector(sel);
              if (el) el.textContent = val;
            };
            set("[data-total-principales]", money(princ));
            set("[data-total-seleccion]", marcados ? money(selec) : "—");
            set("[data-hint-principales]", `${rows.length} producto${rows.length === 1 ? "" : "s"}`);
            set("[data-hint-seleccion]", marcados
              ? `${marcados} de ${rows.length} producto${rows.length === 1 ? "" : "s"}${conOpcion ? ` · ${conOpcion} con opción alternativa` : ""}`
              : "Ningún producto marcado");
          }
          if (canManageThis) {
            rows.forEach(row => {
              const cb = row.querySelector("[data-prodsel]");
              const pick = row.querySelector("[data-pick]:checked");
              if (!row.dataset.itemId) return;
              store[row.dataset.itemId] = {
                include: cb ? cb.checked : true,
                opcion_id: pick?.dataset.pickOpcion ? Number(pick.dataset.pickOpcion) : null,
              };
            });
          }
        };
        if (selAll) {
          selAll.addEventListener("change", () => {
            rows.forEach(row => {
              const cb = row.querySelector("[data-prodsel]");
              if (cb) cb.checked = selAll.checked;
            });
            calcTotals();
          });
        }
        rows.forEach(row => {
          const cb = row.querySelector("[data-prodsel]");
          if (cb) cb.addEventListener("change", calcTotals);
          row.querySelectorAll("[data-pick]").forEach(radio => {
            radio.addEventListener("change", () => {
              if (cb) cb.checked = true;
              row.querySelectorAll(".cp-pick").forEach(label => {
                const input = label.querySelector("[data-pick]");
                label.classList.toggle("on", !!input?.checked);
              });
              calcTotals();
            });
          });
        });
        calcTotals();
      }
      loadSolicitudChat(s.id);
      if (opts.focusChat) {
        requestAnimationFrame(() => {
          const sec = $(".cp-chat-sec", S.root);
          sec?.scrollIntoView({ behavior: "smooth", block: "center" });
          sec?.classList.add("cp-flash");
          setTimeout(() => sec?.classList.remove("cp-flash"), 1800);
          setTimeout(() => $("#cpChatInput", S.root)?.focus({ preventScroll: true }), 450);
        });
      }
      if (opts.focusFirma) {
        requestAnimationFrame(() => {
          focusFirmados(true);
          setTimeout(() => focusFirmados(true), 700);
        });
      }
      if (canChat) {
        const chatForm = $("#cpChatForm", S.root);
        chatForm?.addEventListener("submit", async (e) => {
          e.preventDefault();
          const input = $("#cpChatInput", S.root);
          const msg = (input?.value || "").trim();
          if (!msg) return;
          const send = $("#cpChatSend", S.root);
          if (send) { send.disabled = true; send.textContent = "Enviando…"; }
          try {
            await api(`/api/compras/solicitudes/${s.id}/mensajes`, { method: "POST", body: JSON.stringify({ mensaje: msg }) });
            window.SylpackSound?.play("chat_out");
            if (input) { input.value = ""; input.focus(); }
            await loadSolicitudChat(s.id);
          } catch (err) { toast("No se pudo enviar", err.message, "error"); }
          finally { if (send) { send.disabled = false; send.textContent = "Enviar"; } }
        });
      }
    } catch (e) { toast("No se pudo abrir", e.message, "error"); }
  }

  async function loadSolicitudChat(sid) {
    window.SylpackNotif?.markCompra?.(sid);
    const box = $("#cpChatMsgs", S.root);
    if (!box) return;
    try {
      const rows = await api(`/api/compras/solicitudes/${sid}/mensajes`);
      const stick = box.scrollTop + box.clientHeight >= box.scrollHeight - 24;
      if (!rows.length) {
        box.innerHTML = `<p class="cp-chat-empty">Aún no hay mensajes. Aquí puedes aclarar dudas, pedir cambios o dar seguimiento.</p>`;
        return;
      }
      box.innerHTML = rows.map(m => {
        const mine = String(m.username || "") === username();
        return `<div class="cp-chat-msg${mine ? " mine" : ""}">
          <div class="cp-chat-meta"><b>${esc(m.username || "Cuenta eliminada")}</b>${!mine ? `<em class="cp-chat-area">${esc(m.area || "Sin área")}</em>` : ""}<span>${fdt(m.created_at)}</span></div>
          <p>${nl2br(m.mensaje)}</p>
        </div>`;
      }).join("");
      if (stick || !box.dataset.loaded) box.scrollTop = box.scrollHeight;
      box.dataset.loaded = "1";
    } catch (e) {
      if (box) box.innerHTML = `<p class="cp-chat-empty">No se pudo cargar la conversación.</p>`;
    }
  }

  function docActions(d, s = null) {
    const a = [];
    const esNuevo = (s?.flujo || d.flujo || "legado") === "nuevo";
    const reqFirmada = s?.requisicion_firmada ?? d.requisicion_firmada;
    const ocFirmada = s?.orden_compra_firmada ?? d.orden_compra_firmada;
    if (d.estado === "borrador") a.push(`<button class="cp-mini" data-docact="emitir" data-id="${d.id}">Emitir</button>`);
    if (d.estado === "emitida" && canManage()) {
      if (esNuevo && d.tipo !== "orden_compra") {
        // En el flujo nuevo la requisición se firma y sube; no se autoriza aquí.
      } else if (esNuevo && (!reqFirmada || !ocFirmada)) {
        a.push(`<span class="cp-blockhint">${!reqFirmada ? "Falta la requisición firmada" : "Falta subir la OC firmada por la jefatura"}</span>`);
      } else {
        a.push(`<button class="cp-mini ok" data-docact="autorizar" data-id="${d.id}">Autorizar</button>`);
      }
    }
    if (d.estado === "autorizada" && (!esNuevo || ocFirmada)) a.push(`<button class="cp-mini" data-docact="enviar" data-id="${d.id}">Enviar</button>`);
    if (["autorizada", "enviada"].includes(d.estado) && (!esNuevo || ocFirmada)) a.push(`<button class="cp-mini ok" data-recdoc="${d.id}">Recibir</button>`);
    if (d.estado === "recibida") a.push(`<button class="cp-mini danger" data-devledoc="${d.id}">Devolución</button>`);
    if (!["recibida", "cerrada", "cancelada"].includes(d.estado)) a.push(`<button class="cp-mini" data-docact="cancelar" data-id="${d.id}">Cancelar</button>`);
    return a.join("");
  }

    function nextStepGuide(s) {
    const esNuevo = (s.flujo || "legado") === "nuevo";
    const gestorOk = !s.gestor_por || String(s.gestor_por) === username();
    const canManageThis = canManage() && gestorOk;
    const reqOk = !esNuevo || s.requisicion_firmada;
    const qOk = (s.tipo_compra || "normal") !== "calidad" || s.calidad_estado === "aprobada";
    const oc = (s.documentos || []).find(d => d.tipo === "orden_compra");
    const firmados = s.firmados || [];
    const ocUserFirmada = tieneFirmaVigente(firmados, "orden_compra_firmada");
    const ocFinalFirmada = tieneFirmaVigente(firmados, "orden_compra_firmada_final");
    const firmasOcCompletas = ocFirmasCompletas(s);
    const firmaSiguiente = ocFirmaSiguiente(s);
    const reqFirmada = tieneFirmaVigente(firmados, "requisicion_firmada") || s.requisicion_firmada;

    let guide = null;
    const svgDoc = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M16 13H8"/><path d="M16 17H8"/><path d="M10 9H8"/></svg>`;
    const svgClock = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`;
    const svgEdit = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`;
    const svgCheck = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`;
    const svgBox = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>`;
    const svgUser = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`;
    const svgEye = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;

    if (S.mode === "user") {
      if (s.cambios_oc_motivo && ["aprobada", "en_compra"].includes(s.estado)) {
        guide = { icon: svgClock, title: "Compras ajustará tu OC", desc: "Pediste cambios antes de firmar. Compras generará una nueva orden; no firmes ni subas la anterior.", action: null };
      } else if (["pendiente", "en_revision"].includes(s.estado)) {
        if (esNuevo && !reqFirmada) {
          guide = { icon: svgDoc, title: "Sube la requisición firmada", desc: "Descarga la requisición, fírmala con el jefe de área y súbela en el panel de proceso.", action: "Firmados" };
        } else if ((s.tipo_compra || "normal") === "calidad" && s.calidad_estado !== "aprobada") {
          guide = { icon: svgClock, title: "Esperando revisión de Calidad", desc: "Calidad está revisando las opciones. No se puede avanzar hasta que aprueben.", action: null };
        } else if (s.estado === "en_revision") {
          guide = { icon: svgClock, title: "En revisión por Compras", desc: "El gestor está revisando tu solicitud. Recibirás notificación cuando haya novedades.", action: null };
        } else {
          guide = { icon: svgClock, title: "Solicitud enviada", desc: "Tu solicitud ya está en la bandeja de Compras. Te avisaremos cuando cambie de estado.", action: null };
        }
      } else if (s.estado === "cambios_solicitados") {
        guide = { icon: svgEdit, title: "Corrige y reenvía", desc: "Revisa los cambios solicitados, edita la solicitud y reenvíala para nueva revisión.", action: "Editar" };
      } else if (s.estado === "rechazada") {
        guide = { icon: svgEdit, title: "Corrige y reenvía", desc: "Revisa el motivo del rechazo, edita la solicitud y reenvíala; volverá a Pendiente.", action: "Editar" };
      } else if (s.estado === "aprobada") {
        if (esNuevo && oc && !ocUserFirmada) {
          guide = { icon: svgDoc, title: "Firma la orden de compra", desc: "Descarga la OC, fírmala con el jefe de área y súbela en el panel de proceso.", action: "Firmados" };
        } else if (!esNuevo) {
          guide = { icon: svgClock, title: "Compras generará la orden", desc: "El gestor creará la orden de compra y te avisará cuando esté lista.", action: null };
        } else {
          guide = { icon: svgClock, title: "Generando orden de compra", desc: "El gestor de Compras está preparando la OC.", action: null };
        }
      } else if (s.estado === "en_compra") {
        if (esNuevo && oc && !ocUserFirmada) {
          guide = { icon: svgDoc, title: "Firma la orden de compra", desc: "Descarga la OC, recaba solo la firma del jefe de área y súbela. Compras completa las firmas restantes.", action: "Firmados" };
        } else if (esNuevo && oc && !firmasOcCompletas) {
          guide = { icon: svgClock, title: "Compras completa las firmas", desc: "Tu parte ya está lista. Compras recaba las firmas de Sandra, Lucío y el documento final.", action: null };
        } else if (esNuevo && oc && firmasOcCompletas && !ocFinalFirmada) {
          guide = { icon: svgClock, title: "Compras sube el documento final", desc: "Las firmas ya están completas. Compras integra el documento final para poder cerrar.", action: null };
        } else if (esNuevo && oc && ocFinalFirmada) {
          guide = { icon: svgBox, title: "Esperando recepción", desc: "La OC está completa. Cuando lleguen los productos, Compras registrará la recepción y cerrará la compra.", action: null };
        } else if (!esNuevo) {
          guide = { icon: svgClock, title: "En proceso de compra", desc: "Compras está gestionando la orden con el proveedor.", action: null };
        } else {
          guide = { icon: svgClock, title: "Compras gestiona la OC", desc: "El gestor está tramitando la orden con el proveedor.", action: null };
        }
      } else if (["recibida", "con_incidencias", "devuelta"].includes(s.estado)) {
        if (esNuevo && oc && !firmasOcCompletas) {
          guide = { icon: svgClock, title: "Faltan firmas de la OC", desc: "Compras debe completar las firmas de gestión antes de cerrar la compra.", action: null };
        } else if (esNuevo && oc && !ocFinalFirmada) {
          guide = { icon: svgClock, title: "Esperando documento final", desc: "La recepción ya se registró. Compras debe subir el documento final con todas las firmas.", action: null };
        } else {
          guide = { icon: svgCheck, title: "Compra en proceso de cierre", desc: "La recepción y las firmas están listas. Compras puede cerrar la compra.", action: null };
        }
      } else if (s.estado === "cerrada") {
        guide = { icon: svgCheck, title: "Compra cerrada", desc: "El proceso terminó correctamente. Puedes consultar el historial y los documentos.", action: null };
      }
    } else if (canManageThis) {
      if (s.estado === "pendiente" && !s.gestor_por) {
        guide = { icon: svgUser, title: "Toma la solicitud", desc: "Asígnate esta solicitud para empezar a gestionarla.", action: "Tomar" };
      } else if (s.estado === "pendiente" && gestorOk) {
        if (esNuevo && !reqFirmada) {
          guide = { icon: svgDoc, title: "Esperando requisición firmada", desc: "El solicitante debe subir la requisición firmada por la jefatura de área.", action: null };
        } else if ((s.tipo_compra || "normal") === "calidad" && s.calidad_estado !== "aprobada") {
          guide = { icon: svgClock, title: "Esperando aprobación de Calidad", desc: "Calidad debe revisar y aprobar las opciones antes de que puedas autorizar.", action: null };
        } else {
          guide = { icon: svgCheck, title: "Autoriza la solicitud", desc: "Revisa los productos y autoriza para que pase a compra.", action: "Autorizar" };
        }
      } else if (s.estado === "en_revision" && gestorOk) {
        if (esNuevo && !reqFirmada) {
          guide = { icon: svgDoc, title: "Esperando requisición firmada", desc: "El solicitante debe subir la requisición firmada.", action: null };
        } else if ((s.tipo_compra || "normal") === "calidad" && s.calidad_estado !== "aprobada") {
          guide = { icon: svgClock, title: "Esperando aprobación de Calidad", desc: "Calidad debe aprobar las opciones.", action: null };
        } else {
          guide = { icon: svgCheck, title: "Autoriza o pide cambios", desc: "Puedes aprobar la compra, pedir cambios o rechazarla.", action: "Autorizar" };
        }
      } else if (["aprobada", "en_compra"].includes(s.estado) && gestorOk) {
        if (s.cambios_oc_motivo) {
          guide = { icon: svgDoc, title: "Ajusta la orden de compra", desc: "El solicitante pidió cambios antes de firmar. Genera una nueva OC con la selección corregida.", action: "Generar OC" };
        } else if (!oc) {
          guide = { icon: svgDoc, title: "Genera la orden de compra", desc: "Ajusta cantidades, elige proveedor y crea la OC.", action: "Generar OC" };
        } else if (esNuevo && !ocUserFirmada) {
          guide = { icon: svgClock, title: "Esperando la firma del jefe", desc: "El solicitante debe subir la OC firmada por el jefe de área.", action: null };
        } else if (esNuevo && !firmasOcCompletas) {
          guide = { icon: svgDoc, title: "Sube " + firmaTipoLabel(firmaSiguiente), desc: "Continúa el orden de firmas: jefe, Calidad (si aplica), Sandra, Lucío y documento final.", action: "Firmados" };
        } else if (esNuevo && !ocFinalFirmada) {
          guide = { icon: svgDoc, title: "Sube el documento final", desc: "Las firmas están completas. Integra todas las firmas en un solo PDF y súbelo.", action: "Firmados" };
        } else if (esNuevo && ocFinalFirmada && !(s.recepciones || []).length) {
          guide = { icon: svgBox, title: "Registra la recepción", desc: "La OC está completa. Cuando llegue el producto, registra la recepción para cerrar.", action: "Recepción" };
        } else if (esNuevo) {
          guide = { icon: svgCheck, title: "Cierra la compra", desc: "La OC y la recepción están completas. Puedes cerrar la compra.", action: "Cerrar" };
        } else {
          guide = { icon: svgBox, title: "Registra la recepción", desc: "Cuando llegue el producto, registra la recepción para avanzar.", action: "Recepción" };
        }
      } else if (["recibida", "con_incidencias", "devuelta"].includes(s.estado) && gestorOk) {
        if (esNuevo && !firmasOcCompletas) {
          guide = { icon: svgDoc, title: "Completa las firmas de la OC", desc: "Faltan firmas de gestión antes de poder cerrar la compra.", action: "Firmados" };
        } else if (esNuevo && !ocFinalFirmada) {
          guide = { icon: svgDoc, title: "Sube el documento final", desc: "La recepción ya está registrada. Integra todas las firmas y sube el documento final.", action: "Firmados" };
        } else if (esNuevo && ocFinalFirmada) {
          guide = { icon: svgCheck, title: "Cierra la compra", desc: "Las firmas y la recepción están listas. Puedes cerrar la compra.", action: "Cerrar" };
        } else if (!esNuevo) {
          const firmadoOk = firmados.length > 0;
          if (!firmadoOk) {
            guide = { icon: svgDoc, title: "Sube los documentos firmados", desc: "Necesitas la requisición y la OC firmadas para cerrar.", action: "Firmados" };
          } else {
            guide = { icon: svgCheck, title: "Cierra la compra", desc: "Los documentos están firmados. Puedes cerrar la compra.", action: "Cerrar" };
          }
        }
      }
    } else if (canManage() && !gestorOk) {
      guide = { icon: svgEye, title: "Solo lectura", desc: `Esta solicitud está en proceso por ${s.gestor_por}.`, action: null };
    } else if (S.mode === "admin" || S.mode === "quality") {
      guide = { icon: svgEye, title: "Vista de solo lectura", desc: "Como administrador o Calidad puedes consultar el avance completo.", action: null };
    }

    if (!guide) return "";

    return `<div class="cp-nextguide" data-guide="${esc(JSON.stringify(guide))}">
      <div class="cp-nextguide-icon" aria-hidden="true">${guide.icon}</div>
      <div class="cp-nextguide-content">
        <span class="cp-nextguide-tag">Tu siguiente paso</span>
        <b>${esc(guide.title)}</b>
        <span>${esc(guide.desc)}</span>
      </div>
      ${guide.action ? `<button class="cp-btn primary cp-nextguide-btn" data-guide-action="${esc(guide.action)}" data-sol="${s.id}">${esc(guide.action)}</button>` : ""}
    </div>`;
  }

  function firmadosHTML(s, ctx = "sol", ctxId = null) {
    const rows = (s.firmados || []).filter(f => !String(f.tipo || "").endsWith("_generada"));
    const esNuevo = (s.flujo || "legado") === "nuevo";
    const reopen = ctxId || s.id;
    const oc = (s.documentos || []).find(d => d.tipo === "orden_compra");
    const soySolicitante = String(s.username || "") === username();
    const canCompras = canManage();
    const qualityPuede = esCalidad() && (s.tipo_compra || "normal") === "calidad" &&
      (!s.calidad_por || String(s.calidad_por) === username());
    const cerrada = ["cerrada", "cancelada"].includes(s.estado);
    const reqVigente = !!s.requisicion_firmada;
    const bossVigente = ocFirmaVigente(s, "orden_compra_firmada");
    const calidadVigente = ocFirmaVigente(s, "orden_compra_firmada_calidad");
    const sandraVigente = ocFirmaVigente(s, "orden_compra_firmada_sandra");
    const lucioVigente = ocFirmaVigente(s, "orden_compra_firmada_lucio");
    const finalVigente = ocFirmaVigente(s, OC_FINAL[0]);
    const enCurso = ["aprobada", "en_compra", "recibida", "con_incidencias", "devuelta"].includes(s.estado);
    const puedeSubirBase = esNuevo && !!oc && !cerrada && !s.cambios_oc_motivo && enCurso;
    const canReq = esNuevo && soySolicitante && !cerrada &&
      ["pendiente", "en_revision", "cambios_solicitados"].includes(s.estado);
    const canOcUser = puedeSubirBase && soySolicitante && !sandraVigente && !lucioVigente && !finalVigente;
    const canOcCalidad = puedeSubirBase && bossVigente && !calidadVigente &&
      !sandraVigente && !lucioVigente && !finalVigente && (canCompras || qualityPuede);
    const canOcSandra = puedeSubirBase && canCompras && bossVigente &&
      ((s.tipo_compra || "normal") !== "calidad" || calidadVigente) &&
      !sandraVigente && !lucioVigente && !finalVigente;
    const canOcLucio = puedeSubirBase && canCompras && bossVigente &&
      ((s.tipo_compra || "normal") !== "calidad" || calidadVigente) &&
      sandraVigente && !lucioVigente && !finalVigente;
    const canOcFinal = puedeSubirBase && canCompras && ocFirmasCompletas(s) && !finalVigente;
    const posteriores = {
      requisicion_firmada: [],
      orden_compra_firmada: ["orden_compra_firmada_calidad", "orden_compra_firmada_sandra", "orden_compra_firmada_lucio", OC_FINAL[0]],
      orden_compra_firmada_calidad: ["orden_compra_firmada_sandra", "orden_compra_firmada_lucio", OC_FINAL[0]],
      orden_compra_firmada_sandra: ["orden_compra_firmada_lucio", OC_FINAL[0]],
      orden_compra_firmada_lucio: [OC_FINAL[0]],
    };
    // Los documentos firmados ya no se pueden quitar: son evidencia permanente.
    const puedeQuitar = () => false;
    const upload = (tipo, label, enabled, hint, multiple = false, cta = "") => `<div class="cp-firm-upload">
      <div><b>${esc(label)}</b><small>${esc(hint)}</small></div>
      ${enabled ? `<label class="cp-filepick" for="cpFirmFile-${tipo}">
        <input class="cp-filepick-input" type="file" id="cpFirmFile-${tipo}" accept="application/pdf,.pdf" aria-label="${esc(label)}"${multiple ? " multiple" : ""}>
        <span class="cp-filepick-btn">Elegir PDF</span>
        <span class="cp-filepick-name">No se ha seleccionado ningún archivo</span>
      </label>
      <button class="cp-btn primary" data-firmupload data-sid="${s.id}" data-firmtype="${tipo}" data-ctx="${ctx}" data-ctxid="${reopen}">${esc(cta || `Subir ${label.toLowerCase()}`)}</button>` : ""}
    </div>`;
    const rowHTML = f => `<div class="cp-firm-row${f.vigente === false || f.vigente === 0 ? " off" : ""}">
      <div><b>${esc(firmaTipoLabel(f.tipo))}</b>
        <small>${esc(f.nombre || f.path || "")} · ${fdt(f.created_at)}${f.subido_por ? ` · Subido por ${esc(f.subido_por)}` : ""}${f.vigente === false || f.vigente === 0 ? " · Reemplazado" : ""}</small></div>
      <div class="cp-firm-actions">
        <button class="cp-pdf-btn" data-firmopen="${esc(f.path || "")}" data-name="${esc(f.nombre || "documento.pdf")}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M9 15h6"/><path d="M9 18h4"/></svg>Ver PDF</button>
        ${puedeQuitar(f) ? `<button class="cp-mini danger" data-firmdel="${f.id}" data-sid="${s.id}" data-ctx="${ctx}" data-ctxid="${reopen}">Quitar</button>` : ""}
      </div></div>`;
    const firmList = (list, empty) => list.length
      ? `<div class="cp-firm-list">${list.map(rowHTML).join("")}</div>`
      : `<p class="cp-firm-empty">${esc(empty)}</p>`;
    const block = (tipo, label, hint, enabled, enabledHint, cta) => {
      const list = rows.filter(f => f.tipo === tipo);
      const vigentes = list.filter(f => f.vigente !== false && f.vigente !== 0);
      const anteriores = list.filter(f => f.vigente === false || f.vigente === 0);
      const shown = vigentes.length ? vigentes : list;
      return `<div class="cp-firm-subblock">
        <h3 class="cp-firm-sub">${esc(label)}</h3>
        <p class="cp-muted">${esc(hint)}</p>
        ${shown.length ? `<div class="cp-firm-list">${shown.map(rowHTML).join("")}</div>` : `<p class="cp-firm-empty">Pendiente.</p>`}
        ${anteriores.length ? `<details class="cp-firm-older"><summary>${anteriores.length} versión(es) anterior(es)</summary>${anteriores.map(rowHTML).join("")}</details>` : ""}
        ${upload(tipo, label, enabled, enabledHint, false, cta)}
      </div>`;
    };
    if (esNuevo) {
      const known = ["requisicion_firmada", ...ocFirmaDefs(s).map(x => x[0]), OC_FINAL[0]];
      const otherRows = rows.filter(f => !known.includes(f.tipo));
      return `<section class="cp-sec cp-firmados">
        ${block("requisicion_firmada", "Requisición firmada", "Jefatura de área",
          canReq, reqVigente ? "Ya hay una versión vigente; sube otra para reemplazarla." : "Solo la persona solicitante puede subirla.",
          reqVigente ? "Subir nueva versión" : "")}
        ${!oc ? `<div class="cp-firm-upload"><div><b>Firmas de la OC</b><small>Disponibles cuando Compras genere la orden.</small></div></div>` : ""}
        ${oc ? block("orden_compra_firmada", "Firma del jefe de área", "Jefatura de área",
          canOcUser, bossVigente ? "Ya hay una versión vigente; si la reemplazas se invalidan las firmas posteriores." : (s.cambios_oc_motivo ? "La OC se está ajustando." : "Solo la persona solicitante puede subirla."),
          bossVigente ? "Subir nueva versión" : "Subir PDF") : ""}
        ${oc && (s.tipo_compra || "normal") === "calidad" ? block("orden_compra_firmada_calidad", "Firma de Calidad", "Calidad",
          canOcCalidad, calidadVigente ? "Ya está cargada." : !bossVigente ? "Primero la firma del jefe de área." : "Firma de Calidad.",
          calidadVigente ? "Reemplazar" : "Subir PDF") : ""}
        ${oc ? block("orden_compra_firmada_sandra", "Firma de Sandra Limones", "Sandra Limones",
          canOcSandra, sandraVigente ? "Ya está cargada." : !bossVigente ? "Primero la firma del jefe de área." : "La sube Compras.",
          sandraVigente ? "Reemplazar" : "Subir PDF") : ""}
        ${oc ? block("orden_compra_firmada_lucio", "Firma de Lucío Limones", "Lucío Limones",
          canOcLucio, lucioVigente ? "Ya está cargada." : !sandraVigente ? "Primero la firma de Sandra Limones." : "La sube Compras.",
          lucioVigente ? "Reemplazar" : "Subir PDF") : ""}
        ${oc ? block(OC_FINAL[0], OC_FINAL[1], "Compras",
          canOcFinal, finalVigente ? "Ya está cargada." : !ocFirmasCompletas(s) ? "Primero completa las firmas anteriores." : "Sube el PDF que integre todas las firmas.",
          finalVigente ? "Reemplazar" : "Subir documento final") : ""}
        ${otherRows.length ? `<h3 class="cp-firm-sub">Otros documentos</h3>${firmList(otherRows, "")}` : ""}
      </section>`;
    }
    return `<section class="cp-sec cp-firmados">
      <h3>Documentos firmados</h3>
      <p class="cp-muted">PDF firmado por cada área; obligatorio para cerrar la compra.</p>
      ${rows.length ? `<div class="cp-firm-list">${rows.map(rowHTML).join("")}</div>`
      : `<p class="cp-firm-empty">Aún no hay documentos firmados.</p>`}
      ${canCompras ? `<div class="cp-firm-upload">
        <label class="cp-filepick" for="cpFirmFile-firmado">
          <input class="cp-filepick-input" type="file" id="cpFirmFile-firmado" multiple accept="application/pdf,.pdf" aria-label="Documentos firmados en PDF">
          <span class="cp-filepick-btn">Elegir PDF</span>
          <span class="cp-filepick-name">No se ha seleccionado ningún archivo</span>
        </label>
        <button class="cp-btn primary" data-firmupload data-sid="${s.id}" data-firmtype="firmado" data-ctx="${ctx}" data-ctxid="${reopen}">Subir documentos firmados</button>
      </div>` : ""}
    </section>`;
  }

  // Versión compacta para la columna derecha del panel: muestra el estado de
  // cada firma y deja la carga en una sola línea, sin scroll ni bloques largos.
  function firmadosRailHTML(s) {
    const rows = (s.firmados || []).filter(f => !String(f.tipo || "").endsWith("_generada"));
    const esNuevo = (s.flujo || "legado") === "nuevo";
    if (!esNuevo) return firmadosHTML(s, "sol");
    const oc = (s.documentos || []).find(d => d.tipo === "orden_compra");
    const soySolicitante = String(s.username || "") === username();
    const canCompras = canManage();
    const qualityPuede = esCalidad() && (s.tipo_compra || "normal") === "calidad" &&
      (!s.calidad_por || String(s.calidad_por) === username());
    const cerrada = ["cerrada", "cancelada"].includes(s.estado);
    const reqVigente = !!s.requisicion_firmada;
    const bossVigente = ocFirmaVigente(s, "orden_compra_firmada");
    const calidadVigente = ocFirmaVigente(s, "orden_compra_firmada_calidad");
    const sandraVigente = ocFirmaVigente(s, "orden_compra_firmada_sandra");
    const lucioVigente = ocFirmaVigente(s, "orden_compra_firmada_lucio");
    const finalVigente = ocFirmaVigente(s, OC_FINAL[0]);
    const enCurso = ["aprobada", "en_compra", "recibida", "con_incidencias", "devuelta"].includes(s.estado);
    const puedeSubirBase = !!oc && !cerrada && !s.cambios_oc_motivo && enCurso;
    const canReq = soySolicitante && !cerrada &&
      ["pendiente", "en_revision", "cambios_solicitados"].includes(s.estado);
    const canOcUser = puedeSubirBase && soySolicitante && !sandraVigente && !lucioVigente && !finalVigente;
    const canOcCalidad = puedeSubirBase && bossVigente && !calidadVigente &&
      !sandraVigente && !lucioVigente && !finalVigente && (canCompras || qualityPuede);
    const canOcSandra = puedeSubirBase && canCompras && bossVigente &&
      ((s.tipo_compra || "normal") !== "calidad" || calidadVigente) &&
      !sandraVigente && !lucioVigente && !finalVigente;
    const canOcLucio = puedeSubirBase && canCompras && bossVigente &&
      ((s.tipo_compra || "normal") !== "calidad" || calidadVigente) &&
      sandraVigente && !lucioVigente && !finalVigente;
    const canOcFinal = puedeSubirBase && canCompras && ocFirmasCompletas(s) && !finalVigente;
    const posteriores = {
      requisicion_firmada: [],
      orden_compra_firmada: ["orden_compra_firmada_calidad", "orden_compra_firmada_sandra", "orden_compra_firmada_lucio", OC_FINAL[0]],
      orden_compra_firmada_calidad: ["orden_compra_firmada_sandra", "orden_compra_firmada_lucio", OC_FINAL[0]],
      orden_compra_firmada_sandra: ["orden_compra_firmada_lucio", OC_FINAL[0]],
      orden_compra_firmada_lucio: [OC_FINAL[0]],
    };
    // Los documentos firmados ya no se pueden quitar: son evidencia permanente.
    const puedeQuitar = () => false;
    const fileRow = f => `<div class="cp-firm-file${f.vigente === false || f.vigente === 0 ? " off" : ""}">
      <span class="cp-firm-file-ico">PDF</span>
      <div class="cp-firm-file-txt">
        <b title="${esc(f.nombre || f.path || "Documento firmado")}">${esc(f.nombre || f.path || "Documento firmado")}</b>
        <small>${fdt(f.created_at)}${f.subido_por ? ` · ${esc(f.subido_por)}` : ""}${f.vigente === false || f.vigente === 0 ? " · Reemplazado" : ""}</small>
      </div>
      <div class="cp-firm-file-acts">
        <button class="cp-mini" data-firmopen="${esc(f.path || "")}" data-name="${esc(f.nombre || "documento.pdf")}" title="Ver PDF">Ver</button>
        ${puedeQuitar(f) ? `<button class="cp-mini danger" data-firmdel="${f.id}" data-sid="${s.id}" data-ctx="sol" data-ctxid="${s.id}" title="Quitar este PDF">Quitar</button>` : ""}
      </div>
    </div>`;
    const block = (tipo, label, hint, enabled, enabledHint, cta) => {
      const list = rows.filter(f => f.tipo === tipo);
      const vigentes = list.filter(f => f.vigente !== false && f.vigente !== 0);
      const anteriores = list.filter(f => f.vigente === false || f.vigente === 0);
      const shown = vigentes.length ? vigentes : list;
      const listHTML = shown.length ? shown.map(fileRow).join("") : "";
      const older = anteriores.length
        ? `<details class="cp-firm-older"><summary>${anteriores.length} versión(es) anterior(es)</summary>${anteriores.map(fileRow).join("")}</details>` : "";
      const upload = enabled ? `<div class="cp-firm-upload-row">
          <label class="cp-filepick" for="cpFirmFile-${tipo}">
            <input class="cp-filepick-input" type="file" id="cpFirmFile-${tipo}" accept="application/pdf,.pdf" aria-label="${esc(label)}">
            <span class="cp-filepick-btn">Elegir PDF</span>
            <span class="cp-filepick-name">Ningún archivo</span>
          </label>
          <button class="cp-btn primary sm" data-firmupload data-sid="${s.id}" data-firmtype="${tipo}" data-ctx="sol" data-ctxid="${s.id}">${esc(cta)}</button>
        </div>` : `<p class="cp-firm-note">${esc(enabledHint)}</p>`;
      if (vigentes.length) return `<details class="cp-firm-block done cp-firm-collapsed">
        <summary>
          <span class="cp-firm-state" aria-hidden="true">✓</span>
          <div class="cp-firm-block-txt"><b>${esc(label)}<span class="cp-firm-who"> · ${esc(hint)}</span></b></div>
          <span class="cp-badge ok">Vigente</span>
          <span class="cp-firm-chev" aria-hidden="true">▾</span>
        </summary>
        <div class="cp-firm-body">${listHTML}${older}${upload}</div>
      </details>`;
      return `<div class="cp-firm-block pending">
        <div class="cp-firm-block-head">
          <span class="cp-firm-state" aria-hidden="true">•</span>
          <div class="cp-firm-block-txt"><b>${esc(label)}<span class="cp-firm-who"> · ${esc(hint)}</span></b></div>
          <span class="cp-badge warn">Pendiente</span>
        </div>
        ${listHTML}${older}${upload}
      </div>`;
    };
    const statusRow = ([tipo, label, hint]) => {
      const f = rows.find(x => x.tipo === tipo && x.vigente !== false && x.vigente !== 0);
      return `<div class="cp-firm-status${f ? " ok" : ""}">
        <span class="cp-firm-state" aria-hidden="true">${f ? "✓" : "○"}</span>
        <div class="cp-firm-status-main"><b>${esc(label)}</b><small>${f ? `Vigente · ${fdt(f.created_at)}${f.subido_por ? ` · ${esc(f.subido_por)}` : ""}` : "Pendiente"}</small></div>
        ${f ? `<button class="cp-mini" data-firmopen="${esc(f.path || "")}" data-name="${esc(f.nombre || "documento.pdf")}">Ver</button>` : ""}
      </div>`;
    };
    const statusBlock = (defs, title = "Firmas de gestión") => {
      if (!defs.length) return "";
      const hechas = defs.filter(([t]) => ocFirmaVigente(s, t)).length;
      return `<div class="cp-firm-status-wrap">
        <div class="cp-firm-status-head"><span>${esc(title)}</span><b>${hechas}/${defs.length}</b></div>
        <div class="cp-firm-status-list">${defs.map(statusRow).join("")}</div>
      </div>`;
    };
    const totalFirmas = ocFirmaDefs(s).length + 1;
    const firmasListas = (oc ? ocFirmaDefs(s).filter(([t]) => ocFirmaVigente(s, t)).length + (finalVigente ? 1 : 0) : 0);
    const head = `<div class="cp-rail-sec-head"><h3>Estado de firmas</h3><span>${firmasListas}/${totalFirmas}</span></div>`;
    if (canCompras) {
      const known = ["requisicion_firmada", ...ocFirmaDefs(s).map(x => x[0]), OC_FINAL[0]];
      const otherRows = rows.filter(f => !known.includes(f.tipo));
      return `<section class="cp-sec cp-firmados cp-firmados-rail">
        ${head}
        <p class="cp-muted">La jefatura firma primero; después Calidad (si aplica), Sandra y Lucío. El documento final integra todas las firmas.</p>
        ${block("requisicion_firmada", "Requisición firmada", "Jefatura de área",
          canReq, reqVigente ? "Ya hay una versión vigente; sube otra para reemplazarla." : "Solo la persona solicitante puede subirla.",
          reqVigente ? "Subir nueva versión" : "Subir PDF")}
        ${oc ? block("orden_compra_firmada", "Firma del jefe de área", "Jefatura de área",
          canOcUser, bossVigente ? "La sube la persona solicitante." : "La sube la persona solicitante.",
          bossVigente ? "Subir nueva versión" : "Subir PDF") : ""}        ${oc && (s.tipo_compra || "normal") === "calidad" ? block("orden_compra_firmada_calidad", "Firma de Calidad", "Calidad",
          canOcCalidad, calidadVigente ? "Ya está cargada." : !bossVigente ? "Primero la firma del jefe de área." : "Firma de Calidad.",
          calidadVigente ? "Reemplazar" : "Subir PDF") : ""}
        ${oc ? block("orden_compra_firmada_sandra", "Firma de Sandra Limones", "Sandra Limones",
          canOcSandra, sandraVigente ? "Ya está cargada." : !bossVigente ? "Primero la firma del jefe de área." : "La sube Compras.",
          sandraVigente ? "Reemplazar" : "Subir PDF") : ""}
        ${oc ? block("orden_compra_firmada_lucio", "Firma de Lucío Limones", "Lucío Limones",
          canOcLucio, lucioVigente ? "Ya está cargada." : !sandraVigente ? "Primero la firma de Sandra Limones." : "La sube Compras.",
          lucioVigente ? "Reemplazar" : "Subir PDF") : ""}
        ${oc ? block(OC_FINAL[0], OC_FINAL[1], "Compras",
          canOcFinal, finalVigente ? "Ya está cargada." : !ocFirmasCompletas(s) ? "Primero completa las firmas anteriores." : "Sube el PDF que integre todas las firmas.",
          finalVigente ? "Reemplazar" : "Subir documento final") : ""}
        ${otherRows.length ? `<div class="cp-firm-extra"><div class="cp-rail-sec-head"><h3>Otros documentos</h3></div>${otherRows.map(fileRow).join("")}</div>` : ""}
      </section>`;
    }
    if (soySolicitante) {
      return `<section class="cp-sec cp-firmados cp-firmados-rail">
        ${head}
        ${block("requisicion_firmada", "Requisición firmada", "Jefatura de área",
          canReq, reqVigente ? "Ya hay una versión vigente; sube otra para reemplazarla." : "Solo la persona solicitante puede subirla.",
          reqVigente ? "Subir nueva versión" : "Subir PDF")}
        ${oc ? block("orden_compra_firmada", "Firma del jefe de área", "Jefatura de área",
          canOcUser, !canOcUser ? "Compras ya comenzó las firmas de gestión." : bossVigente ? "Ya está cargada; puedes reemplazarla antes de que Compras continúe." : "Solo necesitas esta firma.",
          bossVigente ? "Subir nueva versión" : "Subir PDF") : ""}
        ${oc ? statusBlock([...ocFirmaDefs(s).filter(([t]) => t !== "orden_compra_firmada"), OC_FINAL]) : ""}
        <p class="cp-firm-note">${oc
          ? (bossVigente ? "Tu parte está completa. Compras recabará las firmas de Sandra, Lucío y el documento final." : "Tu única tarea es subir la firma del jefe de área.")
          : "Las firmas de la OC aparecerán cuando Compras genere la orden."}</p>
      </section>`;
    }
    const shownStatus = oc ? statusBlock([
      ...ocFirmaDefs(s).filter(([t]) => !((s.tipo_compra || "normal") === "calidad" && t === "orden_compra_firmada_calidad")),
      OC_FINAL,
    ]) : "";
    return `<section class="cp-sec cp-firmados cp-firmados-rail">
      ${head}
      ${oc && (s.tipo_compra || "normal") === "calidad" ? block("orden_compra_firmada_calidad", "Firma de Calidad", "Calidad",
        canOcCalidad, calidadVigente ? "Ya está cargada." : !bossVigente ? "Primero la firma del jefe de área." : "Firma de Calidad.",
        calidadVigente ? "Reemplazar" : "Subir PDF") : ""}
      ${shownStatus || `<p class="cp-firm-note">La OC aún no se ha generado.</p>`}
      ${canCompras ? "" : `<p class="cp-firm-note">Las firmas de gestión las administra Compras.</p>`}
    </section>`;
  }

  function firmadoUrl(path) {
    return API() + "/api/compras/firmados/" + encodeURIComponent(path);
  }

  async function uploadFirmados(sid, ctx = "sol", ctxId = null, tipo = "firmado") {
    const input = $(`#cpFirmFile-${tipo}`, S.root);
    const files = [...(input?.files || [])];
    if (!files.length) return toast("Selecciona un archivo", "Elige el PDF del documento firmado.", "error");
    if (files.some(f => !/\.pdf$/i.test(f.name || ""))) {
      return toast("Formato no permitido", "Los documentos firmados deben ser PDF.", "error");
    }
    if (tipo !== "firmado" && files.length > 1) {
      return toast("Un solo archivo", "Sube un único PDF con todas las páginas firmadas.", "error");
    }
    const fd = new FormData();
    fd.append("tipo", tipo);
    files.forEach(f => fd.append("archivos", f, f.name));
    try {
      const saved = await api(`/api/compras/solicitudes/${sid}/firmados`, { method: "POST", body: fd });
      const mensajes = {
        requisicion_firmada: "La requisición firmada quedó registrada y la solicitud pasó a revisión.",
        orden_compra_firmada: "La firma del jefe de área quedó registrada. Compras continúa con las firmas de gestión.",
        orden_compra_firmada_calidad: "La firma de Calidad quedó registrada. Continúa la firma de Sandra Limones.",
        orden_compra_firmada_sandra: "La firma de Sandra Limones quedó registrada. Continúa la firma de Lucío Limones.",
        orden_compra_firmada_lucio: "La firma de Lucío Limones quedó registrada. Falta el documento final con todas las firmas.",
        orden_compra_firmada_final: "El documento final con todas las firmas quedó registrado. Ya puedes registrar la recepción y cerrar.",
      };
      toast("Documento guardado", mensajes[tipo] || "La orden firmada quedó registrada.", "success");
      await refresh(true);
      if (ctx === "doc" && ctxId) await openDocDetalle(ctxId);
      else await openSolicitud(sid);
      // Vista previa inmediata del PDF que se acaba de subir.
      const last = Array.isArray(saved) ? saved[saved.length - 1] : null;
      if (last?.path && window.SylpackPreview) {
        setTimeout(() => window.SylpackPreview.open(
          last.path, last.nombre || "Documento firmado.pdf",
          { url: firmadoUrl(last.path), pdf: true }), 120);
      }
    } catch (e) { toast("No se pudo subir", e.message, "error"); }
  }

  async function downloadFirmado(path, name) {
    const label = name || "documento.pdf";
    const url = firmadoUrl(path);
    if (window.SylpackPreview) return window.SylpackPreview.open(path, label, { url, pdf: true });
    try {
      const r = await fetch(url, { headers: { Authorization: "Bearer " + token() } });
      if (!r.ok) throw new Error("No se pudo descargar");
      const blob = await r.blob();
      const obj = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = obj;
      a.download = label;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(obj), 4000);
    } catch (e) { toast("No se pudo descargar", e.message, "error"); }
  }

  async function generarPdfDigital(id) {
    if (!id) return;
    toast("Generando PDF digital", "Se guardará en el expediente con enlaces, imágenes y variantes.", "info");
    try {
      const d = await api(`/api/compras/documentos/${id}/pdf`, { method: "POST" });
      const tipo = d.tipo === "requisicion" ? "requisicion_generada" : "orden_compra_generada";
      const gen = (d.firmados || []).find(f => f.tipo === tipo && esFirmaVigente(f));
      if (!gen) throw new Error("El servidor no devolvió el PDF generado");
      toast("PDF digital listo", "Guardado en la base de datos con enlaces, imágenes y variantes.");
      await refresh(true).catch(() => {});
      if (S.currentDoc && String(S.currentDoc.id) === String(id)) await openDocDetalle(id);
      await downloadFirmado(gen.path, gen.nombre);
    } catch (e) {
      toast("No se pudo generar", e.message, "error");
    }
  }

  async function deleteFirmado(aid, sid, ctx = "sol", ctxId = null) {
    if (!(await confirmar("Quitar documento", "¿Quitar este documento firmado?", true))) return;
    try {
      await api("/api/compras/firmados/id/" + aid, { method: "DELETE" });
      await refresh(true);
      if (ctx === "doc" && ctxId) await openDocDetalle(ctxId);
      else await openSolicitud(sid);
    } catch (e) { toast("No se pudo quitar", e.message, "error"); }
  }

  function eventLabel(t) {
    const m = {
      // Solicitud
      creada: "Solicitud creada", editada: "Solicitud editada",
      reenviada: "Solicitud corregida y reenviada",
      tomar: "Tomada para revisión", solicitar_cambios: "Cambios solicitados",
      aprobar: "Solicitud aprobada", rechazar: "Solicitud rechazada",
      cancelar: "Cancelada", reabrir: "Reabierta", cerrar: "Compra cerrada",
      // Documentos
      documento_creado: "Documento generado", documento_editado: "Documento editado",
      emitir: "Documento emitido", autorizar: "Orden autorizada",
      enviar: "Enviada al proveedor", pdf_generado: "PDF digital generado",
      requisicion_creada: "Requisición generada",
      orden_compra_creada: "Orden de compra generada",
      solicitar_cambios_oc: "Cambios solicitados a la orden de compra",
      orden_compra_cancelada: "Orden de compra cancelada para ajuste",
      // Firmas
      firmados: "Documentos firmados cargados",
      firmado_eliminado: "Documento firmado retirado",
      firmados_invalidados: "Firmas invalidadas por cambios",
      firmado_requisicion_firmada: "Requisición firmada por la jefatura",
      firmado_orden_compra_firmada: "OC firmada por la jefatura de área",
      firmado_orden_compra_firmada_calidad: "OC firmada por Calidad",
      firmado_orden_compra_firmada_sandra: "OC firmada por Sandra Limones",
      firmado_orden_compra_firmada_lucio: "OC firmada por Lucío Limones",
      firmado_orden_compra_firmada_final: "Documento final de la OC",
      // Recepción y devoluciones
      recepcion: "Recepción registrada", devolucion: "Devolución registrada",
      devolucion_aprobar: "Devolución aprobada", devolucion_rechazar: "Devolución rechazada",
      devolucion_enviar: "Devolución enviada", devolucion_reembolsar: "Devolución reembolsada",
      devolucion_cerrar: "Devolución cerrada",
      // Calidad
      calidad_aprobar: "Calidad aprobó las opciones",
      calidad_rechazar: "Calidad rechazó las opciones",
      calidad_solicitar_cambios: "Calidad pidió cambios",
      calidad_reiniciada: "Revisión de Calidad reiniciada",
      // Catálogo e inventario por área
      catalogo_alta: "Registro dado de alta en el catálogo",
      catalogo_edicion: "Registro del catálogo editado",
      catalogo_baja: "Registro dado de baja del catálogo",
      inventario_alta: "Producto agregado al inventario",
      inventario_edicion: "Producto del inventario actualizado",
      inventario_baja: "Producto retirado del inventario",
    };
    return m[t] || t;
  }

  /* =====================  DOCUMENTO: DETALLE  ===================== */
  async function openDocDetalle(id) {
    try {
      const d = await api("/api/compras/documentos/" + id);
      // Fetch company data for document letterhead
      let empresa = null;
      try {
        empresa = await api("/api/compras/empresa");
      } catch (e) {
        empresa = {
          nombre: "Sylpack",
          rfc: "SYLP123456ABC",
          razon_social: "Sylpack S.A. de C.V.",
          logo: "assets/logo-sylpack.png"
        };
        console.warn("Could not load company data for document:", e);
      }
      S.currentDoc = d;
      S.currentEmpresa = empresa;
      const gestorOk = !d.solicitud?.gestor_por || String(d.solicitud.gestor_por) === username();
      const canManageThis = canManage() && gestorOk;
      const baseReqItems = d.solicitud?.items || [];
      const items = (d.items || []).map((it, i) => {
        const base = baseReqItems.find(x => String(x.id) === String(it.item_id))
          || (baseReqItems[i] || {});
        const ops = base.opciones || [];
        const variantes = ops.length ? `<div class="cp-doc-variants">
          <span class="cp-doc-variants-title">${ops.length} variante${ops.length === 1 ? "" : "s"} cotizada${ops.length === 1 ? "" : "s"}</span>
          <ul>${ops.map((o, k) => {
            const costo = Number(o.costo_unitario) || 0;
            const imp = costo ? costo * (Number(it.cantidad) || 0) : 0;
            const aprobada = o.calidad_aprobada === true || o.calidad_aprobada === 1;
            return `<li><b>${esc(o.etiqueta || `Variante ${k + 1}`)}</b>
              ${o.proveedor ? `<span>${esc(o.proveedor)}</span>` : ""}
              ${o.diferencia ? `<span>${esc(o.diferencia)}</span>` : ""}
              <span class="num">${costo ? `${money(costo)} ${o.precio_incluye_iva ? "IVA incl." : "+ IVA"}${imp ? ` · Importe ${money(imp)}` : ""}` : "Costo pendiente"}</span>
              ${aprobada ? `<span class="cp-badge ok">Calidad ✓</span>` : ""}</li>`;
          }).join("")}</ul>
        </div>` : "";
        return `<tr>
        <td>${i + 1}</td>
        <td class="num">${qty(it.cantidad)} ${esc(it.unidad)}</td>
        <td>${it.id_fabricacion ? `<span class="cp-code">${esc(it.id_fabricacion)}</span>` : "—"}</td>
        <td><b>${esc(it.nombre)}</b>${it.descripcion ? `<small class="cp-block">${nl2br(it.descripcion)}</small>` : ""}${variantes}</td>
        <td class="num">${it.fecha_llegada ? fdate(it.fecha_llegada) : "—"}</td>
        <td class="num">${money(it.costo_unitario)}${Number(it.precio_incluye_iva) ? `<small class="cp-costiva">IVA incl.</small>` : ""}</td>
        <td class="num">${money(it.importe)}</td>
      </tr>`;
      }).join("");
      // Acciones principales visibles y el resto agrupado para no saturar el pie.
      const acts = [
        `<button class="cp-btn primary" data-opendoc="${d.id}">Ver documento</button>`,
        `<button class="cp-btn" data-printdoc="${d.id}">Imprimir</button>`,
      ];
      const more = [];
      if (canManageThis) {
        const esNuevo = d.solicitud?.flujo === "nuevo";
        const reqFirmada = !!d.solicitud?.requisicion_firmada;
        const ocFirmada = !!d.solicitud?.orden_compra_firmada;
        if (d.estado === "borrador") more.push(`<button class="cp-btn" data-docact="emitir" data-id="${d.id}">Emitir</button>`);
        if (d.estado === "emitida") {
          if (esNuevo && d.tipo !== "orden_compra") {
            // La requisición del flujo nuevo se sube firmada, no se autoriza.
          } else if (esNuevo && (!reqFirmada || !ocFirmada)) {
            more.push(`<span class="cp-blockhint">${!reqFirmada ? "Falta subir la requisición firmada" : "Falta subir la OC firmada por la jefatura"}</span>`);
          } else {
            more.push(`<button class="cp-btn ok" data-docact="autorizar" data-id="${d.id}">Autorizar</button>`);
          }
        }
        if (d.estado === "autorizada" && (!esNuevo || ocFirmada)) more.push(`<button class="cp-btn" data-docact="enviar" data-id="${d.id}">Marcar enviada</button>`);
        if (["autorizada", "enviada"].includes(d.estado) && (!esNuevo || ocFirmada)) more.push(`<button class="cp-btn ok" data-recdoc="${d.id}">Registrar recepción</button>`);
        if (d.estado === "recibida") more.push(`<button class="cp-btn danger" data-devledoc="${d.id}">Registrar devolución</button>`);
        if (["recibida", "enviada", "autorizada"].includes(d.estado)) {
          const firmadoOk = (d.solicitud?.flujo === "nuevo")
            ? !!(d.solicitud?.orden_compra_firmada && d.solicitud?.orden_compra_firmada_final)
            : !!(d.firmados || []).length;
          // Sin disabled: si falta la firma, al pulsar se explica qué hacer.
          more.push(`<button class="cp-btn" data-docact="cerrar" data-id="${d.id}" data-needfirma="${firmadoOk ? "" : "1"}">Cerrar compra</button>`);
        }
        if (!["recibida", "cerrada", "cancelada"].includes(d.estado)) more.push(`<button class="cp-btn danger" data-docact="cancelar" data-id="${d.id}">Cancelar documento</button>`);
        if (d.tipo === "requisicion" && d.estado !== "cancelada") more.push(`<button class="cp-btn" data-newdoc="${d.solicitud_id}" data-tipo="orden_compra">Convertir a orden de compra</button>`);
      }
      const moreHTML = more.length ? `<details class="cp-more"><summary class="cp-btn ghost">Más opciones</summary><div class="cp-more-menu">${more.join("")}</div></details>` : "";
      const recs = (d.recepciones || []).map(r => `<div class="cp-timeline-row"><span class="cp-dot ok"></span><div>
        <b>${esc(r.folio || "Recepción")}</b> ${badge(EST_REC, r.estado)}<small>${fdate(r.fecha)} · ${esc(r.recibido_por || "")}</small>
        ${(r.items || []).length ? `<ul class="cp-mini-list">${r.items.map(x => `<li>${esc(x.item_nombre || "Partida")}: ${qty(x.cantidad)} ${x.estado !== "ok" ? `· <b>${esc(x.estado)}</b>` : ""}</li>`).join("")}</ul>` : ""}
        ${r.notas ? `<p>${nl2br(r.notas)}</p>` : ""}</div></div>`).join("");
      const devs = (d.devoluciones || []).map(x => `<div class="cp-timeline-row"><span class="cp-dot danger"></span><div>
        <b>${esc(x.folio || "Devolución")}</b> ${badge(EST_DEV, x.estado)}<small>${fdt(x.created_at)}</small><p>${nl2br(x.motivo || "")}</p>
        ${canManageThis && ["solicitada", "aprobada", "enviada", "reembolsada"].includes(x.estado) ? `<div class="cp-inline-actions">
          ${x.estado === "solicitada" ? `<button class="cp-mini" data-devact="aprobar" data-id="${x.id}" data-devctx="${d.id}">Aprobar</button><button class="cp-mini" data-devact="rechazar" data-id="${x.id}" data-devctx="${d.id}">Rechazar</button>` : ""}
          ${x.estado === "aprobada" ? `<button class="cp-mini" data-devact="enviar" data-id="${x.id}" data-devctx="${d.id}">Enviar</button>` : ""}
          ${x.estado === "enviada" ? `<button class="cp-mini ok" data-devact="reembolsar" data-id="${x.id}" data-devctx="${d.id}">Reembolsada</button>` : ""}
          <button class="cp-mini" data-devact="cerrar" data-id="${x.id}" data-devctx="${d.id}"${(d.firmados || []).length ? "" : ` disabled title="Primero sube los documentos firmados"`}>Cerrar</button></div>` : ""}
        </div></div>`).join("");
      const evs = (d.eventos || []).map(e => `<div class="cp-timeline-row"><span class="cp-dot"></span><div>
        <b>${esc(eventLabel(e.tipo))}</b><small>${fdt(e.created_at)} · ${esc(e.por || "")}</small>
        ${e.nota ? `<p>${nl2br(e.nota)}</p>` : ""}</div></div>`).join("");

      showOverlay(`<div class="cp-veil" data-close></div>
        <aside class="cp-drawer" data-drawer="doc" role="dialog" aria-label="Documento ${esc(d.folio)}">
          <header class="cp-drawer-head"><div>
            <span class="cp-folio">${esc(d.folio)}</span>
            <h2>${d.tipo === "requisicion" ? "Requisición de material" : "Orden de compra"}</h2>
            <p>${esc(d.solicitud?.folio || "")} · ${esc(d.solicitud?.titulo || "")} · ${fdate(d.fecha)}</p>
          </div><button class="cp-x" data-close aria-label="Cerrar">&times;</button></header>
          <div class="cp-drawer-body">
            <div class="cp-statusbar">${badge(EST_DOC, d.estado)}<span class="cp-total">Total <b>${money(d.total)}</b></span>
            </div>
            ${d.solicitud?.gestor_por && viewAll() ? `<div class="cp-alert info"><b>En proceso por ${esc(d.solicitud.gestor_por)}.</b><p>${canManageThis ? "Tú tienes asignada esta solicitud." : "Solo la persona asignada puede modificarla; las demás cuentas tienen acceso de lectura."}</p></div>` : ""}
            <div data-doc-stepper>${d.solicitud?.estado ? stepperHTML(d.solicitud.estado) : ""}</div>
            <!-- Encabezado fiscal del documento -->
            <div class="cp-letterhead">
              <img class="cp-lh-logo" src="assets/logo-sylpack.png" alt="Sylpack" onerror="this.onerror=null;this.src='https://res.cloudinary.com/dpvm2gro2/image/upload/v1790961568/favicon_huka8c.png'" />
              <div class="cp-lh-empresa">
                <b>${esc(S.currentEmpresa.razon_social || S.currentEmpresa.nombre || "Sylpack")}</b>
                <small>RFC: ${esc(S.currentEmpresa.rfc || "—")}</small>
                ${S.currentEmpresa.domicilio ? `<small>${esc(S.currentEmpresa.domicilio)}</small>` : ""}
                ${S.currentEmpresa.telefono || S.currentEmpresa.email ? `<small>${esc([S.currentEmpresa.telefono, S.currentEmpresa.email].filter(Boolean).join(" · "))}</small>` : ""}
              </div>
              <div class="cp-lh-doc">
                <span>${d.tipo === "requisicion" ? "Requisición de material" : "Orden de compra"}</span>
                <b>${esc(d.folio)}</b>
                <small>${fdate(d.fecha)}</small>
              </div>
            </div>
            <div class="cp-summary">
              <div><span>Proveedor</span><b>${esc(d.proveedor_nombre || "—")}</b><small>${esc(d.proveedor_rfc || "")}</small></div>
              <div><span>Solicitó</span><b>${esc(d.solicitud?.username || "—")}</b><small>${esc(d.solicitud?.user_area || "")}</small></div>
              <div><span>Elaboró</span><b>${esc(d.elaborado_por || "—")}</b><small>${fdt(d.created_at)}</small></div>
              <div><span>Autorizó</span><b>${esc(d.autorizado_por || "Pendiente")}</b><small>${d.autorizado_at ? fdt(d.autorizado_at) : ""}</small></div>
              ${d.tipo === "orden_compra" && d.fecha_entrega ? `<div><span>Entrega</span><b>${fdate(d.fecha_entrega)}</b><small>${d.misma_fecha_entrega ? "Todos los productos" : "Fechas por producto"}</small></div>` : ""}
            </div>
            <section class="cp-sec"><h3>Partidas</h3><div class="cp-tablewrap"><table class="cp-table"><thead><tr><th>#</th><th>Cantidad</th><th>ID fabricación</th><th>Descripción</th><th class="num">Llegada</th><th class="num">Costo unit.</th><th class="num">Importe</th></tr></thead><tbody>${items}</tbody></table></div>
              <div class="cp-totals"><div><span>${d.iva_modo === "incluido" ? "Subtotal (IVA incluido)" : "Subtotal"}</span><b>${money(d.subtotal)}</b></div>
              ${(Number(d.descuento_pct) || 0) ? `<div><span>Descuento (${Number(d.descuento_pct) || 0}%)</span><b>- ${money((Number(d.subtotal) || 0) * (Number(d.descuento_pct) || 0) / 100)}</b></div>` : ""}
              ${(() => {
                const sub = Number(d.subtotal) || 0;
                const dp = Number(d.descuento_pct) || 0;
                const base = sub - sub * dp / 100;
                const iva = d.iva_monto != null ? Math.max(0, Number(d.iva_monto) || 0) : Math.max(0, (Number(d.total) || 0) - base);
                return iva > 0.004 ? `<div><span>${d.iva_modo === "mixto" ? "IVA (partidas sin IVA incluido)" : `IVA (${Number(d.iva_pct) || 0}%)`}</span><b>${money(iva)}</b></div>` : "";
              })()}
              <div class="tot"><span>Total</span><b>${money(d.total)}</b></div>
              ${d.iva_modo === "incluido" ? `<div class="cp-iva-note">Los precios ya incluyen IVA; no se agrega IVA adicional.</div>` : ""}</div>
            </section>
            ${d.condiciones ? `<section class="cp-sec"><h3>Condiciones</h3><p>${nl2br(d.condiciones)}</p></section>` : ""}
            ${d.notas ? `<section class="cp-sec"><h3>Notas</h3><p>${nl2br(d.notas)}</p></section>` : ""}
            ${recs ? `<section class="cp-sec"><h3>Recepciones</h3>${recs}</section>` : ""}
            ${devs ? `<section class="cp-sec"><h3>Devoluciones</h3>${devs}</section>` : ""}
            ${firmadosHTML({ ...(d.solicitud || {}), id: d.solicitud_id || d.solicitud?.id, documentos: (d.solicitud?.documentos?.length ? d.solicitud.documentos : [d]), firmados: d.firmados || [] }, "doc", d.id)}
            <section class="cp-sec"><h3>Historial</h3><div class="cp-timeline">${evs || `<p class="cp-muted">Sin movimientos.</p>`}</div></section>
          </div>
          <footer class="cp-drawer-foot">${d.solicitud_id ? `<button class="cp-btn subtle" data-trace="${d.solicitud_id}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>Ver detalles</button>` : ""}${acts.join("")}${moreHTML}<button class="cp-btn ghost" data-close>Cerrar panel</button></footer>
        </aside>`);
    } catch (e) { toast("No se pudo abrir", e.message, "error"); }
  }

  /* =====================  FORM: SOLICITUD  ===================== */
  function unitOptions(cur) {
    return ["pza", "kg", "g", "L", "ml", "m", "caja", "bolsa", "rollo", "juego", "servicio"]
      .map(u => `<option value="${u}"${u === (cur || "pza") ? " selected" : ""}>${u}</option>`).join("");
  }

  function optionRowHTML(op = {}) {
    return `<div class="cp-optrow" data-opt>
      <div class="cp-opt-head">
        <b>Opción</b>
        ${op.calidad_aprobada ? `<span class="cp-badge ok">Aprobada por Calidad</span>` : ""}
        <button type="button" class="cp-ir-remove" data-remove-option>Quitar</button>
      </div>
      <div class="cp-optgrid">
        <label class="cp-f"><span>Nombre de la opción <b class="cp-req">*</b></span><input data-of="etiqueta" maxlength="120" value="${esc(op.etiqueta || "")}" placeholder="Ej. Segunda opción, opción económica"></label>
        <label class="cp-f"><span>Diferencia</span><input data-of="diferencia" maxlength="400" value="${esc(op.diferencia || "")}" placeholder="Ej. presentación de 1 kg, envío gratis"></label>
        <label class="cp-f"><span>Proveedor</span><input data-of="proveedor" maxlength="180" value="${esc(op.proveedor || "")}" placeholder="Nombre del proveedor"></label>
        <label class="cp-f"><span>Costo unitario</span><span class="cp-money"><i>$</i><input type="number" min="0" max="1000000" step="0.01" data-of="costo_unitario" value="${esc(op.costo_unitario ?? 0)}" placeholder="0.00"></span></label>
        <label class="cp-f"><span>IVA</span><select data-of="precio_incluye_iva">
          <option value="0"${Number(op.precio_incluye_iva) ? "" : " selected"}>Se agrega</option>
          <option value="1"${Number(op.precio_incluye_iva) ? " selected" : ""}>Incluido</option>
        </select></label>
        <label class="cp-f span2"><span>Enlace</span><input data-of="link" maxlength="800" value="${esc(op.link || "")}" placeholder="https://..."></label>
        <div class="cp-linkprev-wrap span2">
          <div class="cp-linkprev" data-optprev><span class="cp-linkprev-hint">Pega el enlace del producto y aquí verás su imagen.</span></div>
        </div>
        <input type="hidden" data-of="imagen" value="${esc(op.imagen || "")}">
      </div>
    </div>`;
  }

  function processHTML() {
    return `<div class="cp-process" id="cpProcess" role="list" aria-label="Cómo funciona la solicitud de compra">
      <div class="cp-process-head">
        <div>
          <span class="cp-process-kicker">Ruta de la compra</span>
          <b>De la solicitud al cierre</b>
        </div>
        <span class="cp-process-count">${PROCESS_STEPS.length} pasos</span>
      </div>
      <div class="cp-process-track">
        ${PROCESS_STEPS.map(([title, who, desc], i) => `<div class="cp-pstep${i === 0 ? " on" : ""}" data-pstep="${i}" role="listitem">
          <span class="cp-pstep-rail" aria-hidden="true"><span class="cp-pstep-num">${i + 1}</span></span>
          <div class="cp-pstep-copy">
            <div class="cp-pstep-head"><b>${esc(title)}</b><em>${esc(who)}</em></div>
            <p class="cp-pstep-desc">${esc(desc)}</p>
          </div>
        </div>`).join("")}
      </div>
      <div class="cp-process-ends">
        <span><i aria-hidden="true"></i>Inicio: tú solicitas</span>
        <span><i aria-hidden="true"></i>Fin: compra recibida y firmada</span>
      </div>
    </div>`;
  }

  const PLACEHOLDERS = {
    cpOcRfc: "Ej. EBA230101AB1",
    cpOcRazon: "Razón social de Sylpack",
    cpOcProvNombre: "Ej. Distribuidora del Norte",
    cpOcProvRfc: "Ej. EBA230101AB1",
    cpOcProvRazon: "Razón social del proveedor",
    cpOcProvContacto: "Nombre de la persona de contacto",
    cpOcProvEmail: "ventas@proveedor.com",
    cpOcProvTel: "10 dígitos",
    cpOcProvCond: "Ej. Pago a 30 días",
    cpOcProvDomicilio: "Calle, número, colonia, ciudad",
    cpOcStore: "Ej. Amazon México, Mercado Libre, tienda local",
    cpOcDesc: "0",
    cpOcAlmacen: "Ej. Almacén central",
    cpOcCond: "Ej. Entrega en 5 días hábiles",
    cpOcNotas: "Observaciones para el proveedor o el expediente",
    cpPropNombre: "Ej. Distribuidora del Norte",
    cpPropRfc: "Ej. EBA230101AB1",
    cpPropContacto: "Nombre de la persona de contacto",
    cpPropEmail: "ventas@proveedor.com",
    cpPropTelefono: "10 dígitos",
    cpPropDomicilio: "Calle, número, colonia, ciudad",
    cpProvNombre: "Ej. Empaques del Bajío",
    cpProvRfc: "Ej. EBA230101AB1",
    cpDocProvNombre: "Ej. Distribuidora del Norte",
    cpDocProvRfc: "Ej. EBA230101AB1",
    cpDocProvRazon: "Razón social del proveedor",
    cpDocProvDomicilio: "Calle, número, colonia, ciudad",
    cpDevMotivo: "Ej. Producto dañado, no cumple especificaciones",
    cpDevNotas: "Reposición, nota de crédito o reembolso",
  };
  const PH_BY_FIELD = {
    nombre: "Ej. Bolsa kraft de 250 g para empaque",
    cantidad: "Ej. 10",
    costo_unitario: "0.00",
    motivo: "Ej. Se agotó el material y se detiene la línea de empaque.",
    descripcion: "Medidas, color, material, presentación",
    requisitos_calidad: "Certificados, norma, tolerancias, empaque",
    id_fabricacion: "Código interno, si lo tienes",
    proveedor: "Nombre del proveedor, si ya lo sabes",
    etiqueta: "Ej. Segunda opción, opción económica",
    diferencia: "Ej. presentación de 1 kg, envío gratis",
  };

  function applyPlaceholders(scope) {
    if (!scope) return;
    $$("input, textarea", scope).forEach(el => {
      const type = (el.type || "").toLowerCase();
      if (["hidden", "checkbox", "radio", "file", "date", "submit", "button"].includes(type)) return;
      if (el.hasAttribute("placeholder") && el.getAttribute("placeholder").trim()) return;
      const field = el.dataset.f || el.dataset.of || "";
      let ph = PLACEHOLDERS[el.id] || PH_BY_FIELD[field] || "";
      if (!ph) {
        const label = el.closest("label")?.querySelector("span");
        const text = (label?.textContent || "").replace(/[*()]/g, " ").replace(/\s+/g, " ").trim();
        if (type === "email") ph = "correo@ejemplo.com";
        else if (type === "tel") ph = "10 dígitos";
        else if (type === "url") ph = "https://...";
        else if (type === "number") ph = "0.00";
        else if (text) ph = `Escribe ${text.charAt(0).toLowerCase()}${text.slice(1)}`;
      }
      if (ph) el.placeholder = ph;
    });
  }

  function syncItemOrderLabels(scope = S.root) {
    if (!scope) return;
    $$("#cpSolItems .cp-itemrow", scope).forEach((row, i) => {
      const label = $(".cp-ir-label", row);
      if (label) label.textContent = `Producto ${i + 1}`;
      const badgeEl = $(".cp-ir-badge", row);
      if (badgeEl) badgeEl.textContent = String(i + 1);
      const prio = $(".cp-ir-prio", row);
      if (prio) prio.textContent = i === 0 ? "Prioridad 1 · se compra primero" : `Prioridad ${i + 1}`;
    });
  }

  function updateMoveButtons(scope = S.root) {
    if (!scope) return;
    syncItemOrderLabels(scope);
    const items = $$("#cpSolItems .cp-itemrow", scope);
    items.forEach((row, i) => {
      [
        ["[data-move-up]", i === 0, "Ya es el producto con mayor prioridad", "Subir prioridad: este producto se comprará antes"],
        ["[data-move-down]", i === items.length - 1, "Ya es el producto con menor prioridad", "Bajar prioridad: este producto se comprará después"],
      ].forEach(([sel, edge, edgeTitle, normalTitle]) => {
        const btn = $(sel, row);
        if (!btn) return;
        btn.style.visibility = "visible";
        btn.disabled = edge;
        btn.classList.toggle("edge", edge);
        btn.title = edge ? edgeTitle : normalTitle;
      });
    });
    const sums = $$(".cp-sumrow", scope);
    sums.forEach((row, i) => {
      [
        ["[data-sum-move='-1']", i === 0, "Ya es el producto con mayor prioridad", "Subir prioridad: se comprará antes"],
        ["[data-sum-move='1']", i === sums.length - 1, "Ya es el producto con menor prioridad", "Bajar prioridad: se comprará después"],
      ].forEach(([sel, edge, edgeTitle, normalTitle]) => {
        const btn = $(sel, row);
        if (!btn) return;
        btn.style.visibility = "visible";
        btn.disabled = edge;
        btn.classList.toggle("edge", edge);
        btn.title = edge ? edgeTitle : normalTitle;
      });
    });
  }

  function itemRowHTML(i, it = {}) {
    const abrirDetalles = !!(it.id_fabricacion || it.proveedor || it.descripcion || it.requisitos_calidad);
    const ops = it.opciones || [];
    return `<div class="cp-itemrow" data-row="${i}">
      <div class="cp-ir-head">
        <div class="cp-ir-title">
          <span class="cp-ir-badge">${i + 1}</span>
          <span class="cp-ir-titlecopy">
            <span class="cp-ir-label">Producto ${i + 1}</span>
            <small class="cp-ir-prio">${i === 0 ? "Prioridad 1 · se compra primero" : `Prioridad ${i + 1}`}</small>
          </span>
        </div>
        <span class="cp-ir-tools">
          <button type="button" class="cp-ir-move up" data-move-up title="Subir prioridad: este producto se comprará antes" aria-label="Subir prioridad de este producto">
            <span class="cp-move-ico" aria-hidden="true">↑</span><span>Subir</span>
          </button>
          <button type="button" class="cp-ir-move down" data-move-down title="Bajar prioridad: este producto se comprará después" aria-label="Bajar prioridad de este producto">
            <span class="cp-move-ico" aria-hidden="true">↓</span><span>Bajar</span>
          </button>
          <button type="button" class="cp-ir-remove" data-remove-item>Quitar</button>
        </span>
      </div>
      <div class="cp-formgrid">
        <label class="cp-f span2"><span>¿Qué producto o material? <b class="cp-req">*</b></span><input data-f="nombre" list="cpCertProducts" maxlength="180" value="${esc(it.nombre || "")}" placeholder="Ej. Bolsa kraft de 250 g para empaque">
          ${it.certificado ? `<small class="cp-cert-tag">✓ Producto certificado por Calidad</small>` : ""}</label>
        <label class="cp-f span2"><span>¿Para qué lo necesitas? <small>(un solo motivo para este producto y todas sus variantes)</small></span>
          <input data-f="motivo" maxlength="1000" value="${esc(it.motivo || it.para_que || "")}" placeholder="Ej. Se agotó el material y se detiene la línea de empaque.">
          <small>Ayuda a Compras a priorizar y a autorizar más rápido.</small></label>
        <label class="cp-f"><span>¿Cuántos? <b class="cp-req">*</b></span><input type="number" min="0.01" max="1000000" step="0.01" data-f="cantidad" value="${esc(it.cantidad ?? 1)}"></label>
        <label class="cp-f"><span>Unidad</span><select data-f="unidad">${unitOptions(it.unidad)}</select></label>
        <label class="cp-f"><span>Costo aprox. por unidad <small>(opcional)</small></span><span class="cp-money"><i>$</i><input type="number" min="0" max="1000000" step="0.01" data-f="costo_unitario" value="${esc(it.costo_unitario ?? 0)}" placeholder="0.00"></span></label>
        <label class="cp-f"><span>¿Ese precio incluye IVA?</span><select data-f="precio_incluye_iva">
          <option value="0"${Number(it.precio_incluye_iva) ? "" : " selected"}>No, el IVA se agrega</option>
          <option value="1"${Number(it.precio_incluye_iva) ? " selected" : ""}>Sí, ya lo incluye</option>
        </select></label>
        <label class="cp-f span2"><span>Enlace <small>(opcional)</small></span><input data-f="link" maxlength="800" value="${esc(it.link || "")}" placeholder="Pega el enlace de Mercado Libre, Amazon, Temu o cualquier tienda"></label>
        <div class="cp-linkprev-wrap span2">
          <div class="cp-linkprev" data-linkprev><span class="cp-linkprev-hint">Pega el enlace del producto y aquí verás su imagen.</span></div>
        </div>
        <input type="hidden" data-f="imagen" value="${esc(it.imagen || "")}">
      </div>
      <details class="cp-adv"${abrirDetalles ? " open" : ""}>
        <summary>Más detalles <small>(opcional)</small></summary>
        <div class="cp-formgrid">
          <label class="cp-f"><span>ID de fabricación</span><input data-f="id_fabricacion" maxlength="120" data-fmt="upper" spellcheck="false" value="${esc(it.id_fabricacion || "")}" placeholder="Código interno, si lo tienes"></label>
          <label class="cp-f"><span>Proveedor sugerido</span><input data-f="proveedor" maxlength="180" value="${esc(it.proveedor || "")}" placeholder="Si ya sabes con quién comprarlo"></label>
          <label class="cp-f span2"><span>Especificaciones</span><input data-f="descripcion" maxlength="1000" value="${esc(it.descripcion || "")}" placeholder="Medidas, color, material, presentación…"></label>
          <label class="cp-f span2"><span>Requisitos de Calidad <small>(opcional)</small></span><input data-f="requisitos_calidad" maxlength="1000" value="${esc(it.requisitos_calidad || "")}" placeholder="Certificados, norma, tolerancias, empaque…"></label>
        </div>
      </details>
      <details class="cp-adv cp-optbox"${ops.length ? " open" : ""}>
        <summary>Opciones / variantes <small>(mismo producto en otra tienda o proveedor)</small></summary>
        <p class="cp-guide sm">Agrega una opción por cada alternativa y ponle un nombre propio; no uses solo el nombre del proveedor. Compras elegirá una sola opción por producto.</p>
        <div class="cp-optlist" data-options>${ops.map(optionRowHTML).join("")}</div>
        <button type="button" class="cp-btn ghost cp-addopt" data-add-option>+ Agregar opción o variante</button>
      </details>
    </div>`;
  }

  async function ensureCertificados(force = false) {
    if (!force && S.certificados.length) return S.certificados;
    try { S.certificados = await api("/api/compras/productos-certificados"); }
    catch { S.certificados = S.certificados || []; }
    return S.certificados;
  }

  const aprobadosCatalogo = () => (S.certificados || []).filter(
    p => p.activo && (p.calidad_estado || "aprobado") === "aprobado");

  async function newSolicitud(editId = null) {
    if (!canManage() && S.mode !== "user") return;
    let s = null;
    if (!editId) { try { await ensureCertificados(true); } catch { /* catálogo opcional */ } }
    if (editId) {
      try { s = await api("/api/compras/solicitudes/" + editId); } catch (e) { return toast("No se pudo abrir", e.message, "error"); }
    }
    S.editEstado = s?.estado || "";
    const items = (s?.items?.length ? s.items : [{}]);
    const pseg = (k, lbl) => `<button type="button" class="cp-pseg${(s?.prioridad || "media") === k ? " on" : ""}" data-prio="${k}"><i class="pdot"></i>${lbl}</button>`;
    const motivoForm = S.editEstado === "rechazada" && s?.motivo_rechazo
      ? `<div class="cp-alert danger"><b>Tu solicitud fue rechazada. Este es el motivo:</b><p>${nl2br(s.motivo_rechazo)}</p><small>Corrige lo necesario y reenvíala; volverá a estado Pendiente para nueva revisión.</small></div>`
      : S.editEstado === "cambios_solicitados" && s?.motivo_cambios
      ? `<div class="cp-alert warn"><b>Te pidieron estos cambios:</b><p>${nl2br(s.motivo_cambios)}</p><small>Ajusta los datos y reenvía; volverá a estado Pendiente.</small></div>` : "";
    const reenvHint = (S.editEstado === "rechazada" || S.editEstado === "cambios_solicitados")
      ? "<b>Al reenviar, tu solicitud vuelve a estado Pendiente y el gestor la revisará de nuevo.</b>"
      : "";
    showOverlay(`<div class="cp-veil"></div>
      <div class="cp-modal cp-form-modal" role="dialog" aria-label="Solicitud de compra">
        <header class="cp-modal-head"><div>
          <span class="cp-kicker">${S.editEstado === "rechazada" || S.editEstado === "cambios_solicitados" ? "Corregir y reenviar" : (editId ? "Editar solicitud" : "Nueva solicitud")}</span>
          <div class="cp-wiz-head"><h2>Pedir una compra</h2><span class="cp-wiz-stage" title="Etapa actual del proceso">Etapa: ${esc(ETAPA[s?.etapa_actual] || "Preparando requisición")}</span></div>
          <div class="cp-steps" aria-label="Pasos del formulario">
            <span class="cp-step on" data-step="1"><i>1</i>Productos</span>
            <span class="cp-step-line"></span>
            <span class="cp-step" data-step="2"><i>2</i>Detalles</span>
            <span class="cp-step-line"></span>
            <span class="cp-step" data-step="3"><i>3</i>Revisar</span>
          </div>
          <p class="cp-wiz-now" id="cpWizNow" aria-live="polite">Paso 1 de 3 · Productos</p>
        </div><button class="cp-x" data-close aria-label="Cerrar">&times;</button></header>
        <form id="cpSolForm" class="cp-modal-body" autocomplete="off" novalidate>
          <section id="cpStep1">
            ${motivoForm}
            <p class="cp-guide">Dinos qué necesitas comprar. Solo el producto y la cantidad son obligatorios; lo demás nos ayuda a cotizar mejor. Los campos con <b class="cp-req">*</b> en rojo son obligatorios.</p>
            <div class="cp-items-head"><h3>¿Qué necesitas comprar?</h3><span id="cpSolTotal" class="cp-total">$0.00</span></div>
            <p class="cp-guide sm">Agrega un producto por cada artículo distinto. Si no conoces el precio o la tienda, déjalo vacío.</p>
            <datalist id="cpCertProducts">${aprobadosCatalogo().map(p => `<option value="${esc(p.nombre)}"></option>`).join("")}</datalist>
            <div id="cpSolItems">${items.map((it, i) => itemRowHTML(i, it)).join("")}</div>
            <button type="button" class="cp-btn ghost" data-add-item>+ Agregar otro producto</button>
          </section>
          <section id="cpStep2" hidden>
            <p class="cp-guide">Define el tipo de compra y los datos que ayudan a revisarla. Puedes dejar en blanco lo opcional.</p>
            <div class="cp-typepick">
              <label class="${(s?.tipo_compra || "normal") === "normal" ? "on" : ""}${editId ? " is-disabled" : ""}"${editId ? ` title="El tipo de compra ya no se puede cambiar en una solicitud existente." aria-disabled="true"` : ""}>
                <input type="radio" name="cpTipo" value="normal"${(s?.tipo_compra || "normal") === "normal" ? " checked" : ""}${editId ? " disabled" : ""}>
                <b>Compra normal</b><span>Compras revisa, autoriza y genera la orden.</span>
                ${editId ? `<em class="cp-typefix">No editable</em>` : ""}
              </label>
              <label class="${s?.tipo_compra === "calidad" ? "on" : ""}${editId ? " is-disabled" : ""}"${editId ? ` title="El tipo de compra ya no se puede cambiar en una solicitud existente." aria-disabled="true"` : ""}>
                <input type="radio" name="cpTipo" value="calidad"${s?.tipo_compra === "calidad" ? " checked" : ""}${editId ? " disabled" : ""}>
                <b>Compra con Calidad</b><span>Calidad aprueba las opciones antes de Compras.</span>
                ${editId ? `<em class="cp-typefix">No editable</em>` : ""}
              </label>
            </div>
            ${editId ? `<p class="cp-locknote"><b>Tipo de compra fijo.</b> Para cambiar entre compra normal y compra con Calidad, crea una solicitud nueva.</p>` : ""}
            <div class="cp-formgrid cp-extra" id="cpProvProp"${(s?.tipo_compra || "normal") === "calidad" ? "" : " hidden"}>
              <div class="cp-f span2"><b>Proveedor propuesto para Calidad</b><small>Calidad revisará estas opciones; no sustituye al proveedor fiscal de la orden de compra.</small></div>
              <label class="cp-f"><span>Nombre del proveedor <b class="cp-req">*</b></span><input id="cpPropNombre" maxlength="180" value="${esc(s?.proveedor_propuesto?.nombre || "")}" placeholder="Ej. Distribuidora del Norte"></label>
              <label class="cp-f"><span>RFC <small>(opcional)</small></span><input id="cpPropRfc" maxlength="13" data-fmt="rfc" value="${esc(s?.proveedor_propuesto?.rfc || "")}"></label>
              <label class="cp-f"><span>Contacto</span><input id="cpPropContacto" maxlength="160" value="${esc(s?.proveedor_propuesto?.contacto || "")}"></label>
              <label class="cp-f"><span>Correo</span><input id="cpPropEmail" type="email" maxlength="140" value="${esc(s?.proveedor_propuesto?.email || "")}"></label>
              <label class="cp-f"><span>Teléfono</span><input id="cpPropTelefono" maxlength="10" data-fmt="digits" value="${esc(s?.proveedor_propuesto?.telefono || "")}"></label>
              <label class="cp-f span2"><span>Domicilio</span><input id="cpPropDomicilio" maxlength="400" value="${esc(s?.proveedor_propuesto?.domicilio || "")}"></label>
            </div>
            <div class="cp-formgrid cp-extra">
              <label class="cp-f span2"><span>Contexto general de la solicitud <small>(opcional)</small></span><textarea id="cpJust" rows="3" maxlength="4000" placeholder="Ej. Reposición mensual del área; el detalle de cada producto está arriba.">${esc(s?.justificacion || "")}</textarea>
                <small>El “para qué” de cada producto ya se capturó arriba. Usa este espacio solo si necesitas dar contexto adicional.</small></label>
              <div class="cp-f span2"><span>¿Qué tan urgente es?</span>
                <div class="cp-prioseg" id="cpPrioSeg">
                  ${pseg("baja", "Baja")}${pseg("media", "Normal")}${pseg("alta", "Urgente")}${pseg("urgente", "Crítico")}
                </div>
              </div>
            </div>
            <details class="cp-sec cp-fold cp-process-help">
              <summary>¿Cómo funciona el proceso?</summary>
              <div class="cp-process-help-body">${processHTML()}</div>
            </details>
          </section>
          <section id="cpStep3" hidden>
            <p class="cp-guide">${reenvHint} Revisa que todo esté correcto. Usa los botones <b>Subir</b> y <b>Bajar</b> de cada producto para cambiar el orden de prioridad: el número 1 se atiende primero. Después de enviar, el gestor de compras la verá de inmediato y podrás seguir su avance en la pestaña <b>Compras</b>.</p>
            <div class="cp-sumcard" id="cpSumCard"></div>
          </section>
          <p class="cp-ferrbox" id="cpSolErr" role="alert" hidden></p>
        </form>
        <footer class="cp-modal-foot">
          <button class="cp-btn ghost" data-close>Cancelar</button>
          <button class="cp-btn ghost" id="cpSolBack" hidden>← Atrás</button>
          <button class="cp-btn primary" id="cpSolNext">Continuar →</button>
          <button class="cp-btn primary" id="cpSolSave" hidden>${editId ? "Guardar cambios ✓" : "Enviar solicitud ✓"}</button>
        </footer>
      </div>`);
    const form = $("#cpSolForm", S.root);
    form.addEventListener("change", e => {
      const inp = e.target.closest('[data-f="nombre"]');
      if (!inp) return;
      const row = inp.closest(".cp-itemrow");
      const lbl = inp.closest(".cp-f");
      const nombre = inp.value.trim().toLowerCase();
      const p = aprobadosCatalogo().find(x => String(x.nombre || "").trim().toLowerCase() === nombre);
      row?.querySelector(".cp-cert-tag")?.remove();
      if (!p) return;
      const fill = (f, val) => {
        const el = $(`[data-f="${f}"]`, row);
        if (el && !String(el.value || "").trim()) el.value = val || "";
      };
      const unidad = $('[data-f="unidad"]', row);
      if (unidad && p.unidad) unidad.value = p.unidad;
      fill("id_fabricacion", p.id_fabricacion);
      fill("descripcion", p.descripcion);
      fill("requisitos_calidad", p.requisitos_calidad);
      lbl?.insertAdjacentHTML("beforeend", '<small class="cp-cert-tag">✓ Producto certificado por Calidad</small>');
    });
    const collect = () => {
      const rows = $$(".cp-itemrow", form);
      const items = rows.map(r => ({
        nombre: $('[data-f="nombre"]', r).value.trim(),
        motivo: $('[data-f="motivo"]', r)?.value.trim() || "",
        descripcion: $('[data-f="descripcion"]', r).value.trim(),
        requisitos_calidad: $('[data-f="requisitos_calidad"]', r).value.trim(),
        id_fabricacion: $('[data-f="id_fabricacion"]', r).value.trim(),
        cantidad: Number($('[data-f="cantidad"]', r).value) || 0,
        unidad: $('[data-f="unidad"]', r).value,
        costo_unitario: Number($('[data-f="costo_unitario"]', r).value) || 0,
        precio_incluye_iva: $('[data-f="precio_incluye_iva"]', r).value === "1",
        link: $('[data-f="link"]', r).value.trim(),
        imagen: safeImg($('[data-f="imagen"]', r).value),
        proveedor: $('[data-f="proveedor"]', r).value.trim(),
        opciones: $$(".cp-optrow", r).map(o => ({
          etiqueta: $('[data-of="etiqueta"]', o).value.trim(),
          diferencia: $('[data-of="diferencia"]', o).value.trim(),
          proveedor: $('[data-of="proveedor"]', o).value.trim(),
          costo_unitario: Number($('[data-of="costo_unitario"]', o).value) || 0,
          precio_incluye_iva: $('[data-of="precio_incluye_iva"]', o).value === "1",
          link: $('[data-of="link"]', o).value.trim(),
          imagen: safeImg($('[data-of="imagen"]', o).value),
        })).filter(o => o.etiqueta || o.link || o.proveedor || o.costo_unitario > 0),
      })).filter(x => x.nombre);
      const tipo_compra = form.querySelector('input[name="cpTipo"]:checked')?.value || s?.tipo_compra || "normal";
      const prop = tipo_compra === "calidad" ? {
        nombre: $("#cpPropNombre", form)?.value.trim() || "",
        rfc: normalizeRfc($("#cpPropRfc", form)?.value || ""),
        contacto: $("#cpPropContacto", form)?.value.trim() || "",
        email: $("#cpPropEmail", form)?.value.trim() || "",
        telefono: normalizeDigits($("#cpPropTelefono", form)?.value || ""),
        domicilio: $("#cpPropDomicilio", form)?.value.trim() || "",
      } : {};
      return {
        // El título se genera con los productos: evitamos pedir lo mismo dos veces.
        titulo: tituloDesdeItems(items),
        justificacion: $("#cpJust", form).value.trim(),
        prioridad: $(".cp-pseg.on", form)?.dataset.prio || "media",
        tipo_compra,
        proveedor_propuesto: prop,
        // En edición se conservan estos campos (el formulario simplificado no los pide).
        proveedor_sugerido: s?.proveedor_sugerido || "",
        notas: s?.notas || "",
        items,
      };
    };
    const recalc = () => {
      let t = 0;
      $$(".cp-itemrow", form).forEach(r => {
        const c = Number($('[data-f="cantidad"]', r)?.value) || 0;
        const p = Number($('[data-f="costo_unitario"]', r)?.value) || 0;
        t += c * p;
      });
      const el = $("#cpSolTotal", form);
      if (el) el.textContent = money(t);
    };
    form.addEventListener("input", recalc);
    // Enter nunca envía el formulario por accidente: avanza al siguiente campo.
    form.addEventListener("submit", e => e.preventDefault());
    form.addEventListener("keydown", e => {
      if (e.key !== "Enter" || e.isComposing) return;
      const active = e.target;
      if (!active.matches("input, select, textarea")) return;
      if (active.tagName === "TEXTAREA" || active.type === "hidden" || active.type === "file") return;
      e.preventDefault();
      const fields = [...form.querySelectorAll("input, select, textarea")].filter(el =>
        !el.disabled && el.type !== "hidden" && el.type !== "file" && el.getClientRects().length && !el.closest("details:not([open])"));
      const i = fields.indexOf(active);
      if (i < 0) return;
      if (i < fields.length - 1) { fields[i + 1].focus(); return; }
      const next = $("#cpSolSave", S.root)?.hidden === false ? $("#cpSolSave", S.root) : $("#cpSolNext", S.root);
      next?.focus();
    });
    form.addEventListener("input", (e) => {
      if (e.target.matches('[data-f="link"], [data-of="link"]')) {
        const row = e.target.closest(".cp-itemrow");
        if (!row) return;
        const opt = e.target.closest(".cp-optrow");
        const holder = opt || row;
        clearTimeout(holder._prevTimer);
        holder._prevTimer = setTimeout(() => (opt ? refreshOptionPreview(opt) : refreshRowPreview(row)), 550);
      }
    });
    form.addEventListener("change", (e) => {
      if (e.target.matches('[data-f="link"], [data-of="link"]')) {
        const row = e.target.closest(".cp-itemrow");
        if (!row) return;
        const opt = e.target.closest(".cp-optrow");
        if (opt) refreshOptionPreview(opt);
        else refreshRowPreview(row);
      }
    });
    const syncTipo = () => {
      const tipo = form.querySelector('input[name="cpTipo"]:checked')?.value || "normal";
      const prov = $("#cpProvProp", form);
      if (prov) {
        const activo = tipo === "calidad";
        prov.hidden = !activo;
        $$("input,textarea,select", prov).forEach(el => { el.disabled = !activo; });
      }
      $$('input[name="cpTipo"]', form).forEach(r => r.closest("label")?.classList.toggle("on", r.checked));
    };
    form.addEventListener("change", e => { if (e.target.name === "cpTipo") syncTipo(); });
    syncTipo();
    recalc();
    hydrateFormPreviews(form);
    const proc = $("#cpProcess", S.root);
    const setProc = (idx) => {
      if (!proc) return;
      $$("[data-pstep]", proc).forEach((b, i) => b.classList.toggle("on", i === idx));
    };
    proc?.addEventListener("click", e => {
      const b = e.target.closest("[data-pstep]");
      if (b) setProc(Number(b.dataset.pstep));
    });
    $('[data-f="nombre"]', form)?.focus();
    /* --- pasos --- */
    const $s1 = $("#cpStep1", S.root), $s2 = $("#cpStep2", S.root), $s3 = $("#cpStep3", S.root), $err = $("#cpSolErr", S.root);
    const WIZ_LABELS = ["Productos", "Detalles", "Revisar y enviar"];
    const currentStep = () => $s1.hidden ? ($s2.hidden ? 3 : 2) : 1;
    $$("#cpPrioSeg .cp-pseg", S.root).forEach(b => b.onclick = () => {
      $$("#cpPrioSeg .cp-pseg", S.root).forEach(x => x.classList.remove("on"));
      b.classList.add("on");
    });
    const goStep = n => {
      $s1.hidden = n !== 1; $s2.hidden = n !== 2; $s3.hidden = n !== 3;
      const next = $("#cpSolNext", S.root), save = $("#cpSolSave", S.root), back = $("#cpSolBack", S.root);
      if (next) {
        next.hidden = n === 3;
        next.textContent = n === 1 ? "Continuar →" : "Revisar solicitud →";
      }
      if (save) save.hidden = n !== 3;
      if (back) {
        back.hidden = n === 1;
        back.textContent = n === 3 ? "← Volver a detalles" : "← Atrás";
      }
      $$(".cp-steps .cp-step", S.root).forEach(el => {
        const step = Number(el.dataset.step);
        el.classList.toggle("on", step <= n);
        el.classList.toggle("done", step < n);
        if (step === n) el.setAttribute("aria-current", "step");
        else el.removeAttribute("aria-current");
      });
      const now = $("#cpWizNow", S.root);
      if (now) now.textContent = `Paso ${n} de 3 · ${WIZ_LABELS[n - 1]}`;
      if (n === 3) buildSummary();
      const body = S.root.querySelector(".cp-modal .cp-modal-body");
      body?.scrollTo?.({ top: 0, behavior: "smooth" });
      // Notify step change for panel guide
      document.dispatchEvent(new CustomEvent("cp:step-change", { detail: { step: n } }));
    };
    const clearErrors = () => {
      $$(".cp-f.bad, .cp-itemrow.bad, .cp-optbox.bad", form).forEach(x => x.classList.remove("bad"));
      $$("[aria-invalid]", form).forEach(x => x.removeAttribute("aria-invalid"));
      $$(".cp-ferr", form).forEach(x => x.remove());
      $err.hidden = true;
    };
    const mark = (box, msg) => {
      if (!box) return;
      const det = box.closest("details");
      if (det) det.open = true;
      box.classList.add("bad");
      const small = document.createElement("small");
      small.className = "cp-ferr";
      small.setAttribute("role", "alert");
      small.textContent = msg;
      box.appendChild(small);
      box.querySelector("input, select, textarea")?.setAttribute("aria-invalid", "true");
    };
    const validate = (scope = "all") => {
      clearErrors();
      const problems = [];
      const checkProducts = scope === "all" || scope === "products";
      const checkDetails = scope === "all" || scope === "details";
      const rows = $$(".cp-itemrow", form);
      const tipo = form.querySelector('input[name="cpTipo"]:checked')?.value || "normal";
      if (checkProducts) {
        let conProducto = false;
        rows.forEach(r => {
          const nombre = $('[data-f="nombre"]', r).value.trim();
          const cantEl = $('[data-f="cantidad"]', r);
          const cant = Number(cantEl.value) || 0;
          const tieneDatos = nombre || ["motivo", "link", "descripcion", "requisitos_calidad", "id_fabricacion", "proveedor"].some(f => $('[data-f="' + f + '"]', r).value.trim()) || Number($('[data-f="costo_unitario"]', r).value) > 0;
          if (nombre) conProducto = true;
          if (!tieneDatos) return; // una fila extra vacía no estorba
          if (!nombre) { mark(r.querySelector('[data-f="nombre"]').closest(".cp-f"), "Escribe el nombre del producto."); }
          else if (cant <= 0) { mark(cantEl.closest(".cp-f"), "Indica cuántos necesitas."); }
          else if (cant > 1000000) { mark(cantEl.closest(".cp-f"), "La cantidad máxima es 1,000,000."); }
          const costoEl = $('[data-f="costo_unitario"]', r);
          if (Number(costoEl.value) < 0 || Number(costoEl.value) > 1000000) {
            mark(costoEl.closest(".cp-f"), "El costo debe estar entre 0 y 1,000,000.");
          }
          // Validar enlace si existe
          const linkEl = $('[data-f="link"]', r);
          if (linkEl && linkEl.value.trim() && !safeUrl(linkEl.value.trim())) {
            mark(linkEl.closest(".cp-f"), "El enlace no es válido. Debe empezar con http:// o https://");
          }
          $$(".cp-optrow", r).forEach(o => {
            const nombreOpt = $('[data-of="etiqueta"]', o)?.value.trim() || "";
            const conDatos = ["proveedor", "diferencia", "link"].some(f => $('[data-of="' + f + '"]', o)?.value.trim()) ||
              Number($('[data-of="costo_unitario"]', o)?.value) > 0;
            if (conDatos && !nombreOpt) {
              mark($('[data-of="etiqueta"]', o).closest(".cp-f"), "Ponle un nombre a la opción (por ejemplo, Segunda opción).");
            }
          });
        });
        if (!conProducto) {
          const firstNombre = form.querySelector('[data-f="nombre"]');
          if (firstNombre) mark(firstNombre.closest(".cp-f"), "Escribe el nombre del producto.");
          problems.push("Agrega al menos un producto con su nombre");
        }
        if (tipo === "calidad") {
          rows.forEach(r => {
            if (!$('[data-f="nombre"]', r).value.trim()) return;
            const ops = $$(".cp-optrow", r).map(o => ({
              etiqueta: $('[data-of="etiqueta"]', o).value.trim(),
              link: $('[data-of="link"]', o).value.trim(),
              costo: Number($('[data-of="costo_unitario"]', o).value) || 0,
            })).filter(o => o.etiqueta || o.link);
            if (!ops.length) {
              mark(r.querySelector(".cp-optbox"), "Agrega al menos una opción o proveedor para que Calidad la revise.");
              problems.push("Cada producto necesita al menos una opción");
            }
            $$(".cp-optrow", r).forEach(o => {
              const c = Number($('[data-of="costo_unitario"]', o).value) || 0;
              if (c < 0 || c > 1000000) mark($('[data-of="costo_unitario"]', o).closest(".cp-f"), "El costo debe estar entre 0 y 1,000,000.");
              const optLink = $('[data-of="link"]', o);
              if (optLink && optLink.value.trim() && !safeUrl(optLink.value.trim())) {
                mark(optLink.closest(".cp-f"), "El enlace no es válido. Debe empezar con http:// o https://");
              }
            });
          });
        }
      }
      if (checkDetails && tipo === "calidad") {
        const prop = $("#cpPropNombre", form);
        if (prop && !prop.value.trim()) {
          mark(prop.closest(".cp-f"), "Captura el nombre del proveedor propuesto para Calidad.");
          problems.push("Captura el proveedor propuesto para Calidad");
        }
        const propEmail = $("#cpPropEmail", form);
        if (propEmail && propEmail.value.trim() && !validEmail(propEmail.value.trim())) {
          mark(propEmail.closest(".cp-f"), "El correo no es válido.");
          problems.push("Correo del proveedor no válido");
        }
        const propTel = $("#cpPropTelefono", form);
        if (propTel && propTel.value.trim() && normalizeDigits(propTel.value.trim()).length < 10) {
          mark(propTel.closest(".cp-f"), "El teléfono debe tener 10 dígitos.");
          problems.push("Teléfono del proveedor incompleto");
        }
        const propRfc = $("#cpPropRfc", form);
        if (propRfc && propRfc.value.trim() && !validRfc(propRfc.value.trim())) {
          mark(propRfc.closest(".cp-f"), "El RFC no es válido (12 o 13 caracteres).");
          problems.push("RFC del proveedor no válido");
        }
      }
      if (checkDetails) {
        const just = $("#cpJust", form);
        if (just && just.value.trim().length > 0 && just.value.trim().length < 10) {
          mark(just.closest(".cp-f"), "El contexto general debe tener al menos 10 caracteres si se proporciona.");
          problems.push("Contexto general muy corto");
        }
      }
      if (problems.length) {
        $err.innerHTML = problems.map(p => `• ${esc(p)}`).join("<br>");
        $err.hidden = false;
        const first = form.querySelector(".cp-f.bad, .cp-itemrow.bad");
        first?.scrollIntoView?.({ block: "center", behavior: "smooth" });
        first?.querySelector?.("input")?.focus?.();
        return false;
      }
      return true;
    };
    const buildSummary = () => {
      const d = collect();
      const rows = d.items.map((it, i) => `<div class="cp-sumrow" data-sumrow="${i}">
        <div class="cp-sumorder">
          <span class="cp-sumpos" title="Prioridad ${i + 1}">${i + 1}</span>
          <button type="button" class="cp-summove up" data-sum-move="-1" title="Subir prioridad: se comprará antes" aria-label="Subir prioridad de ${esc(it.nombre)}">
            <span aria-hidden="true">↑</span><span>Subir</span>
          </button>
          <button type="button" class="cp-summove down" data-sum-move="1" title="Bajar prioridad: se comprará después" aria-label="Bajar prioridad de ${esc(it.nombre)}">
            <span aria-hidden="true">↓</span><span>Bajar</span>
          </button>
        </div>
        <span class="cp-sumq">${qty(it.cantidad)} ${esc(it.unidad)}</span>
        <div class="cp-prodcell">
          <div class="cp-prodthumb${it.imagen || it.link ? "" : " empty"}" data-cpmedia data-cpimg="${esc(it.imagen || "")}" data-cplink="${esc(safeUrl(it.link))}">${mediaPlaceholder()}</div>
          <div class="cp-sumn"><b>${esc(it.nombre)}</b>
            ${it.id_fabricacion ? `<small>ID: ${esc(it.id_fabricacion)}</small>` : ""}
            ${it.descripcion ? `<small>${esc(it.descripcion)}</small>` : ""}
            ${it.motivo ? `<small class="cp-sumnote"><b>Para qué:</b> ${esc(it.motivo)}</small>` : ""}
            <small>${it.precio_incluye_iva ? "Precio capturado con IVA incluido" : "Precio capturado sin IVA"}</small>
            ${safeUrl(it.link) ? productLinkHTML(it.link) : ""}
            ${(it.opciones || []).length ? `<div class="cp-sumopts"><b>Opciones para revisar:</b>${it.opciones.map(o => {
              const optLink = safeUrl(o.link);
              const optImg = safeImg(o.imagen || "");
              return `<div class="cp-sumopt">
                <div class="cp-prodthumb cp-optthumb${optImg || optLink ? "" : " empty"}" data-cpmedia data-cpimg="${esc(optImg)}" data-cplink="${esc(optLink)}">${mediaPlaceholder()}</div>
                <div class="cp-sumopt-copy">
                  <b>${esc(o.etiqueta || "Opción")}</b>
                  ${o.diferencia ? `<small>${esc(o.diferencia)}</small>` : ""}
                  <small>${o.proveedor ? esc(o.proveedor) + " · " : ""}${money(o.costo_unitario)}${o.precio_incluye_iva ? " IVA incluido" : " + IVA"}</small>
                  ${optLink ? productLinkHTML(optLink, o.etiqueta) : ""}
                </div>
              </div>`;
            }).join("")}</div>` : ""}
          </div>
        </div>
        <span class="cp-sump">${it.costo_unitario ? money(it.costo_unitario * it.cantidad) : '<small class="cp-muted">sin precio</small>'}</span>
      </div>`).join("");
      const total = d.items.reduce((t, it) => t + (Number(it.costo_unitario) || 0) * (Number(it.cantidad) || 0), 0);
      const n = d.items.length;
      $("#cpSumCard", S.root).innerHTML = `
        <div class="cp-sumhead"><span>Productos</span><b>${n} producto${n === 1 ? "" : "s"}</b></div>
        <div class="cp-sumhead"><span>Tipo de compra</span><b>${d.tipo_compra === "calidad" ? "Con revisión de Calidad" : "Compra normal"}</b></div>
        ${d.tipo_compra === "calidad" && d.proveedor_propuesto?.nombre ? `<div class="cp-sumhead"><span>Proveedor propuesto</span><b>${esc(d.proveedor_propuesto.nombre)}</b></div>` : ""}
        ${d.justificacion ? `<div class="cp-sumhead"><span>Contexto general</span><b>${esc(d.justificacion)}</b></div>` : ""}
        <div class="cp-sumhead"><span>Urgencia</span>${badge(PRIO, d.prioridad)}</div>
        <div class="cp-sumitems">${rows}</div>
        ${total ? `<div class="cp-sumtotal"><span>Costo estimado total</span><b>${money(total)}</b></div>` : `<p class="cp-muted" style="margin:10px 0 0">Sin precios estimados — el gestor los completará al generar el documento.</p>`}`;
      hydrateMedia($("#cpSumCard", S.root));
      updateMoveButtons($("#cpSumCard", S.root));
    };
    $("#cpSumCard", S.root)?.addEventListener("click", e => {
      const btn = e.target.closest("[data-sum-move]");
      if (!btn) return;
      const idx = Number(btn.closest("[data-sumrow]")?.dataset.sumrow);
      const dir = Number(btn.dataset.sumMove);
      const rows = $$(".cp-itemrow", form).filter(r => $('[data-f="nombre"]', r).value.trim());
      const row = rows[idx];
      const other = dir < 0 ? rows[idx - 1] : rows[idx + 1];
      if (!row || !other) return;
      if (dir < 0) row.parentElement.insertBefore(row, other);
      else row.parentElement.insertBefore(other, row);
      syncItemOrderLabels(form);
      buildSummary();
    });
    $("#cpSolNext", S.root).onclick = () => {
      const n = currentStep();
      if (n === 1 && validate("products")) goStep(2);
      else if (n === 2 && validate("details")) goStep(3);
    };
    $("#cpSolBack", S.root).onclick = () => goStep(currentStep() === 3 ? 2 : 1);
    $("#cpSolSave", S.root).onclick = async () => {
      const body = collect();
      if (!body.titulo || !body.items.length) { goStep(1); validate("products"); return; }
      if (!validate("all")) {
        const bad = form.querySelector(".cp-f.bad, .cp-itemrow.bad");
        const step = bad?.closest("#cpStep1") ? 1 : bad?.closest("#cpStep2") ? 2 : 3;
        goStep(step);
        requestAnimationFrame(() => {
          bad?.scrollIntoView?.({ block: "center", behavior: "smooth" });
          bad?.querySelector?.("input")?.focus?.();
        });
        return;
      }
      const reenviada = editId && ["cambios_solicitados", "rechazada"].includes(S.editEstado || "");
      try {
        const out = editId
          ? await api("/api/compras/solicitudes/" + editId, { method: "PATCH", body: JSON.stringify(body) })
          : await api("/api/compras/solicitudes", { method: "POST", body: JSON.stringify(body) });
        hideOverlay();
        toast(reenviada ? "¡Solicitud reenviada!" : (editId ? "Solicitud actualizada" : "¡Solicitud enviada!"),
          reenviada ? `${out.folio} volvió a Pendiente para nueva revisión. Firma de nuevo la requisición actualizada.`
            : editId ? `${out.folio} · Firma de nuevo la requisición para que Compras pueda continuar.`
              : `${out.folio} · ${out.titulo}`);
        await refresh(true);
        if (!editId) openSolicitud(out.id);
        else openSolicitud(editId, { focusFirma: true });
      } catch (e) { toast("No se pudo guardar", e.message, "error"); }
    };
  }

  /* =====================  FORM: ORDEN DE COMPRA (FLUJO NUEVO)  ===================== */
  function newOrdenCompra(s) {
    if (!canManage()) return toast("Solo lectura", "La orden de compra la genera un gestor de Compras.", "warning");
    if (s.gestor_por && s.gestor_por !== username()) {
      return toast("En proceso", `Esta solicitud ya está siendo atendida por ${s.gestor_por}.`, "warning");
    }
    if ((s.flujo || "legado") === "nuevo" && !s.requisicion_firmada) {
      return toast("Falta la requisición firmada", "La persona solicitante debe subir la requisición firmada por la jefatura antes de generar la OC.", "warning");
    }
    const empresa = S.empresa || {};
    const activos = (S.proveedores || []).filter(p => p.activo && (p.calidad_estado || "aprobado") === "aprobado");
    const propuesta = s.proveedor_propuesto || {};
    const norm = v => String(v || "").trim().toLowerCase();
    const match = propuesta.nombre && activos.find(p => norm(p.nombre) === norm(propuesta.nombre));
    const calidad = (s.tipo_compra || "normal") === "calidad";
    const blocks = (s.items || []).map((it, idx) => {
      const ops = it.opciones || [];
      const qtyBox = (value, attrs, disabled = false) => `<span class="cp-qty">
        <button type="button" data-qty-step="-1" aria-label="Reducir cantidad"${disabled ? " disabled" : ""}>−</button>
        <input type="number" min="0" max="${esc(it.cantidad)}" step="0.01" ${attrs} value="${esc(value)}"${disabled ? " disabled" : ""} placeholder="0.00">
        <button type="button" data-qty-step="1" aria-label="Aumentar cantidad"${disabled ? " disabled" : ""}>+</button>
      </span>`;
      const baseRef = calidad;
      const prev = S.ocSelections?.[s.id]?.[it.id] || {};
      const incluido = prev.include !== false;
      let chosenOid = prev.opcion_id != null ? String(prev.opcion_id) : "";
      if (calidad && !ops.some(o => String(o.id) === chosenOid && o.calidad_aprobada)) {
        chosenOid = String(ops.find(o => o.calidad_aprobada)?.id || "");
      }
      if (!calidad && chosenOid && !ops.some(o => String(o.id) === chosenOid)) chosenOid = "";
      const baseSelected = !calidad && !chosenOid;
      const options = ops.map((o, k) => {
        const aprobada = !calidad || !!o.calidad_aprobada;
        const selected = chosenOid === String(o.id);
        const optLink = safeUrl(o.link);
        const optImg = safeImg(o.imagen || "");
        const optSite = o.proveedor ? esc(o.proveedor) : linkSiteName(optLink);
        const nombre = opcionNombre(o, k + 1);
        return `<label class="cp-ocopt${aprobada ? "" : " off"}${selected ? " on" : ""}">
          <input type="radio" name="ocopt-${it.id}" data-oc-opt="${o.id}" data-oc-api="${aprobada ? "1" : "0"}"${selected ? " checked" : ""}${aprobada ? "" : " disabled"}>
          <span class="cp-ocopt-main"><b>${esc(nombre)}</b>
            ${o.diferencia ? `<small>${esc(o.diferencia)}</small>` : ""}
            <small>${o.proveedor ? esc(o.proveedor) + " · " : ""}${money(o.costo_unitario)}${o.precio_incluye_iva ? " IVA incluido" : " + IVA"}</small>
            ${o.calidad_aprobada ? `<span class="cp-badge ok">Aprobada por Calidad</span>` : (calidad ? `<span class="cp-badge muted">No aprobada</span>` : "")}
          </span>
          <span class="cp-ocopt-qty">${qtyBox(selected ? it.cantidad : 0, `data-oc-qty`, !selected)}</span>
          <span class="cp-ocopt-cost"><span class="cp-money"><i>$</i><input type="number" min="0" step="0.01" data-oc-cost value="${esc(o.costo_unitario || 0)}" placeholder="0.00"${selected ? "" : " disabled"}></span></span>
          <div class="cp-ocopt-preview" data-ocoptprev data-opt-link="${esc(optLink)}" data-opt-img="${esc(optImg)}" data-opt-site="${esc(optSite)}" data-opt-label="${esc(nombre)}" hidden>
            <div class="cp-ocopt-preview-inner">
              <span class="cp-ocopt-preview-img" data-cpmedia data-cpimg="${esc(optImg)}" data-cplink="${esc(optLink)}">${mediaPlaceholder()}</span>
              <div class="cp-ocopt-preview-info">
                <b>${esc(nombre)}</b>
                ${o.diferencia ? `<small>${esc(o.diferencia)}</small>` : ""}
                <small class="cp-ocopt-source">${esc(optSite)}${optLink ? ` · <a href="${esc(optLink)}" target="_blank" rel="noopener">${esc(optSite || "Ver producto")}</a>` : ""}</small>
                <small>${money(o.costo_unitario)}${o.precio_incluye_iva ? " IVA incluido" : " + IVA"}</small>
              </div>
            </div>
          </div>
        </label>`;
      }).join("");
      const base = `<label class="cp-ocopt${baseRef ? " off" : ""}${baseSelected ? " on" : ""}"${baseRef ? " data-oc-ref=\"1\"" : ""}>
          <input type="radio" name="ocopt-${it.id}" value="base" data-oc-base="1"${baseSelected ? " checked" : ""}${baseRef ? " disabled" : ""}>
          <span class="cp-ocopt-main"><b>${opcionOrden(0)}</b><small>${baseRef ? "Referencia solicitada; la compra se hará con una opción aprobada por Calidad." : ops.length ? "Producto solicitado tal como se capturó. Puedes cambiar a una alternativa." : "Sin alternativas capturadas; se usará el costo de la solicitud."}</small></span>
          <span class="cp-ocopt-qty">${qtyBox(baseSelected ? it.cantidad : 0, "data-oc-base-qty", !baseSelected)}</span>
          <span class="cp-ocopt-cost"><span class="cp-money"><i>$</i><input type="number" min="0" step="0.01" data-oc-base-cost value="${esc(it.costo_unitario || 0)}" placeholder="0.00"${baseSelected ? "" : " disabled"}></span></span>
          <div class="cp-ocopt-preview" data-ocoptprev data-opt-link="${esc(safeUrl(it.link))}" data-opt-img="${esc(safeImg(it.imagen || ""))}" data-opt-site="${esc(it.proveedor || linkSiteName(safeUrl(it.link)))}" data-opt-label="${esc(it.nombre)}" hidden>
            <div class="cp-ocopt-preview-inner">
              <span class="cp-ocopt-preview-img" data-cpmedia data-cpimg="${esc(safeImg(it.imagen || ""))}" data-cplink="${esc(safeUrl(it.link))}">${mediaPlaceholder()}</span>
              <div class="cp-ocopt-preview-info">
                <b>${esc(it.nombre)}</b>
                ${it.id_fabricacion ? `<small>ID: ${esc(it.id_fabricacion)}</small>` : ""}
                ${it.descripcion ? `<small>${esc(it.descripcion)}</small>` : ""}
                <small class="cp-ocopt-source">Primera opción · producto solicitado${safeUrl(it.link) ? ` · <a href="${esc(safeUrl(it.link))}" target="_blank" rel="noopener">${esc(it.proveedor || "Ver producto")}</a>` : ""}</small>
                <small>${money(it.costo_unitario || 0)}</small>
              </div>
            </div>
          </div>
        </label>`;
      return `<div class="cp-ocitem${incluido ? "" : " off"}" data-ocitem="${it.id}" data-ocreq="${esc(it.cantidad)}">
        <div class="cp-ocitem-head">
          <div class="cp-ocitem-title"><span class="cp-ocnum">${idx + 1}</span>
            <div><b>${esc(it.nombre)}</b>
              <div class="cp-ocitem-meta"><span>${qty(it.cantidad)} ${esc(it.unidad)} solicitadas</span>${it.descripcion ? `<span>${esc(it.descripcion)}</span>` : ""}${it.id_fabricacion ? `<span>ID ${esc(it.id_fabricacion)}</span>` : ""}</div>
            </div>
          </div>
          <div class="cp-ocitem-tools">
            <span class="cp-ocsum" data-ocsum></span>
            <label class="cp-ocinclude"><input type="checkbox" data-oc-include${incluido ? " checked" : ""}> Incluir en la OC</label>
            <label class="cp-ocinclude cp-ocdate"><span>Llega</span><input type="date" data-oc-fecha value="${esc(plusDaysISO(7))}"></label>
          </div>
        </div>
        <div class="cp-occols"><span></span><span>Producto / opción</span><span>Cantidad</span><span>Costo unit.</span></div>
        <div class="cp-ocopts">${base}${options}</div>
      </div>`;
    }).join("");
    showOverlay(`<div class="cp-veil"></div>
      <div class="cp-modal cp-form-modal cp-oc-modal" role="dialog" aria-label="Generar orden de compra">
        <header class="cp-modal-head"><div><span class="cp-kicker">Aprobar compra</span><h2>Generar orden de compra</h2><p>${esc(s.folio)} · ${esc(s.titulo)}</p></div><button class="cp-x" data-close aria-label="Cerrar">&times;</button></header>
        <div class="cp-modal-body">
          <div class="cp-alert info"><b>Elige una sola opción por producto.</b><p>La primera opción es el producto solicitado tal como se capturó; las siguientes son alternativas. Selecciona solo una, ajusta la cantidad o desmarca “Incluir en la OC”. Nunca se puede comprar más de lo solicitado.${calidad ? " En compras de Calidad, la primera opción es solo referencia y solo se habilitan las alternativas aprobadas." : ""}</p></div>
          <section class="cp-sec"><h3>Datos de la empresa</h3>
            <div class="cp-formgrid">
              <label class="cp-f"><span>RFC <b class="cp-req">*</b></span><input id="cpOcRfc" maxlength="13" data-fmt="rfc" value="${esc(normalizeRfc(empresa.rfc || ""))}"></label>
              <label class="cp-f"><span>Razón social <b class="cp-req">*</b></span><input id="cpOcRazon" maxlength="220" value="${esc(empresa.razon_social || empresa.nombre || "")}"></label>
            </div>
          </section>
          <section class="cp-sec"><h3>Proveedor</h3>
            <label class="cp-checkline"><input type="checkbox" id="cpOcOnline">
              <span><b>Compra en línea (sin proveedor fiscal)</b><small>Para Amazon, Mercado Libre, tiendas en línea o compras de mostrador. La OC se genera sin RFC del proveedor.</small></span>
            </label>
            <div class="cp-formgrid" id="cpOcOnlineStore" hidden>
              <label class="cp-f span2"><span>Tienda o plataforma</span><input id="cpOcStore" maxlength="180" placeholder="Ej. Amazon México, Mercado Libre, tienda local"></label>
            </div>
            <div class="cp-formgrid" id="cpOcProvFields">
              <label class="cp-f span2"><span>Proveedor registrado</span><select id="cpOcProv"><option value="">- Capturar proveedor nuevo -</option>
                ${activos.map(p => `<option value="${p.id}"${match && match.id === p.id ? " selected" : ""}>${esc(p.nombre)}${p.rfc ? ` · ${esc(p.rfc)}` : ""}</option>`).join("")}
              </select></label>
              <label class="cp-f"><span>Nombre <b class="cp-req">*</b></span><input id="cpOcProvNombre" maxlength="180" value="${esc(match ? match.nombre : (propuesta.nombre || ""))}"></label>
              <label class="cp-f"><span>RFC <b class="cp-req">*</b></span><input id="cpOcProvRfc" maxlength="13" data-fmt="rfc" value="${esc(match ? match.rfc : (propuesta.rfc || ""))}"></label>
              <label class="cp-f"><span>Razón social</span><input id="cpOcProvRazon" maxlength="220" value="${esc(match ? match.razon_social : (propuesta.razon_social || propuesta.nombre || ""))}"></label>
              <label class="cp-f"><span>Contacto</span><input id="cpOcProvContacto" maxlength="160" value="${esc(match ? match.contacto : (propuesta.contacto || ""))}"></label>
              <label class="cp-f"><span>Correo</span><input id="cpOcProvEmail" type="email" maxlength="140" value="${esc(match ? match.email : (propuesta.email || ""))}"></label>
              <label class="cp-f"><span>Teléfono</span><input id="cpOcProvTel" maxlength="10" data-fmt="digits" value="${esc(match ? match.telefono : (propuesta.telefono || ""))}"></label>
              <label class="cp-f"><span>Condiciones de pago</span><input id="cpOcProvCond" maxlength="300" value="${esc(match ? match.condiciones_pago : (propuesta.condiciones_pago || ""))}"></label>
              <label class="cp-f span2"><span>Domicilio</span><input id="cpOcProvDomicilio" maxlength="400" value="${esc(match ? match.domicilio : (propuesta.domicilio || ""))}"></label>
            </div>
          </section>
          <section class="cp-sec"><h3>Partidas y opciones</h3><div class="cp-ocitems">${blocks}</div></section>
          <section class="cp-sec"><h3>Datos de la orden</h3>
            <div class="cp-formgrid">
              <label class="cp-f"><span>Fecha de la OC</span><input id="cpOcFecha" type="date" value="${esc(s.requisicion?.fecha || todayISO())}"></label>
              <label class="cp-f"><span>Fecha de entrega</span><input id="cpOcEntrega" type="date" value="${esc(plusDaysISO(7))}"></label>
              <label class="cp-checkline span2"><input type="checkbox" id="cpOcMisma" checked>
                <span><b>Todos los productos llegan el mismo día</b><small>Si lo desmarcas, captura la fecha de llegada de cada producto en la lista de partidas.</small></span>
              </label>
              <label class="cp-f"><span>Descuento %</span><input id="cpOcDesc" type="number" min="0" max="100" step="0.01" value="0"></label>
              <div class="cp-f"><span>IVA</span><small class="cp-muted">Automático: no se suma si el precio ya lo incluye.</small></div>
              <label class="cp-f"><span>Almacén / destino</span><input id="cpOcAlmacen" maxlength="160" value=""></label>
              <label class="cp-f span2"><span>Condiciones</span><input id="cpOcCond" maxlength="800" value=""></label>
              <label class="cp-f span2"><span>Notas</span><textarea id="cpOcNotas" rows="2" maxlength="2000"></textarea></label>
            </div>
            <div class="cp-oc-total"><span>Total de la orden</span><b id="cpOcTotal">$0.00</b></div>
          </section>
        </div>
        <footer class="cp-modal-foot"><button class="cp-btn ghost" data-close>Cancelar</button><button class="cp-btn primary" id="cpOcSave">Generar orden de compra</button></footer>
      </div>`);
    const form = $(".cp-oc-modal", S.root);
    const syncOnline = () => {
      const online = !!$("#cpOcOnline", form)?.checked;
      const fields = $("#cpOcProvFields", form);
      const store = $("#cpOcOnlineStore", form);
      if (fields) {
        fields.classList.toggle("off", online);
        $$("input, select", fields).forEach(el => { el.disabled = online; });
      }
      if (store) store.hidden = !online;
    };
    $("#cpOcOnline", form)?.addEventListener("change", syncOnline);
    syncOnline();
    const syncFechas = () => {
      const misma = !!$("#cpOcMisma", form)?.checked;
      const entrega = $("#cpOcEntrega", form)?.value || "";
      $$("[data-oc-fecha]", form).forEach(inp => {
        inp.disabled = misma;
        if (misma) inp.value = entrega;
      });
    };
    $("#cpOcMisma", form)?.addEventListener("change", syncFechas);
    $("#cpOcEntrega", form)?.addEventListener("change", syncFechas);
    syncFechas();
    const rowCheck = row => $("[data-oc-opt], [data-oc-base]", row);
    const rowQty = row => $("[data-oc-qty], [data-oc-base-qty]", row);
    const rowCost = row => $("[data-oc-cost], [data-oc-base-cost]", row);
    const isRef = row => row.hasAttribute("data-oc-ref");
    const syncRow = row => {
      const box = row.closest("[data-ocitem]");
      const include = box ? $("[data-oc-include]", box)?.checked !== false : true;
      const cb = rowCheck(row);
      const enabled = include && !isRef(row) && !!cb && cb.checked;
      [rowQty(row), rowCost(row)].forEach(el => { if (el) el.disabled = !enabled; });
      $$("[data-qty-step]", row).forEach(b => { b.disabled = !enabled; });
    };
    const syncBox = box => { $$(".cp-ocopt", box).forEach(syncRow); };
    const boxTotals = box => {
      let sum = 0, moneySum = 0;
      $$(".cp-ocopt", box).forEach(row => {
        if (isRef(row)) return;
        const cb = rowCheck(row);
        if (cb && !cb.checked) return;
        const q = Number(rowQty(row)?.value) || 0;
        const c = Number(rowCost(row)?.value) || 0;
        sum += q; moneySum += q * c;
      });
      return { sum, moneySum };
    };
    const recalc = () => {
      let total = 0;
      $$("[data-ocitem]", form).forEach(box => {
        const req = Number(box.dataset.ocreq) || 0;
        const include = $("[data-oc-include]", box)?.checked !== false;
        const hint = $("[data-ocsum]", box);
        if (!include) {
          if (hint) { hint.textContent = "No incluido"; hint.className = "cp-ocsum partial"; }
          return;
        }
        const { sum, moneySum } = boxTotals(box);
        if (hint) {
          const over = sum > req + 0.001;
          const partial = sum > 0 && sum < req - 0.001;
          hint.textContent = `${qty(sum)} de ${qty(req)}${partial ? " (parcial)" : ""}`;
          hint.className = "cp-ocsum" + (over ? " bad" : partial ? " partial" : sum > 0 ? " ok" : " partial");
        }
        total += moneySum;
      });
      const el = $("#cpOcTotal", form);
      if (el) el.textContent = money(total);
    };
    const clampQty = (input) => {
      const row = input.closest(".cp-ocopt");
      const box = input.closest("[data-ocitem]");
      if (!row || !box) return;
      const req = Number(box.dataset.ocreq) || 0;
      const current = Number(input.value) || 0;
      const others = boxTotals(box).sum - current;
      const max = Math.max(0, req - others);
      if (current > max) input.value = max > 0 ? String(Math.round(max * 100) / 100) : "0";
    };
    form.addEventListener("click", (e) => {
      const stepBtn = e.target.closest("[data-qty-step]");
      if (!stepBtn) return;
      e.preventDefault();
      e.stopPropagation();
      const row = stepBtn.closest(".cp-ocopt");
      const input = row ? rowQty(row) : null;
      if (!input || input.disabled) return;
      const box = input.closest("[data-ocitem]");
      const req = Number(box?.dataset.ocreq) || 0;
      const current = Number(input.value) || 0;
      const others = boxTotals(box).sum - current;
      const max = Math.max(0, req - others);
      const next = Math.max(0, Math.min(max, Math.round((current + (Number(stepBtn.dataset.qtyStep) || 0)) * 100) / 100));
      input.value = next > 0 ? String(next) : "0";
      recalc();
    });
    form.addEventListener("input", (e) => {
      if (e.target.matches("[data-oc-qty], [data-oc-base-qty]")) clampQty(e.target);
      recalc();
    });
    form.addEventListener("change", (e) => {
      if (e.target.matches("[data-oc-include]")) {
        const box = e.target.closest("[data-ocitem]");
        if (!box) return;
        box.classList.toggle("off", !e.target.checked);
        syncBox(box);
        recalc();
        return;
      }
      if (e.target.matches("[data-oc-base]")) {
        const row = e.target.closest(".cp-ocopt");
        const box = row?.closest("[data-ocitem]");
        if (!row || !box) return;
        const req = Number(box.dataset.ocreq) || 0;
        const preview = row.querySelector("[data-ocoptprev]");
        if (preview) {
          preview.hidden = !e.target.checked;
          if (!preview.hidden) hydrateMedia(preview);
        }
        if (e.target.checked) {
          $$("[data-oc-opt]", box).forEach(cb => { cb.checked = false; });
          $$(".cp-ocopt", box).forEach(r => {
            if (r === row || isRef(r)) return;
            const q = rowQty(r); if (q) q.value = "0";
            const otherPreview = r.querySelector("[data-ocoptprev]");
            if (otherPreview) otherPreview.hidden = true;
          });
          const q = rowQty(row); if (q) q.value = req > 0 ? String(req) : "0";
        } else {
          const q = rowQty(row); if (q) q.value = "0";
        }
        $$(".cp-ocopt", box).forEach(r => {
          const cb = rowCheck(r);
          r.classList.toggle("on", !!cb?.checked);
        });
        syncBox(box);
        recalc();
        return;
      }
      if (e.target.matches("[data-oc-opt]")) {
        const row = e.target.closest(".cp-ocopt");
        const box = row?.closest("[data-ocitem]");
        if (!row || !box) return;
        const req = Number(box.dataset.ocreq) || 0;
        const qty = rowQty(row);
        // Al cambiar de opción se limpia la cantidad de las demás: solo una
        // alternativa puede quedar seleccionada por producto.
        $$(".cp-ocopt", box).forEach(r => {
          if (r !== row) {
            const q = rowQty(r); if (q) q.value = "0";
            const otherPreview = r.querySelector("[data-ocoptprev]");
            if (otherPreview) otherPreview.hidden = true;
          }
          const cb = rowCheck(r);
          r.classList.toggle("on", !!cb?.checked);
        });
        const preview = row.querySelector("[data-ocoptprev]");
        if (preview) {
          preview.hidden = !e.target.checked;
          if (!preview.hidden) hydrateMedia(preview);
        }
        if (e.target.checked) {
          const base = $("[data-oc-base]", box);
          if (base) {
            base.checked = false;
            const bq = rowQty(base.closest(".cp-ocopt"));
            if (bq) bq.value = "0";
          }
          if (qty) qty.value = String(req > 0 ? req : 0);
        } else if (qty) {
          qty.value = "0";
        }
        syncBox(box);
        recalc();
      }
      if (e.target.matches("[data-oc-qty], [data-oc-base-qty]")) clampQty(e.target);
      if (e.target.id === "cpOcProv") {
        const p = activos.find(x => String(x.id) === String(e.target.value));
        if (p) {
          $("#cpOcProvNombre", form).value = p.nombre || "";
          $("#cpOcProvRfc", form).value = normalizeRfc(p.rfc || "");
          $("#cpOcProvRazon", form).value = p.razon_social || p.nombre || "";
          $("#cpOcProvContacto", form).value = p.contacto || "";
          $("#cpOcProvEmail", form).value = p.email || "";
          $("#cpOcProvTel", form).value = normalizeDigits(p.telefono || "");
          $("#cpOcProvCond", form).value = p.condiciones_pago || "";
          $("#cpOcProvDomicilio", form).value = p.domicilio || "";
        }
      }
    });
    $$("[data-ocitem]", form).forEach(syncBox);
    recalc();
    $("#cpOcSave", S.root).onclick = async () => {
      const rfc = normalizeRfc($("#cpOcRfc", form).value);
      const razon = $("#cpOcRazon", form).value.trim();
      const online = !!$("#cpOcOnline", form)?.checked;
      const pid = online ? null : (Number($("#cpOcProv", form).value) || null);
      const pnombre = online ? "" : $("#cpOcProvNombre", form).value.trim();
      const prfc = online ? "" : normalizeRfc($("#cpOcProvRfc", form).value);
      if (!validRfc(rfc)) return toast("RFC de la empresa", "Captura un RFC válido.", "warning");
      if (!razon) return toast("Falta la razón social", "Captura la razón social de la empresa.", "warning");
      if (!online && !pid && !pnombre) return toast("Falta el proveedor", "Selecciona uno o captura su nombre, o marca Compra en línea.", "warning");
      if (!online && !pid && !validRfc(prfc)) return toast("RFC del proveedor", "Captura un RFC válido del proveedor.", "warning");
      const mismaFecha = !!$("#cpOcMisma", form)?.checked;
      const fechaEntrega = $("#cpOcEntrega", form)?.value || "";
      if (!fechaEntrega) return toast("Falta la fecha de entrega", "Indica cuándo se compromete la entrega de la orden.", "warning");
      if (!mismaFecha && $$("[data-oc-fecha]", form).some(inp => !inp.value)) {
        return toast("Falta una fecha de llegada", "Captura la fecha de llegada de cada producto o marca que todos llegan el mismo día.", "warning");
      }
      const items = [];
      let over = false;
      $$("[data-ocitem]", form).forEach(box => {
        if ($("[data-oc-include]", box)?.checked === false) return;
        const req = Number(box.dataset.ocreq) || 0;
        const itemId = Number(box.dataset.ocitem);
        const fechaLlegada = mismaFecha ? fechaEntrega : ($("[data-oc-fecha]", box)?.value || "");
        let sum = 0;
        $$(".cp-ocopt", box).forEach(row => {
          if (isRef(row)) return;
          const cb = $("[data-oc-opt]", row);
          if (cb && !cb.checked) return;
          const q = Number($("[data-oc-qty], [data-oc-base-qty]", row)?.value) || 0;
          const c = Number($("[data-oc-cost], [data-oc-base-cost]", row)?.value) || 0;
          if (q <= 0) return;
          sum += q;
          items.push({
            item_id: itemId,
            opcion_id: cb ? Number(cb.dataset.ocOpt) || null : null,
            cantidad: q,
            costo_unitario: c,
            descuento_pct: 0,
            fecha_llegada: fechaLlegada,
          });
        });
        if (sum > req + 0.001) over = true;
      });
      if (over) return toast("Cantidad mayor a la solicitada", "No puedes comprar más de lo solicitado. Reduce la cantidad o quita el producto de la OC.", "warning");
      if (!items.length) return toast("Sin partidas", "Incluye al menos un producto y selecciona una opción.", "warning");
      const prov = online || pid ? {} : {
        nombre: pnombre, rfc: prfc,
        razon_social: $("#cpOcProvRazon", form).value.trim() || pnombre,
        domicilio: $("#cpOcProvDomicilio", form).value.trim(),
        contacto: $("#cpOcProvContacto", form).value.trim(),
        email: $("#cpOcProvEmail", form).value.trim(),
        telefono: normalizeDigits($("#cpOcProvTel", form).value),
        condiciones_pago: $("#cpOcProvCond", form).value.trim(),
      };
      const body = {
        empresa: { rfc, razon_social: razon, nombre: razon },
        sin_proveedor: online,
        proveedor_nombre: online ? ($("#cpOcStore", form)?.value.trim() || "Compra en línea") : "",
        proveedor_id: pid,
        proveedor: prov,
        fecha: $("#cpOcFecha", form).value,
        fecha_entrega: fechaEntrega,
        misma_fecha_entrega: mismaFecha,
        // El servidor calcula el IVA con base en precio_incluye_iva; no se envía un % fijo.
        descuento_pct: Number($("#cpOcDesc", form).value) || 0,
        almacen: $("#cpOcAlmacen", form).value.trim(),
        condiciones: $("#cpOcCond", form).value.trim(),
        notas: $("#cpOcNotas", form).value.trim(),
        items,
      };
      const btn = $("#cpOcSave", form);
      if (btn) { btn.disabled = true; btn.textContent = "Generando…"; }
      try {
        const doc = await api(`/api/compras/solicitudes/${s.id}/orden`, { method: "POST", body: JSON.stringify(body) });
        hideOverlay();
        toast("Orden de compra generada", `${doc.folio} · ${money(doc.total)}`, "success");
        await refresh(true);
        openDocDetalle(doc.id);
      } catch (e) {
        if (btn) { btn.disabled = false; btn.textContent = "Generar orden de compra"; }
        toast("No se pudo generar", e.message, "error");
      }
    };
  }

  /* =====================  FORM: DOCUMENTO  ===================== */
  async function newDocumento(sid, tipo = "ambos") {
    if (!canManage()) return toast("Solo lectura", "La orden de compra la genera un gestor de Compras.", "warning");
    try {
      const s = await api("/api/compras/solicitudes/" + sid);
      if ((s.flujo || "legado") === "nuevo") return newOrdenCompra(s);
      const previos = s.documentos || [];
      const reqPrev = previos.find(d => d.tipo === "requisicion");
      const ocPrev = previos.find(d => d.tipo === "orden_compra");
      if (ocPrev) {
        toast("La compra ya tiene documentos", `${ocPrev.folio} ya está generada.`, "info");
        return openDocDetalle(ocPrev.id);
      }
      if (tipo === "ambos" && reqPrev) tipo = "orden_compra";
      S.docBase = s; S.docTipo = tipo;
      let empresa = S.empresa;
      if (!empresa) {
        try { empresa = await api("/api/compras/empresa"); S.empresa = empresa; }
        catch { empresa = {}; }
      }
      empresa = empresa || {};
      const activos = (S.proveedores || []).filter(p => p.activo && (p.calidad_estado || "aprobado") === "aprobado");
      const sugerido = (s.proveedor_sugerido || (s.items || []).map(x => x.proveedor).find(Boolean) || "").trim();
      const norm = v => String(v || "").trim().toLowerCase();
      const match = sugerido && activos.find(p => norm(p.nombre) === norm(sugerido));
      const inicial = match || (activos.length === 1 ? activos[0] : null);
      const prov = inicial || {};
      const provOpts = `<option value="">— Capturar proveedor nuevo —</option>` +
        activos.map(p => `<option value="${p.id}"${inicial && p.id === inicial.id ? " selected" : ""}>${esc(p.nombre)}${p.rfc ? " · " + esc(p.rfc) : ""}</option>`).join("");
      const itemMap = new Map((s.items || []).map(it => [String(it.id), it]));
      const rows = (s.items || []).map((it, i) => `<tr data-docrow="${i}" data-item-id="${it.id}">
        <td>${i + 1}</td>
        <td><b>${esc(it.nombre)}</b>${it.descripcion ? `<small class="cp-block">${nl2br(it.descripcion)}</small>` : ""}${it.id_fabricacion ? `<span class="cp-code">${esc(it.id_fabricacion)}</span>` : ""}</td>
        <td><input type="number" min="0.01" max="1000000" step="0.01" class="cp-in num" data-df="cantidad" value="${it.cantidad}"></td>
        <td><input type="number" min="0" max="1000000" step="0.01" class="cp-in num" data-df="costo_unitario" value="${it.costo_unitario}"></td>
        <td><select class="cp-in" data-df="precio_incluye_iva">
          <option value="0"${Number(it.precio_incluye_iva) ? "" : " selected"}>No</option>
          <option value="1"${Number(it.precio_incluye_iva) ? " selected" : ""}>Sí</option>
        </select></td>
        <td><input type="number" min="0" max="100" step="0.01" class="cp-in num" data-df="descuento_pct" value="0"></td>
        <td class="num cp-line-importe">${money(it.importe)}</td>
      </tr>`).join("");
      const titulo = tipo === "ambos" ? "Generar requisición + orden de compra" : "Generar orden de compra";
      showOverlay(`<div class="cp-veil"></div>
        <div class="cp-modal cp-form-modal wide" role="dialog" aria-label="Generar documentos de compra">
          <header class="cp-modal-head"><div><span class="cp-kicker">Paso final de la compra</span>
            <h2>${titulo}</h2>
            <p>${esc(s.folio)} · ${esc(s.titulo)}</p></div><button class="cp-x" data-close aria-label="Cerrar">&times;</button></header>
          <div class="cp-modal-body">
            <div class="cp-alert info"><b>Se generan dos documentos con la misma información.</b>
              <p>La <b>requisición</b> es la autorización interna y la <b>orden de compra</b> es el documento que se envía al proveedor. Captura todo una sola vez.</p></div>
            ${!(empresa.rfc || "").trim() || !(empresa.razon_social || "").trim() ? `<div class="cp-alert warn"><b>Faltan datos fiscales de la empresa.</b><p>Captura el RFC y la razón social aquí abajo; se guardarán para los siguientes documentos.</p></div>` : ""}
            <section class="cp-formsec">
              <h3>1. Datos fiscales de la empresa</h3>
              <div class="cp-formgrid">
                <label class="cp-f"><span>RFC <b class="cp-req">*</b></span><input id="cpDocEmpRfc" maxlength="13" data-fmt="rfc" autocomplete="off" spellcheck="false" value="${esc(normalizeRfc(empresa.rfc || ""))}" placeholder="Ej. SYL230101AB1"></label>
                <label class="cp-f"><span>Razón social <b class="cp-req">*</b></span><input id="cpDocEmpRazon" maxlength="220" value="${esc(empresa.razon_social || empresa.nombre || "")}"></label>
                <label class="cp-f span2"><span>Nombre comercial</span><input id="cpDocEmpNombre" maxlength="180" value="${esc(empresa.nombre || "")}"></label>
                <label class="cp-f span2"><span>Domicilio fiscal</span><input id="cpDocEmpDom" maxlength="400" value="${esc(empresa.domicilio || "")}"></label>
                <label class="cp-f"><span>Teléfono</span><input id="cpDocEmpTel" type="tel" inputmode="numeric" maxlength="10" data-fmt="digits" data-max="10" value="${esc(empresa.telefono || "")}"></label>
                <label class="cp-f"><span>Correo</span><input id="cpDocEmpEmail" type="email" maxlength="140" data-fmt="email" value="${esc(empresa.email || "")}"></label>
              </div>
            </section>
            <section class="cp-formsec">
              <h3>2. Proveedor</h3>
              <div class="cp-formgrid">
                <label class="cp-f span2"><span>Elegir proveedor existente</span><select id="cpDocProv">${provOpts}</select></label>
                <label class="cp-f"><span>Nombre comercial <b class="cp-req">*</b></span><input id="cpDocProvNombre" maxlength="180" value="${esc(prov.nombre || sugerido || "")}"></label>
                <label class="cp-f"><span>RFC <b class="cp-req">*</b></span><input id="cpDocProvRfc" maxlength="13" data-fmt="rfc" autocomplete="off" spellcheck="false" value="${esc(normalizeRfc(prov.rfc || ""))}" placeholder="Ej. EBA230101AB1"></label>
                <label class="cp-f span2"><span>Razón social</span><input id="cpDocProvRazon" maxlength="180" value="${esc(prov.razon_social || "")}"></label>
                <label class="cp-f span2"><span>Domicilio</span><input id="cpDocProvDom" maxlength="400" value="${esc(prov.domicilio || "")}"></label>
                <label class="cp-f"><span>Contacto</span><input id="cpDocProvContacto" maxlength="120" value="${esc(prov.contacto || "")}"></label>
                <label class="cp-f"><span>Teléfono</span><input id="cpDocProvTel" type="tel" inputmode="numeric" maxlength="10" data-fmt="digits" data-max="10" value="${esc(prov.telefono || "")}"></label>
                <label class="cp-f"><span>Correo</span><input id="cpDocProvEmail" type="email" maxlength="120" data-fmt="email" value="${esc(prov.email || "")}"></label>
                <label class="cp-f span2"><span>Condiciones de pago</span><input id="cpDocProvCond" maxlength="120" value="${esc(prov.condiciones_pago || "")}" placeholder="Ej. 30 días"></label>
              </div>
            </section>
            <section class="cp-formsec">
              <h3>3. Partidas y precios</h3>
              <p class="cp-guide sm">Confirma el costo de cada producto y si ese precio ya incluye IVA. Si ya lo incluye, no se vuelve a sumar: el total conserva el precio capturado.</p>
              <div class="cp-tablewrap"><table class="cp-table cp-table-form"><thead><tr><th>#</th><th>Producto</th><th>Cantidad</th><th>Costo unit.</th><th>¿Incluye IVA?</th><th>Desc. %</th><th class="num">Importe</th></tr></thead><tbody id="cpDocRows">${rows}</tbody></table></div>
            </section>
            <section class="cp-formsec">
              <h3>4. Condiciones del documento</h3>
              <div class="cp-formgrid">
                <label class="cp-f"><span>Fecha</span><input type="date" id="cpDocFecha" value="${todayISO()}"></label>
                <label class="cp-f"><span>Moneda</span><select id="cpDocMoneda"><option value="MXN">MXN · Peso mexicano</option><option value="USD">USD · Dólar</option></select></label>
                <label class="cp-f"><span>Almacén / destino</span><input id="cpDocAlmacen" value="Almacén general" maxlength="160"></label>
                <label class="cp-f"><span>Entregar a</span><input id="cpDocEntrega" value="${esc(s.username || "")}" maxlength="160"></label>
                <label class="cp-f"><span>Descuento global (%)</span><input type="number" id="cpDocDesc" min="0" max="100" step="0.01" value="0"></label>
                <div class="cp-f"><span>IVA</span><small class="cp-muted">Se calcula solo sobre las partidas cuyo precio no lo incluye.</small></div>
                <label class="cp-f span2"><span>Condiciones de pago / entrega</span><input id="cpDocCond" maxlength="800" value="Pago a 30 días. Entrega en almacén de El Marqués, Qro."></label>
                <label class="cp-f span2"><span>Notas del documento</span><textarea id="cpDocNotas" rows="2" maxlength="2000" placeholder="Observaciones para el proveedor o para el expediente."></textarea></label>
              </div>
            </section>
            <div class="cp-items-head"><h3>Resumen</h3><span id="cpDocTotal" class="cp-total">$0.00</span></div>
            <div id="cpDocTotals" class="cp-totals"></div>
          </div>
          <footer class="cp-modal-foot"><button class="cp-btn ghost" data-close>Cancelar</button><button class="cp-btn primary" id="cpDocSave">${tipo === "ambos" ? "Generar ambos documentos" : "Generar orden de compra"}</button></footer>
        </div>`);
      const fillProv = () => {
        const id = Number($("#cpDocProv", S.root).value) || null;
        const p = activos.find(x => x.id === id) || {};
        $("#cpDocProvNombre", S.root).value = p.nombre || "";
        $("#cpDocProvRfc", S.root).value = normalizeRfc(p.rfc || "");
        $("#cpDocProvRazon", S.root).value = p.razon_social || "";
        $("#cpDocProvDom", S.root).value = p.domicilio || "";
        $("#cpDocProvContacto", S.root).value = p.contacto || "";
        $("#cpDocProvTel", S.root).value = p.telefono || "";
        $("#cpDocProvEmail", S.root).value = p.email || "";
        $("#cpDocProvCond", S.root).value = p.condiciones_pago || "";
      };
      $("#cpDocProv", S.root).addEventListener("change", fillProv);
      const recalc = () => {
        let sub = 0, ivaBruto = 0, todasIncluyen = true, hayFilas = false;
        $$("#cpDocRows tr", S.root).forEach(tr => {
          const c = Number($('[data-df="cantidad"]', tr).value) || 0;
          const bruto = Number($('[data-df="costo_unitario"]', tr).value) || 0;
          const dpItem = Number($('[data-df="descuento_pct"]', tr).value) || 0;
          const incl = $('[data-df="precio_incluye_iva"]', tr).value === "1";
          const imp = c * bruto * (1 - dpItem / 100);
          $(".cp-line-importe", tr).textContent = money(imp);
          sub += imp;
          hayFilas = true;
          if (incl) ivaBruto += imp - imp / 1.16;
          else { todasIncluyen = false; ivaBruto += imp * 0.16; }
        });
        const dp = Number($("#cpDocDesc", S.root).value) || 0;
        const desc = sub * dp / 100;
        const iva = (hayFilas && todasIncluyen) ? 0 : ivaBruto * (1 - dp / 100);
        const total = sub - desc + iva;
        $("#cpDocTotal", S.root).textContent = money(total);
        $("#cpDocTotals", S.root).innerHTML = `<div><span>${(hayFilas && todasIncluyen) ? "Subtotal (IVA incluido)" : "Subtotal"}</span><b>${money(sub)}</b></div>
          ${dp ? `<div><span>Descuento (${dp}%)</span><b>- ${money(desc)}</b></div>` : ""}
          ${iva > 0.004 ? `<div><span>IVA</span><b>${money(iva)}</b></div>` : ""}
          <div class="tot"><span>Total</span><b>${money(total)}</b></div>
          ${(hayFilas && todasIncluyen) ? `<div class="cp-iva-note">Los precios ya incluyen IVA; no se agrega IVA adicional.</div>` : ""}`;
      };
      $("#cpDocRows", S.root).addEventListener("input", recalc);
      $("#cpDocRows", S.root).addEventListener("change", recalc);
      $("#cpDocDesc", S.root).addEventListener("input", recalc);
      recalc();
      $("#cpDocSave", S.root).onclick = async () => {
        const empresaData = {
          nombre: $("#cpDocEmpNombre", S.root).value.trim(),
          rfc: normalizeRfc($("#cpDocEmpRfc", S.root).value),
          razon_social: $("#cpDocEmpRazon", S.root).value.trim(),
          domicilio: $("#cpDocEmpDom", S.root).value.trim(),
          telefono: normalizeDigits($("#cpDocEmpTel", S.root).value, 10),
          email: $("#cpDocEmpEmail", S.root).value.trim(),
        };
        if (!empresaData.rfc) return toast("Falta el RFC de la empresa", "El RFC es obligatorio para los documentos oficiales.", "warning");
        if (!validRfc(empresaData.rfc)) return toast("RFC de la empresa no válido", "Usa el formato oficial de 12 o 13 caracteres. Ej. SYL230101AB1.", "warning");
        if (!empresaData.razon_social) return toast("Falta la razón social", "Escribe la razón social de la empresa.", "warning");
        if (empresaData.email && !validEmail(empresaData.email)) return toast("Correo de la empresa no válido", "Escribe un correo como compras@empresa.com.", "warning");
        const provData = {
          nombre: $("#cpDocProvNombre", S.root).value.trim(),
          rfc: normalizeRfc($("#cpDocProvRfc", S.root).value),
          razon_social: $("#cpDocProvRazon", S.root).value.trim(),
          domicilio: $("#cpDocProvDom", S.root).value.trim(),
          contacto: $("#cpDocProvContacto", S.root).value.trim(),
          telefono: normalizeDigits($("#cpDocProvTel", S.root).value, 10),
          email: $("#cpDocProvEmail", S.root).value.trim(),
          condiciones_pago: $("#cpDocProvCond", S.root).value.trim(),
        };
        if (!provData.nombre) return toast("Falta el proveedor", "Escribe el nombre del proveedor.", "warning");
        if (!provData.rfc) return toast("Falta el RFC del proveedor", "El RFC es obligatorio en la orden de compra.", "warning");
        if (!validRfc(provData.rfc)) return toast("RFC del proveedor no válido", "Usa el formato oficial de 12 o 13 caracteres. Ej. EBA230101AB1.", "warning");
        if (provData.email && !validEmail(provData.email)) return toast("Correo del proveedor no válido", "Escribe un correo como ventas@proveedor.com.", "warning");
        const items = $$("#cpDocRows tr", S.root).map(tr => {
          const src = itemMap.get(String(tr.dataset.itemId)) || {};
          return {
            item_id: Number(tr.dataset.itemId) || null,
            nombre: src.nombre || $("td:nth-child(2) b", tr).textContent.trim(),
            descripcion: src.descripcion || $("td:nth-child(2) small", tr)?.textContent.trim() || "",
            id_fabricacion: src.id_fabricacion || $("td:nth-child(2) .cp-code", tr)?.textContent.trim() || "",
            cantidad: Number($('[data-df="cantidad"]', tr).value) || 0,
            unidad: src.unidad || "pza",
            costo_unitario: Number($('[data-df="costo_unitario"]', tr).value) || 0,
            precio_incluye_iva: $('[data-df="precio_incluye_iva"]', tr).value === "1",
            descuento_pct: Number($('[data-df="descuento_pct"]', tr).value) || 0,
          };
        }).filter(x => x.nombre);
        if (!items.length) return toast("Sin partidas", "La solicitud no tiene productos.", "error");
        if (items.some(x => x.cantidad <= 0 || x.cantidad > 1000000)) {
          return toast("Cantidad no válida", "Cada partida debe tener entre 0.01 y 1,000,000 unidades.", "warning");
        }
        if (items.some(x => x.costo_unitario < 0 || x.costo_unitario > 1000000)) {
          return toast("Costo no válido", "El costo unitario debe estar entre 0 y 1,000,000.", "warning");
        }
        const provSel = Number($("#cpDocProv", S.root).value) || null;
        const body = {
          tipo, empresa: empresaData,
          proveedor_id: provSel, proveedor: provData,
          fecha: $("#cpDocFecha", S.root).value,
          moneda: $("#cpDocMoneda", S.root).value,
          almacen: $("#cpDocAlmacen", S.root).value.trim(),
          entregar_a: $("#cpDocEntrega", S.root).value.trim(),
          descuento_pct: Number($("#cpDocDesc", S.root).value) || 0,
          condiciones: $("#cpDocCond", S.root).value.trim(),
          notas: $("#cpDocNotas", S.root).value.trim(),
          items,
        };
        try {
          const doc = await api(`/api/compras/solicitudes/${sid}/documento`, { method: "POST", body: JSON.stringify(body) });
          const made = doc.requisicion && doc.orden_compra ? [doc.requisicion, doc.orden_compra] : [doc];
          hideOverlay();
          toast(made.length > 1 ? "Requisición y orden creadas" : "Documento generado",
            made.map(x => `${x.folio} · ${money(x.total)}`).join("  ·  "));
          await refresh(true);
          if (made.length > 1) await openSolicitud(sid);
          else openDocViewer(made[0].id);
        } catch (e) {
          if (e.status === 409 && e.data?.documento_id) {
            hideOverlay(); await refresh(true);
            if (e.data.faltante === "orden_compra") {
              toast("Solo falta la orden de compra", "La requisición ya existe; se abrirá el formulario para completar la orden.", "info");
              return newDocumento(sid, "orden_compra");
            }
            openDocDetalle(e.data.documento_id);
          } else toast("No se pudo generar", e.message, "error");
        }
      };
    } catch (e) { toast("No se pudo abrir", e.message, "error"); }
  }

  /* =====================  RECEPCIÓN  ===================== */
  async function openRecepcion(docId) {
    if (!canManage()) return toast("Solo lectura", "Solo un gestor de Compras puede registrar la recepción.", "warning");
    try {
      const d = await api("/api/compras/documentos/" + docId);
      const rows = (d.items || []).map((it, i) => `<tr data-recrow="${i}" data-item-id="${it.id}">
        <td>${i + 1}</td><td><b>${esc(it.nombre)}</b><small class="cp-block">${qty(it.cantidad)} ${esc(it.unidad)} pedidas</small></td>
        <td><input type="number" class="cp-in num" data-rf="cantidad" min="0" step="0.01" value="${it.cantidad}"></td>
        <td><select class="cp-in" data-rf="estado"><option value="ok">Correcto</option><option value="danado">Dañado</option><option value="faltante">Faltante</option><option value="incorrecto">Producto incorrecto</option></select></td>
        <td><input class="cp-in" data-rf="notas" maxlength="600" placeholder="Observaciones"></td>
      </tr>`).join("");
      showOverlay(`<div class="cp-veil"></div>
        <div class="cp-modal cp-form-modal wide" role="dialog" aria-label="Registrar recepción">
          <header class="cp-modal-head"><div><span class="cp-kicker">Recepción</span><h2>Registrar llegada del producto</h2><p>${esc(d.folio)} · ${esc(d.proveedor_nombre || "")}</p></div><button class="cp-x" data-close aria-label="Cerrar">&times;</button></header>
          <div class="cp-modal-body">
            <div class="cp-formgrid">
              <label class="cp-f"><span>Fecha de recepción</span><input type="date" id="cpRecFecha" value="${todayISO()}"></label>
              <label class="cp-f"><span>Resultado general</span><select id="cpRecEstado"><option value="completa">Completa · todo llegó bien</option><option value="parcial">Parcial · faltan piezas</option><option value="con_incidencias">Con incidencias · dañado o incorrecto</option></select></label>
              <label class="cp-f span2"><span>Notas de recepción</span><textarea id="cpRecNotas" rows="2" maxlength="2000" placeholder="Quién recibió, estado del empaque, observaciones…"></textarea></label>
            </div>
            <div class="cp-items-head"><h3>Partidas recibidas</h3></div>
            <div class="cp-tablewrap"><table class="cp-table cp-table-form"><thead><tr><th>#</th><th>Producto</th><th>Cantidad recibida</th><th>Estado</th><th>Observaciones</th></tr></thead><tbody id="cpRecRows">${rows}</tbody></table></div>
            <div class="cp-alert warn"><b>¿Llegó algo mal?</b><p>Marca la partida como dañada, faltante o incorrecta. Después podrás registrar la devolución desde el documento.</p></div>
          </div>
          <footer class="cp-modal-foot"><button class="cp-btn ghost" data-close>Cancelar</button><button class="cp-btn primary" id="cpRecSave">Registrar recepción</button></footer>
        </div>`);
      $("#cpRecSave", S.root).onclick = async () => {
        const items = $$("#cpRecRows tr", S.root).map(tr => ({
          item_id: Number(tr.dataset.itemId),
          cantidad: Number($('[data-rf="cantidad"]', tr).value) || 0,
          estado: $('[data-rf="estado"]', tr).value,
          notas: $('[data-rf="notas"]', tr).value.trim(),
        }));
        try {
          await api(`/api/compras/documentos/${docId}/recepcion`, { method: "POST", body: JSON.stringify({
            fecha: $("#cpRecFecha", S.root).value,
            estado: $("#cpRecEstado", S.root).value,
            notas: $("#cpRecNotas", S.root).value.trim(),
            items,
          }) });
          hideOverlay();
          toast("Recepción registrada", "El estado de la compra se actualizó.");
          await refresh(true);
          openDocDetalle(docId);
        } catch (e) { toast("No se pudo registrar", e.message, "error"); }
      };
    } catch (e) { toast("No se pudo abrir", e.message, "error"); }
  }

  /* =====================  DEVOLUCIÓN  ===================== */
  async function openDevolucion(docId) {
    if (!canManage()) return toast("Solo lectura", "Solo un gestor de Compras puede registrar devoluciones.", "warning");
    try {
      const d = await api("/api/compras/documentos/" + docId);
      const rows = (d.items || []).map((it, i) => `<tr data-devrow="${i}" data-item-id="${it.id}">
        <td>${i + 1}</td><td><b>${esc(it.nombre)}</b><small class="cp-block">${qty(it.cantidad)} ${esc(it.unidad)}</small></td>
        <td><input type="number" class="cp-in num" data-dvf="cantidad" min="0" step="0.01" value="${it.cantidad}"></td>
        <td><input class="cp-in" data-dvf="motivo" maxlength="600" placeholder="Motivo de esta partida"></td>
      </tr>`).join("");
      showOverlay(`<div class="cp-veil"></div>
        <div class="cp-modal cp-form-modal wide" role="dialog" aria-label="Registrar devolución">
          <header class="cp-modal-head"><div><span class="cp-kicker">Devolución</span><h2>Registrar devolución al proveedor</h2><p>${esc(d.folio)} · ${esc(d.proveedor_nombre || "")}</p></div><button class="cp-x" data-close aria-label="Cerrar">&times;</button></header>
          <div class="cp-modal-body">
            <label class="cp-f span2"><span>Motivo general <b class="cp-req">*</b></span><textarea id="cpDevMotivo" rows="3" maxlength="2000" placeholder="Ej. Producto dañado, no cumple especificaciones, llegó incompleto…"></textarea></label>
            <label class="cp-f span2"><span>Notas / acuerdo con el proveedor</span><textarea id="cpDevNotas" rows="2" maxlength="2000" placeholder="Reposición, nota de crédito, reembolso…"></textarea></label>
            <div class="cp-items-head"><h3>Partidas a devolver</h3></div>
            <div class="cp-tablewrap"><table class="cp-table cp-table-form"><thead><tr><th>#</th><th>Producto</th><th>Cantidad a devolver</th><th>Motivo de la partida</th></tr></thead><tbody id="cpDevRows">${rows}</tbody></table></div>
          </div>
          <footer class="cp-modal-foot"><button class="cp-btn ghost" data-close>Cancelar</button><button class="cp-btn danger" id="cpDevSave">Registrar devolución</button></footer>
        </div>`);
      $("#cpDevSave", S.root).onclick = async () => {
        const motivo = $("#cpDevMotivo", S.root).value.trim();
        if (!motivo) return toast("Falta el motivo", "Explica por qué se devuelve el producto.", "warning");
        const items = $$("#cpDevRows tr", S.root).map(tr => ({
          item_id: Number(tr.dataset.itemId),
          cantidad: Number($('[data-dvf="cantidad"]', tr).value) || 0,
          motivo: $('[data-dvf="motivo"]', tr).value.trim(),
        })).filter(x => x.cantidad > 0);
        try {
          await api(`/api/compras/documentos/${docId}/devolucion`, { method: "POST", body: JSON.stringify({
            motivo, notas: $("#cpDevNotas", S.root).value.trim(), items,
          }) });
          hideOverlay();
          toast("Devolución registrada", "Queda en revisión por el gestor de compras.");
          await refresh(true);
          openDocDetalle(docId);
        } catch (e) { toast("No se pudo registrar", e.message, "error"); }
      };
    } catch (e) { toast("No se pudo abrir", e.message, "error"); }
  }

  /* =====================  PROVEEDORES  ===================== */
  function areaField(rec) {
    const value = rec?.area || myArea();
    if (!isCatalogAdmin()) {
      return `<label class="cp-f"><span>Área dueña</span><input value="${esc(value || "Sin área asignada")}" readonly aria-readonly="true"><small>La asigna administración en tu cuenta.</small></label>`;
    }
    return `<label class="cp-f"><span>Área dueña <b class="cp-req">*</b></span>
      <input id="cpCatArea" list="cpAreasList" maxlength="80" minlength="2" value="${esc(value)}" placeholder="Ej. Producción">
      <datalist id="cpAreasList">${AREAS_CATALOGO.map(a => `<option value="${esc(a)}"></option>`).join("")}</datalist>
      <small>Calidad verá todas; cada área solo verá la suya.</small></label>`;
  }

  function estadoField(rec) {
    if (!isCatalogAdmin()) return "";
    const estado = rec?.calidad_estado || "aprobado";
    return `<label class="cp-f"><span>Estado de Calidad</span>
      <select id="cpCatEstado">
        <option value="pendiente"${estado === "pendiente" ? " selected" : ""}>Pendiente de revisión</option>
        <option value="aprobado"${estado === "aprobado" ? " selected" : ""}>Aprobado / apto</option>
        <option value="rechazado"${estado === "rechazado" ? " selected" : ""}>Rechazado / no apto</option>
      </select></label>
    <label class="cp-f span2"><span>Observación de Calidad <small>(opcional)</small></span>
      <textarea id="cpCatNota" rows="2" maxlength="1000" placeholder="Motivo, condiciones o requisitos adicionales.">${esc(rec?.calidad_nota || "")}</textarea></label>`;
  }

  function openProveedor(p = null) {
    if (!canCreateCatalog()) return toast("Sin área", "Tu cuenta no tiene un área asignada. Pide a administración que la capture.", "warning");
    if (p && !canEditCatalog(p)) return toast("Sin permiso", "Este proveedor pertenece a otra área.", "warning");
    const identLocked = !!p && p.calidad_estado === "aprobado" && !isCatalogAdmin();
    showOverlay(`<div class="cp-veil"></div>
      <div class="cp-modal" role="dialog" aria-label="Proveedor">
        <header class="cp-modal-head"><div><span class="cp-kicker">${p ? "Editar" : "Nuevo"} · Catálogo</span><h2>Proveedor</h2><p>${isCatalogAdmin()
          ? "Si lo dejas en <b>pendiente</b>, Calidad deberá autorizarlo. Los datos fiscales se imprimen en la orden de compra."
          : "El proveedor se guarda <b>aprobado</b> de inmediato. Solo los enviados a revisión de Calidad quedan pendientes."}</p></div><button class="cp-x" data-close aria-label="Cerrar">&times;</button></header>
        <div class="cp-modal-body">
          <div class="cp-formgrid">
            ${areaField(p)}
            ${estadoField(p)}
            <label class="cp-f span2"><span>Nombre comercial <b class="cp-req">*</b></span><input id="cpProvNombre" minlength="3" maxlength="180" value="${esc(p?.nombre || "")}" placeholder="Ej. Empaques del Bajío" ${identLocked ? "readonly aria-readonly=true" : ""}></label>
            <label class="cp-f"><span>RFC</span><input id="cpProvRfc" maxlength="13" data-fmt="rfc" autocomplete="off" spellcheck="false" value="${esc(normalizeRfc(p?.rfc || ""))}" placeholder="Ej. EBA230101AB1" ${identLocked ? "readonly aria-readonly=true" : ""}></label>
            <label class="cp-f"><span>Razón social</span><input id="cpProvRazon" maxlength="180" value="${esc(p?.razon_social || "")}" ${identLocked ? "readonly aria-readonly=true" : ""}></label>
            <label class="cp-f span2"><span>Domicilio</span><input id="cpProvDom" maxlength="400" value="${esc(p?.domicilio || "")}"></label>
            <label class="cp-f"><span>Contacto</span><input id="cpProvContacto" maxlength="120" value="${esc(p?.contacto || "")}"></label>
            <label class="cp-f"><span>Teléfono <small>(7 a 10 dígitos)</small></span><input id="cpProvTel" type="tel" inputmode="numeric" minlength="7" maxlength="10" data-fmt="digits" data-max="10" value="${esc(p?.telefono || "")}"></label>
            <label class="cp-f"><span>Correo</span><input id="cpProvEmail" type="email" maxlength="120" data-fmt="email" value="${esc(p?.email || "")}"></label>
            <label class="cp-f"><span>Condiciones de pago</span><input id="cpProvCond" maxlength="120" value="${esc(p?.condiciones_pago || "")}" placeholder="Ej. 30 días"></label>
          </div>
          ${identLocked ? `<p class="cp-guide sm"><b>Datos fiscales bloqueados:</b> el proveedor ya fue aprobado. Pide a Calidad o administración que modifique nombre, RFC o razón social.</p>` : ""}
          <p class="cp-ferrbox" id="cpProvErr" hidden></p>
        </div>
        <footer class="cp-modal-foot"><button class="cp-btn ghost" data-close>Cancelar</button><button class="cp-btn primary" id="cpProvSave">${p ? "Guardar cambios" : "Guardar proveedor"}</button></footer>
      </div>`);
    $("#cpProvSave", S.root).onclick = async () => {
      const errBox = $("#cpProvErr", S.root);
      const fail = (msg) => { if (errBox) { errBox.textContent = msg; errBox.hidden = false; } else toast("Revisa el proveedor", msg, "warning"); };
      const areaInput = $("#cpCatArea", S.root);
      const body = {
        nombre: $("#cpProvNombre", S.root).value.trim(),
        rfc: normalizeRfc($("#cpProvRfc", S.root).value),
        razon_social: $("#cpProvRazon", S.root).value.trim(),
        domicilio: $("#cpProvDom", S.root).value.trim(),
        contacto: $("#cpProvContacto", S.root).value.trim(),
        telefono: normalizeDigits($("#cpProvTel", S.root).value, 10),
        email: $("#cpProvEmail", S.root).value.trim().toLowerCase(),
        condiciones_pago: $("#cpProvCond", S.root).value.trim(),
      };
      if (areaInput) body.area = areaInput.value.trim();
      if (!body.area && isCatalogAdmin()) return fail("Selecciona el área dueña del proveedor.");
      if (body.nombre.length < 3) return fail("El nombre debe tener al menos 3 caracteres.");
      if (body.nombre.length > 180) return fail("El nombre no puede exceder 180 caracteres.");
      if (body.rfc && !validRfc(body.rfc)) return fail("RFC no válido. Usa el formato oficial de 12 o 13 caracteres. Ej. EBA230101AB1.");
      if (body.email && !validEmail(body.email)) return fail("Escribe un correo válido, por ejemplo ventas@proveedor.com.");
      if (body.telefono && (body.telefono.length < 7 || body.telefono.length > 10)) return fail("El teléfono debe tener entre 7 y 10 dígitos.");
      if (body.domicilio.length > 400) return fail("El domicilio no puede exceder 400 caracteres.");
      if (isCatalogAdmin()) {
        body.calidad_estado = $("#cpCatEstado", S.root)?.value || "pendiente";
        body.calidad_nota = $("#cpCatNota", S.root)?.value.trim() || "";
      }
      try {
        if (p) await api("/api/compras/proveedores/" + p.id, { method: "PATCH", body: JSON.stringify(body) });
        else await api("/api/compras/proveedores", { method: "POST", body: JSON.stringify(body) });
        hideOverlay(); toast(p ? "Proveedor actualizado" : "Proveedor guardado", body.nombre);
        if (S.view === "catalogo") S.catalogTab = "proveedores";
        await refresh(true);
      } catch (e) { fail(e.message); }
    };
  }

  /* =====================  EMPRESA  ===================== */
  function openEmpresa() {
    if (!canManage()) return;
    const e = S.empresa || {};
    showOverlay(`<div class="cp-veil"></div>
      <div class="cp-modal" role="dialog" aria-label="Datos fiscales">
        <header class="cp-modal-head"><div><span class="cp-kicker">Documentos oficiales</span><h2>Datos fiscales de la empresa</h2><p>El gestor de compras los captura una vez y aparecen en todas las requisiciones y órdenes de compra.</p></div><button class="cp-x" data-close aria-label="Cerrar">&times;</button></header>
        <div class="cp-modal-body">
          <div class="cp-alert info"><b>Datos obligatorios para documentos oficiales.</b><p>Sin RFC y razón social no se pueden generar la requisición ni la orden de compra.</p></div>
          <div class="cp-formgrid">
            <label class="cp-f"><span>RFC <b class="cp-req">*</b></span><input id="cpEmpRfc" maxlength="13" data-fmt="rfc" autocomplete="off" spellcheck="false" value="${esc(normalizeRfc(e.rfc || ""))}" placeholder="Ej. SYL230101AB1"></label>
            <label class="cp-f"><span>Razón social <b class="cp-req">*</b></span><input id="cpEmpRazon" maxlength="220" value="${esc(e.razon_social || e.nombre || "")}"></label>
            <label class="cp-f span2"><span>Nombre comercial</span><input id="cpEmpNombre" maxlength="180" value="${esc(e.nombre || "")}"></label>
            <label class="cp-f span2"><span>Domicilio fiscal</span><input id="cpEmpDom" maxlength="400" value="${esc(e.domicilio || "")}"></label>
            <label class="cp-f"><span>Teléfono</span><input id="cpEmpTel" type="tel" inputmode="numeric" maxlength="10" data-fmt="digits" data-max="10" value="${esc(e.telefono || "")}"></label>
            <label class="cp-f"><span>Correo</span><input id="cpEmpEmail" type="email" maxlength="140" data-fmt="email" value="${esc(e.email || "")}"></label>
          </div>
        </div>
        <footer class="cp-modal-foot"><button class="cp-btn ghost" data-close>Cancelar</button><button class="cp-btn primary" id="cpEmpSave">Guardar datos fiscales</button></footer>
      </div>`);
    $("#cpEmpSave", S.root).onclick = async () => {
      const rfc = normalizeRfc($("#cpEmpRfc", S.root).value);
      const razon = $("#cpEmpRazon", S.root).value.trim();
      const email = $("#cpEmpEmail", S.root).value.trim();
      if (!rfc) return toast("Falta el RFC", "El RFC es obligatorio para documentos oficiales.", "warning");
      if (!validRfc(rfc)) return toast("RFC no válido", "Usa el formato oficial: 3 o 4 letras, 6 dígitos de fecha y 3 caracteres. Ej. SYL230101AB1.", "warning");
      if (!razon) return toast("Falta la razón social", "Escribe la razón social de la empresa.", "warning");
      if (email && !validEmail(email)) return toast("Correo no válido", "Escribe un correo como compras@empresa.com.", "warning");
      try {
        S.empresa = await api("/api/compras/empresa", { method: "PATCH", body: JSON.stringify({
          nombre: $("#cpEmpNombre", S.root).value.trim(), rfc,
          razon_social: razon, domicilio: $("#cpEmpDom", S.root).value.trim(),
          telefono: $("#cpEmpTel", S.root).value.trim(), email: $("#cpEmpEmail", S.root).value.trim(),
        }) });
        hideOverlay();
        renderFiscalWarn();
        toast("Datos actualizados", "Los documentos usarán esta información.");
      } catch (e) { toast("No se pudo guardar", e.message, "error"); }
    };
  }

  /* =====================  VISOR DE DOCUMENTO  ===================== */
  function openDocViewer(id) {
    showOverlay(`<div class="cp-veil" data-close></div>
      <div class="cp-docview" role="dialog" aria-label="Vista previa del documento">
        <div class="cp-docview-bar">
          <div><b>Vista previa</b><span>Documento oficial · datos en tiempo real</span></div>
          <div class="cp-docview-actions">
            <button class="cp-btn" data-printdoc="${id}">Imprimir</button>
            <button class="cp-btn ghost" data-close>Cerrar</button>
          </div>
        </div>
        <iframe id="cpDocFrame" title="Documento de compra" src="compras-doc.html?id=${id}&token=${encodeURIComponent(token())}"></iframe>
      </div>`, "docmode");
  }

  async function printDoc(id) {
    const docId = id || S.currentDoc?.id || "";
    if (!docId) return toast("Documento no disponible", "Abre el documento antes de imprimir.", "warning");
    let docData = (S.currentDoc && String(S.currentDoc.id) === String(docId)) ? S.currentDoc : null;
    if (!docData) {
      try { docData = await api("/api/compras/documentos/" + docId); } catch { docData = null; }
    }
    const filename = docData ? docFileName(docData) : "";
    // En la app de escritorio se genera un PDF y se abre con Adobe Acrobat/Reader.
    if (window.pywebview?.api?.print_document) {
      try {
        toast("Preparando impresión", "Se abrirá el documento en Adobe.", "info");
        const r = await window.pywebview.api.print_document(String(docId), token(), filename);
        if (r?.ok) return toast("Documento abierto", r.viewer === "adobe" ? "Se abrió en Adobe Acrobat/Reader." : "Se abrió en tu visor de PDF.");
        toast("No se pudo abrir en Adobe", r?.msg || "Se intentará imprimir desde la vista previa.", "warning");
      } catch (e) {
        console.warn("print bridge:", e);
      }
    }
    const f = $("#cpDocFrame", S.root);
    if (f) {
      try {
        f.contentWindow.focus();
        f.contentWindow.print();
        return;
      } catch (e) { /* continúa con la ventana nueva */ }
    }
    window.open(`compras-doc.html?id=${docId}&print=1&token=${encodeURIComponent(token())}`, "_blank");
  }

  /* =====================  ACCIONES  ===================== */
  async function accionSolicitud(id, accion) {
    const esCambioOC = accion === "solicitar_cambios_oc";
    if (!["cancelar", "solicitar_cambios_oc"].includes(accion) && !canManage()) return toast("Solo lectura", "Solo un gestor de Compras puede realizar esta acción.", "warning");
    if (esCambioOC && String(S.currentSol?.username || "") !== username()) {
      return toast("Solo la persona solicitante", "Únicamente quien pidió la compra puede solicitar cambios en la OC.", "warning");
    }
    if (accion === "aprobar" || accion === "tomar") {
      const s = S.currentSol && String(S.currentSol.id) === String(id)
        ? S.currentSol
        : await api("/api/compras/solicitudes/" + id).catch(() => null);
      if (((s?.flujo) || "legado") === "nuevo" && !s?.requisicion_firmada) {
        return toast(
          "Falta la requisición firmada",
          "La persona solicitante debe descargar la requisición, firmarla con la jefatura de su área y subirla antes de que Compras pueda autorizar la compra.",
          "warning");
      }
      if (((s?.tipo_compra) || "normal") === "calidad" && s?.calidad_estado !== "aprobada") {
        return toast("Falta la revisión de Calidad", "Calidad debe aprobar las opciones antes de autorizar la compra.", "warning");
      }
    }
    let motivo = "";
    if (esCambioOC) {
      if (!window.Modal) {
        motivo = prompt("¿Qué debe cambiar de la orden de compra?:") || "";
        if (!motivo) return;
      } else {
        const r = await window.Modal.show({
          title: "Solicitar cambios en la OC",
          type: "info",
          msg: "Explica qué debe cambiar en la orden de compra antes de firmarla. La OC actual se cancelará y Compras generará una nueva; la requisición y la aprobación de la compra se conservan.",
          fields: [{ name: "motivo", label: "Cambios necesarios", type: "textarea", placeholder: "Ej. quiero sí o sí el producto del proveedor X; corrige la opción, cantidad o proveedor." }],
          buttons: [{ label: "Cancelar", value: false }, { label: "Solicitar cambios", value: true, primary: true }],
        });
        if (!r?.button) return;
        motivo = (r.values?.motivo || "").trim();
        if (!motivo) return toast("Falta explicar", "Escribe qué debe cambiar la orden de compra.", "warning");
      }
    } else if (accion === "rechazar" || accion === "solicitar_cambios") {
      const esCambio = accion === "solicitar_cambios";
      if (!window.Modal) {
        motivo = prompt(esCambio ? "¿Qué debe cambiar la persona solicitante?:" : "Motivo del rechazo:") || "";
        if (!motivo) return;
      } else {
        const r = await window.Modal.show({
          title: esCambio ? "Pedir cambios a la solicitud" : "Rechazar solicitud",
          type: esCambio ? "info" : "error",
          msg: esCambio
            ? "La solicitud volverá a la persona solicitante para que corrija los datos. Explica con claridad qué debe cambiar."
            : "Explica por qué no se autoriza la compra. La persona solicitante verá este motivo.",
          fields: [{ name: "motivo", label: esCambio ? "Cambios necesarios" : "Motivo del rechazo", type: "textarea", placeholder: esCambio ? "Ej. falta la cantidad, el enlace no corresponde, especifica medidas o color." : "Ej. no hay presupuesto, ya se compró, especificaciones incompletas…" }],
          buttons: [{ label: "Cancelar", value: false }, { label: esCambio ? "Pedir cambios" : "Rechazar", value: true, primary: true, danger: !esCambio }],
        });
        if (!r?.button) return;
        motivo = (r.values?.motivo || "").trim();
        if (!motivo) return toast("Falta explicar", esCambio ? "Escribe qué datos debe corregir." : "Escribe por qué se rechaza.", "warning");
      }
    } else {
      if (accion === "cerrar") {
        const s = await api("/api/compras/solicitudes/" + id).catch(() => null);
        const esNuevo = ((s?.flujo) || "legado") === "nuevo";
        const firmado = s ? (esNuevo ? (s.orden_compra_firmada && s.orden_compra_firmada_final) : (s.firmados || []).length) : true;
        if (!firmado) {
          return toast(
            "Falta la firma final",
            esNuevo
              ? "La OC debe tener la firma del jefe de área y la firma final del gestor asignado antes de cerrar la compra."
              : "Sube los documentos firmados que entrega cada área antes de cerrar la compra.",
            "warning");
        }
      }
      const labels = { tomar: "tomar esta solicitud", aprobar: "aprobar esta solicitud", cancelar: "cancelar esta solicitud", reabrir: "reabrir esta solicitud", cerrar: "cerrar esta compra" };
      if (!(await confirmar("Confirmar", `¿Deseas ${labels[accion] || accion}?`, ["cancelar", "cerrar"].includes(accion)))) return;
    }
    try {
      await api(`/api/compras/solicitudes/${id}/accion`, { method: "POST", body: JSON.stringify({ accion, motivo }) });
      toast("Listo", esCambioOC ? "Compras generará una nueva orden con los cambios." : "La solicitud se actualizó.");
      await refresh(true);
      openSolicitud(id);
    } catch (e) { toast("No se pudo actualizar", e.message, "error"); }
  }

  async function accionCalidad(id, accion) {
    let nota = "";
    let ids = [];
    if (accion === "aprobar") {
      ids = $$("[data-qopt]:checked", S.root).map(x => Number(x.dataset.qopt)).filter(Boolean);
      if (!ids.length) return toast("Selecciona opciones", "Aprueba al menos una opción de cada producto.", "warning");
      if (!(await confirmar("Aprobar opciones", "¿Confirmas las opciones seleccionadas? Compras solo podrá elegir esas opciones.", false))) return;
    } else {
      if (!window.Modal) {
        nota = prompt(accion === "solicitar_cambios" ? "¿Qué debe cambiar el solicitante?:" : "Motivo del rechazo de Calidad:") || "";
        if (!nota) return;
      } else {
        const esCambio = accion === "solicitar_cambios";
        const r = await window.Modal.show({
          title: esCambio ? "Calidad pide cambios" : "Calidad rechaza la compra",
          type: esCambio ? "info" : "error",
          msg: esCambio ? "La requisición se invalidará y el solicitante deberá corregir y firmar de nuevo." : "Explica por qué Calidad no autoriza esta compra.",
          fields: [{ name: "nota", label: esCambio ? "Cambios necesarios" : "Motivo", type: "textarea" }],
          buttons: [{ label: "Cancelar", value: false }, { label: esCambio ? "Pedir cambios" : "Rechazar", value: true, primary: true, danger: !esCambio }],
        });
        if (!r?.button) return;
        nota = (r.values?.nota || "").trim();
        if (!nota) return toast("Falta explicar", "Escribe la observación de Calidad.", "warning");
      }
    }
    try {
      await api(`/api/compras/solicitudes/${id}/calidad`, { method: "POST", body: JSON.stringify({ accion, nota, opciones_aprobadas: ids }) });
      toast("Calidad actualizó la solicitud", accion === "aprobar" ? "Ya puede continuar Compras." : "Se notificó al solicitante.");
      await refresh(true);
      openSolicitud(id);
    } catch (e) { toast("No se pudo actualizar", e.message, "error"); }
  }

  async function accionDocumento(id, accion) {
    if (!canManage()) return toast("Solo lectura", "Solo un gestor de Compras puede realizar esta acción.", "warning");
    let doc = S.currentDoc && String(S.currentDoc.id) === String(id) ? S.currentDoc : null;
    if (!doc && ["autorizar", "enviar", "cerrar"].includes(accion)) {
      doc = await api("/api/compras/documentos/" + id).catch(() => null);
    }
    const esNuevo = doc?.solicitud?.flujo === "nuevo";
    if (doc && accion === "autorizar" && esNuevo) {
      if (doc.tipo !== "orden_compra") {
        return toast("Paso incorrecto", "La requisición debe subirse firmada por la jefatura; no se autoriza desde el documento.", "warning");
      }
      if (!doc.solicitud?.requisicion_firmada) {
        return toast("Falta la requisición firmada", "La persona solicitante debe subir primero la requisición firmada por la jefatura de su área.", "warning");
      }
      if (!doc.solicitud?.orden_compra_firmada) {
        return toast("Falta la OC firmada", "La persona solicitante debe subir la OC firmada por la jefatura antes de que Compras la autorice.", "warning");
      }
    }
    if (doc && accion === "enviar" && esNuevo && !doc.solicitud?.orden_compra_firmada) {
      return toast("Falta la OC firmada", "No puedes enviar la OC hasta que la persona solicitante suba la versión firmada por la jefatura.", "warning");
    }
    if (accion === "cerrar") {
      const firmadoOk = doc && (esNuevo
        ? !!(doc.solicitud?.orden_compra_firmada && doc.solicitud?.orden_compra_firmada_final)
        : !!(doc.firmados || []).length);
      if (doc && !firmadoOk) {
        return toast(
          "Falta la firma final",
          esNuevo
            ? "La OC debe tener la firma del jefe de área y la firma final del gestor asignado antes de cerrar la compra."
            : "Sube los documentos firmados que entrega cada área antes de cerrar la compra.",
          "warning");
      }
    }
    const labels = { emitir: "emitir este documento", autorizar: "autorizar esta orden de compra", enviar: "marcar como enviada al proveedor", cancelar: "cancelar este documento", cerrar: "cerrar esta compra" };
    if (!(await confirmar("Confirmar", `¿Deseas ${labels[accion] || accion}?`, ["cancelar", "cerrar"].includes(accion)))) return;
    try {
      await api(`/api/compras/documentos/${id}/accion`, { method: "POST", body: JSON.stringify({ accion }) });
      toast("Listo", "El documento se actualizó.");
      await refresh(true);
      openDocDetalle(id);
    } catch (e) { toast("No se pudo actualizar", e.message, "error"); }
  }

  async function accionDevolucion(id, accion, ctx) {
    if (!canManage()) return toast("Solo lectura", "Solo un gestor de Compras puede realizar esta acción.", "warning");
    const labels = { aprobar: "aprobar la devolución", rechazar: "rechazar la devolución", enviar: "marcar como enviada", reembolsar: "marcar como reembolsada", cerrar: "cerrar la devolución" };
    if (!(await confirmar("Confirmar", `¿Deseas ${labels[accion] || accion}?`, ["rechazar"].includes(accion)))) return;
    try {
      await api(`/api/compras/devoluciones/${id}/accion`, { method: "POST", body: JSON.stringify({ accion }) });
      toast("Listo", "La devolución se actualizó.");
      await refresh(true);
      if (ctx === "list") hideOverlay();
      else if (ctx) openDocDetalle(ctx);
      else hideOverlay();
    } catch (e) { toast("No se pudo actualizar", e.message, "error"); }
  }

  /* =====================  EVENTOS  ===================== */
  function bind() {
    const root = S.root;
    if (!S.printMsgBound) {
      S.printMsgBound = true;
      // El botón "Imprimir" dentro del iframe delega aquí: así se usa el puente
      // de escritorio (Adobe) y no el diálogo de impresión del navegador.
      window.addEventListener("message", e => {
        const d = e.data || {};
        if (d.type === "sylpack:print-doc" && /^\d+$/.test(String(d.id || ""))) {
          printDoc(String(d.id));
        }
      });
    }
    if (root.dataset.cpBound === "1") return;
    root.dataset.cpBound = "1";
    // Las tarjetas del catálogo se abren con clic o con Enter/Espacio.
    root.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" && e.key !== " " && e.key !== "Spacebar") return;
      const card = e.target.closest("[data-catopen]");
      if (!card || e.target.closest("button, a, input, select, textarea")) return;
      e.preventDefault();
      openCatalogoDetalle(card.dataset.catopen, card.dataset.id);
    });
    root.addEventListener("click", async (e) => {
      const t = e.target;
      if (t.closest("[data-close]")) { hideOverlay(); return; }
      const kpi = t.closest("[data-kpi-view]");
      if (kpi) {
        S.view = kpi.dataset.kpiView;
        S.estado = kpi.dataset.kpiEstado || "";
        S.calidad = kpi.dataset.kpiCalidad || "";
        $$("#cpTabs button", root).forEach(b => b.classList.toggle("on", b.dataset.view === S.view));
        $$(".cp-kpi", root).forEach(b => { const on = b === kpi; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
        setEstadoOptions(); await refresh(true); return;
      }
      const view = t.closest("[data-view]");
      if (view) {
        S.view = view.dataset.view; S.estado = ""; S.calidad = ""; S.q = "";
        $$("#cpTabs button", root).forEach(b => b.classList.toggle("on", b === view));
        $$(".cp-kpi", root).forEach(b => { b.classList.remove("on"); b.setAttribute("aria-pressed", "false"); });
        const q = $("#cpQ", root); if (q) q.value = "";
        const filters = $(".cp-filters", root);
        if (filters) filters.hidden = S.view === "certificados";
        setEstadoOptions();
        if (S.view === "catalogo") { S.catalogTab = "productos"; S.catalogEstado = ""; S.catalogArea = ""; S.catalogCat = ""; S.catalogPrecioMin = ""; S.catalogPrecioMax = ""; S.catalogSort = "prioridad"; }
        if (S.view === "inventario") { S.invArea = ""; S.invCat = ""; S.invLow = false; }
        if (S.view === "proveedores" && viewAll()) {
          try { S.list = await api("/api/compras/proveedores"); renderList(); } catch (err) { toast("No se pudo cargar", err.message, "error"); }
        } else await refresh(true);
        return;
      }
      const catStat = t.closest("[data-catstat]");
      if (catStat) {
        S.catalogEstado = catStat.dataset.catstat === "todos" ? "" : catStat.dataset.catstat;
        renderList();
        return;
      }
      const catClear = t.closest("[data-catclear]");
      if (catClear) {
        S.catalogEstado = ""; S.catalogArea = ""; S.catalogCat = "";
        S.catalogPrecioMin = ""; S.catalogPrecioMax = ""; S.catalogSort = "prioridad";
        renderList();
        return;
      }
      const catTab = t.closest("[data-cattab]");
      if (catTab) {
        S.catalogTab = catTab.dataset.cattab === "proveedores" ? "proveedores" : "productos";
        S.list = S.catalogTab === "proveedores" ? (S.proveedores || []) : (S.certificados || []);
        renderList();
        return;
      }
      const catNew = t.closest("[data-catnew]");
      if (catNew) return catNew.dataset.catnew === "proveedor" ? openProveedor() : certificadoForm();
      const catEdit = t.closest("[data-catedit]");
      if (catEdit) {
        const kind = catEdit.dataset.kind === "proveedor" ? "proveedor" : "producto";
        const source = kind === "proveedor" ? S.proveedores : S.certificados;
        const rec = (source || []).find(x => String(x.id) === String(catEdit.dataset.catedit));
        return kind === "proveedor" ? openProveedor(rec || null) : certificadoForm(catEdit.dataset.catedit);
      }
      const catQa = t.closest("[data-catqa]");
      if (catQa) return catalogQuality(catQa.dataset.kind, catQa.dataset.id, catQa.dataset.catqa);
      const catOff = t.closest("[data-catoff]");
      if (catOff) return catalogToggle(catOff.dataset.catoff, catOff.dataset.id);
      const catOpen = t.closest("[data-catopen]");
      if (catOpen) return openCatalogoDetalle(catOpen.dataset.catopen, catOpen.dataset.id);
      const invNew = t.closest("[data-invnew]");
      if (invNew) return inventoryForm();
      const invEdit = t.closest("[data-invedit]");
      if (invEdit) return inventoryForm(invEdit.dataset.invedit);
      const invDel = t.closest("[data-invdel]");
      if (invDel) return deleteInventario(invDel.dataset.invdel);
      const invClear = t.closest("[data-invclear]");
      if (invClear) { S.invArea = ""; S.invCat = ""; S.invLow = false; return refresh(true); }
      const certNew = t.closest("[data-certnew]");
      if (certNew) return certificadoForm();
      const certEdit = t.closest("[data-certedit]");
      if (certEdit) return certificadoForm(certEdit.dataset.certedit);
      const act = t.closest("[data-act]");
      if (act) {
        const a = act.dataset.act;
        if (a === "new-sol") return newSolicitud();
        if (a === "providers") { S.view = "proveedores"; $$("#cpTabs button", root).forEach(b => b.classList.toggle("on", b.dataset.view === "proveedores")); setEstadoOptions(); S.list = await api("/api/compras/proveedores"); renderList(); return; }
        if (a === "company") return openEmpresa();
        if (a === "refresh") return refresh();
      }
      const railTabBtn = t.closest("[data-rail-tab]");
      if (railTabBtn) {
        const rail = railTabBtn.closest(".cp-rail");
        const tab = railTabBtn.dataset.railTab;
        $$("[data-rail-tab]", rail).forEach(b => {
          const on = b === railTabBtn;
          b.classList.toggle("on", on);
          b.setAttribute("aria-selected", on ? "true" : "false");
        });
        $$("[data-rail-pane]", rail).forEach(p => { p.hidden = p.dataset.railPane !== tab; });
        rail.scrollTop = 0;
        syncRailScroll();
        return;
      }
      const traceBtn = t.closest("[data-trace]");
      if (traceBtn) return openTrace(traceBtn.dataset.trace);
      const traceClose = t.closest("[data-trace-close]");
      if (traceClose) { traceClose.closest(".cp-trace-layer")?.remove(); return; }
      const traceTab = t.closest("[data-trace-tab]");
      if (traceTab) {
        const layer = traceTab.closest(".cp-trace-layer");
        const tab = traceTab.dataset.traceTab;
        $$("[data-trace-tab]", layer).forEach(b => {
          const on = b === traceTab;
          b.classList.toggle("on", on);
          b.setAttribute("aria-selected", on ? "true" : "false");
        });
        $$("[data-trace-pane]", layer).forEach(p => { p.hidden = p.dataset.tracePane !== tab; });
        if (tab === "chat") loadTraceChat(layer.dataset.traceSid);
        return;
      }
      const guideBtn = t.closest("[data-guide-action]");
      if (guideBtn) {
        const action = guideBtn.dataset.guideAction;
        const solId = guideBtn.dataset.sol;
        switch (action) {
          case "Tomar": return accionSolicitud(solId, "tomar");
          case "Autorizar": return accionSolicitud(solId, "aprobar");
          case "Generar OC": return newDocumento(solId, "orden_compra");
          case "Firmar final":
          case "Firmar":
          case "Firmados": {
            return guideToSignature(action);
          }
          case "Recepción": {
            const docSec = document.querySelector(".cp-sol-layout .cp-rail .cp-sec:has([data-opendoc])");
            if (docSec) {
              docSec.scrollIntoView({ behavior: "smooth", block: "center" });
              docSec.classList.add("cp-flash");
              setTimeout(() => docSec.classList.remove("cp-flash"), 1800);
            } else {
              document.querySelector(".cp-sol-layout .cp-rail")?.scrollIntoView({ behavior: "smooth", block: "start" });
            }
            return;
          }
          case "Cerrar": return accionSolicitud(solId, "cerrar");
          case "Editar": return newSolicitud(solId);
        }
      }
      const sol = t.closest("[data-sol]");
      if (sol) return openSolicitud(sol.dataset.sol);
      const doc = t.closest("[data-doc]");
      if (doc && !t.closest("[data-firmopen]")) return openDocDetalle(doc.dataset.doc);
      const dev = t.closest("[data-dev]");
      if (dev) {
        const d = S.list.find(x => String(x.id) === String(dev.dataset.dev));
        if (d) return openDevCard(d);
      }
      const prov = t.closest("[data-editprov]");
      if (prov) { const p = S.list.find(x => String(x.id) === String(prov.dataset.editprov)); return openProveedor(p || null); }
      const opendoc = t.closest("[data-opendoc]");
      if (opendoc) return openDocViewer(opendoc.dataset.opendoc);
      const printb = t.closest("[data-printdoc]");
      if (printb) return printDoc(printb.dataset.printdoc);
      const edit = t.closest("[data-editsol]");
      if (edit) return newSolicitud(edit.dataset.editsol);
      const nd = t.closest("[data-newdoc]");
      if (nd) return newDocumento(nd.dataset.newdoc, nd.dataset.tipo);
      const qa = t.closest("[data-qact]");
      if (qa) return accionCalidad(qa.dataset.id, qa.dataset.qact);
      const sa = t.closest("[data-solact]");
      if (sa) return accionSolicitud(sa.dataset.id, sa.dataset.solact);
      const da = t.closest("[data-docact]");
      if (da) return accionDocumento(da.dataset.id, da.dataset.docact);
      const da2 = t.closest("[data-devact]");
      if (da2) return accionDevolucion(da2.dataset.id, da2.dataset.devact, da2.dataset.devctx);
      const rec = t.closest("[data-recdoc]");
      if (rec) return openRecepcion(rec.dataset.recdoc);
      const devl = t.closest("[data-devledoc]");
      if (devl) return openDevolucion(devl.dataset.devledoc);
      const firmUp = t.closest("[data-firmupload]");
      if (firmUp) return uploadFirmados(Number(firmUp.dataset.sid), firmUp.dataset.ctx || "sol", Number(firmUp.dataset.ctxid) || null, firmUp.dataset.firmtype || "firmado");
      const firmDl = t.closest("[data-firmopen]");
      if (firmDl) return downloadFirmado(firmDl.dataset.firmopen, firmDl.dataset.name);
      const genPdf = t.closest("[data-genpdf]");
      if (genPdf) return generarPdfDigital(genPdf.dataset.genpdf);
      const firmDel = t.closest("[data-firmdel]");
      if (firmDel) return deleteFirmado(Number(firmDel.dataset.firmdel), Number(firmDel.dataset.sid), firmDel.dataset.ctx || "sol", Number(firmDel.dataset.ctxid) || null);
      const addItem = t.closest("[data-add-item]");
      if (addItem) {
        const box = $("#cpSolItems", root);
        const n = $$(".cp-itemrow", box).length;
        box.insertAdjacentHTML("beforeend", itemRowHTML(n));
        applyPlaceholders(box);
        updateMoveButtons(box);
        box.lastElementChild?.querySelector('[data-f="nombre"]')?.focus();
        return;
      }
      const addOpt = t.closest("[data-add-option]");
      if (addOpt) {
        const box = addOpt.closest(".cp-optbox")?.querySelector("[data-options]");
        if (box) {
          box.insertAdjacentHTML("beforeend", optionRowHTML({}));
          applyPlaceholders(box);
          box.lastElementChild?.querySelector('[data-of="etiqueta"]')?.focus();
        }
        return;
      }
      const rmOpt = t.closest("[data-remove-option]");
      if (rmOpt) {
        rmOpt.closest(".cp-optrow")?.remove();
        $('#cpSolForm', root).dispatchEvent(new Event("input", { bubbles: true }));
        return;
      }
      const mv = t.closest("[data-move-up], [data-move-down]");
      if (mv) {
        const row = mv.closest(".cp-itemrow");
        const box = row?.parentElement;
        if (row && box) {
          if (mv.matches("[data-move-up]") && row.previousElementSibling) {
            box.insertBefore(row, row.previousElementSibling);
          } else if (mv.matches("[data-move-down]") && row.nextElementSibling) {
            box.insertBefore(row.nextElementSibling, row);
          }
          updateMoveButtons(box);
          $('#cpSolForm', root).dispatchEvent(new Event("input", { bubbles: true }));
          mv.focus();
        }
        return;
      }
      const rm = t.closest("[data-remove-item]");
      if (rm) {
        const rows = $$(".cp-itemrow", $("#cpSolItems", root));
        if (rows.length <= 1) return toast("Debe quedar un producto", "Agrega otro antes de quitar este.", "warning");
        rm.closest(".cp-itemrow").remove();
        updateMoveButtons($("#cpSolItems", root));
        $('#cpSolForm', root).dispatchEvent(new Event("input", { bubbles: true }));
        return;
      }
    });
    root.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        if (!overlayHasFormModal()) hideOverlay();
        return;
      }
      if (e.key === "Enter" && e.target.matches(".cp-card")) { e.target.click(); }
    });
    root.addEventListener("input", (e) => {
      maskInput(e.target);
      if (e.target.id === "cpQ") {
        clearTimeout(S._qt);
        S._qt = setTimeout(async () => { S.q = e.target.value.trim(); S.estado = ""; S.calidad = ""; setEstadoOptions(); await refresh(true); }, 320);
      }
    });
    root.addEventListener("blur", (e) => tidyInput(e.target), true);
    root.addEventListener("change", async (e) => {
      if (e.target.id === "cpEstado") { S.estado = e.target.value; S.calidad = ""; await refresh(true); }
      if (e.target.matches("[data-catfilter]")) {
        const key = e.target.dataset.catfilter;
        if (key === "estado") S.catalogEstado = e.target.value;
        else if (key === "area") S.catalogArea = e.target.value;
        else if (key === "sort") S.catalogSort = e.target.value || "prioridad";
        else if (key === "categoria") S.catalogCat = e.target.value;
        else if (key === "precio") {
          const opt = e.target.selectedOptions?.[0];
          S.catalogPrecioMin = opt?.dataset.min || "";
          S.catalogPrecioMax = opt?.dataset.max || "";
        }
        renderList();
        return;
      }
      if (e.target.matches("[data-invfilter]")) {
        const key = e.target.dataset.invfilter;
        if (key === "categoria") S.invCat = e.target.value;
        else if (key === "area") S.invArea = e.target.value;
        else if (key === "bajo") S.invLow = !!e.target.checked;
        await refresh(true);
        return;
      }
      if (e.target.matches(".cp-filepick-input")) {
        const wrap = e.target.closest(".cp-filepick");
        const name = wrap?.querySelector(".cp-filepick-name");
        if (name) name.textContent = e.target.files?.[0]?.name || "No se ha seleccionado ningún archivo";
      }
    });
    const tabs = $("#cpTabs", root);
    if (tabs) tabs.addEventListener("keydown", (e) => { /* accesible con Tab/Enter nativo */ });
  }

  function openDevCard(d) {
    const rows = (d.items || []).map(x => `<li>${esc(x.item_nombre || "Partida")}: ${qty(x.cantidad)} ${x.motivo ? `· ${esc(x.motivo)}` : ""}</li>`).join("");
    const acts = canManage() && ["solicitada", "aprobada", "enviada", "reembolsada"].includes(d.estado) ? `
      ${d.estado === "solicitada" ? `<button class="cp-btn" data-devact="aprobar" data-id="${d.id}" data-devctx="list">Aprobar</button><button class="cp-btn danger" data-devact="rechazar" data-id="${d.id}" data-devctx="list">Rechazar</button>` : ""}
      ${d.estado === "aprobada" ? `<button class="cp-btn" data-devact="enviar" data-id="${d.id}" data-devctx="list">Marcar enviada</button>` : ""}
      ${d.estado === "enviada" ? `<button class="cp-btn ok" data-devact="reembolsar" data-id="${d.id}" data-devctx="list">Reembolsada</button>` : ""}
      <button class="cp-btn ghost" data-devact="cerrar" data-id="${d.id}" data-devctx="list">Cerrar</button>` : "";
    showOverlay(`<div class="cp-veil" data-close></div>
      <aside class="cp-drawer"><header class="cp-drawer-head"><div>
        <span class="cp-folio">${esc(d.folio || "")}</span><h2>Devolución</h2>
        <p>${esc(d.documento_folio || "")} · ${esc(d.solicitud_titulo || "")} · ${fdt(d.created_at)}</p>
      </div><button class="cp-x" data-close aria-label="Cerrar">&times;</button></header>
      <div class="cp-drawer-body"><div class="cp-statusbar">${badge(EST_DEV, d.estado)}</div>
        <section class="cp-sec"><h3>Motivo</h3><p>${nl2br(d.motivo || "")}</p></section>
        ${d.notas ? `<section class="cp-sec"><h3>Notas</h3><p>${nl2br(d.notas)}</p></section>` : ""}
        <section class="cp-sec"><h3>Partidas</h3><ul class="cp-mini-list">${rows || "<li>Sin partidas</li>"}</ul></section>
      </div><footer class="cp-drawer-foot">${acts}<button class="cp-btn ghost" data-close>Cerrar</button></footer></aside>`);
  }

  // Actualiza en sitio el estado/avance del drawer abierto sin cerrarlo ni
  // perder el scroll. Así el semáforo cambia en tiempo real al recibir el socket.
  async function syncOpenDrawer() {
    if (!S.root || S._syncing) return;
    const overlay = $("#cpOverlay", S.root);
    if (!overlay || overlay.hidden) return;
    if (overlay.querySelector("#cpSolForm, #cpDocForm, #cpRecForm, #cpDevForm")) return;
    const solDrawer = overlay.querySelector('[data-drawer="sol"]');
    const docDrawer = overlay.querySelector('[data-drawer="doc"]');
    if (!solDrawer && !docDrawer) return;
    S._syncing = true;
    try {
      if (solDrawer && S.currentSol) {
        const fresh = await api("/api/compras/solicitudes/" + S.currentSol.id);
        S.currentSol = fresh;
        const bar = solDrawer.querySelector(".cp-statusbar");
        if (bar) bar.innerHTML = `${badge(EST_SOL, fresh.estado)}${etapaBadge(fresh)}`;
        const st = solDrawer.querySelector(".cp-stepper");
        if (st) st.outerHTML = stepperHTML(fresh.estado);
        const pcard = solDrawer.querySelector(".cp-progresscard");
        if (pcard) {
          const small = pcard.querySelector(".cp-progresscard-head small");
          if (small) small.textContent = ETAPA[fresh.etapa_actual] || "Solicitud recibida";
          const count = pcard.querySelector(".cp-progress-count");
          if (count) count.textContent = `Etapa ${Math.min((SOL_STEP_INDEX[fresh.estado] ?? 0) + 1, SOL_STEPS.length)} de ${SOL_STEPS.length}`;
        }
      } else if (docDrawer && S.currentDoc) {
        const fresh = await api("/api/compras/documentos/" + S.currentDoc.id);
        S.currentDoc = fresh;
        const bar = docDrawer.querySelector(".cp-statusbar");
        if (bar) bar.innerHTML = `${badge(EST_DOC, fresh.estado)}<span class="cp-total">Total <b>${money(fresh.total)}</b></span>`;
        const holder = docDrawer.querySelector("[data-doc-stepper]");
        if (holder && fresh.solicitud?.estado) holder.innerHTML = stepperHTML(fresh.solicitud.estado);
      }
    } catch (e) {
      // Sin conexión momentánea: se reintenta con el siguiente evento/poll.
    } finally {
      S._syncing = false;
    }
  }

  function scheduleRefresh() {
    if (!S.root) return;
    clearTimeout(S._rt);
    S._rt = setTimeout(async () => {
      if (!S.root) return;
      await refresh(true);
      syncOpenDrawer();
    }, 300);
  }

  function onComprasEvent(d) {
    if (!d || !d.tipo) return;
    const destinos = Array.isArray(d.to) ? d.to : (typeof d.to === "string" && d.to ? [d.to] : null);
    const rolActual = role();
    const supervision = rolActual === "admin" || rolActual === "super";
    if (destinos && destinos.length && !supervision && !destinos.includes(username()) && !destinos.includes(rolActual)) return;
    if (d.tipo === "mensaje") {
      const mine = String(d.de || "") === username();
      if (S.currentSol && String(S.currentSol.id) === String(d.solicitud_id)) {
        loadSolicitudChat(d.solicitud_id);
      }
      if (!mine && !d.auto) {
        const title = `Nuevo mensaje · ${d.folio || "Solicitud"}`;
        const body = `${d.de || "Alguien"}: ${String(d.mensaje || "").slice(0, 130)}`;
        const open = () => window.goToCompra?.(d.solicitud_id);
        window.SylpackSound?.play("chat_in");
        window.SylpackToast?.show({
          kind: "message", title, body, sound: null, duration: 7000, onClick: open,
        });
        window.SylpackNotif?.desktop(title, body, { tag: `compra-${d.solicitud_id}`, onClick: open });
        window.SylpackNotif?.refresh?.();
      }
      scheduleRefresh();
      return;
    }
    if (d.tipo === "catalogo") {
      const mine = d.por && String(d.por) === username();
      const visible = isCatalogAdmin() || role() === "compras" || String(d.area || "") === myArea();
      if (!mine && visible) {
        const estado = (ESTADO_CATALOGO[d.estado] || [d.estado || "Actualizado"])[0];
        const title = `Catálogo · ${d.catalogo === "proveedor" ? "Proveedor" : "Producto"}`;
        const body = `${d.nombre || "Registro"} · ${estado}${d.area ? ` · ${d.area}` : ""}`;
        window.SylpackSound?.play("notif");
        window.SylpackToast?.show({
          kind: "info", title, body, sound: null, duration: 7000,
        });
        window.SylpackNotif?.desktop(title, body, { tag: `catalogo-${d.catalogo}-${d.id}` });
        window.SylpackNotif?.refresh?.();
      }
      scheduleRefresh();
      return;
    }
    if (d.tipo === "inventario") {
      const own = myArea();
      const visible = isInvAdmin() || (!!own && (String(d.area || "") === own ||
        (Array.isArray(d.areas_extra) && d.areas_extra.includes(own))));
      if (visible) {
        const mine = d.por && String(d.por) === username();
        if (!mine) {
          const label = d.accion === "baja" ? "Artículo eliminado" : d.accion === "alta" ? "Artículo agregado" : "Inventario actualizado";
          const body = `${d.nombre || "Artículo"}${d.area ? ` · ${d.area}` : ""}`;
          window.SylpackSound?.play("notif");
          window.SylpackToast?.show({ kind: "info", title: `Inventario · ${label}`, body, sound: null, duration: 6000 });
          window.SylpackNotif?.desktop(`Inventario · ${label}`, body, { tag: `inv-${d.id}` });
          window.SylpackNotif?.refresh?.();
        }
      }
      scheduleRefresh();
      return;
    }
    const mine = d.por && String(d.por) === username();
    if (!mine) {
      let label = "Se actualizó una compra";
      if (d.tipo === "solicitud" && d.estado) {
        label = `Solicitud ${d.folio || ""} · ${(EST_SOL[d.estado] || [d.estado])[0]}`;
      } else if (d.tipo === "documento") {
        label = `Documento ${d.folio || ""} actualizado`;
      } else if (d.tipo === "recepcion") {
        label = `Recepción ${d.folio || ""} registrada`;
      } else if (d.tipo === "devolucion") {
        label = `Devolución ${d.folio || ""} actualizada`;
      }
      window.SylpackSound?.play("notif");
      window.SylpackToast?.show({
        kind: "info", title: "Actualización de compra", body: label, sound: null,
        onClick: () => window.goToCompra?.(d.solicitud_id),
      });
      window.SylpackNotif?.desktop("Actualización de compra", label, { tag: `compra-${d.solicitud_id}` });
      window.SylpackNotif?.refresh?.();
    }
    scheduleRefresh();
  }

  window.addEventListener("sylpack:compras-event", (e) => onComprasEvent(e.detail));

  /* =====================  INIT  ===================== */
  function init(opts = {}) {
    // Asegurar que no hay lock residual de sesiones anteriores
    document.body.classList.remove("cp-lock");
    S.root = typeof opts.root === "string" ? document.querySelector(opts.root) : opts.root;
    if (!S.root) return console.warn("[compras] falta el contenedor");
    S.mode = opts.mode || "user";
    // "catalogo": monta solo la sección del catálogo (sección propia del portal).
    S.solo = opts.solo === "catalogo" ? "catalogo" : "";
    S.view = S.solo === "catalogo" ? "catalogo" : "solicitudes";
    S.catalogTab = "productos";
    S.catalogEstado = "";
    S.catalogArea = "";
    S.catalogCat = "";
    S.catalogPrecioMin = "";
    S.catalogPrecioMax = "";
    S.catalogSort = "prioridad";
    S.estado = "";
    S.calidad = "";
    S.q = "";
    S.invArea = "";
    S.invCat = "";
    S.invLow = false;
    S.root.innerHTML = shellHTML();
    bind();
    setEstadoOptions();
    // Verificar token antes de hacer llamadas
    if (!token()) {
      console.warn("[compras] Sin token de acceso, redirigiendo a login");
      if (window.SylpackAuth?.fail) window.SylpackAuth.fail();
      return;
    }
    refresh();
    clearInterval(S.timer);
    S.timer = setInterval(() => {
      if (document.hidden) return;
      // Refresca lista y, si hay un drawer abierto, su avance en tiempo real.
      refresh(true);
      syncOpenDrawer();
    }, 25000);
    window.addEventListener("sylpack:compras", () => { refresh(true); syncOpenDrawer(); });
    if (!S._railEvents) {
      S._railEvents = true;
      window.addEventListener("resize", () => requestAnimationFrame(syncRailScroll));
      // Abrir/cerrar un <details> cambia la altura útil del rail.
      document.addEventListener("toggle", () => requestAnimationFrame(syncRailScroll), true);
    }
  }

  // Cambia entre "mis compras" (usuario), "gestionar" (rol compras) y
  // "solo lectura" (admin/super) reutilizando la misma instancia y contenedor.
  function setMode(mode) {
    if (!["user", "manager", "admin", "quality"].includes(mode) || !S.root) return;
    // Limpiar lock residual al cambiar de modo
    document.body.classList.remove("cp-lock");
    if (mode === S.mode) return refresh(true);
    S.mode = mode;
    S.view = "solicitudes";
    S.estado = "";
    S.calidad = "";
    S.q = "";
    S.invArea = "";
    S.invCat = "";
    S.invLow = false;
    S.busy = false;
    S.root.innerHTML = shellHTML();
    bind();
    setEstadoOptions();
    if (!token()) {
      if (window.SylpackAuth?.fail) window.SylpackAuth.fail();
      return;
    }
    refresh();
    // Global Escape key to close any open overlay (prevents app freeze)
    if (!S._escBound) {
      S._escBound = true;
      document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
          const ov = $("#cpOverlay", S.root);
          if (ov && !ov.hidden && !overlayHasFormModal()) hideOverlay();
        }
      });
    }
  }

  function openModule(view) {
    if (!S.root || !["catalogo", "proveedores"].includes(view)) return;
    const tab = $$("#cpTabs button", S.root).find(b => b.dataset.view === view);
    if (tab) tab.click();
  }

  window.ComprasUI = { init, setMode, refresh, openSolicitud, openDocViewer, openModule };
  // Navegación desde notificaciones
  window.goToCompra = function(solId) {
    if (typeof solId === "number" || String(solId).match(/^\d+$/)) {
      // Asegurar que estamos en modo manager si el usuario tiene rol compras
      if (role() === "compras" && S.mode !== "manager") {
        ComprasUI.setMode("manager");
      }
      openSolicitud(solId);
    }
  };
})();
