/* Modales glassmorphism para toda la app: éxito, error, info y formularios. */
(() => {
  const ICONS = {
    ok: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
    error: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
    info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
  };

  function ensureRoot() {
    let root = document.getElementById("modal-root");
    if (!root) {
      root = document.createElement("div");
      root.id = "modal-root";
      document.body.appendChild(root);
    }
    return root;
  }

  let activeClose = null;
  function show({ title = "", msg = "", type = "info", buttons = null, fields = null, html = false, onInput = null }) {
    return new Promise(resolve => {
      // Si otro modal quedó abierto (por ejemplo al insistir en un botón),
      // se cierra de forma limpia antes de montar el nuevo. Así no se apilan
      // velos invisibles ni se fugan candados de scroll.
      if (activeClose) {
        try { activeClose(false); } catch {}
        activeClose = null;
      }
      const root = ensureRoot();
      root.innerHTML = "";
      root.classList.add("show");
      window.SylpackScroll?.lock();
      const veil = document.createElement("div");
      veil.className = "modal-veil";
      const card = document.createElement("div");
      card.className = "modal-card";
      card.setAttribute("role", "dialog");
      card.innerHTML = `<div class="modal-head"><div class="modal-ico ${type}">${ICONS[type] || ICONS.info}</div><h3></h3></div><div class="modal-body"></div>`;
      card.querySelector("h3").textContent = title;
      const _b = card.querySelector(".modal-body");
      if (html) _b.innerHTML = String(msg || "");
      else _b.innerHTML = String(msg || "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c])).replace(/\n/g, "<br>");

      const values = {};
      const wrapEls = {};
      const errEls = {};
      const cleanups = [];
      const applyVisibility = () => {
        fields.forEach(f => {
          const w = wrapEls[f.name];
          if (!w || !f.visibleWhen) return;
          const dep = values[f.visibleWhen.field];
          const show = !!dep && dep.value === f.visibleWhen.equals;
          w.style.display = show ? "" : "none";
        });
      };
      const collect = () => {
        const out = {};
        Object.keys(values).forEach(k => {
          const el = values[k];
          if (!el) return;
          if (el.type === "checkbox") out[k] = el.checked ? "1" : "0";
          else if (el.type === "radio") {
            const ch = card.querySelector(`input[type="radio"][name="${CSS.escape(k)}"]:checked`);
            out[k] = ch ? ch.value : "";
          }
          else if (el.type === "file") out[k] = el._clipboardFile || (el.files && el.files[0]) || "";
          else out[k] = el.value;
        });
        return out;
      };
      if (fields) {
        fields.forEach((f, fi) => {
          const wrap = document.createElement("div");
          wrap.className = "modal-field";
          const lab = document.createElement("label");
          lab.textContent = f.label;
          wrap.appendChild(lab);
          let inp;
          if (f.type === "select") {
            inp = document.createElement("select");
            inp.name = f.name;
            f.options.forEach(o => {
              const op = document.createElement("option");
              op.value = o.value; op.textContent = o.label;
              inp.appendChild(op);
            });
            if (f.value) inp.value = f.value;
            wrap.appendChild(inp);
          } else if (f.type === "range") {
            inp = document.createElement("input");
            inp.type = "range"; inp.name = f.name;
            inp.min = f.min ?? 80; inp.max = f.max ?? 150; inp.step = f.step ?? 5;
            inp.value = f.value ?? 100;
            const row = document.createElement("div");
            row.className = "mrange-row";
            const out = document.createElement("span");
            out.className = "mrange-val";
            out.textContent = inp.value + (f.suffix || "%");
            inp.addEventListener("input", () => out.textContent = inp.value + (f.suffix || "%"));
            row.appendChild(inp); row.appendChild(out);
            wrap.appendChild(row);
          } else if (f.type === "segmented") {
            // grupo de píldoras excluyentes (más intuitivo que un select)
            inp = null;
            const seg = document.createElement("div");
            seg.className = "seg";
            seg.setAttribute("role", "radiogroup");
            f.options.forEach(o => {
              const lab = document.createElement("label");
              lab.className = "seg-opt";
              const radio = document.createElement("input");
              radio.type = "radio"; radio.name = f.name; radio.value = o.value;
              if (String(f.value) === String(o.value)) radio.checked = true;
              const sp = document.createElement("span");
              sp.textContent = o.label;
              lab.appendChild(radio); lab.appendChild(sp);
              seg.appendChild(lab);
              if (!values[f.name] && radio.checked) values[f.name] = radio;
              if (radio.checked) values[f.name] = radio;
            });
            if (!values[f.name]) {
              const first = seg.querySelector("input");
              if (first) { first.checked = true; values[f.name] = first; }
            }
            wrap.appendChild(seg);
          } else if (f.type === "textarea") {
            inp = document.createElement("textarea");
            inp.name = f.name;
            inp.rows = 3;
            inp.maxLength = 500;
            inp.placeholder = f.placeholder || "";
            inp.value = f.value || "";
            wrap.appendChild(inp);
          } else if (f.type === "toggle") {
            const sw = document.createElement("label");
            sw.className = "mswitch";
            inp = document.createElement("input");
            inp.type = "checkbox"; inp.name = f.name;
            inp.checked = f.value === "1" || f.value === true;
            const kn = document.createElement("span");
            kn.className = "mknob";
            const tx = document.createElement("span");
            tx.className = "mstate";
            tx.textContent = inp.checked ? (f.on || "Activado") : (f.off || "Desactivado");
            inp.addEventListener("change", () => tx.textContent = inp.checked ? (f.on || "Activado") : (f.off || "Desactivado"));
            sw.appendChild(inp); sw.appendChild(kn);
            const line = document.createElement("div");
            line.className = "mtoggle-line";
            line.appendChild(sw); line.appendChild(tx);
            if (f.hint) {
              const h = document.createElement("small");
              h.className = "mhint"; h.textContent = f.hint;
              wrap.appendChild(line); wrap.appendChild(h);
            } else wrap.appendChild(line);
          } else if (f.inputType === "file") {
            // selector de archivo con diseño (no genérico)
            inp = document.createElement("input");
            inp.type = "file"; inp.name = f.name;
            if (f.accept) inp.accept = f.accept;
            inp.style.display = "none";
            const pick = document.createElement("label");
            pick.className = "mfile";
            pick.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg><span></span>`;
            const ftxt = pick.querySelector("span");
            const baseTxt = f.placeholder || "Seleccionar imagen (png, jpg, webp)";
            ftxt.textContent = baseTxt;
            const box = document.createElement("div");
            box.className = "mpreview"; box.hidden = true;
            const img = document.createElement("img");
            img.alt = "Vista previa de la evidencia";
            const cap = document.createElement("small");
            box.appendChild(img); box.appendChild(cap);
            let objUrl = "";
            const showPreview = file => {
              if (!file) { box.hidden = true; img.removeAttribute("src"); cap.textContent = ""; return; }
              if (objUrl) URL.revokeObjectURL(objUrl);
              objUrl = URL.createObjectURL(file);
              img.src = objUrl;
              cap.textContent = file.name || "Imagen lista";
              box.hidden = false;
            };
            cleanups.push(() => { if (objUrl) URL.revokeObjectURL(objUrl); });
            inp.addEventListener("change", () => {
              if (inp.files && inp.files.length) {
                inp._clipboardFile = null;
                ftxt.textContent = inp.files[0].name;
                pick.classList.add("has");
                showPreview(inp.files[0]);
              } else {
                ftxt.textContent = baseTxt;
                pick.classList.remove("has");
                showPreview(null);
              }
            });
            pick.appendChild(inp);
            wrap.appendChild(pick);
            wrap.appendChild(box);
            if (f.clipboard) {
              const pbtn = document.createElement("button");
              pbtn.type = "button"; pbtn.className = "mbtn ghost mpaste";
              pbtn.textContent = "Pegar imagen (Ctrl+V)";
              pbtn.onclick = async () => {
                try {
                  if (!navigator.clipboard?.read) throw new Error("sin acceso");
                  const items = await navigator.clipboard.read();
                  let file = null;
                  for (const item of items) {
                    const tipo = (item.types || []).find(t => t.startsWith("image/"));
                    if (!tipo) continue;
                    const blob = await item.getType(tipo);
                    const ext = (tipo.split("/")[1] || "png").replace("jpeg", "jpg");
                    file = new File([blob], `pegado_${Date.now()}.${ext}`, { type: tipo });
                    break;
                  }
                  if (!file) throw new Error("sin imagen");
                  inp._clipboardFile = file;
                  ftxt.textContent = "Imagen pegada desde el portapapeles";
                  pick.classList.add("has");
                  showPreview(file);
                } catch {
                  window.Modal?.error("No se pudo pegar", "Copia una imagen y presiona Ctrl+V dentro de este formulario.");
                }
              };
              wrap.appendChild(pbtn);
              const onPaste = e => {
                const item = [...(e.clipboardData?.items || [])].find(it => it.kind === "file" && /^image\//i.test(it.type));
                if (!item) return;
                const file = item.getAsFile();
                if (!file) return;
                e.preventDefault();
                inp._clipboardFile = file;
                ftxt.textContent = "Imagen pegada desde el portapapeles";
                pick.classList.add("has");
                showPreview(file);
              };
              document.addEventListener("paste", onPaste);
              cleanups.push(() => document.removeEventListener("paste", onPaste));
            }
          } else {
            inp = document.createElement("input");
            inp.name = f.name;
            inp.type = f.inputType || "text";
            inp.placeholder = f.placeholder || "";
            inp.value = f.value || "";
            if (f.maxLength) inp.maxLength = f.maxLength;
            if (f.eyeToggle && inp.type === "password") {
              const pw = document.createElement("div");
              pw.className = "mpass";
              const eb = document.createElement("button");
              eb.type = "button"; eb.className = "meye"; eb.setAttribute("aria-label", "Mostrar contraseña");
              eb.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;
              eb.onclick = () => {
                const show = inp.type === "password";
                inp.type = show ? "text" : "password";
                eb.classList.toggle("off", !show);
              };
              pw.appendChild(inp); pw.appendChild(eb);
              wrap.appendChild(pw);
            } else wrap.appendChild(inp);
            if (f.preview) {
              const box = document.createElement("div");
              box.className = "mpreview"; box.hidden = true;
              const img = document.createElement("img");
              img.alt = "Vista previa de la imagen";
              const cap = document.createElement("small");
              box.appendChild(img); box.appendChild(cap);
              wrap.appendChild(box);
              let objUrl = "", seq = 0, timer = 0;
              const clear = () => {
                if (objUrl) { URL.revokeObjectURL(objUrl); objUrl = ""; }
                img.removeAttribute("src"); box.hidden = true; cap.textContent = "";
              };
              cleanups.push(() => { if (objUrl) URL.revokeObjectURL(objUrl); clearTimeout(timer); });
              const load = async () => {
                const url = String(inp.value || "").trim();
                if (!/^https?:\/\//i.test(url)) { clear(); return; }
                const my = ++seq;
                cap.textContent = "Cargando vista previa…";
                box.hidden = false;
                try {
                  const tk = localStorage.getItem("access") || sessionStorage.getItem("access") || "";
                  const api = String((typeof API_BASE !== "undefined" ? API_BASE : (window.API_BASE || ""))).replace(/\/$/, "");
                  const r = await fetch(api + "/api/compras/imagen?url=" + encodeURIComponent(url), {
                    headers: { Authorization: "Bearer " + tk }, cache: "no-store"
                  });
                  if (!r.ok) throw new Error("sin imagen");
                  if (my !== seq) return;
                  if (objUrl) URL.revokeObjectURL(objUrl);
                  objUrl = URL.createObjectURL(await r.blob());
                  img.src = objUrl;
                  cap.textContent = "Vista previa de la imagen";
                } catch {
                  if (my !== seq) return;
                  clear();
                  // Respaldo: si el servidor no pudo descargarla, el navegador
                  // intenta mostrarla directamente sin referrer.
                  img.referrerPolicy = "no-referrer";
                  img.onerror = () => clear();
                  img.src = url;
                  box.hidden = false;
                  cap.textContent = "Vista previa de la imagen";
                }
              };
              inp.addEventListener("input", () => {
                clearTimeout(timer);
                timer = setTimeout(load, 450);
              });
              inp.addEventListener("blur", load);
              if (String(inp.value || "").trim()) load();
            }
          }
          const err = document.createElement("small");
          err.className = "merr";
          err.id = "merr-" + fi;
          err.setAttribute("role", "alert");
          err.hidden = true;
          if (inp) {
            const prev = inp.getAttribute("aria-describedby");
            inp.setAttribute("aria-describedby", (prev ? prev + " " : "") + err.id);
          }
          wrap.appendChild(err);
          card.appendChild(wrap);
          if (inp) values[f.name] = inp;
          wrapEls[f.name] = wrap;
          errEls[f.name] = err;
        });

        const setErr = (f, msg) => {
          const err = errEls[f.name];
          const inp = values[f.name];
          const wrap = wrapEls[f.name];
          if (!err) return !msg;
          err.textContent = msg || "";
          err.hidden = !msg;
          if (wrap) wrap.classList.toggle("invalid", !!msg);
          if (inp) {
            if (msg) inp.setAttribute("aria-invalid", "true");
            else inp.removeAttribute("aria-invalid");
          }
          return !msg;
        };

        const validateField = (f, all) => {
          const inp = values[f.name];
          const wrap = wrapEls[f.name];
          if (!inp || !wrap || wrap.style.display === "none") return true;
          let msg = "";
          if (typeof f.validate === "function") {
            const r = f.validate(all || collect());
            if (r === false) msg = f.error || "Revisa este campo.";
            else if (typeof r === "string") msg = r;
          }
          if (!msg) {
            const val = inp.type === "checkbox" ? inp.checked : String(inp.value ?? "").trim();
            if (f.required && (inp.type === "checkbox" ? !val : !val)) {
              msg = f.error || `${f.label || "Este campo"} es obligatorio.`;
            } else if (val && f.minLength && String(val).length < f.minLength) {
              msg = f.error || `Mínimo ${f.minLength} caracteres.`;
            } else if (val && f.maxLength && String(val).length > f.maxLength) {
              msg = f.error || `Máximo ${f.maxLength} caracteres.`;
            } else if (val && f.pattern) {
              let re = f.pattern;
              if (!(re instanceof RegExp)) {
                try { re = new RegExp("^(?:" + re + ")$"); } catch { re = null; }
              }
              if (re && !re.test(String(val))) msg = f.error || "El formato no es válido.";
            }
          }
          return setErr(f, msg);
        };

        const validateAll = () => {
          let firstBad = null, ok = true;
          fields.forEach(f => {
            if (!validateField(f, collect())) {
              ok = false;
              if (!firstBad) firstBad = values[f.name];
            }
          });
          if (firstBad) firstBad.focus?.();
          return ok;
        };

        applyVisibility();
        const handleInput = e => {
          applyVisibility();
          const f = fields.find(x => values[x.name] === e.target);
          if (f && !errEls[f.name]?.hidden) validateField(f, collect());
          if (typeof onInput === "function") { try { onInput(collect()); } catch {} }
        };
        card.addEventListener("input", handleInput);
        card.addEventListener("change", handleInput);

        // Enter en el último campo enfoca el botón primario; al activarlo se
        // validan todos los campos y los errores aparecen debajo de cada uno.
        card._validateFields = validateAll;
      }

      const row = document.createElement("div");
      row.className = "modal-btns";
      const defs = buttons || [{ label: "Entendido", value: true, primary: true }];
      const visible = el => !!(el && el.getClientRects().length && getComputedStyle(el).visibility !== "hidden" && !el.closest("details:not([open])"));
      const enterFields = () => [...card.querySelectorAll("input, select, textarea")].filter(el =>
        visible(el) && !el.disabled && !el.readOnly &&
        !["hidden", "file", "checkbox", "radio", "range", "color", "button", "submit", "reset"].includes(el.type));
      const onKey = e => {
        if (e.key === "Escape") { e.preventDefault(); close(false); return; }
        if (e.key !== "Enter" || e.isComposing) return;
        const active = document.activeElement;
        // Enter en un campo avanza al siguiente en vez de cerrar el modal.
        // En el último campo lleva el foco al botón principal (un Enter más confirma).
        if (!card.contains(active) || !active.matches("input, select, textarea")) return;
        if (active.tagName === "TEXTAREA") return;
        const fields = enterFields();
        const i = fields.indexOf(active);
        if (i < 0) return;
        e.preventDefault();
        if (i < fields.length - 1) {
          fields[i + 1].focus();
        } else {
          const primary = [...card.querySelectorAll(".modal-btns .mbtn")].find(b => !b.classList.contains("ghost")) || card.querySelector(".modal-btns .mbtn");
          primary?.focus();
        }
      };
      document.addEventListener("keydown", onKey);
      let settled = false;
      const close = val => {
        if (settled) return;
        settled = true;
        document.removeEventListener("keydown", onKey);
        cleanups.forEach(fn => { try { fn(); } catch {} });
        cleanups.length = 0;
        window.SylpackScroll?.unlock();
        root.classList.remove("show");
        root.innerHTML = "";
        if (activeClose === close) activeClose = null;
        if (fields) resolve({ button: val, values: collect() });
        else resolve(val);
      };
      activeClose = close;
      defs.forEach(d => {
        const b = document.createElement("button");
        b.className = "mbtn" + (d.primary ? "" : " ghost") + (d.danger ? " danger" : "");
        b.textContent = d.label;
        b.onclick = () => {
          if (fields && d.primary && typeof card._validateFields === "function" && !card._validateFields()) return;
          close(d.value);
        };
        row.appendChild(b);
      });
      card.appendChild(row);
      veil.onclick = () => close(false);
      root.appendChild(veil); root.appendChild(card);
      const first = [...card.querySelectorAll("input, select, textarea, .mbtn")].find(visible);
      first?.focus?.();
    });
  }

  window.Modal = {
    show,
    ok: (title, msg) => show({ title, msg, type: "ok" }),
    error: (title, msg) => show({ title, msg, type: "error" }),
    info: (title, msg) => show({ title, msg, type: "info" }),
  };
  /* candado de scroll: con modal abierto solo se recorre el modal */
  let locks = 0;
  window.SylpackScroll = {
    lock() { locks++; document.body.style.overflow = "hidden"; },
    unlock() { locks = Math.max(0, locks - 1); if (!locks) document.body.style.overflow = ""; }
  };
})();
