/* Cierre protegido de la aplicación (solo sede):
   la bandeja llama a SylpackExit.pedir(); se exige usuario admin o super admin. */
(() => {
  async function pedir() {
    if (!window.Modal) return;
    const r = await window.Modal.show({
      title: "Cerrar Sylpack Tickets",
      msg: "Para cerrar la aplicación necesitas una cuenta de administrador o super admin. Las cuentas de usuario normal no pueden cerrarla.",
      type: "error",
      fields: [
        { name: "username", label: "Usuario/a", placeholder: "admin o super admin" },
        { name: "password", label: "Contraseña", inputType: "password", eyeToggle: true }
      ],
      buttons: [
        { label: "Cerrar aplicación", value: "ok", danger: true, primary: true },
        { label: "Cancelar", value: "cancel" }
      ]
    });
    if (!r || r.button !== "ok") return;
    const u = (r.values.username || "").trim();
    const p = r.values.password || "";
    if (!u || !p) {
      window.Modal.error("Faltan datos", "Ingresa usuario y contraseña de administración.");
      return;
    }
    if (!window.pywebview || !window.pywebview.api || !window.pywebview.api.exit_app) {
      window.Modal.error("No disponible", "No se puede cerrar la aplicación desde aquí.");
      return;
    }
    let res = null;
    try {
      res = await window.pywebview.api.exit_app(u, p);
    } catch {
      res = { ok: false, msg: "No se pudo verificar. Inténtalo de nuevo." };
    }
    if (!res || !res.ok) {
      window.Modal.error("No autorizado", (res && res.msg) || "Credenciales inválidas o sin permisos.");
    }
    // si es ok, el proceso se cierra solo
  }
  window.SylpackExit = { pedir };
})();
