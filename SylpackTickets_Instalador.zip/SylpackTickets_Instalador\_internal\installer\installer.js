/* Lógica del instalador real de Sylpack Tickets. */
(() => {
  let step = 1;
  const panes = () => document.querySelectorAll(".ipane");
  const items = () => document.querySelectorAll(".isteps li");

  function mark(n) {
    panes().forEach(p => p.classList.toggle("on", p.dataset.pane === String(n)));
    items().forEach(li => {
      const k = Number(li.dataset.step);
      const active = k === n || (n === "u" && k === 2);
      li.classList.toggle("on", active);
      li.classList.toggle("done", k < n && n !== "u");
      if (k < n && n !== "u" && li.querySelector(".n").textContent !== "✓") {
        li.querySelector(".n").textContent = "✓";
      }
    });
  }

  function go(n) { step = n; mark(n); }

  document.querySelectorAll("[data-next]").forEach(b => b.onclick = () => { go(2); buscarSede(); });
  document.querySelectorAll("[data-back]").forEach(b => b.onclick = () => go(1));

  // selección de rol
  document.querySelectorAll(".rcard").forEach(card => {
    card.onclick = () => {
      document.querySelectorAll(".rcard").forEach(c => c.classList.remove("on"));
      card.classList.add("on");
      card.querySelector("input").checked = true;
      updateDest();
    };
  });
  function currentRole() {
    const on = document.querySelector(".rcard.on");
    return on ? on.dataset.role : "cliente";
  }
  function updateDest() {
    const d = document.getElementById("destInfo");
    if (!d) return;
    d.textContent = currentRole() === "sede"
      ? "Sede: se abrirá el Firewall y el inicio automático en este equipo"
      : "Cliente: se conecta a la sede de la red (sin firewall)";
  }
  updateDest();

  function setRole(role) {
    document.querySelectorAll(".rcard").forEach(c => {
      const on = c.dataset.role === role;
      c.classList.toggle("on", on);
      c.querySelector("input").checked = on;
    });
    updateDest();
  }

  // Al entrar al paso 2, busca una Sede ya instalada para recomendar el rol.
  async function buscarSede() {
    const h = document.getElementById("sedeHint");
    if (!h) return;
    h.className = "sedehint";
    h.textContent = "Buscando la Sede en tu red…";
    let ip = "";
    try {
      if (window.pywebview?.api?.find_sede) {
        const r = await window.pywebview.api.find_sede();
        ip = (r && r.ip) || "";
      }
    } catch {}
    if (ip) {
      setRole("cliente");
      h.className = "sedehint ok";
      h.textContent = `Sede encontrada en ${ip}. Este equipo debería instalarse como Cliente.`;
    } else {
      setRole("sede");
      h.className = "sedehint warn";
      h.textContent = "No se encontró otra Sede en la red: este equipo quedará como Sede (solo debe haber una).";
    }
  }

  const bar = () => document.getElementById("instBar");
  const pct = () => document.getElementById("instPct");
  const stg = () => document.getElementById("instStage");

  function poll() {
    go(3);
    const iv = setInterval(async () => {
      let s = null;
      try { s = await window.pywebview.api.op_status(); } catch { clearInterval(iv); return; }
      if (!s) return;
      if (s.error) {
        clearInterval(iv);
        document.getElementById("progTitle").textContent = "Ocurrió un problema";
        stg().textContent = "Error: " + s.error;
        document.getElementById("progNote").textContent = "Puedes cerrar el instalador y volver a intentarlo.";
        return;
      }
      if (s.stage) stg().textContent = s.stage;
      bar().style.width = (s.pct || 0) + "%";
      pct().textContent = Math.floor(s.pct || 0);
      if (s.done) {
        clearInterval(iv);
        setTimeout(() => done(s.mode), 350);
      }
    }, 180);
  }

  function done(mode) {
    const un = mode === "uninstall";
    document.getElementById("doneIco").textContent = un ? "✓" : "✓";
    document.getElementById("doneTitle").textContent = un ? "Desinstalado" : "Todo listo";
    document.getElementById("btnFinish").textContent = un ? "Cerrar" : "Terminar";
    if (un) {
      document.getElementById("doneSummary").textContent = "Sylpack Tickets se quitó de este equipo por completo.";
    } else {
      const role = currentRole();
      const names = [];
      if (document.getElementById("optShortcut").checked) names.push("acceso directo en el escritorio");
      if (document.getElementById("optLaunch").checked) names.push("apertura automática");
      if (role === "sede") names.push("inicio automático + Firewall");
      document.getElementById("doneSummary").textContent =
        `Sylpack Tickets quedó instalado como ${role === "sede" ? "Sede" : "Cliente"}` +
        (names.length ? ` con ${names.join(", ")}.` : ".");
      avCard(role);
    }
    go(4);
  }

  const AV_PATH = "C:\\ProgramData\\Sylpack_Sistemas\\SylpackTickets";

  async function avCard(role) {
    const card = document.getElementById("avCard");
    if (!card) return;
    if (role === "uninstall") { card.hidden = true; return; }
    let info = null;
    try { info = await window.pywebview?.api?.av_info(); } catch {}
    const list = (info && info.list) || [];
    const kav = !!(info && info.kaspersky);
    if (!list.length) { card.hidden = true; return; }
    document.getElementById("avPath").textContent = AV_PATH;
    document.getElementById("avList").textContent = list.join(", ");
    if (kav) {
      document.getElementById("avTitle").textContent = "Kaspersky detectado";
      document.getElementById("avLead").textContent =
        "Kaspersky puede borrar archivos de Sylpack Tickets por error (falso positivo). Agrega esta carpeta como exclusión ANTES de abrir la app:";
      document.getElementById("avSteps").innerHTML =
        "<li>Abre Kaspersky y entra a <b>Configuración</b> (engranaje abajo a la izquierda).</li>" +
        "<li>Sección <b>Amenazas y exclusiones</b> → <b>Gestionar exclusiones</b>.</li>" +
        "<li>Pulsa <b>Agregar</b> → <b>Carpeta</b>, pega la ruta de abajo y acepta.</li>" +
        "<li>Guarda y vuelve aquí. Recién entonces pulsa <b>Terminar</b>.</li>";
    } else {
      document.getElementById("avTitle").textContent = "Antivirus detectado";
      document.getElementById("avLead").textContent =
        "Algunos antivirus marcan por error apps sin firma digital. Si bloquea Sylpack Tickets, agrega esta carpeta como exclusión:";
      document.getElementById("avSteps").innerHTML =
        "<li>Abre tu antivirus y busca <b>Exclusiones</b> o <b>Lista blanca</b>.</li>" +
        "<li>Agrega la carpeta de abajo como ruta de confianza.</li>" +
        "<li>Guarda y vuelve aquí para pulsar <b>Terminar</b>.</li>";
    }
    card.hidden = false;
  }

  const btnCopy = document.getElementById("btnCopyPath");
  if (btnCopy) btnCopy.onclick = async () => {
    try { await window.pywebview?.api?.copy_text(document.getElementById("avPath").textContent); } catch {}
    btnCopy.textContent = "Copiado ✓";
    setTimeout(() => { btnCopy.textContent = "Copiar"; }, 1600);
  };
  const btnOpen = document.getElementById("btnOpenFolder");
  if (btnOpen) btnOpen.onclick = async () => {
    try { await window.pywebview?.api?.open_folder(AV_PATH); } catch {}
  };

  document.getElementById("btnInstall").onclick = async () => {
    const role = currentRole();
    const shortcut = document.getElementById("optShortcut").checked;
    try {
      if (!window.pywebview?.api?.start_install) throw 0;
      await window.pywebview.api.start_install(role, shortcut);
      document.getElementById("progTitle").textContent = "Instalando…";
      document.getElementById("progNote").textContent = avNote(role)
        ? "Al terminar, agrega la carpeta como exclusión en Kaspersky (si lo usas)."
        : "No cierres esta ventana.";
      poll();
    } catch {
      document.getElementById("progTitle").textContent = "Modo demo";
      stg().textContent = "Instalación simulada (sin backend).";
      let v = 0;
      const iv = setInterval(() => {
        v += 3; bar().style.width = v + "%"; pct().textContent = Math.min(100, v);
        if (v >= 100) { clearInterval(iv); done("install"); }
      }, 60);
    }
  };

  document.getElementById("btnUninstallStart").onclick = () => {
    document.getElementById("btnFinish").textContent = "Cerrar";
    go("u");
  };

  document.getElementById("btnUninstallNow").onclick = async () => {
    try {
      if (!window.pywebview?.api?.start_uninstall) throw 0;
      await window.pywebview.api.start_uninstall();
      document.getElementById("progTitle").textContent = "Desinstalando…";
      document.getElementById("progNote").textContent = "No cierres esta ventana.";
      poll();
    } catch {
      done("uninstall");
    }
  };

  document.getElementById("btnFinish").onclick = async () => {
    const launch = document.getElementById("optLaunch").checked;
    try { await window.pywebview?.api.finish(launch); } catch {}
    window.close();
  };

  // aviso de administrador
  (async () => {
    try {
      const e = await window.pywebview?.api?.env_info();
      if (e && e.admin === false) document.getElementById("adminWarn").hidden = false;
    } catch {}
  })();
})();
