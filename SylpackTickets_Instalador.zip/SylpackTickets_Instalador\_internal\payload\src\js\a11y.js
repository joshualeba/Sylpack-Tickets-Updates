/* Accesibilidad Sylpack: zoom con barra, espaciado y opciones activar/desactivar.
   Todo se aplica en vivo y se guarda por equipo. */
(() => {
  const KEY = "sylpack-a11y";
  const DEF = { zoom: "100", ls: "0", contrast: "0", motion: "0", links: "0", lh: "0" };

  function prefs() {
    try { return { ...DEF, ...JSON.parse(localStorage.getItem(KEY) || "{}") }; }
    catch { return { ...DEF }; }
  }
  function cssZoom(pct) {
    // Respaldo para el navegador: compensa los elementos fijos con --a11y-zoom.
    const h = document.documentElement;
    h.style.setProperty("--a11y-zoom", String(pct / 100));
    document.body.style.zoom = pct === 100 ? "" : pct + "%";
  }
  function apply(p) {
    const v = { ...DEF, ...p };
    try {
      const h = document.documentElement;
      const pct = Math.max(80, Math.min(150, Number(v.zoom) || 100));
      // En la app usamos el zoom nativo del WebView: el navegador reacomoda el
      // contenido y el texto crece sin descolocar modales ni paneles.
      const bridge = window.pywebview?.api;
      if (bridge?.set_ui_zoom) {
        h.style.setProperty("--a11y-zoom", "1");
        document.body.style.zoom = "";
        try {
          Promise.resolve(bridge.set_ui_zoom(pct))
            .then(ok => { if (!ok) cssZoom(pct); })
            .catch(() => cssZoom(pct));
        } catch { cssZoom(pct); }
      } else {
        cssZoom(pct);
      }
      document.body.style.letterSpacing = v.ls === "0" ? "" : v.ls + "em";
      h.dataset.aContrast = v.contrast;
      h.dataset.aMotion = v.motion;
      h.dataset.aLinks = v.links;
      h.dataset.aLh = v.lh;
      localStorage.setItem(KEY, JSON.stringify(v));
    } catch {}
    return v;
  }
  apply(prefs());
  window.addEventListener("pywebviewready", () => apply(prefs()));
  // el fondo animado respeta "reducir movimiento"
  window.addEventListener("sylpack-a11y", () => {});

  window.SylpackA11y = {
    open: async () => {
      const p = prefs();
      const r = await window.Modal?.show({
        title: "Accesibilidad",
        msg: "Mueve la barra y activa lo que necesites. Todo se aplica al instante y se guarda en este equipo.",
        type: "info",
        fields: [
          { name: "zoom", label: "Zoom de la interfaz", type: "range", min: 80, max: 150, step: 5, value: p.zoom, suffix: "%" },
          {
            name: "ls", label: "Espaciado entre letras", type: "segmented", value: p.ls,
            options: [
              { value: "0", label: "Normal" },
              { value: "0.04", label: "Amplio" },
              { value: "0.08", label: "Extra" }
            ]
          },
          { name: "contrast", label: "Alto contraste", type: "toggle", value: p.contrast, hint: "Textos más marcados y bordes más visibles." },
          { name: "motion", label: "Reducir movimiento", type: "toggle", value: p.motion, hint: "Detiene animaciones y el fondo interactivo." },
          { name: "links", label: "Subrayar enlaces", type: "toggle", value: p.links, hint: "Marca los enlaces con subrayado permanente." },
          { name: "lh", label: "Interlineado amplio", type: "toggle", value: p.lh, hint: "Más aire entre líneas para leer con calma." }
        ],
        buttons: [
          { label: "Listo", value: "ok", primary: true },
          { label: "Restablecer", value: "reset" }
        ],
        onInput: v => apply(v) // vista previa en vivo mientras ajustas
      });
      if (!r) return;
      if (r.button === "reset") apply({ ...DEF });
      else apply({ zoom: r.values.zoom, ls: r.values.ls, contrast: r.values.contrast, motion: r.values.motion, links: r.values.links, lh: r.values.lh });
    }
  };

  document.addEventListener("click", e => {
    if (e.target.closest("[data-a11y-open]")) window.SylpackA11y.open();
  });
})();
