/* Modo día/noche Sylpack: persiste en localStorage, por defecto noche. */
(() => {
  const KEY = "sylpack-theme";
  const LOCK_DARK = document.body?.dataset.page === "Acceso"
    || /(^|\/)login\.html$/i.test(location.pathname);
  function current() {
    return document.documentElement.dataset.theme === "light" ? "light" : "dark";
  }
  function apply(t) {
    if (LOCK_DARK) t = "dark";
    document.documentElement.dataset.theme = t;
    if (!LOCK_DARK) try { localStorage.setItem(KEY, t); } catch {}
    document.querySelectorAll("[data-theme-toggle]").forEach(b =>
      b.setAttribute("aria-checked", t === "light" ? "true" : "false"));
    window.dispatchEvent(new CustomEvent("sylpack-theme", { detail: t }));
  }
  window.SylpackTheme = { current, apply, toggle: () => apply(current() === "light" ? "dark" : "light") };
  document.addEventListener("click", e => {
    if (e.target.closest("[data-theme-toggle]")) window.SylpackTheme.toggle();
  });
})();
