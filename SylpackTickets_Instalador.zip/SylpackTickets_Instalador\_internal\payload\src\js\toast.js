/* Sylpack Tickets · Toasts apilados (esquina inferior derecha)
   Avisos breves con icono por tipo, barra de progreso y acción opcional.
   Máximo 4 visibles: al llegar uno nuevo se descarta el más antiguo. */
(() => {
  "use strict";
  const MAX = 4;
  let stack = null;

  const ICONS = {
    ticket:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-2a2 2 0 0 0 0-4z"/><path d="M13 6v2M13 11v2M13 16v2"/></svg>',
    message: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-8 8H7l-4 3v-7a8 8 0 0 1 8-8h2a8 8 0 0 1 8 4z"/></svg>',
    close:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m8.5 12 2.5 2.5 4.5-5"/></svg>',
    reopen:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/></svg>',
    success: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m8 12 2.6 2.6L16.5 9"/></svg>',
    warning: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 2.5 20h19z"/><path d="M12 9v5M12 17.2v.1"/></svg>',
    error:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m9 9 6 6M15 9l-6 6"/></svg>',
    info:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.8v.1"/></svg>',
  };

  function ensure() {
    if (stack && document.body.contains(stack)) return stack;
    stack = document.createElement("div");
    stack.className = "st-stack";
    stack.setAttribute("aria-live", "polite");
    document.body.appendChild(stack);
    return stack;
  }

  function dismiss(el) {
    if (!el || el._dismissed) return;
    el._dismissed = true;
    clearTimeout(el._timer);
    el.classList.remove("in");
    el.classList.add("out");
    setTimeout(() => el.remove(), 240);
  }

  const SOUND_BY_KIND = {
    ticket: "ticket", message: "message", close: "close", reopen: "reopen",
    success: "success", warning: "notif", error: "error", info: "notif",
  };

  function show(opts = {}) {
    const o = Object.assign({ kind: "info", title: "", body: "", duration: 5200, onClick: null, sound: undefined }, opts);
    ensure();
    const sound = o.sound === undefined ? SOUND_BY_KIND[o.kind] : o.sound;
    if (sound && window.SylpackSound) window.SylpackSound.play(sound);

    const el = document.createElement("div");
    el.className = "st-toast k-" + o.kind;
    el.setAttribute("role", "status");
    el.innerHTML =
      '<span class="st-ico">' + (ICONS[o.kind] || ICONS.info) + "</span>" +
      '<div class="st-txt"><b></b><span class="st-msg"></span></div>' +
      '<button class="st-x" type="button" aria-label="Cerrar">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="m7 7 10 10M17 7 7 17"/></svg>' +
      "</button>" +
      '<span class="st-bar" style="animation-duration:' + Math.max(1800, o.duration) + 'ms"></span>';
    el.querySelector("b").textContent = o.title;
    el.querySelector(".st-msg").textContent = o.body;

    stack.appendChild(el);
    while (stack.children.length > MAX) dismiss(stack.firstElementChild);

    requestAnimationFrame(() => el.classList.add("in"));

    const arm = (ms) => { clearTimeout(el._timer); el._timer = setTimeout(() => dismiss(el), ms); };
    arm(o.duration);

    el.addEventListener("mouseenter", () => { clearTimeout(el._timer); el.classList.add("hold"); });
    el.addEventListener("mouseleave", () => { el.classList.remove("hold"); arm(1600); });
    el.querySelector(".st-x").addEventListener("click", (e) => { e.stopPropagation(); dismiss(el); });
    if (typeof o.onClick === "function") {
      el.classList.add("clickable");
      el.addEventListener("click", () => { o.onClick(); dismiss(el); });
    }
    return el;
  }

  window.SylpackToast = {
    show,
    dismiss,
    info:    (title, body, o) => show(Object.assign({ kind: "info" }, o, { title, body })),
    success: (title, body, o) => show(Object.assign({ kind: "success" }, o, { title, body })),
    warning: (title, body, o) => show(Object.assign({ kind: "warning" }, o, { title, body })),
    error:   (title, body, o) => show(Object.assign({ kind: "error" }, o, { title, body })),
    ticket:  (title, body, o) => show(Object.assign({ kind: "ticket" }, o, { title, body })),
  };
})();
