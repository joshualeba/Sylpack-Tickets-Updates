"""
Sylpack Tickets · Backend LAN-first
Escucha en 192.168.0.146:5000 (o 0.0.0.0:5000).
- PostgreSQL si DATABASE_URL=postgresql://... , si no SQLite local (dev).
- Notificaciones admin solo in-app via SocketIO evento 'nuevo_ticket'.
"""
import os, secrets, mimetypes, socket, sys, json, threading, re, time, ipaddress, subprocess, shutil, unicodedata, hashlib, zipfile, ctypes
from datetime import datetime, timezone, timedelta
from pathlib import Path, PurePosixPath
import secrets
from functools import wraps
from urllib.parse import urlparse, urljoin, quote, urlencode, parse_qs, parse_qsl, urlunparse
from urllib.request import Request as URLRequest, build_opener, HTTPRedirectHandler
from urllib.error import HTTPError, URLError
from html import unescape as html_unescape

from flask import Flask, request, jsonify, send_from_directory, Response
from flask_cors import CORS
from flask_jwt_extended import (
    JWTManager, create_access_token, create_refresh_token,
    jwt_required, get_jwt_identity, get_jwt
)
from flask_socketio import SocketIO
import bcrypt
from dotenv import load_dotenv
try:
    from zoneinfo import ZoneInfo
except ImportError:
    ZoneInfo = None

BASE = Path(os.getenv("SYLPACK_SERVER", "") or Path(__file__).resolve().parent)
# Directorio de datos escribible. En la app empaquetada (.exe) apunta a
# %LOCALAPPDATA%/SylpackTickets vía SYLPACK_DATA; en desarrollo es el server/.
DATA_DIR = Path(os.getenv("SYLPACK_DATA", str(BASE)))
try:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    DATA_DIR = BASE
load_dotenv(DATA_DIR / ".env")
load_dotenv(BASE / ".env")

# ---- Horario de atención (acumulación fuera de horario) ----
# Por defecto: Lun–Vie 10:00–18:00 (hora de Ciudad de México).
# Fuera de ese horario los tickets NO se procesan: se acumulan en el
# equipo y se envían solos cuando abre el horario.
TZ_NAME = os.getenv("TZ", "America/Mexico_City")
try:
    TZ = ZoneInfo(TZ_NAME) if ZoneInfo else timezone.utc
except Exception:
    TZ = timezone.utc
HORARIO_ACTIVO = os.getenv("HORARIO_ACTIVO", "true").lower() == "true"
HORA_INICIO = int(os.getenv("HORA_INICIO", "10"))
HORA_FIN = int(os.getenv("HORA_FIN", "18"))
DIAS_HABILES = {int(x) for x in os.getenv("DIAS_HABILES", "0,1,2,3,4").split(",") if x.strip().isdigit()}

def en_horario(now=None):
    """True si está dentro del horario de atención."""
    if not HORARIO_ACTIVO:
        return True, "Horario libre"
    now = now or datetime.now(TZ)
    if now.weekday() in DIAS_HABILES and HORA_INICIO <= now.hour < HORA_FIN:
        return True, "Horario de atención"
    return False, "Fuera de horario (Lun–Vie 10:00–18:00)"

# ---- Recepción de reportes: pausa manual y apertura manual ----
# La pausa manual manda sobre el horario. Si administración reanuda fuera de
# horario, se abre una ventana manual hasta la próxima apertura para que los
# reportes en cola salgan de inmediato. Todo se guarda en disco.
RECEPCION_FILE = DATA_DIR / "recepcion.json"
_recv_lock = threading.Lock()
_recepcion = {"paused": False, "by": "", "at": "", "override_until": ""}


def _next_apertura(now=None):
    """Próxima apertura del horario (para cerrar una apertura manual)."""
    now = now or datetime.now(TZ)
    for i in range(0, 9):
        day = (now + timedelta(days=i)).date()
        if day.weekday() in DIAS_HABILES:
            start = datetime(day.year, day.month, day.day, HORA_INICIO, 0, tzinfo=TZ)
            if start > now:
                return start
    return now + timedelta(days=1)


def _parse_dt(value):
    try:
        dt = datetime.fromisoformat(str(value or ""))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=TZ)
        return dt
    except Exception:
        return None


def _load_recepcion():
    global _recepcion
    try:
        d = json.loads(RECEPCION_FILE.read_text(encoding="utf-8"))
        _recepcion = {"paused": bool(d.get("paused")),
                      "by": str(d.get("by") or ""),
                      "at": str(d.get("at") or ""),
                      "override_until": str(d.get("override_until") or "")}
    except Exception:
        _recepcion = {"paused": False, "by": "", "at": "", "override_until": ""}


def _save_recepcion():
    try:
        tmp = RECEPCION_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(_recepcion, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, RECEPCION_FILE)
    except Exception:
        pass


def _recepcion_state():
    """Estado efectivo: horario, pausa admin y apertura manual."""
    now = datetime.now(TZ)
    abierto, msg_h = en_horario(now)
    with _recv_lock:
        paused = bool(_recepcion.get("paused"))
        by = _recepcion.get("by") or ""
        at = _recepcion.get("at") or ""
        until = _parse_dt(_recepcion.get("override_until"))
    override = bool(until and until > now and not paused)
    aceptando = (abierto or override) and not paused
    if paused:
        motivo = "pausado"
    elif override:
        motivo = "manual"
    elif not abierto:
        motivo = "fuera_horario"
    else:
        motivo = "ok"
    mensaje = ("Recepción manual activa" if override else msg_h)
    return {"paused": paused, "pausado": paused, "abierto": abierto,
            "aceptando": aceptando, "motivo": motivo,
            "override": override,
            "override_until": until.isoformat() if override else "",
            "by": by, "at": at, "mensaje": mensaje,
            "ventana": f"Lun–Vie {HORA_INICIO:02d}:00–{HORA_FIN:02d}:00"}


_load_recepcion()

# ---- DB layer (psycopg2 o sqlite3 segun URL) ----
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///tickets.db")
# fallback automático a sqlite si postgres no responde (dev)
def pg_ok(url):
    if not url.startswith("postgresql"):
        return False
    try:
        import psycopg2
        c = psycopg2.connect(url, connect_timeout=3)
        c.close()
        return True
    except Exception as e:
        print(f"[db] postgres no disponible ({e}), usando sqlite local")
        return False

if DATABASE_URL.startswith("postgresql") and not pg_ok(DATABASE_URL):
    DATABASE_URL = "sqlite:///tickets.db"
USE_PG = DATABASE_URL.startswith("postgresql")

if USE_PG:
    import psycopg2
    import psycopg2.extras
    def conn():
        c = psycopg2.connect(DATABASE_URL)
        return c
    PH = "%s"
else:
    import sqlite3
    def conn():
        p = DATA_DIR / "tickets.db"
        c = sqlite3.connect(str(p))
        c.row_factory = sqlite3.Row
        return c
    PH = "?"

def q_all(sql, params=()):
    c = conn(); cur = c.cursor()
    if USE_PG:
        cur.execute(sql, params)
        rows = cur.fetchall()
        cols = [d[0] for d in cur.description]
        out = [dict(zip(cols, r)) for r in rows]
    else:
        cur.execute(sql.replace("%s", "?"), params)
        out = [dict(r) for r in cur.fetchall()]
    c.close()
    return out

def q_one(sql, params=()):
    rows = q_all(sql, params)
    return rows[0] if rows else None

def q_exec(sql, params=(), returning_id=False):
    c = conn(); cur = c.cursor()
    s = sql if USE_PG else sql.replace("%s", "?")
    if returning_id:
        s += "" if USE_PG else ""
    cur.execute(s, params)
    last = None
    if returning_id:
        if USE_PG:
            # requiere RETURNING id en el sql
            row = cur.fetchone()
            last = row[0] if row else None
        else:
            last = cur.lastrowid
    c.commit(); c.close()
    return last

def _compras_ddl():
    """DDL del módulo de compras (compatible SQLite/PostgreSQL)."""
    pg = USE_PG
    pk = "SERIAL PRIMARY KEY" if pg else "INTEGER PRIMARY KEY AUTOINCREMENT"
    ts = "TIMESTAMPTZ NOT NULL DEFAULT NOW()" if pg else "TEXT NOT NULL DEFAULT ''"
    tsn = "TIMESTAMPTZ" if pg else "TEXT"
    num = "DOUBLE PRECISION" if pg else "REAL"
    b = "BOOLEAN" if pg else "INTEGER"
    bt = "TRUE" if pg else "1"
    bf = "FALSE" if pg else "0"
    return [
        f"""CREATE TABLE IF NOT EXISTS proveedores(
          id {pk}, nombre TEXT NOT NULL,
          rfc TEXT NOT NULL DEFAULT '', razon_social TEXT NOT NULL DEFAULT '',
          domicilio TEXT NOT NULL DEFAULT '', contacto TEXT NOT NULL DEFAULT '',
          email TEXT NOT NULL DEFAULT '', telefono TEXT NOT NULL DEFAULT '',
          condiciones_pago TEXT NOT NULL DEFAULT '',
          area TEXT NOT NULL DEFAULT '', calidad_estado TEXT NOT NULL DEFAULT 'pendiente',
          calidad_por TEXT NOT NULL DEFAULT '', calidad_at {tsn},
          calidad_nota TEXT NOT NULL DEFAULT '',
          created_by TEXT NOT NULL DEFAULT '', updated_by TEXT NOT NULL DEFAULT '',
          updated_at {tsn}, activo {b} NOT NULL DEFAULT {bt},
          created_at {ts})""",
        f"""CREATE TABLE IF NOT EXISTS compras_solicitudes(
          id {pk}, folio TEXT NOT NULL DEFAULT '',
          user_id INTEGER NOT NULL, area TEXT NOT NULL DEFAULT '',
          titulo TEXT NOT NULL, justificacion TEXT NOT NULL DEFAULT '',
          prioridad TEXT NOT NULL DEFAULT 'media',
          estado TEXT NOT NULL DEFAULT 'pendiente',
          tipo_compra TEXT NOT NULL DEFAULT 'normal',
          flujo TEXT NOT NULL DEFAULT 'legado',
          jefe_area TEXT NOT NULL DEFAULT '',
          calidad_estado TEXT NOT NULL DEFAULT 'no_requiere',
          calidad_por TEXT NOT NULL DEFAULT '',
          calidad_at {tsn},
          calidad_nota TEXT NOT NULL DEFAULT '',
          proveedor_propuesto TEXT NOT NULL DEFAULT '',
          proveedor_sugerido TEXT NOT NULL DEFAULT '',
          notas TEXT NOT NULL DEFAULT '',
          revisado_por TEXT NOT NULL DEFAULT '', revisado_at {tsn},
          gestor_por TEXT NOT NULL DEFAULT '', gestor_at {tsn},
          motivo_rechazo TEXT NOT NULL DEFAULT '',
          motivo_cambios TEXT NOT NULL DEFAULT '',
          created_at {ts}, updated_at {ts})""",
        f"""CREATE TABLE IF NOT EXISTS compras_items(
          id {pk}, solicitud_id INTEGER NOT NULL,
          nombre TEXT NOT NULL, descripcion TEXT NOT NULL DEFAULT '',
          motivo TEXT NOT NULL DEFAULT '',
          requisitos_calidad TEXT NOT NULL DEFAULT '',
          id_fabricacion TEXT NOT NULL DEFAULT '',
          cantidad {num} NOT NULL DEFAULT 1, unidad TEXT NOT NULL DEFAULT 'pza',
          link TEXT NOT NULL DEFAULT '', imagen TEXT NOT NULL DEFAULT '',
          proveedor TEXT NOT NULL DEFAULT '',
          costo_unitario {num} NOT NULL DEFAULT 0,
          precio_incluye_iva {b} NOT NULL DEFAULT {bt},
          orden INTEGER NOT NULL DEFAULT 0,
          created_at {ts})""",
        f"""CREATE TABLE IF NOT EXISTS compras_item_opciones(
          id {pk}, item_id INTEGER NOT NULL,
          etiqueta TEXT NOT NULL DEFAULT '',
          diferencia TEXT NOT NULL DEFAULT '',
          link TEXT NOT NULL DEFAULT '', imagen TEXT NOT NULL DEFAULT '',
          proveedor TEXT NOT NULL DEFAULT '',
          costo_unitario {num} NOT NULL DEFAULT 0,
          precio_incluye_iva {b} NOT NULL DEFAULT {bt},
          orden INTEGER NOT NULL DEFAULT 0,
          calidad_aprobada {b} NOT NULL DEFAULT {bf},
          calidad_por TEXT NOT NULL DEFAULT '', calidad_at {tsn},
          created_at {ts})""",
        f"""CREATE TABLE IF NOT EXISTS compras_documentos(
          id {pk}, folio TEXT NOT NULL DEFAULT '',
          tipo TEXT NOT NULL DEFAULT 'requisicion',
          tipo_compra TEXT NOT NULL DEFAULT 'normal',
          solicitud_id INTEGER NOT NULL, origen_id INTEGER,
          proveedor_id INTEGER,
          estado TEXT NOT NULL DEFAULT 'borrador',
          jefe_area TEXT NOT NULL DEFAULT '',
          calidad_por TEXT NOT NULL DEFAULT '', calidad_at {tsn},
          fecha TEXT NOT NULL DEFAULT '', moneda TEXT NOT NULL DEFAULT 'MXN',
          subtotal {num} NOT NULL DEFAULT 0,
          descuento_pct {num} NOT NULL DEFAULT 0,
          iva_pct {num} NOT NULL DEFAULT 16,
          total {num} NOT NULL DEFAULT 0,
          condiciones TEXT NOT NULL DEFAULT '', notas TEXT NOT NULL DEFAULT '',
          fecha_entrega TEXT NOT NULL DEFAULT '',
          misma_fecha_entrega {b} NOT NULL DEFAULT {bf},
          almacen TEXT NOT NULL DEFAULT '', entregar_a TEXT NOT NULL DEFAULT '',
          elaborado_por TEXT NOT NULL DEFAULT '',
          autorizado_por TEXT NOT NULL DEFAULT '', autorizado_at {tsn},
          empresa_snapshot TEXT NOT NULL DEFAULT '',
          proveedor_snapshot TEXT NOT NULL DEFAULT '',
          created_at {ts}, updated_at {ts})""",
        f"""CREATE TABLE IF NOT EXISTS compras_documento_items(
          id {pk}, documento_id INTEGER NOT NULL, item_id INTEGER,
          opcion_id INTEGER, opcion_etiqueta TEXT NOT NULL DEFAULT '',
          link TEXT NOT NULL DEFAULT '', diferencia TEXT NOT NULL DEFAULT '',
          nombre TEXT NOT NULL, descripcion TEXT NOT NULL DEFAULT '',
          id_fabricacion TEXT NOT NULL DEFAULT '',
          cantidad {num} NOT NULL DEFAULT 1, unidad TEXT NOT NULL DEFAULT 'pza',
          costo_unitario {num} NOT NULL DEFAULT 0,
          descuento_pct {num} NOT NULL DEFAULT 0,
          importe {num} NOT NULL DEFAULT 0,
          precio_incluye_iva {b} NOT NULL DEFAULT {bt},
          fecha_llegada TEXT NOT NULL DEFAULT '',
          created_at {ts})""",
        f"""CREATE TABLE IF NOT EXISTS compras_eventos(
          id {pk}, solicitud_id INTEGER, documento_id INTEGER,
          tipo TEXT NOT NULL, estado_anterior TEXT NOT NULL DEFAULT '',
          estado_nuevo TEXT NOT NULL DEFAULT '', por TEXT NOT NULL DEFAULT '',
          area TEXT NOT NULL DEFAULT '', areas_extra TEXT NOT NULL DEFAULT '',
          nota TEXT NOT NULL DEFAULT '', created_at {ts})""",
        f"""CREATE TABLE IF NOT EXISTS compras_mensajes(
          id {pk}, solicitud_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
          mensaje TEXT NOT NULL, created_at {ts})""",
        f"""CREATE TABLE IF NOT EXISTS compras_recepciones(
          id {pk}, folio TEXT NOT NULL DEFAULT '',
          documento_id INTEGER NOT NULL, solicitud_id INTEGER,
          recibido_por TEXT NOT NULL DEFAULT '', fecha TEXT NOT NULL DEFAULT '',
          estado TEXT NOT NULL DEFAULT 'completa',
          notas TEXT NOT NULL DEFAULT '', created_at {ts})""",
        f"""CREATE TABLE IF NOT EXISTS compras_recepcion_items(
          id {pk}, recepcion_id INTEGER NOT NULL, item_id INTEGER,
          cantidad {num} NOT NULL DEFAULT 0, estado TEXT NOT NULL DEFAULT 'ok',
          notas TEXT NOT NULL DEFAULT '', created_at {ts})""",
        f"""CREATE TABLE IF NOT EXISTS compras_devoluciones(
          id {pk}, folio TEXT NOT NULL DEFAULT '',
          documento_id INTEGER, recepcion_id INTEGER, solicitud_id INTEGER,
          motivo TEXT NOT NULL DEFAULT '', estado TEXT NOT NULL DEFAULT 'solicitada',
          notas TEXT NOT NULL DEFAULT '', creado_por TEXT NOT NULL DEFAULT '',
          aprobado_por TEXT NOT NULL DEFAULT '',
          created_at {ts}, updated_at {ts})""",
        f"""CREATE TABLE IF NOT EXISTS compras_devolucion_items(
          id {pk}, devolucion_id INTEGER NOT NULL, item_id INTEGER,
          cantidad {num} NOT NULL DEFAULT 0, motivo TEXT NOT NULL DEFAULT '',
          estado TEXT NOT NULL DEFAULT 'pendiente', created_at {ts})""",
        f"""CREATE TABLE IF NOT EXISTS compras_empresa(
          id INTEGER PRIMARY KEY, nombre TEXT NOT NULL DEFAULT '',
          rfc TEXT NOT NULL DEFAULT '', razon_social TEXT NOT NULL DEFAULT '',
          domicilio TEXT NOT NULL DEFAULT '', telefono TEXT NOT NULL DEFAULT '',
          email TEXT NOT NULL DEFAULT '', logo TEXT NOT NULL DEFAULT 'assets/logo.png',
          updated_at {tsn})""",
        f"""CREATE TABLE IF NOT EXISTS compras_adjuntos(
          id {pk}, solicitud_id INTEGER NOT NULL, documento_id INTEGER,
          path TEXT NOT NULL, nombre TEXT NOT NULL,
          tipo TEXT NOT NULL DEFAULT 'firmado', subido_por TEXT NOT NULL DEFAULT '',
          vigente {b} NOT NULL DEFAULT {bt},
          created_at {ts})""",
        f"""CREATE TABLE IF NOT EXISTS compras_productos_certificados(
          id {pk}, nombre TEXT NOT NULL,
          descripcion TEXT NOT NULL DEFAULT '',
          categoria TEXT NOT NULL DEFAULT '',
          unidad TEXT NOT NULL DEFAULT 'pza',
          id_fabricacion TEXT NOT NULL DEFAULT '',
          requisitos_calidad TEXT NOT NULL DEFAULT '',
          link TEXT NOT NULL DEFAULT '',
          imagen TEXT NOT NULL DEFAULT '',
          proveedor_id INTEGER,
          area TEXT NOT NULL DEFAULT '', calidad_estado TEXT NOT NULL DEFAULT 'pendiente',
          calidad_por TEXT NOT NULL DEFAULT '', calidad_at {tsn},
          calidad_nota TEXT NOT NULL DEFAULT '',
          activo {b} NOT NULL DEFAULT {bt},
          created_by TEXT NOT NULL DEFAULT '', updated_by TEXT NOT NULL DEFAULT '',
          created_at {ts}, updated_at {ts})""",
        f"""CREATE TABLE IF NOT EXISTS inventario_items(
          id {pk}, area TEXT NOT NULL DEFAULT '',
          nombre TEXT NOT NULL, descripcion TEXT NOT NULL DEFAULT '',
          categoria TEXT NOT NULL DEFAULT '',
          cantidad {num} NOT NULL DEFAULT 0, unidad TEXT NOT NULL DEFAULT 'pza',
          minimo {num} NOT NULL DEFAULT 0,
          ubicacion TEXT NOT NULL DEFAULT '', lote TEXT NOT NULL DEFAULT '',
          caducidad TEXT NOT NULL DEFAULT '',
          costo_unitario {num} NOT NULL DEFAULT 0,
          proveedor TEXT NOT NULL DEFAULT '',
          areas_extra TEXT NOT NULL DEFAULT '',
          notas TEXT NOT NULL DEFAULT '',
          created_by TEXT NOT NULL DEFAULT '', updated_by TEXT NOT NULL DEFAULT '',
          created_at {ts}, updated_at {ts})""",
        "CREATE INDEX IF NOT EXISTS idx_cp_sol_user ON compras_solicitudes(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_cp_sol_estado ON compras_solicitudes(estado)",
        "CREATE INDEX IF NOT EXISTS idx_cp_items_sol ON compras_items(solicitud_id)",
        "CREATE INDEX IF NOT EXISTS idx_cp_opciones_item ON compras_item_opciones(item_id)",
        "CREATE INDEX IF NOT EXISTS idx_cp_doc_sol ON compras_documentos(solicitud_id)",
        "CREATE INDEX IF NOT EXISTS idx_cp_doc_estado ON compras_documentos(estado)",
        "CREATE INDEX IF NOT EXISTS idx_cp_docitems_doc ON compras_documento_items(documento_id)",
        "CREATE INDEX IF NOT EXISTS idx_cp_ev_sol ON compras_eventos(solicitud_id)",
        "CREATE INDEX IF NOT EXISTS idx_cp_ev_doc ON compras_eventos(documento_id)",
        "CREATE INDEX IF NOT EXISTS idx_cp_msg_sol ON compras_mensajes(solicitud_id)",
        "CREATE INDEX IF NOT EXISTS idx_cp_rec_doc ON compras_recepciones(documento_id)",
        "CREATE INDEX IF NOT EXISTS idx_cp_dev_doc ON compras_devoluciones(documento_id)",
        "CREATE INDEX IF NOT EXISTS idx_cp_adj_sol ON compras_adjuntos(solicitud_id)",
        "CREATE INDEX IF NOT EXISTS idx_cp_adj_tipo ON compras_adjuntos(solicitud_id,tipo,vigente)",
        "CREATE INDEX IF NOT EXISTS idx_cp_cert_nombre ON compras_productos_certificados(nombre)",
        "CREATE INDEX IF NOT EXISTS idx_cp_cert_area ON compras_productos_certificados(area,calidad_estado)",
        "CREATE INDEX IF NOT EXISTS idx_cp_prov_area ON proveedores(area,calidad_estado)",
        "CREATE INDEX IF NOT EXISTS idx_inv_area ON inventario_items(area)",
        "CREATE INDEX IF NOT EXISTS idx_inv_nombre ON inventario_items(nombre)",
        "CREATE INDEX IF NOT EXISTS idx_inv_categoria ON inventario_items(categoria)",
    ]


def _init_compras():
    c = conn(); cur = c.cursor()
    ddl = _compras_ddl()
    for stmt in ddl:
        if not stmt.lstrip().upper().startswith("CREATE INDEX"):
            cur.execute(stmt)
    # Migraciones compatibles con instalaciones que ya tenían el módulo.
    pg_cols = (
        ("compras_solicitudes", "motivo_cambios", "TEXT NOT NULL DEFAULT ''"),
        ("compras_solicitudes", "cambios_oc_motivo", "TEXT NOT NULL DEFAULT ''"),
        ("compras_solicitudes", "tipo_compra", "TEXT NOT NULL DEFAULT 'normal'"),
        ("compras_solicitudes", "flujo", "TEXT NOT NULL DEFAULT 'legado'"),
        ("compras_solicitudes", "jefe_area", "TEXT NOT NULL DEFAULT ''"),
        ("compras_solicitudes", "calidad_estado", "TEXT NOT NULL DEFAULT 'no_requiere'"),
        ("compras_solicitudes", "calidad_por", "TEXT NOT NULL DEFAULT ''"),
        ("compras_solicitudes", "calidad_at", "TIMESTAMPTZ"),
        ("compras_solicitudes", "calidad_nota", "TEXT NOT NULL DEFAULT ''"),
        ("compras_solicitudes", "proveedor_propuesto", "TEXT NOT NULL DEFAULT ''"),
        ("compras_solicitudes", "gestor_por", "TEXT NOT NULL DEFAULT ''"),
        ("compras_solicitudes", "gestor_at", "TIMESTAMPTZ"),
        ("compras_items", "imagen", "TEXT NOT NULL DEFAULT ''"),
        ("compras_items", "motivo", "TEXT NOT NULL DEFAULT ''"),
        ("compras_items", "precio_incluye_iva", "BOOLEAN NOT NULL DEFAULT FALSE"),
        ("compras_items", "requisitos_calidad", "TEXT NOT NULL DEFAULT ''"),
        ("compras_items", "orden", "INTEGER NOT NULL DEFAULT 0"),
        ("compras_items", "certificado", "BOOLEAN NOT NULL DEFAULT FALSE"),
        ("compras_documentos", "tipo_compra", "TEXT NOT NULL DEFAULT 'normal'"),
        ("compras_documentos", "jefe_area", "TEXT NOT NULL DEFAULT ''"),
        ("compras_documentos", "calidad_por", "TEXT NOT NULL DEFAULT ''"),
        ("compras_documentos", "calidad_at", "TIMESTAMPTZ"),
        ("compras_documentos", "fecha_entrega", "TEXT NOT NULL DEFAULT ''"),
        ("compras_documentos", "misma_fecha_entrega", "BOOLEAN NOT NULL DEFAULT FALSE"),
        ("compras_eventos", "area", "TEXT NOT NULL DEFAULT ''"),
        ("compras_eventos", "areas_extra", "TEXT NOT NULL DEFAULT ''"),
        ("compras_documento_items", "precio_incluye_iva", "BOOLEAN NOT NULL DEFAULT FALSE"),
        ("compras_documento_items", "opcion_id", "INTEGER"),
        ("compras_documento_items", "opcion_etiqueta", "TEXT NOT NULL DEFAULT ''"),
        ("compras_documento_items", "link", "TEXT NOT NULL DEFAULT ''"),
        ("compras_documento_items", "diferencia", "TEXT NOT NULL DEFAULT ''"),
        ("compras_documento_items", "fecha_llegada", "TEXT NOT NULL DEFAULT ''"),
        ("compras_adjuntos", "documento_id", "INTEGER"),
        ("compras_adjuntos", "tipo", "TEXT NOT NULL DEFAULT 'firmado'"),
        ("compras_adjuntos", "subido_por", "TEXT NOT NULL DEFAULT ''"),
        ("compras_adjuntos", "vigente", "BOOLEAN NOT NULL DEFAULT TRUE"),
        ("proveedores", "area", "TEXT NOT NULL DEFAULT ''"),
        ("proveedores", "calidad_estado", "TEXT NOT NULL DEFAULT 'pendiente'"),
        ("proveedores", "calidad_por", "TEXT NOT NULL DEFAULT ''"),
        ("proveedores", "calidad_at", "TIMESTAMPTZ"),
        ("proveedores", "calidad_nota", "TEXT NOT NULL DEFAULT ''"),
        ("proveedores", "created_by", "TEXT NOT NULL DEFAULT ''"),
        ("proveedores", "updated_by", "TEXT NOT NULL DEFAULT ''"),
        ("proveedores", "updated_at", "TIMESTAMPTZ"),
        ("compras_productos_certificados", "link", "TEXT NOT NULL DEFAULT ''"),
    ("compras_productos_certificados", "imagen", "TEXT NOT NULL DEFAULT ''"),
    ("compras_productos_certificados", "proveedor_id", "INTEGER"),
        ("compras_productos_certificados", "categoria", "TEXT NOT NULL DEFAULT ''"),
        ("compras_productos_certificados", "area", "TEXT NOT NULL DEFAULT ''"),
        ("compras_productos_certificados", "calidad_estado", "TEXT NOT NULL DEFAULT 'pendiente'"),
        ("compras_productos_certificados", "calidad_por", "TEXT NOT NULL DEFAULT ''"),
        ("compras_productos_certificados", "calidad_at", "TIMESTAMPTZ"),
        ("compras_productos_certificados", "calidad_nota", "TEXT NOT NULL DEFAULT ''"),
        ("compras_productos_certificados", "created_by", "TEXT NOT NULL DEFAULT ''"),
        ("compras_productos_certificados", "updated_by", "TEXT NOT NULL DEFAULT ''"),
        ("compras_productos_certificados", "updated_at", "TIMESTAMPTZ"),
    )
    lite_cols = (
        ("compras_solicitudes", "motivo_cambios", "TEXT NOT NULL DEFAULT ''"),
        ("compras_solicitudes", "cambios_oc_motivo", "TEXT NOT NULL DEFAULT ''"),
        ("compras_solicitudes", "tipo_compra", "TEXT NOT NULL DEFAULT 'normal'"),
        ("compras_solicitudes", "flujo", "TEXT NOT NULL DEFAULT 'legado'"),
        ("compras_solicitudes", "jefe_area", "TEXT NOT NULL DEFAULT ''"),
        ("compras_solicitudes", "calidad_estado", "TEXT NOT NULL DEFAULT 'no_requiere'"),
        ("compras_solicitudes", "calidad_por", "TEXT NOT NULL DEFAULT ''"),
        ("compras_solicitudes", "calidad_at", "TEXT"),
        ("compras_solicitudes", "calidad_nota", "TEXT NOT NULL DEFAULT ''"),
        ("compras_solicitudes", "proveedor_propuesto", "TEXT NOT NULL DEFAULT ''"),
        ("compras_solicitudes", "gestor_por", "TEXT NOT NULL DEFAULT ''"),
        ("compras_solicitudes", "gestor_at", "TEXT"),
        ("compras_items", "imagen", "TEXT NOT NULL DEFAULT ''"),
        ("compras_items", "motivo", "TEXT NOT NULL DEFAULT ''"),
        ("compras_items", "precio_incluye_iva", "INTEGER NOT NULL DEFAULT 0"),
        ("compras_items", "requisitos_calidad", "TEXT NOT NULL DEFAULT ''"),
        ("compras_items", "orden", "INTEGER NOT NULL DEFAULT 0"),
        ("compras_items", "certificado", "INTEGER NOT NULL DEFAULT 0"),
        ("compras_documentos", "tipo_compra", "TEXT NOT NULL DEFAULT 'normal'"),
        ("compras_documentos", "jefe_area", "TEXT NOT NULL DEFAULT ''"),
        ("compras_documentos", "calidad_por", "TEXT NOT NULL DEFAULT ''"),
        ("compras_documentos", "calidad_at", "TEXT"),
        ("compras_documentos", "fecha_entrega", "TEXT NOT NULL DEFAULT ''"),
        ("compras_documentos", "misma_fecha_entrega", "INTEGER NOT NULL DEFAULT 0"),
        ("compras_eventos", "area", "TEXT NOT NULL DEFAULT ''"),
        ("compras_eventos", "areas_extra", "TEXT NOT NULL DEFAULT ''"),
        ("compras_documento_items", "precio_incluye_iva", "INTEGER NOT NULL DEFAULT 0"),
        ("compras_documento_items", "opcion_id", "INTEGER"),
        ("compras_documento_items", "opcion_etiqueta", "TEXT NOT NULL DEFAULT ''"),
        ("compras_documento_items", "link", "TEXT NOT NULL DEFAULT ''"),
        ("compras_documento_items", "diferencia", "TEXT NOT NULL DEFAULT ''"),
        ("compras_documento_items", "fecha_llegada", "TEXT NOT NULL DEFAULT ''"),
        ("compras_adjuntos", "documento_id", "INTEGER"),
        ("compras_adjuntos", "tipo", "TEXT NOT NULL DEFAULT 'firmado'"),
        ("compras_adjuntos", "subido_por", "TEXT NOT NULL DEFAULT ''"),
        ("compras_adjuntos", "vigente", "INTEGER NOT NULL DEFAULT 1"),
        ("proveedores", "area", "TEXT NOT NULL DEFAULT ''"),
        ("proveedores", "calidad_estado", "TEXT NOT NULL DEFAULT 'pendiente'"),
        ("proveedores", "calidad_por", "TEXT NOT NULL DEFAULT ''"),
        ("proveedores", "calidad_at", "TEXT"),
        ("proveedores", "calidad_nota", "TEXT NOT NULL DEFAULT ''"),
        ("proveedores", "created_by", "TEXT NOT NULL DEFAULT ''"),
        ("proveedores", "updated_by", "TEXT NOT NULL DEFAULT ''"),
        ("proveedores", "updated_at", "TEXT"),
        ("compras_productos_certificados", "link", "TEXT NOT NULL DEFAULT ''"),
    ("compras_productos_certificados", "imagen", "TEXT NOT NULL DEFAULT ''"),
    ("compras_productos_certificados", "proveedor_id", "INTEGER"),
        ("compras_productos_certificados", "categoria", "TEXT NOT NULL DEFAULT ''"),
        ("compras_productos_certificados", "area", "TEXT NOT NULL DEFAULT ''"),
        ("compras_productos_certificados", "calidad_estado", "TEXT NOT NULL DEFAULT 'pendiente'"),
        ("compras_productos_certificados", "calidad_por", "TEXT NOT NULL DEFAULT ''"),
        ("compras_productos_certificados", "calidad_at", "TEXT"),
        ("compras_productos_certificados", "calidad_nota", "TEXT NOT NULL DEFAULT ''"),
        ("compras_productos_certificados", "created_by", "TEXT NOT NULL DEFAULT ''"),
        ("compras_productos_certificados", "updated_by", "TEXT NOT NULL DEFAULT ''"),
        ("compras_productos_certificados", "updated_at", "TEXT"),
    )
    if USE_PG:
        for table, col, decl in pg_cols:
            try: cur.execute(f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS {col} {decl}")
            except Exception: pass
    else:
        def _cols(table):
            try:
                cur.execute(f"PRAGMA table_info({table})")
                return {r[1] for r in cur.fetchall()}
            except Exception:
                return set()
        for table, col, decl in lite_cols:
            if col not in _cols(table):
                try: cur.execute(f"ALTER TABLE {table} ADD COLUMN {col} {decl}")
                except Exception: pass
    # Los catálogos que existían antes de separar por área se conservan como
    # registros globales ya aprobados para no romper solicitudes históricas.
    for table in ("proveedores", "compras_productos_certificados"):
        try:
            cur.execute(
                f"UPDATE {table} SET calidad_estado='aprobado' "
                f"WHERE COALESCE(area,'')='' AND "
                f"(calidad_estado IS NULL OR calidad_estado='' OR calidad_estado='pendiente')")
        except Exception:
            pass
    for stmt in ddl:
        if stmt.lstrip().upper().startswith("CREATE INDEX"):
            try: cur.execute(stmt)
            except Exception: pass
    c.commit(); c.close()
    if not q_one("SELECT id FROM compras_empresa WHERE id=1"):
        now = datetime.now(timezone.utc).isoformat()
        q_exec(
            f"INSERT INTO compras_empresa(id,nombre,rfc,razon_social,domicilio,telefono,email,logo,updated_at)"
            f" VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH})",
            (1, "Sylpack Alimentos", "SAL090528QK5", "SYLPACK ALIMENTOS S.A. DE C.V.",
             "El Marqués, Querétaro, México", "442 221 5367", "compras@sylpack.com.mx",
             "assets/logo.png", now))


def init_db():
    if USE_PG:
        schema = (BASE / "schema.sql").read_text(encoding="utf-8")
        c = conn(); cur = c.cursor()
        cur.execute(schema)
        c.commit(); c.close()
    else:
        c = conn(); cur = c.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
          password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user',
          area TEXT NOT NULL DEFAULT '', jefe_area TEXT NOT NULL DEFAULT '',
          puesto TEXT NOT NULL DEFAULT '',
          active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)""")
        cur.execute("""CREATE TABLE IF NOT EXISTS tickets(
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
          titulo TEXT NOT NULL, descripcion TEXT NOT NULL,
          prioridad TEXT NOT NULL DEFAULT 'media', estado TEXT NOT NULL DEFAULT 'abierto',
          adjunto_path TEXT, adjunto_nombre TEXT,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL)""")
        cur.execute("""CREATE TABLE IF NOT EXISTS ticket_messages(
          id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL,
          user_id INTEGER NOT NULL, mensaje TEXT NOT NULL,
          created_at TEXT NOT NULL)""")
        cur.execute("""CREATE TABLE IF NOT EXISTS ticket_valoraciones(
          ticket_id INTEGER PRIMARY KEY, estrellas INTEGER NOT NULL,
          comentario TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL)""")
        cur.execute("""CREATE TABLE IF NOT EXISTS ticket_cierres(
          ticket_id INTEGER PRIMARY KEY, nota TEXT NOT NULL DEFAULT '',
          evidencia_path TEXT, evidencia_nombre TEXT, created_at TEXT NOT NULL)""")
        cur.execute("""CREATE TABLE IF NOT EXISTS ticket_adjuntos(
          id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL,
          path TEXT NOT NULL, nombre TEXT NOT NULL)""")
        cur.execute("""CREATE TABLE IF NOT EXISTS ticket_eventos(
          id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL,
          tipo TEXT NOT NULL, por TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL)""")
        cur.execute("""CREATE TABLE IF NOT EXISTS audit_logs(
          id INTEGER PRIMARY KEY AUTOINCREMENT, actor_id INTEGER, actor TEXT NOT NULL DEFAULT '',
          accion TEXT NOT NULL, detalle TEXT NOT NULL DEFAULT '',
          ticket_id INTEGER, created_at TEXT NOT NULL)""")
        # traspasa adjuntos viejos (columna única) a la tabla múltiple
        cur.execute("""INSERT INTO ticket_adjuntos(ticket_id, path, nombre)
          SELECT t.id, t.adjunto_path, COALESCE(t.adjunto_nombre, 'imagen') FROM tickets t
          WHERE t.adjunto_path IS NOT NULL AND NOT EXISTS
          (SELECT 1 FROM ticket_adjuntos a WHERE a.ticket_id = t.id AND a.path = t.adjunto_path)""")
        try:
            cur.execute("ALTER TABLE users ADD COLUMN area TEXT NOT NULL DEFAULT ''")
        except Exception:
            pass  # ya existe en BDs creadas antes
        try:
            cur.execute("ALTER TABLE users ADD COLUMN jefe_area TEXT NOT NULL DEFAULT ''")
        except Exception:
            pass
        try:
            cur.execute("ALTER TABLE users ADD COLUMN puesto TEXT NOT NULL DEFAULT ''")
        except Exception:
            pass
        c.commit(); c.close()
    if USE_PG:
        # migraciones para BDs ya creadas
        c = conn(); cur = c.cursor()
        cur.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS area VARCHAR(80) DEFAULT ''")
        cur.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS jefe_area VARCHAR(120) DEFAULT ''")
        cur.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS puesto VARCHAR(80) DEFAULT ''")
        try:
            cur.execute("ALTER TABLE users DROP CONSTRAINT IF EXISTS users_role_check")
            cur.execute("ALTER TABLE users ADD CONSTRAINT users_role_check CHECK (role IN ('admin','user','super','compras','calidad'))")
        except Exception:
            pass
        cur.execute("""CREATE TABLE IF NOT EXISTS ticket_messages(
          id SERIAL PRIMARY KEY, ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
          user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          mensaje VARCHAR(500) NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())""")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_msg_ticket ON ticket_messages(ticket_id)")
        cur.execute("""CREATE TABLE IF NOT EXISTS ticket_valoraciones(
          ticket_id INTEGER PRIMARY KEY REFERENCES tickets(id) ON DELETE CASCADE,
          estrellas SMALLINT NOT NULL CHECK (estrellas BETWEEN 1 AND 5),
          comentario VARCHAR(500) NOT NULL DEFAULT '',
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())""")
        cur.execute("""CREATE TABLE IF NOT EXISTS ticket_cierres(
          ticket_id INTEGER PRIMARY KEY REFERENCES tickets(id) ON DELETE CASCADE,
          nota TEXT NOT NULL DEFAULT '',
          evidencia_path VARCHAR(500), evidencia_nombre VARCHAR(255),
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())""")
        cur.execute("""CREATE TABLE IF NOT EXISTS ticket_adjuntos(
          id SERIAL PRIMARY KEY, ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
          path VARCHAR(500) NOT NULL, nombre VARCHAR(255) NOT NULL)""")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_adj_ticket ON ticket_adjuntos(ticket_id)")
        cur.execute("""CREATE TABLE IF NOT EXISTS ticket_eventos(
          id SERIAL PRIMARY KEY, ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
          tipo VARCHAR(20) NOT NULL, por VARCHAR(60) NOT NULL DEFAULT '',
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())""")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_ev_ticket ON ticket_eventos(ticket_id)")
        cur.execute("""CREATE TABLE IF NOT EXISTS audit_logs(
          id SERIAL PRIMARY KEY, actor_id INTEGER, actor VARCHAR(60) NOT NULL DEFAULT '',
          accion VARCHAR(40) NOT NULL, detalle TEXT NOT NULL DEFAULT '',
          ticket_id INTEGER, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())""")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_audit_accion ON audit_logs(accion)")
        cur.execute("""INSERT INTO ticket_adjuntos(ticket_id, path, nombre)
          SELECT t.id, t.adjunto_path, COALESCE(t.adjunto_nombre, 'imagen') FROM tickets t
          WHERE t.adjunto_path IS NOT NULL AND NOT EXISTS
          (SELECT 1 FROM ticket_adjuntos a WHERE a.ticket_id = t.id AND a.path = t.adjunto_path)""")
        c.commit(); c.close()
    # bootstrap admin
    au = os.getenv("BOOTSTRAP_ADMIN_USER", "admin")
    ap = os.getenv("BOOTSTRAP_ADMIN_PASS", "Contraseña123!")
    if not q_one(f"SELECT id FROM users WHERE username={PH}", (au,)):
        ph = bcrypt.hashpw(ap.encode(), bcrypt.gensalt()).decode()
        now = datetime.now(timezone.utc).isoformat()
        if USE_PG:
            q_exec("INSERT INTO users(username,password_hash,role,active,created_at) VALUES(%s,%s,'admin',TRUE,%s)", (au, ph, now))
        else:
            q_exec("INSERT INTO users(username,password_hash,role,active,created_at) VALUES(?,?,?,1,?)", (au, ph, "admin", now))
        print(f"[init] admin creado: {au}")
    # equipo de administración: Joshua (super) crea/borra admins; Carlos y María gestionan usuarios
    for uname, urole, upass in (
        (os.getenv("SUPER_USER", "Joshua"), "super", os.getenv("SUPER_PASS", "Joshua123*")),
        (os.getenv("ADMIN1_USER", "Carlos"), "admin", os.getenv("ADMIN1_PASS", "Carlos123*")),
        (os.getenv("ADMIN2_USER", "Maria"), "admin", os.getenv("ADMIN2_PASS", "Maria123*")),
    ):
        if not q_one(f"SELECT id FROM users WHERE username={PH}", (uname,)):
            ph = bcrypt.hashpw(upass.encode(), bcrypt.gensalt()).decode()
            now = datetime.now(timezone.utc).isoformat()
            if USE_PG:
                q_exec("INSERT INTO users(username,password_hash,role,area,active,created_at) VALUES(%s,%s,%s,'Administración',TRUE,%s)", (uname, ph, urole, now))
            else:
                q_exec("INSERT INTO users(username,password_hash,role,area,active,created_at) VALUES(?,?,?,'Administración',1,?)", (uname, ph, urole, now))
            print(f"[init] {urole} creado: {uname} (cámbiale la contraseña en Usuarios)")
    # Módulo de compras (solicitudes, requisiciones, órdenes, recepciones y devoluciones)
    _init_compras()

# ---- App ----
app = Flask(__name__)
app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET", "dev-secret")
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(minutes=15)
app.config["JWT_REFRESH_TOKEN_EXPIRES"] = timedelta(days=30)
CORS(app)
jwt = JWTManager(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

_up = (os.getenv("UPLOAD_DIR") or "").strip()
if not _up:
    UPLOAD_DIR = DATA_DIR / "uploads"
elif os.path.isabs(_up):
    UPLOAD_DIR = Path(_up)
else:
    # ruta relativa (p.ej. "./uploads" del .env) => relativa a DATA_DIR
    UPLOAD_DIR = DATA_DIR / _up
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
# Caché local de imágenes de producto: una vez que una imagen remota se pudo
# descargar, se guarda en el equipo sede y se sirve siempre desde ahí.
IMAGE_CACHE_DIR = UPLOAD_DIR / "compras-cache"
IMAGE_CACHE_DIR.mkdir(parents=True, exist_ok=True)
MAX_MB = int(os.getenv("MAX_MB", "10"))
MAX_BYTES = MAX_MB * 1024 * 1024
# Solo imágenes: así la vista previa siempre funciona garantizada
ALLOWED_EXT = {".png", ".jpg", ".jpeg", ".webp"}
ALLOWED_MIME = {"image/png", "image/jpeg", "image/webp"}

def role_required(*roles):
    """'admin' incluye a 'super'. 'super' es solo super admin."""
    allowed = set()
    for x in roles:
        if x == "admin":
            allowed |= {"admin", "super"}
        else:
            allowed.add(x)

    def deco(fn):
        @wraps(fn)
        @jwt_required()
        def inner(*a, **kw):
            claims = get_jwt()
            if claims.get("role") not in allowed:
                return jsonify({"msg": "Solo administradores"}), 403
            return fn(*a, **kw)
        return inner
    return deco

def _es_admin(role):
    return role in ("admin", "super")

def _puede_gestionar(me_role, target_role):
    """Quién puede crear/editar/borrar a quién."""
    if me_role == "super":
        return True, ""
    if target_role in ("admin", "super"):
        return False, "Solo Joshua (super admin) puede gestionar administradores"
    return True, ""

def valid_file(filename, data: bytes):
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXT:
        return False, "Solo se permiten imágenes (png, jpg, webp)"
    if len(data) > MAX_BYTES:
        return False, f"Excede {MAX_MB} MB"
    if len(data) == 0:
        return False, "Archivo vacío"
    # magic-bytes estrictos de imagen (detecta archivos falsos/corruptos)
    if data.startswith(b"\x89PNG"):
        kind = "png"
    elif data.startswith(b"\xff\xd8\xff"):
        kind = "jpg"
    elif data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        kind = "webp"
    else:
        return False, "No es una imagen válida o está corrupta"
    if ext in (".jpg", ".jpeg") and kind != "jpg":
        return False, "La extensión no coincide con el contenido"
    if ext == ".png" and kind != "png":
        return False, "La extensión no coincide con el contenido"
    if ext == ".webp" and kind != "webp":
        return False, "La extensión no coincide con el contenido"
    try:
        from PIL import Image
        import io as _io
        im = Image.open(_io.BytesIO(data))
        im.verify()
    except Exception:
        return False, "La imagen está corrupta"
    return True, "ok"


def valid_signed_file(filename, data: bytes):
    """Documentos firmados: únicamente PDF, con validación de contenido."""
    ext = Path(filename).suffix.lower()
    if ext != ".pdf":
        return False, "Solo se permiten documentos PDF"
    if len(data) > MAX_BYTES:
        return False, f"Excede {MAX_MB} MB"
    if len(data) == 0:
        return False, "Archivo vacío"
    if not data.startswith(b"%PDF"):
        return False, "El PDF está dañado o no es un PDF válido"
    return True, "ok"


def _cp_image_kind(data: bytes):
    if not data:
        return ""
    if data.startswith(b"\x89PNG"):
        return "png"
    if data.startswith(b"\xff\xd8\xff"):
        return "jpg"
    if data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        return "webp"
    return ""


def _cp_compress_image(data: bytes):
    """Reduce la imagen para que el equipo sede no guarde archivos pesados.

    Máximo 1920 px por lado y calidad 82 en WebP. Si por algún motivo no se
    puede convertir, se conserva la imagen original ya validada.
    """
    try:
        from PIL import Image
        import io as _io
        im = Image.open(_io.BytesIO(data))
        try:
            im.seek(0)
        except Exception:
            pass
        im.load()
        max_side = 1920
        if max(im.size) > max_side:
            im.thumbnail((max_side, max_side), Image.LANCZOS)
        if im.mode not in ("RGB", "RGBA"):
            im = im.convert("RGBA" if "A" in im.getbands() else "RGB")
        out = _io.BytesIO()
        im.save(out, format="WEBP", quality=82, method=6)
        converted = out.getvalue()
        if converted:
            return converted, ".webp"
    except Exception:
        pass
    return data, ""


def _cp_compress_pdf(data: bytes):
    """Intenta recomprimir el PDF sin alterar su contenido visible."""
    try:
        from pypdf import PdfReader, PdfWriter
        import io as _io
        reader = PdfReader(_io.BytesIO(data))
        writer = PdfWriter()
        for page in reader.pages:
            writer.add_page(page)
        for page in writer.pages:
            try:
                page.compress_content_streams()
            except Exception:
                pass
        out = _io.BytesIO()
        writer.write(out)
        converted = out.getvalue()
        if converted.startswith(b"%PDF") and len(converted) < len(data):
            return converted
    except Exception:
        pass
    return data


def _cp_store_image(data: bytes, filename: str, prefix: str = ""):
    """Valida, comprime y guarda una imagen. Devuelve (ruta, nombre visible)."""
    ok, msg = valid_file(filename, data)
    if not ok:
        return None, None, msg
    converted, new_ext = _cp_compress_image(data)
    ext = new_ext or Path(filename).suffix.lower()
    safe = (f"{prefix}{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}_"
            f"{secrets.token_hex(4)}{ext}")
    safe = "".join(ch for ch in safe if ch.isalnum() or ch in ("-", "_", "."))
    (UPLOAD_DIR / safe).write_bytes(converted)
    display = (Path(filename).stem[:120] or "imagen") + ext
    return safe, display, None


def _cp_store_remote_image(url: str, prefix: str = ""):
    """Descarga una imagen por enlace y la guarda comprimida en el equipo sede."""
    try:
        data, ctype, final = _cp_remote_open(url, "image/", MAX_BYTES)
    except ValueError as e:
        return None, None, str(e)
    except Exception:
        return None, None, "No se pudo descargar la imagen del enlace"
    kind = _cp_image_kind(data)
    if not ctype.startswith("image/") or not kind:
        return None, None, "El enlace no es una imagen válida"
    name = Path(urlparse(final).path).name or f"imagen.{kind}"
    if not Path(name).suffix:
        name += f".{kind}"
    return _cp_store_image(data, name, prefix=prefix)

def _lan_ip():
    """IP de este equipo (la sede) dentro de la red local."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            if ip and not ip.startswith("127."):
                return ip
        finally:
            s.close()
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if ip and not ip.startswith("127.") and ip.startswith(("10.", "192.168.", "172.")):
                return ip
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if ip and not ip.startswith("127."):
                return ip
    except Exception:
        pass
    return "127.0.0.1"

# ---------------------------------------------------------------------
# Actualizaciones desde GitHub Releases
# ---------------------------------------------------------------------
_UPDATE_CONFIG_FILE = BASE / "update_config.json"
_UPDATE_DATA_FILE = DATA_DIR / "update.json"
_UPDATE_DEFAULT_ASSET = "SylpackTickets_App.zip"
_UPDATE_MAX_BYTES = 600 * 1024 * 1024
_UPDATE_DIR = DATA_DIR / "updates"
# Canal público de actualizaciones (no requiere token ni configuración).
_UPDATE_FEED_DEFAULT = ("https://github.com/joshualeba/Sylpack-Tickets-Updates"
                        "/releases/latest/download/latest.json")


def _update_read_json(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return {}


def _update_config():
    cfg = {}
    for path in (_UPDATE_CONFIG_FILE, _UPDATE_DATA_FILE):
        data = _update_read_json(path)
        if isinstance(data, dict):
            cfg.update(data)
    repo = str(os.getenv("SYLPACK_UPDATE_REPO") or cfg.get("repo") or "").strip()
    token = str(os.getenv("SYLPACK_UPDATE_TOKEN") or cfg.get("token") or "").strip()
    asset = str(os.getenv("SYLPACK_UPDATE_ASSET") or cfg.get("asset") or _UPDATE_DEFAULT_ASSET).strip()
    if repo and not re.match(r"^[\w.-]+/[\w.-]+$", repo):
        repo = ""
    feed_env = os.getenv("SYLPACK_UPDATE_FEED")
    if feed_env is not None:
        feed = feed_env.strip()
    elif "feed" in cfg:
        feed = str(cfg.get("feed") or "").strip()
    else:
        feed = _UPDATE_FEED_DEFAULT
    return {"repo": repo, "token": token, "asset": asset or _UPDATE_DEFAULT_ASSET,
            "feed": feed}


def _app_version():
    data = _update_read_json(BASE / "version.json")
    version = str(data.get("version") or "").strip()
    if not version:
        try:
            txt = (BASE.parent / "src" / "js" / "config.js").read_text(encoding="utf-8")
            m = re.search(r'APP_VERSION\s*=\s*"([^"]+)"', txt)
            version = m.group(1) if m else "1.0.0"
        except Exception:
            version = "1.0.0"
    return version.lstrip("vV")


def _version_tuple(value):
    nums = [int(x) for x in re.findall(r"\d+", str(value or ""))]
    return tuple(nums[:5]) or (0,)


def _install_root():
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    if BASE.name == "server" and (BASE / "app.py").is_file():
        return BASE.parent
    return BASE


def _github_request(url, token="", accept="application/vnd.github+json", timeout=25):
    headers = {
        "Accept": accept,
        "User-Agent": "SylpackTickets-Updater/1.0",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if token:
        headers["Authorization"] = "Bearer " + token
    req = URLRequest(url, headers=headers)
    return build_opener().open(req, timeout=timeout)


def _github_json(url, token=""):
    with _github_request(url, token) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def _update_release_feed(feed, cfg=None):
    """Lee latest.json del canal público. No usa token ni la API de GitHub."""
    cfg = cfg or _update_config()
    sep = "&" if "?" in feed else "?"
    url = feed + sep + "t=" + str(int(time.time()))
    try:
        data = _github_json(url)
    except HTTPError as e:
        if e.code == 404:
            raise ValueError("El canal de actualizaciones no está publicado todavía.")
        raise ValueError("El canal de actualizaciones respondió con error " + str(e.code))
    except URLError as e:
        raise ValueError("No se pudo conectar con el canal de actualizaciones: "
                         + str(getattr(e, "reason", e)))
    except Exception as e:
        raise ValueError("No se pudo leer el canal de actualizaciones: " + str(e))
    if not isinstance(data, dict):
        raise ValueError("El canal de actualizaciones devolvió un formato no válido.")
    latest = str(data.get("version") or data.get("tag") or "").strip().lstrip("vV") or "0"
    current = _app_version()
    asset = data.get("app") if isinstance(data.get("app"), dict) else {}
    asset_url = str(asset.get("url") or "").strip()
    if asset_url and not re.match(r"^https?://", asset_url, re.I):
        asset_url = urljoin(feed, asset_url)
    try:
        asset_size = int(asset.get("size") or 0)
    except Exception:
        asset_size = 0
    sha = str(asset.get("sha256") or "").strip().lower()
    notes = str(data.get("notes") or "")
    return {
        "repo": str(data.get("repo") or cfg.get("repo") or ""),
        "current": current,
        "latest": latest,
        "tag": str(data.get("tag") or ("v" + latest)),
        "name": str(data.get("name") or ("Sylpack Tickets v" + latest)),
        "notes": notes[:6000],
        "published_at": str(data.get("published_at") or ""),
        "update_available": _version_tuple(latest) > _version_tuple(current),
        "asset_name": str(asset.get("name") or cfg.get("asset") or _UPDATE_DEFAULT_ASSET),
        "asset_size": asset_size,
        "checksum_available": bool(sha),
        "_asset_url": asset_url,
        "_asset_sha256": sha,
        "_checksum_url": "",
        "_checksum_name": "",
        "_token": "",
    }


def _update_release():
    cfg = _update_config()
    if cfg["feed"]:
        return _update_release_feed(cfg["feed"], cfg)
    repo = cfg["repo"]
    if not repo:
        raise ValueError("Falta configurar el repositorio de GitHub para actualizaciones.")
    try:
        rel = _github_json(f"https://api.github.com/repos/{repo}/releases/latest", cfg["token"])
    except HTTPError as e:
        if e.code == 404:
            raise ValueError("No se encontró el repositorio o es privado. Si es privado, "
                             "configura un token de lectura en data/update.json.")
        if e.code in (401, 403):
            raise ValueError("GitHub rechazó el acceso. Revisa el token de actualizaciones.")
        raise ValueError("GitHub respondió con error " + str(e.code))
    tag = str(rel.get("tag_name") or "").strip()
    latest = tag.lstrip("vV") or "0"
    current = _app_version()
    assets = rel.get("assets") or []
    wanted = cfg["asset"]
    asset = next((a for a in assets if a.get("name") == wanted), None)
    if not asset:
        asset = next((a for a in assets if str(a.get("name") or "").lower().endswith(".zip")
                      and "app" in str(a.get("name") or "").lower()), None)
    checksum = next((a for a in assets if str(a.get("name") or "").lower()
                     in ("checksums.txt", "sha256sums.txt", wanted + ".sha256")), None)
    return {
        "repo": repo,
        "current": current,
        "latest": latest,
        "tag": tag or latest,
        "name": rel.get("name") or tag,
        "notes": (rel.get("body") or "")[:6000],
        "published_at": rel.get("published_at") or "",
        "update_available": _version_tuple(latest) > _version_tuple(current),
        "asset_name": (asset or {}).get("name") or "",
        "asset_size": int((asset or {}).get("size") or 0),
        "checksum_available": bool(checksum),
        "_asset_url": (asset or {}).get("url") or "",
        "_checksum_url": (checksum or {}).get("url") or "",
        "_checksum_name": (checksum or {}).get("name") or "",
        "_token": cfg["token"],
    }


def _update_public(info):
    return {k: v for k, v in info.items() if not k.startswith("_")}


def _github_download(url, dest, token=""):
    dest.parent.mkdir(parents=True, exist_ok=True)
    total = 0
    with _github_request(url, token, accept="application/octet-stream", timeout=180) as r:
        with open(dest, "wb") as f:
            while True:
                chunk = r.read(1024 * 256)
                if not chunk:
                    break
                total += len(chunk)
                if total > _UPDATE_MAX_BYTES:
                    raise ValueError("La actualización excede el tamaño permitido.")
                f.write(chunk)
    if total <= 0:
        raise ValueError("La actualización descargada está vacía.")


def _update_checksum(info):
    preset = str(info.get("_asset_sha256") or "").strip().lower()
    if preset:
        return preset
    url = info.get("_checksum_url")
    name = info.get("_checksum_name") or ""
    if not url:
        return ""
    try:
        with _github_request(url, info.get("_token") or "", accept="application/octet-stream") as r:
            txt = r.read(512 * 1024).decode("utf-8", "replace")
    except Exception:
        return ""
    target = info.get("asset_name") or ""
    if name.endswith(".sha256"):
        return txt.strip().split()[0] if txt.strip() else ""
    for line in txt.splitlines():
        parts = line.strip().split()
        if len(parts) >= 2 and parts[-1].lstrip("*") == target:
            return parts[0]
    return ""


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _update_extract(zip_path, dest):
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as z:
        names = z.namelist()
        for raw in names:
            name = str(raw).replace("\\", "/")
            p = PurePosixPath(name)
            if p.is_absolute() or ".." in p.parts:
                raise ValueError("El paquete de actualización contiene rutas no válidas.")
        z.extractall(dest)
    if (dest / "SylpackTickets.exe").is_file():
        return dest
    roots = {PurePosixPath(str(n).replace("\\", "/")).parts[0]
             for n in names if str(n).strip() and not str(n).endswith("/")}
    for root in roots:
        candidate = dest / root
        if (candidate / "SylpackTickets.exe").is_file():
            return candidate
    raise ValueError("El paquete no contiene una instalación válida de Sylpack Tickets.")


def _update_apply_script(staging, target, exe, zip_path=None):
    _UPDATE_DIR.mkdir(parents=True, exist_ok=True)
    log = _UPDATE_DIR / "update.log"
    script = _UPDATE_DIR / "apply_update.ps1"

    def psq(value):
        return "'" + str(value).replace("'", "''") + "'"

    content = f"""$ErrorActionPreference = 'SilentlyContinue'
$log = {psq(log)}
function Log($m) {{ Add-Content -LiteralPath $log -Value ("[" + (Get-Date -Format s) + "] " + $m) }}
Log 'Actualizacion iniciada'
try {{ Wait-Process -Id {os.getpid()} -Timeout 120 -ErrorAction SilentlyContinue }} catch {{}}
Start-Sleep -Milliseconds 900
try {{ Stop-Process -Id {os.getpid()} -Force -ErrorAction SilentlyContinue }} catch {{}}
Log 'Copiando archivos actualizados'
$args = @({psq(staging)}, {psq(target)}, '/E', '/XD', {psq(target / 'data')}, '/XF', '.env', 'tickets.db', '*.log', '/R:2', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP')
$p = Start-Process -FilePath 'robocopy.exe' -ArgumentList $args -Wait -PassThru -WindowStyle Hidden
Log ('robocopy exit code: ' + $p.ExitCode)
Remove-Item -LiteralPath {psq(staging)} -Recurse -Force
{"Remove-Item -LiteralPath " + psq(zip_path) + " -Force" if zip_path else ""}
Log 'Reiniciando Sylpack Tickets'
Start-Process -FilePath 'explorer.exe' -ArgumentList {psq(exe)}
"""
    script.write_text(content, encoding="utf-8-sig")
    return script, log


def _update_can_write(target):
    try:
        target.mkdir(parents=True, exist_ok=True)
        probe = target / ".sylpack_write_test"
        probe.write_text("x", encoding="utf-8")
        probe.unlink(missing_ok=True)
        return True
    except Exception:
        return False


def _update_launch(script, target):
    """Aplica la actualización sin UAC si la carpeta es escribible."""
    params = f'-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{script}"'
    if _update_can_write(target):
        try:
            subprocess.Popen(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass",
                              "-WindowStyle", "Hidden", "-File", str(script)],
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                             close_fds=True)
            return
        except Exception:
            pass
    rc = ctypes.windll.shell32.ShellExecuteW(None, "runas", "powershell.exe", params, None, 0)
    if rc <= 32:
        raise ValueError("No se pudo iniciar la actualización. Acepta el aviso de administrador.")


@app.get("/api/updates/check")
@role_required("admin")
def updates_check():
    try:
        info = _update_release()
    except ValueError as e:
        return jsonify({"configured": False, "msg": str(e), "current_version": _app_version()}), 200
    except Exception as e:
        return jsonify({"configured": True, "msg": "No se pudo consultar GitHub: " + str(e),
                        "current_version": _app_version()}), 200
    out = _update_public(info)
    out.update({
        "configured": True,
        "installed": ( _install_root() / "SylpackTickets.exe").is_file(),
        "install_root": str(_install_root()),
        "admin": bool(ctypes.windll.shell32.IsUserAnAdmin()),
    })
    return jsonify(out)


@app.get("/api/updates/config")
@role_required("admin")
def updates_config_get():
    cfg = _update_config()
    return jsonify({"repo": cfg["repo"], "asset": cfg["asset"], "has_token": bool(cfg["token"])})


@app.post("/api/updates/config")
@role_required("admin")
def updates_config_set():
    d = request.get_json(force=True, silent=True) or {}
    repo = str(d.get("repo") or "").strip()
    asset = str(d.get("asset") or _UPDATE_DEFAULT_ASSET).strip() or _UPDATE_DEFAULT_ASSET
    token = str(d.get("token") or "").strip()
    if repo and not re.match(r"^[\w.-]+/[\w.-]+$", repo):
        return jsonify({"msg": "El repositorio debe verse así: usuario/repositorio"}), 400
    current = _update_read_json(_UPDATE_DATA_FILE)
    if not isinstance(current, dict):
        current = {}
    current["repo"] = repo
    current["asset"] = asset
    if token:
        current["token"] = token
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    _UPDATE_DATA_FILE.write_text(json.dumps(current, indent=2), encoding="utf-8")
    return jsonify({"ok": True})


@app.post("/api/updates/apply")
@role_required("admin")
def updates_apply():
    root = _install_root()
    exe = root / "SylpackTickets.exe"
    if not exe.is_file():
        return jsonify({"msg": "La actualización solo está disponible en la app instalada."}), 400
    try:
        info = _update_release()
    except Exception as e:
        return jsonify({"msg": str(e)}), 400
    if not info.get("update_available"):
        return jsonify({"msg": "Ya tienes la versión más reciente.", "version": info.get("current")}), 409
    if not info.get("_asset_url"):
        return jsonify({"msg": "La versión publicada no incluye el paquete de actualización."}), 400
    try:
        _UPDATE_DIR.mkdir(parents=True, exist_ok=True)
        safe_ver = re.sub(r"[^0-9A-Za-z._-]+", "_", info.get("latest") or "update")
        zip_path = _UPDATE_DIR / f"SylpackTickets-{safe_ver}.zip"
        _github_download(info["_asset_url"], zip_path, info.get("_token") or "")
        expected = _update_checksum(info)
        if expected and _sha256_file(zip_path) != expected.lower():
            zip_path.unlink(missing_ok=True)
            return jsonify({"msg": "La actualización no pasó la verificación de integridad."}), 400
        staging = _UPDATE_DIR / "staging"
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        source = _update_extract(zip_path, staging)
        for required in ("src", "server", "assets"):
            if not (source / required).is_dir():
                raise ValueError("El paquete no contiene la carpeta " + required)
        script, _log = _update_apply_script(source, root, exe, zip_path)
        _update_launch(script, root)
        threading.Timer(2.5, lambda: os._exit(0)).start()
        return jsonify({"ok": True, "version": info.get("latest"),
                        "msg": "Actualización lista. La app se reiniciará en unos segundos."})
    except ValueError as e:
        return jsonify({"msg": str(e)}), 400
    except Exception as e:
        return jsonify({"msg": "No se pudo preparar la actualización: " + str(e)}), 500


@app.get("/api/health")
def health():
    ok_h, _msg_h = en_horario()
    return jsonify({"ok": True, "db": "postgres" if USE_PG else "sqlite",
                    "ip": _lan_ip(), "horario_abierto": ok_h,
                    "time": datetime.now(timezone.utc).isoformat()})

@app.get("/api/horario")
def horario():
    st = _recepcion_state()
    return jsonify({"abierto": st["abierto"], "aceptando": st["aceptando"],
                    "pausado": st["paused"], "motivo": st["motivo"],
                    "override": st["override"], "override_until": st["override_until"],
                    "by": st["by"], "mensaje": st["mensaje"],
                    "ventana": st["ventana"], "ahora": datetime.now(TZ).isoformat()})

@app.get("/api/recepcion")
def get_recepcion():
    return jsonify(_recepcion_state())

@app.post("/api/recepcion")
@role_required("admin")
def set_recepcion():
    global _recepcion
    d = request.get_json(force=True, silent=True) or {}
    if "paused" not in d:
        return jsonify({"msg": "Falta el campo paused"}), 400
    paused = bool(d.get("paused"))
    force = bool(d.get("force"))
    before = _recepcion_state()
    if (not paused) and (not before["abierto"]) and (not before["override"]) and (not force):
        return jsonify({
            "msg": "Estás fuera del horario de atención. Puedes activar la recepción "
                   "manual para enviar de inmediato los reportes en cola.",
            "requiere_confirmacion": True, "estado": before}), 409
    ahora = datetime.now(TZ)
    override_until = ""
    if (not paused) and (not before["abierto"]):
        override_until = _next_apertura(ahora).isoformat()
    with _recv_lock:
        _recepcion = {"paused": paused,
                      "by": get_jwt().get("username") or "",
                      "at": datetime.now(timezone.utc).isoformat(),
                      "override_until": override_until}
        _save_recepcion()
    st = _recepcion_state()
    try:
        socketio.emit("recepcion_estado", st)
    except Exception:
        pass
    detalle = "pausada" if paused else "reanudada"
    if (not paused) and st["override"]:
        detalle += " (apertura manual fuera de horario)"
    _audit(int(get_jwt_identity()), get_jwt().get("username") or "",
           "recepcion_update", detalle)
    return jsonify({"ok": True, "estado": st})

@app.post("/api/login")
def login():
    d = request.get_json(force=True, silent=True) or {}
    u, p = (d.get("username") or "").strip(), d.get("password") or ""
    row = q_one(f"SELECT * FROM users WHERE username={PH} ORDER BY id DESC LIMIT 1", (u,))
    if not row:
        _audit(None, u, "login_fail", "Usuario inexistente")
        return jsonify({"msg": "Credenciales inválidas"}), 401
    active = row["active"] if USE_PG else row["active"]
    if not active:
        _audit(row["id"], u, "login_fail", "Cuenta desactivada")
        return jsonify({"msg": "Cuenta desactivada, contacta a administración"}), 403
    if not bcrypt.checkpw(p.encode(), row["password_hash"].encode()):
        _audit(row["id"], u, "login_fail", "Contraseña incorrecta")
        return jsonify({"msg": "Credenciales inválidas"}), 401
    _audit(row["id"], u, "login", f"Rol {row['role']}")
    ident = str(row["id"])
    access = create_access_token(identity=ident, additional_claims={"role": row["role"], "username": row["username"]})
    refresh = create_refresh_token(identity=ident, additional_claims={"role": row["role"]})
    return jsonify({"access": access, "refresh": refresh, "role": row["role"], "username": row["username"], "area": row.get("area") or "", "puesto": row.get("puesto") or ""})

@app.post("/api/refresh")
@jwt_required(refresh=True)
def refresh():
    ident = get_jwt_identity()
    claims = get_jwt()
    row = q_one(f"SELECT * FROM users WHERE id={PH}", (int(ident),))
    if not row:
        return jsonify({"msg": "No existe"}), 404
    access = create_access_token(identity=str(ident), additional_claims={"role": row["role"], "username": row["username"]})
    return jsonify({"access": access, "role": row["role"], "username": row["username"]})

@app.get("/api/me")
@jwt_required()
def me():
    ident = get_jwt_identity()
    row = q_one(f"SELECT id,username,role,area,puesto,jefe_area,active FROM users WHERE id={PH}", (int(ident),))
    return jsonify(dict(row) if row else {})

# --- usuarios (solo admin) ---
@app.get("/api/users")
@role_required("admin")
def list_users():
    rows = q_all("SELECT id,username,role,area,puesto,jefe_area,active,created_at FROM users ORDER BY id")
    return jsonify(rows)

AREAS_VALIDAS = {"Producción", "Embarques", "Almacén", "Calidad", "Mantenimiento", "Administración", "Ventas", "Compras", "Otra"}

def _password_error(p):
    if len(p) < 8:
        return "La contraseña debe tener al menos 8 caracteres"
    if len(p) > 25:
        return "La contraseña no puede tener más de 25 caracteres"
    if not any(c.isupper() for c in p):
        return "La contraseña debe incluir al menos una mayúscula"
    if not any((not c.isalnum()) and (not c.isspace()) for c in p):
        return "La contraseña debe incluir al menos un carácter especial"
    return None

@app.post("/api/users")
@role_required("admin")
def create_user():
    d = request.get_json(force=True, silent=True) or {}
    u = (d.get("username") or "").strip()
    p = d.get("password") or ""
    role = d.get("role", "user")
    area = (d.get("area") or "").strip()[:80]
    puesto = (d.get("puesto") or "").strip()[:80]
    jefe_area = (d.get("jefe_area") or "").strip()[:120]
    if len(u) < 3 or role not in ("admin", "user", "super", "compras", "calidad"):
        return jsonify({"msg": "Datos inválidos (nombre de usuario/a de 3+ caracteres)"}), 400
    perr = _password_error(p)
    if perr:
        return jsonify({"msg": perr}), 400
    me_role = get_jwt().get("role")
    ok, msg = _puede_gestionar(me_role, role)
    if not ok:
        return jsonify({"msg": msg}), 403
    if not area:
        return jsonify({"msg": "Selecciona el área a la que pertenece"}), 400
    # El nombre de usuario es único en toda la instalación porque el login es
    # solamente por nombre (no pide área). Validarlo así evita el error 500 de
    # la restricción UNIQUE de la base de datos.
    if q_one(f"SELECT id FROM users WHERE username={PH}", (u,)):
        return jsonify({"msg": "Ese nombre de usuario/a ya existe. Elige otro."}), 409
    # bcrypt con salt aleatorio (cost 12): nunca se guarda la contraseña en claro
    ph = bcrypt.hashpw(p.encode(), bcrypt.gensalt()).decode()
    now = datetime.now(timezone.utc).isoformat()
    try:
        if USE_PG:
            q_exec("INSERT INTO users(username,password_hash,role,area,puesto,jefe_area,active,created_at) VALUES(%s,%s,%s,%s,%s,%s,TRUE,%s)", (u, ph, role, area, puesto, jefe_area, now))
        else:
            q_exec("INSERT INTO users(username,password_hash,role,area,puesto,jefe_area,active,created_at) VALUES(?,?,?,?,?,?,1,?)", (u, ph, role, area, puesto, jefe_area, now))
    except Exception:
        return jsonify({"msg": "Ese nombre de usuario/a ya existe. Elige otro."}), 409
    _audit(int(get_jwt_identity()), get_jwt().get("username") or "", "user_create", f"{u} · rol {role} · {area} · puesto {puesto or '-'} · jefe {jefe_area or '-'}")
    return jsonify({"ok": True}), 201

# --- tickets ---
@app.post("/api/tickets")
@jwt_required()
def create_ticket():
    ident = int(get_jwt_identity())
    st = _recepcion_state()
    if st["paused"]:
        return jsonify({"msg": "La recepción de reportes está pausada por administración. "
                               "Tu reporte se guardará y se enviará automáticamente al reanudarse.",
                        "fuera_horario": False, "pausado": True,
                        "motivo": "pausado"}), 423
    if not st["aceptando"]:
        return jsonify({"msg": "Estamos fuera del horario de atención. Tu reporte se "
                               "guardará y se enviará automáticamente al abrir.",
                        "fuera_horario": True, "pausado": False,
                        "motivo": "fuera_horario"}), 423
    titulo = (request.form.get("titulo") or "").strip()[:140]
    descripcion = (request.form.get("descripcion") or "").strip()
    prioridad = (request.form.get("prioridad") or "media").strip()
    if not titulo or not descripcion:
        return jsonify({"msg": "Título y descripción requeridos"}), 400
    if prioridad not in ("baja", "media", "alta", "critica"):
        prioridad = "media"
    adj_path, adj_name = None, None
    # hasta 4 imágenes por reporte ("adjuntos" múltiple + "adjunto" único heredado)
    incoming = [f for f in request.files.getlist("adjuntos") if f and f.filename]
    legacy = request.files.get("adjunto")
    if legacy and legacy.filename:
        incoming.append(legacy)
    urls_in = []
    raw_urls = (request.form.get("adjuntos_url") or "").strip()
    if raw_urls:
        try:
            parsed_urls = json.loads(raw_urls)
            if isinstance(parsed_urls, list):
                urls_in = [str(u).strip() for u in parsed_urls if str(u).strip()]
        except Exception:
            urls_in = [u.strip() for u in raw_urls.splitlines() if u.strip()]
    if len(incoming) + len(urls_in) > 4:
        return jsonify({"msg": "Máximo 4 imágenes por reporte"}), 400
    saved = []
    for f in incoming:
        safe, display, msg = _cp_store_image(f.read(), f.filename)
        if not safe:
            return jsonify({"msg": f"{f.filename}: {msg}"}), 400
        saved.append((safe, display))
    for url in urls_in:
        safe, display, msg = _cp_store_remote_image(url, prefix="adjunto_")
        if not safe:
            return jsonify({"msg": f"{url}: {msg}"}), 400
        saved.append((safe, display))
    if saved:
        adj_path, adj_name = saved[0]
    now = datetime.now(timezone.utc).isoformat()
    if USE_PG:
        tid = q_exec(
            "INSERT INTO tickets(user_id,titulo,descripcion,prioridad,estado,adjunto_path,adjunto_nombre,created_at,updated_at) VALUES(%s,%s,%s,%s,'abierto',%s,%s,%s,%s) RETURNING id",
            (ident, titulo, descripcion, prioridad, adj_path, adj_name, now, now), returning_id=True)
    else:
        tid = q_exec(
            "INSERT INTO tickets(user_id,titulo,descripcion,prioridad,estado,adjunto_path,adjunto_nombre,created_at,updated_at) VALUES(?,?,?,?,?,?,?, ?, ?)",
            (ident, titulo, descripcion, prioridad, "abierto", adj_path, adj_name, now, now), returning_id=True)
    for safe, orig in saved:
        if USE_PG:
            q_exec("INSERT INTO ticket_adjuntos(ticket_id,path,nombre) VALUES(%s,%s,%s)", (tid, safe, orig))
        else:
            q_exec("INSERT INTO ticket_adjuntos(ticket_id,path,nombre) VALUES(?,?,?)", (tid, safe, orig))
    autor = q_one(f"SELECT username, area FROM users WHERE id={PH}", (ident,)) or {}
    payload = {"id": tid, "titulo": titulo, "prioridad": prioridad, "estado": "abierto",
               "created_at": now, "user_id": ident, "adjunto_nombre": adj_name,
               "username": autor.get("username") or "",
               "area": autor.get("area") or "",
               "descripcion": descripcion[:140],
               "adjuntos": len(saved)}
    # Aviso solo in-app a admins conectados
    socketio.emit("nuevo_ticket", payload)
    _audit(ident, get_jwt().get("username") or "", "ticket_create", f"#{tid} · {titulo} · {prioridad}", tid)
    return jsonify(payload), 201

def _extras(rows):
    """Adjunta conteo de mensajes, valoración, cierre, imágenes y reapertura."""
    tids = [r["id"] for r in rows]
    counts, vals, cierres, adjs, reab = {}, {}, {}, {}, {}
    if tids:
        ph_list = ",".join([PH] * len(tids))
        for m in q_all(f"SELECT ticket_id, COUNT(*) AS n FROM ticket_messages WHERE ticket_id IN ({ph_list}) GROUP BY ticket_id", tuple(tids)):
            counts[m["ticket_id"]] = m["n"]
        for v in q_all(f"SELECT ticket_id, estrellas, comentario FROM ticket_valoraciones WHERE ticket_id IN ({ph_list})", tuple(tids)):
            vals[v["ticket_id"]] = v
        for c in q_all(f"SELECT ticket_id, nota, evidencia_path, evidencia_nombre FROM ticket_cierres WHERE ticket_id IN ({ph_list})", tuple(tids)):
            cierres[c["ticket_id"]] = c
        for a in q_all(f"SELECT ticket_id, path, nombre FROM ticket_adjuntos WHERE ticket_id IN ({ph_list}) ORDER BY id", tuple(tids)):
            adjs.setdefault(a["ticket_id"], []).append({"path": a["path"], "nombre": a["nombre"]})
        for e in q_all(f"SELECT ticket_id, created_at, por FROM ticket_eventos WHERE ticket_id IN ({ph_list}) AND tipo='reabierto' ORDER BY created_at DESC", tuple(tids)):
            reab.setdefault(e["ticket_id"], e)
    for r in rows:
        r["mensajes"] = counts.get(r["id"], 0)
        r["valoracion"] = vals.get(r["id"])
        r["cierre"] = cierres.get(r["id"])
        own = [{"path": r.get("adjunto_path"), "nombre": r.get("adjunto_nombre")}] if r.get("adjunto_path") else []
        seen = {a["path"] for a in adjs.get(r["id"], [])}
        r["adjuntos"] = adjs.get(r["id"], []) + [o for o in own if o["path"] not in seen]
        r["reabierto"] = reab.get(r["id"])
    return rows

def _log_evento(tid, tipo, por=""):
    now = datetime.now(timezone.utc).isoformat()
    if USE_PG:
        q_exec("INSERT INTO ticket_eventos(ticket_id,tipo,por,created_at) VALUES(%s,%s,%s,%s)", (tid, tipo, por, now))
    else:
        q_exec("INSERT INTO ticket_eventos(ticket_id,tipo,por,created_at) VALUES(?,?,?,?)", (tid, tipo, por, now))

ACCIONES_ES = {
    "login": "Inicio de sesión", "login_fail": "Acceso fallido",
    "user_create": "Alta de usuario/a", "user_update": "Edición de usuario/a", "user_delete": "Baja de usuario/a",
    "ticket_create": "Reporte creado", "ticket_update": "Reporte actualizado",
    "ticket_cierre": "Reporte cerrado", "ticket_reapertura": "Reporte reabierto",
    "mensaje": "Mensaje de chat", "valoracion": "Calificación de servicio",
    "imagen_delete": "Imagen borrada", "recepcion_update": "Recepción de reportes",
    "compra_solicitud": "Solicitud de compra", "compra_estado": "Estado de compra",
    "compra_documento": "Documento de compra", "compra_recepcion": "Recepción de compra",
    "compra_devolucion": "Devolución de compra", "compra_proveedor": "Proveedor",
    "compra_empresa": "Datos fiscales",
}

def _audit(actor_id, actor, accion, detalle="", ticket_id=None):
    try:
        now = datetime.now(timezone.utc).isoformat()
        if USE_PG:
            q_exec("INSERT INTO audit_logs(actor_id,actor,accion,detalle,ticket_id,created_at) VALUES(%s,%s,%s,%s,%s,%s)",
                   (actor_id, actor, accion, detalle[:1000], ticket_id, now))
        else:
            q_exec("INSERT INTO audit_logs(actor_id,actor,accion,detalle,ticket_id,created_at) VALUES(?,?,?,?,?,?)",
                   (actor_id, actor, accion, detalle[:1000], ticket_id, now))
    except Exception:
        pass

@app.get("/api/logs")
@role_required("admin")
def list_logs():
    accion = request.args.get("accion", "")
    actor = (request.args.get("actor") or "").strip()[:60]
    ticket = (request.args.get("ticket") or "").strip()
    desde = (request.args.get("desde") or "").strip()[:10]
    hasta = (request.args.get("hasta") or "").strip()[:10]
    try:
        limit = min(int(request.args.get("limit", 200)), 500)
        offset = max(int(request.args.get("offset", 0)), 0)
    except (TypeError, ValueError):
        limit, offset = 200, 0
    conds, params = [], []
    if accion in ACCIONES_ES:
        conds.append(f"accion={PH}"); params.append(accion)
    if actor:
        conds.append(f"actor LIKE {PH}"); params.append(f"%{actor}%")
    if ticket.isdigit():
        conds.append(f"ticket_id={PH}"); params.append(int(ticket))
    if desde:
        conds.append(f"created_at>={PH}"); params.append(desde)
    if hasta:
        conds.append(f"created_at<={PH}"); params.append(hasta + "T23:59:59")
    where = (" WHERE " + " AND ".join(conds)) if conds else ""
    total = q_one(f"SELECT COUNT(*) AS n FROM audit_logs{where}", tuple(params))["n"]
    if USE_PG:
        rows = q_all(f"SELECT * FROM audit_logs{where} ORDER BY id DESC LIMIT %s OFFSET %s", tuple(params) + (limit, offset))
    else:
        rows = q_all(f"SELECT * FROM audit_logs{where} ORDER BY id DESC LIMIT ? OFFSET ?", tuple(params) + (limit, offset))
    return jsonify({"total": total, "rows": rows, "acciones": ACCIONES_ES})

@app.get("/api/tickets")
@jwt_required()
def list_tickets():
    claims = get_jwt()
    ident = int(get_jwt_identity())
    estado = request.args.get("estado", "")
    if _es_admin(claims.get("role")):
        sql = """SELECT t.*, COALESCE(u.username,'(cuenta eliminada)') AS username, COALESCE(u.area,'') AS area FROM tickets t LEFT JOIN users u ON u.id=t.user_id"""
        params: list = []
        if estado in ("abierto", "en_proceso", "cerrado"):
            sql += f" WHERE t.estado={PH}"
            params.append(estado)
        sql += " ORDER BY t.created_at DESC LIMIT 500"
        return jsonify(_extras(q_all(sql, tuple(params))))
    else:
        return jsonify(_extras(q_all(f"SELECT * FROM tickets WHERE user_id={PH} ORDER BY created_at DESC LIMIT 200", (ident,))))

@app.patch("/api/tickets/<int:tid>")
@role_required("admin")
def update_ticket(tid):
    d = request.get_json(force=True, silent=True) or {}
    sets, params = [], []
    if d.get("estado") in ("abierto", "en_proceso", "cerrado"):
        sets.append(f"estado={PH}"); params.append(d["estado"])
    if d.get("prioridad") in ("baja", "media", "alta", "critica"):
        sets.append(f"prioridad={PH}"); params.append(d["prioridad"])
    if not sets:
        return jsonify({"msg": "Nada que actualizar"}), 400
    prev = q_one(f"SELECT estado FROM tickets WHERE id={PH}", (tid,))
    sets.append(f"updated_at={PH}")
    params.append(datetime.now(timezone.utc).isoformat())
    params.append(tid)
    q_exec(f"UPDATE tickets SET {', '.join(sets)} WHERE id={PH}", tuple(params))
    reabierto = bool(d.get("estado") == "abierto" and prev and prev.get("estado") == "cerrado")
    me, who = int(get_jwt_identity()), get_jwt().get("username") or ""
    if reabierto:
        _log_evento(tid, "reabierto", who)
        _audit(me, who, "ticket_reapertura", f"Reporte #{tid} reabierto", tid)
    else:
        _audit(me, who, "ticket_update", f"Reporte #{tid}: " + ", ".join(k for k in d.keys() if k in ("estado", "prioridad")), tid)
    socketio.emit("ticket_actualizado", {
        "id": tid, "estado": d.get("estado") or "",
        "reabierto": reabierto,
        "reabierto_en": datetime.now(TZ).isoformat() if reabierto else None,
        "por": get_jwt().get("username") or ""
    })
    return jsonify({"ok": True})

@app.get("/api/uploads/<path:name>")
@jwt_required()
def download_upload(name):
    # evita path traversal + solo su dueño/a o administración
    safe = Path(name).name
    claims = get_jwt()
    ident = int(get_jwt_identity())
    if not _es_admin(claims.get("role")):
        t = q_one(f"SELECT id FROM tickets WHERE adjunto_path={PH} AND user_id={PH}", (safe, ident))
        a = q_one(f"""SELECT a.ticket_id FROM ticket_adjuntos a JOIN tickets t ON t.id=a.ticket_id
                       WHERE a.path={PH} AND t.user_id={PH}""", (safe, ident))
        c = q_one(f"""SELECT c.ticket_id FROM ticket_cierres c JOIN tickets t ON t.id=c.ticket_id
                       WHERE c.evidencia_path={PH} AND t.user_id={PH}""", (safe, ident))
        if not t and not a and not c:
            return jsonify({"msg": "Sin acceso"}), 403
    return send_from_directory(str(UPLOAD_DIR), safe, as_attachment=False)

# --- post-servicio: calificación del usuario/a (solo tickets cerrados) ---
@app.post("/api/tickets/<int:tid>/valoracion")
@jwt_required()
def post_valoracion(tid):
    ident = int(get_jwt_identity())
    if _es_admin(get_jwt().get("role")):
        return jsonify({"msg": "Solo la persona usuaria califica su servicio"}), 403
    t = q_one(f"SELECT estado FROM tickets WHERE id={PH} AND user_id={PH}", (tid, ident))
    if not t:
        return jsonify({"msg": "Sin acceso"}), 403
    if t["estado"] != "cerrado":
        return jsonify({"msg": "Podrás calificar cuando tu reporte esté resuelto"}), 400
    if q_one(f"SELECT ticket_id FROM ticket_valoraciones WHERE ticket_id={PH}", (tid,)):
        return jsonify({"msg": "Ya calificaste este servicio"}), 409
    d = request.get_json(force=True, silent=True) or {}
    try:
        est = int(d.get("estrellas") or 0)
    except (TypeError, ValueError):
        est = 0
    if est < 1 or est > 5:
        return jsonify({"msg": "Elige de 1 a 5 estrellas"}), 400
    com = (d.get("comentario") or "").strip()[:500]
    now = datetime.now(timezone.utc).isoformat()
    if USE_PG:
        q_exec("INSERT INTO ticket_valoraciones(ticket_id,estrellas,comentario,created_at) VALUES(%s,%s,%s,%s)", (tid, est, com, now))
    else:
        q_exec("INSERT INTO ticket_valoraciones(ticket_id,estrellas,comentario,created_at) VALUES(?,?,?,?)", (tid, est, com, now))
    socketio.emit("ticket_actualizado", {"id": tid, "estado": "cerrado"})
    _audit(ident, get_jwt().get("username") or "", "valoracion", f"Reporte #{tid}: {est}★ · {com[:80]}", tid)
    return jsonify({"ok": True}), 201

# --- cierre con evidencia/nota de administración ---
@app.post("/api/tickets/<int:tid>/cierre")
@role_required("admin")
def post_cierre(tid):
    nota = (request.form.get("nota") or "").strip()[:2000]
    if not nota:
        return jsonify({"msg": "Escribe qué se hizo para resolverlo"}), 400
    ev_path, ev_name = None, None
    f = request.files.get("evidencia")
    if f and f.filename:
        safe, display, msg = _cp_store_image(f.read(), f.filename, prefix=f"cierre_{tid}_")
        if not safe:
            return jsonify({"msg": msg}), 400
        ev_path, ev_name = safe, display
    else:
        url = (request.form.get("evidencia_url") or "").strip()
        if url:
            safe, display, msg = _cp_store_remote_image(url, prefix=f"cierre_{tid}_")
            if not safe:
                return jsonify({"msg": msg}), 400
            ev_path, ev_name = safe, display
    now = datetime.now(timezone.utc).isoformat()
    if USE_PG:
        q_exec("""INSERT INTO ticket_cierres(ticket_id,nota,evidencia_path,evidencia_nombre,created_at)
                  VALUES(%s,%s,%s,%s,%s)
                  ON CONFLICT (ticket_id) DO UPDATE SET nota=EXCLUDED.nota,
                  evidencia_path=EXCLUDED.evidencia_path, evidencia_nombre=EXCLUDED.evidencia_nombre,
                  created_at=EXCLUDED.created_at""", (tid, nota, ev_path, ev_name, now))
        q_exec("UPDATE tickets SET estado='cerrado', updated_at=%s WHERE id=%s", (now, tid))
    else:
        # Los archivos anteriores no se borran: solo se actualiza la referencia.
        q_exec("""INSERT INTO ticket_cierres(ticket_id,nota,evidencia_path,evidencia_nombre,created_at)
                  VALUES(?,?,?,?,?) ON CONFLICT(ticket_id) DO UPDATE SET nota=excluded.nota,
                  evidencia_path=excluded.evidencia_path, evidencia_nombre=excluded.evidencia_nombre,
                  created_at=excluded.created_at""", (tid, nota, ev_path, ev_name, now))
        q_exec("UPDATE tickets SET estado='cerrado', updated_at=? WHERE id=?", (now, tid))
    socketio.emit("ticket_actualizado", {"id": tid, "estado": "cerrado"})
    try:
        _log_evento(tid, "cerrado", get_jwt().get("username") or "")
    except Exception:
        pass
    _audit(int(get_jwt_identity()), get_jwt().get("username") or "", "ticket_cierre",
           f"Reporte #{tid} cerrado" + (" con evidencia" if ev_path else ""), tid)
    return jsonify({"ok": True})

# --- galería de imágenes (administración) ---
@app.get("/api/imagenes")
@role_required("admin")
def list_imagenes():
    out = []
    for a in q_all("""SELECT a.path, a.nombre, a.ticket_id, t.titulo, t.created_at AS t_created,
                             u.username, u.area
                      FROM ticket_adjuntos a
                      JOIN tickets t ON t.id=a.ticket_id
                      LEFT JOIN users u ON u.id=t.user_id
                      ORDER BY t.created_at DESC LIMIT 1000"""):
        a["tipo"] = "adjunto"
        a["origen"] = "reporte"
        a["username"] = a.get("username") or "(cuenta eliminada)"
        out.append(a)
    for c in q_all("""SELECT c.evidencia_path AS path, c.evidencia_nombre AS nombre, c.ticket_id,
                             t.titulo, t.created_at AS t_created, u.username, u.area
                      FROM ticket_cierres c
                      JOIN tickets t ON t.id=c.ticket_id
                      LEFT JOIN users u ON u.id=t.user_id
                      WHERE c.evidencia_path IS NOT NULL
                      ORDER BY t.created_at DESC LIMIT 1000"""):
        c["tipo"] = "evidencia"
        c["origen"] = "reporte"
        c["username"] = c.get("username") or "(cuenta eliminada)"
        out.append(c)
    for f in q_all("""SELECT a.id AS adjunto_id, a.path, a.nombre, a.solicitud_id,
                             a.documento_id, a.tipo AS firmado_tipo, a.subido_por,
                             a.vigente, a.created_at, s.folio AS solicitud_folio,
                             s.titulo, s.jefe_area, s.calidad_por, s.tipo_compra,
                             s.estado AS solicitud_estado, s.created_at AS t_created,
                             d.tipo AS documento_tipo, d.folio AS documento_folio,
                             d.elaborado_por, d.autorizado_por, u.username,
                             COALESCE(NULLIF(s.area, ''), u.area, '') AS area
                      FROM compras_adjuntos a
                      JOIN compras_solicitudes s ON s.id=a.solicitud_id
                      LEFT JOIN users u ON u.id=s.user_id
                      LEFT JOIN compras_documentos d ON d.id=a.documento_id
                      ORDER BY a.created_at DESC LIMIT 1000"""):
        f["tipo"] = "firmado"
        f["origen"] = "compra"
        f["username"] = f.get("username") or "(cuenta eliminada)"
        f["vigente"] = _cp_bool(f.get("vigente"))
        out.append(f)
    out.sort(key=lambda x: str(x.get("created_at") or x.get("t_created") or ""), reverse=True)
    return jsonify(out)

@app.delete("/api/imagenes")
@role_required("admin")
def delete_imagen():
    # Las imágenes y documentos son evidencia permanente: no se eliminan.
    return jsonify({"msg": "Las imágenes y documentos no se pueden eliminar"}), 403

# --- analítica (administración) ---
@app.get("/api/analitica")
@role_required("admin")
def analitica():
    desde = (request.args.get("desde") or "").strip()[:10]
    hasta = (request.args.get("hasta") or "").strip()[:10]
    area = (request.args.get("area") or "").strip()[:80]
    estado = request.args.get("estado", "")
    prioridad = request.args.get("prioridad", "")
    conds, params = [], []
    if desde:
        conds.append(f"t.created_at>={PH}"); params.append(desde)
    if hasta:
        conds.append(f"t.created_at<={PH}"); params.append(hasta + "T23:59:59")
    if area:
        conds.append(f"u.area={PH}"); params.append(area)
    if estado in ("abierto", "en_proceso", "cerrado"):
        conds.append(f"t.estado={PH}"); params.append(estado)
    if prioridad in ("baja", "media", "alta", "critica"):
        conds.append(f"t.prioridad={PH}"); params.append(prioridad)
    where = (" WHERE " + " AND ".join(conds)) if conds else ""
    base = f"FROM tickets t LEFT JOIN users u ON u.id=t.user_id{where}"
    total = q_one(f"SELECT COUNT(*) AS n {base}", tuple(params))["n"]
    by = lambda col: {r["k"]: r["n"] for r in q_all(f"SELECT {col} AS k, COUNT(*) AS n {base} GROUP BY {col}", tuple(params))}
    por_estado = by("t.estado")
    por_prioridad = by("t.prioridad")
    por_area_raw = q_all(f"SELECT COALESCE(NULLIF(u.area,''),'(sin área)') AS area, COUNT(*) AS n {base} GROUP BY area ORDER BY n DESC LIMIT 20", tuple(params))
    por_dia = q_all(f"SELECT SUBSTR(t.created_at,1,10) AS dia, COUNT(*) AS n {base} GROUP BY dia ORDER BY dia DESC LIMIT 60", tuple(params))
    # tiempo medio de resolución: created_at del ticket vs su evento 'cerrado'
    tmr = None
    try:
        ev_where = where + (" AND " if where else " WHERE ") + "e.tipo='cerrado'"
        evs = q_all(f"SELECT t.created_at AS c, e.created_at AS f FROM ticket_eventos e JOIN tickets t ON t.id=e.ticket_id LEFT JOIN users u ON u.id=t.user_id{ev_where} LIMIT 2000", tuple(params))
        hs = []
        for r in evs:
            try:
                a = datetime.fromisoformat(str(r["c"]).replace("Z", "+00:00"))
                b = datetime.fromisoformat(str(r["f"]).replace("Z", "+00:00"))
                h = (b - a).total_seconds() / 3600
                if 0 <= h < 24 * 30:
                    hs.append(h)
            except Exception:
                pass
        if hs:
            tmr = round(sum(hs) / len(hs), 1)
    except Exception:
        tmr = None
    cal = q_all(f"SELECT AVG(estrellas) AS p, COUNT(*) AS n FROM ticket_valoraciones v JOIN tickets t ON t.id=v.ticket_id LEFT JOIN users u ON u.id=t.user_id{where}", tuple(params))
    calif = {"promedio": round(float(cal[0]["p"] or 0), 1), "total": cal[0]["n"]}
    return jsonify({
        "total": total,
        "por_estado": por_estado, "por_prioridad": por_prioridad,
        "por_area": por_area_raw, "por_dia": list(reversed(por_dia)),
        "tmr_horas": tmr, "calificacion": calif,
    })

# --- CRUD de usuarios (administración) ---
def _admin_count():
    r = q_one("SELECT COUNT(*) AS n FROM users WHERE role IN ('admin','super') AND active=1")
    return r["n"] if r else 0

@app.patch("/api/users/<int:uid>")
@role_required("admin")
def patch_user(uid):
    me = int(get_jwt_identity())
    me_role = get_jwt().get("role")
    d = request.get_json(force=True, silent=True) or {}
    row = q_one(f"SELECT * FROM users WHERE id={PH}", (uid,))
    if not row:
        return jsonify({"msg": "No existe esa cuenta"}), 404
    ok, msg = _puede_gestionar(me_role, row["role"])
    if not ok:
        return jsonify({"msg": msg}), 403
    sets, params, cambios = [], [], []
    if "area" in d:
        area = (d.get("area") or "").strip()[:80]
        if not area:
            return jsonify({"msg": "El área no puede quedar vacía"}), 400
        sets.append(f"area={PH}"); params.append(area); cambios.append(f"área→{area}")
    if "puesto" in d:
        puesto = (d.get("puesto") or "").strip()[:80]
        sets.append(f"puesto={PH}"); params.append(puesto); cambios.append(f"puesto→'{puesto or '-'}'")
    if "jefe_area" in d:
        jefe = (d.get("jefe_area") or "").strip()[:120]
        sets.append(f"jefe_area={PH}"); params.append(jefe); cambios.append(f"jefatura de área→'{jefe or '-'}'")
    if "role" in d:
        role = d.get("role")
        if role not in ("admin", "user", "super", "compras", "calidad"):
            return jsonify({"msg": "Rol inválido"}), 400
        if role in ("admin", "super") and me_role != "super":
            return jsonify({"msg": "Solo Joshua (super admin) puede dar rol de administración"}), 403
        if uid == me and role != row["role"]:
            return jsonify({"msg": "No puedes cambiar tu propio rol"}), 400
        if row["role"] in ("admin", "super") and role not in ("admin", "super") and _admin_count() <= 1:
            return jsonify({"msg": "Debe quedar al menos una cuenta de administración activa"}), 400
        sets.append(f"role={PH}"); params.append(role); cambios.append(f"rol→{role}")
    if "active" in d:
        active = bool(d.get("active"))
        if uid == me and not active:
            return jsonify({"msg": "No puedes desactivar tu propia cuenta"}), 400
        if row["role"] in ("admin", "super") and not active and _admin_count() <= 1:
            return jsonify({"msg": "Debe quedar al menos una cuenta de administración activa"}), 400
        if USE_PG:
            sets.append(f"active={PH}"); params.append(active)
        else:
            sets.append("active=?"); params.append(1 if active else 0)
        cambios.append("activada" if active else "desactivada")
    if d.get("password"):
        perr = _password_error(d["password"])
        if perr:
            return jsonify({"msg": perr}), 400
        ph = bcrypt.hashpw(d["password"].encode(), bcrypt.gensalt()).decode()
        sets.append(f"password_hash={PH}"); params.append(ph); cambios.append("contraseña renovada")
    if not sets:
        return jsonify({"msg": "Nada que actualizar"}), 400
    params.append(uid)
    q_exec(f"UPDATE users SET {', '.join(sets)} WHERE id={PH}", tuple(params))
    _audit(me, get_jwt().get("username") or "", "user_update", f"{row['username']}: {', '.join(cambios)}")
    return jsonify({"ok": True})

@app.delete("/api/users/<int:uid>")
@role_required("admin")
def delete_user(uid):
    me = int(get_jwt_identity())
    me_role = get_jwt().get("role")
    if uid == me:
        return jsonify({"msg": "No puedes eliminar tu propia cuenta"}), 400
    row = q_one(f"SELECT * FROM users WHERE id={PH}", (uid,))
    if not row:
        return jsonify({"msg": "No existe esa cuenta"}), 404
    ok, msg = _puede_gestionar(me_role, row["role"])
    if not ok:
        return jsonify({"msg": msg}), 403
    if row["role"] in ("admin", "super") and _admin_count() <= 1:
        return jsonify({"msg": "Debe quedar al menos una cuenta de administración activa"}), 400
    # los reportes se conservan (muestran "(cuenta eliminada)")
    q_exec(f"DELETE FROM users WHERE id={PH}", (uid,))
    _audit(me, get_jwt().get("username") or "", "user_delete", f"{row['username']} · rol {row['role']}")
    return jsonify({"ok": True})

# --- conversación del ticket (chat usuario/a <-> administración) ---
def _puede_ver(ident, role, tid):
    if _es_admin(role):
        return True
    t = q_one(f"SELECT user_id FROM tickets WHERE id={PH}", (tid,))
    return bool(t) and int(t["user_id"]) == int(ident)

@app.get("/api/tickets/<int:tid>/mensajes")
@jwt_required()
def list_mensajes(tid):
    claims = get_jwt()
    ident = int(get_jwt_identity())
    if not _puede_ver(ident, claims.get("role"), tid):
        return jsonify({"msg": "Sin acceso"}), 403
    rows = q_all(
        f"""SELECT m.id, m.mensaje, m.created_at, COALESCE(u.username,'(cuenta eliminada)') AS username,
                   COALESCE(u.role,'user') AS role, COALESCE(u.area,'') AS area
            FROM ticket_messages m LEFT JOIN users u ON u.id=m.user_id
            WHERE m.ticket_id={PH} ORDER BY m.created_at ASC LIMIT 200""", (tid,))
    return jsonify(rows)

@app.post("/api/tickets/<int:tid>/mensajes")
@jwt_required()
def post_mensaje(tid):
    claims = get_jwt()
    ident = int(get_jwt_identity())
    if not _puede_ver(ident, claims.get("role"), tid):
        return jsonify({"msg": "Sin acceso"}), 403
    tk = q_one(f"SELECT estado FROM tickets WHERE id={PH}", (tid,))
    if tk and tk.get("estado") == "cerrado":
        return jsonify({"msg": "Este reporte ya fue cerrado, el chat está bloqueado"}), 400
    d = request.get_json(force=True, silent=True) or {}
    msg = (d.get("mensaje") or "").strip()
    if len(msg) < 1 or len(msg) > 500:
        return jsonify({"msg": "Mensaje de 1 a 500 caracteres"}), 400
    now = datetime.now(timezone.utc).isoformat()
    if USE_PG:
        q_exec("INSERT INTO ticket_messages(ticket_id,user_id,mensaje,created_at) VALUES(%s,%s,%s,%s)",
               (tid, ident, msg, now))
    else:
        q_exec("INSERT INTO ticket_messages(ticket_id,user_id,mensaje,created_at) VALUES(?,?,?,?)",
               (tid, ident, msg, now))
    autor = q_one(f"SELECT area FROM users WHERE id={PH}", (ident,)) or {}
    socketio.emit("nuevo_mensaje", {"ticket_id": tid, "de": claims.get("username"),
                                    "role": claims.get("role"), "area": autor.get("area") or "",
                                    "mensaje": msg[:140]})
    _audit(ident, claims.get("username") or "", "mensaje", f"Reporte #{tid}: {msg[:80]}", tid)
    return jsonify({"ok": True}), 201

# --- notificaciones (campana global) ---
@app.get("/api/notificaciones")
@jwt_required()
def notificaciones():
    claims = get_jwt()
    ident = int(get_jwt_identity())
    try:
        limit = min(int(request.args.get("limit", 20)), 50)
    except (TypeError, ValueError):
        limit = 20
    items = []
    if _es_admin(claims.get("role")):
        for m in q_all(
            f"""SELECT m.id, m.mensaje, m.created_at, m.ticket_id, u.username, t.titulo
                FROM ticket_messages m JOIN users u ON u.id=m.user_id
                JOIN tickets t ON t.id=m.ticket_id
                WHERE u.role='user' ORDER BY m.created_at DESC LIMIT {limit}"""):
            items.append({"id": f"m{m['id']}", "kind": "mensaje", "ticket_id": m["ticket_id"],
                          "titulo": m["titulo"], "texto": m["mensaje"], "de": m["username"],
                          "rol": "user", "created_at": m["created_at"], "tiene_imagen": False})
        for t in q_all(f"""SELECT t.id, t.titulo, t.created_at, u.username,
                                  (SELECT COUNT(*) FROM ticket_adjuntos a WHERE a.ticket_id=t.id) AS imgs
                           FROM tickets t LEFT JOIN users u ON u.id=t.user_id
                           ORDER BY t.created_at DESC LIMIT {limit}"""):
            items.append({"id": f"t{t['id']}", "kind": "ticket", "ticket_id": t["id"],
                          "titulo": t["titulo"], "texto": t["titulo"],
                          "de": t.get("username") or "(cuenta eliminada)", "rol": "user",
                          "created_at": t["created_at"], "tiene_imagen": (t.get("imgs") or 0) > 0})
    else:
        for m in q_all(
            f"""SELECT m.id, m.mensaje, m.created_at, m.ticket_id, u.username, u.role, t.titulo
                FROM ticket_messages m JOIN users u ON u.id=m.user_id
                JOIN tickets t ON t.id=m.ticket_id
                WHERE t.user_id={PH} AND m.user_id!={PH} ORDER BY m.created_at DESC LIMIT {limit}""",
            (ident, ident)):
            items.append({"id": f"m{m['id']}", "kind": "mensaje", "ticket_id": m["ticket_id"],
                          "titulo": m["titulo"], "texto": m["mensaje"], "de": m["username"],
                          "rol": m["role"], "created_at": m["created_at"], "tiene_imagen": False})
        for t in q_all(
            f"""SELECT id, titulo, updated_at FROM tickets
                WHERE user_id={PH} AND estado='cerrado' ORDER BY updated_at DESC LIMIT 5""", (ident,)):
            items.append({"id": f"c{t['id']}", "kind": "cierre", "ticket_id": t["id"],
                          "titulo": t["titulo"],
                          "texto": "Tu reporte fue cerrado. Ya puedes calificar el servicio.",
                          "de": "Administración", "rol": "admin",
                          "created_at": t["updated_at"], "tiene_imagen": False})

    # --- compras: mensajes de la conversación y avisos de seguimiento ---
    role = claims.get("role") or ""
    username = claims.get("username") or ""
    admin = _es_admin(role)
    conds, params = [f"m.user_id!={PH}"], [ident]
    if role == "user":
        conds.append(f"s.user_id={PH}"); params.append(ident)
    elif role == "calidad":
        conds.append("s.tipo_compra='calidad'")
        conds.append(f"(COALESCE(s.calidad_por,'')='' OR s.calidad_por={PH} OR s.user_id={PH})")
        params += [username, ident]
    elif not admin and role != "compras":
        conds.append("1=0")
    for m in q_all(
        f"""SELECT m.id, m.solicitud_id, m.mensaje, m.created_at, s.folio, s.titulo,
                   COALESCE(u.username,'(cuenta eliminada)') AS username
            FROM compras_mensajes m
            JOIN compras_solicitudes s ON s.id=m.solicitud_id
            LEFT JOIN users u ON u.id=m.user_id
            WHERE {' AND '.join(conds)}
            ORDER BY m.created_at DESC LIMIT {limit}""", tuple(params)):
        items.append({
            "id": f"cm{m['id']}", "kind": "compra_mensaje", "ticket_id": None,
            "solicitud_id": m["solicitud_id"], "compras": True, "folio": m["folio"],
            "titulo": f"Mensaje en {m['folio']} · {m['titulo']}",
            "texto": m["mensaje"], "de": m["username"], "rol": role,
            "created_at": m["created_at"], "tiene_imagen": False,
        })

    # --- compras: novedades del proceso para el solicitante ---
    if role == "user" and not admin:
        ev_txt = {
            "tomar": "Compras tomó tu solicitud y comenzó la revisión.",
            "aprobar": "Tu solicitud fue aprobada. Compras puede generar la orden.",
            "solicitar_cambios": "Compras pidió cambios en tu solicitud. Corrige y reenvía.",
            "rechazar": "Tu solicitud fue rechazada. Revisa el motivo y corrige si aplica.",
            "cancelar": "Tu solicitud fue cancelada.",
            "reabrir": "Tu solicitud fue reabierta para nueva revisión.",
            "cerrar": "Tu compra fue cerrada.",
            "requisicion_creada": "La requisición fue generada y está lista para firma.",
            "orden_compra_creada": "La orden de compra ya está lista. Descárgala, fírmala con el jefe de área y súbela.",
            "documento_creado": "Se generó un documento en tu proceso de compra.",
            "documento_editado": "Se actualizó un documento de tu compra; revisa la nueva versión.",
            "firmados_invalidados": "Los documentos firmados anteriores ya no son válidos. Debes firmar de nuevo.",
            "firmado_eliminado": "Compras retiró un documento firmado de tu solicitud. Revisa el detalle.",
            "calidad_reiniciada": "Calidad debe revisar de nuevo las opciones de tu compra.",
            "calidad_aprobar": "Calidad aprobó las opciones de tu compra.",
            "calidad_rechazar": "Calidad rechazó las opciones de tu compra.",
            "calidad_solicitar_cambios": "Calidad pidió cambios en tu compra.",
            "firmado_orden_compra_firmada": "La jefatura de área firmó la OC. Compras continúa con las firmas de gestión.",
            "firmado_orden_compra_firmada_calidad": "Calidad firmó la OC. Compras continúa con las firmas de gestión.",
            "firmado_orden_compra_firmada_sandra": "Sandra Limones firmó la OC. Falta la firma de Lucío Limones.",
            "firmado_orden_compra_firmada_lucio": "Lucío Limones firmó la OC. Falta el documento final con todas las firmas.",
            "firmado_orden_compra_firmada_final": "La OC ya tiene todas las firmas. La compra puede cerrarse.",
            "recepcion": "Se registró la recepción de tu compra.",
            "devolucion": "Se registró una devolución en tu compra.",
            "devolucion_aprobar": "La devolución de tu compra fue aprobada.",
            "devolucion_rechazar": "La devolución de tu compra fue rechazada.",
            "devolucion_enviar": "La devolución de tu compra fue enviada.",
            "devolucion_reembolsar": "La devolución de tu compra fue reembolsada.",
            "devolucion_cerrar": "La devolución de tu compra fue cerrada.",
        }
        for e in q_all(
            f"""SELECT e.id, e.solicitud_id, e.tipo, e.estado_anterior, e.estado_nuevo,
                       e.por, e.nota, e.created_at, s.folio, s.titulo
                FROM compras_eventos e
                JOIN compras_solicitudes s ON s.id=e.solicitud_id
                WHERE s.user_id={PH} AND COALESCE(e.por,'')!={PH}
                ORDER BY e.created_at DESC, e.id DESC LIMIT {limit}""",
                (ident, username)):
            texto = ev_txt.get(e["tipo"])
            if e["tipo"] == "accion":
                texto = {
                    "emitida": "Se emitió un documento de tu compra.",
                    "autorizada": "La orden de compra fue autorizada por Compras.",
                    "enviada": "La orden de compra fue enviada al proveedor.",
                    "recibida": "La orden de compra fue marcada como recibida.",
                    "cerrada": "El documento de tu compra fue cerrado.",
                    "cancelada": "El documento de tu compra fue cancelado.",
                }.get(e.get("estado_nuevo") or "")
            if not texto:
                continue
            if e["tipo"] in ("solicitar_cambios", "rechazar") and (e.get("nota") or "").strip():
                texto += " Motivo: " + e["nota"][:300]
            items.append({
                "id": f"ce{e['id']}", "kind": "compra_evento", "ticket_id": None,
                "solicitud_id": e["solicitud_id"], "compras": True, "folio": e["folio"],
                "estado": e.get("estado_nuevo") or None,
                "titulo": f"{e['folio']} · {e['titulo']}",
                "texto": texto, "de": e.get("por") or "Compras", "rol": "compras",
                "created_at": e["created_at"], "tiene_imagen": False,
            })

    # --- compras: novedades del proceso para gestores, Calidad y administración ---
    if role != "user":
        ev_conds = [f"COALESCE(e.por,'')!={PH}"]
        ev_params = [username]
        if role == "calidad":
            ev_conds.append("s.tipo_compra='calidad'")
        elif role not in ("compras", "admin", "super"):
            ev_conds.append("1=0")
        ev_txt_staff = {
            "tomar": "Compras tomó la solicitud.",
            "aprobar": "La solicitud fue aprobada.",
            "solicitar_cambios": "Se pidieron cambios a la solicitud.",
            "rechazar": "La solicitud fue rechazada.",
            "cancelar": "La solicitud fue cancelada.",
            "reabrir": "La solicitud fue reabierta.",
            "cerrar": "La compra fue cerrada.",
            "requisicion_creada": "Se generó la requisición.",
            "orden_compra_creada": "Se generó la orden de compra.",
            "documento_creado": "Se generó un documento de la compra.",
            "documento_editado": "Se actualizó un documento de la compra.",
            "firmados_invalidados": "Los documentos firmados dejaron de ser válidos.",
            "firmado_eliminado": "Se retiró un documento firmado.",
            "calidad_reiniciada": "Calidad debe revisar de nuevo la compra.",
            "calidad_aprobar": "Calidad aprobó las opciones de la compra.",
            "calidad_rechazar": "Calidad rechazó las opciones de la compra.",
            "calidad_solicitar_cambios": "Calidad pidió cambios en la compra.",
            "firmado_orden_compra_firmada": "Se subió la firma del jefe de área.",
            "firmado_orden_compra_firmada_calidad": "Se subió la firma de Calidad.",
            "firmado_orden_compra_firmada_sandra": "Se subió la firma de Sandra Limones.",
            "firmado_orden_compra_firmada_lucio": "Se subió la firma de Lucío Limones.",
            "firmado_orden_compra_firmada_final": "Se subió el documento final con todas las firmas.",
            "recepcion": "Se registró la recepción de la compra.",
            "devolucion": "Se registró una devolución.",
            "devolucion_aprobar": "La devolución fue aprobada.",
            "devolucion_rechazar": "La devolución fue rechazada.",
            "devolucion_enviar": "La devolución fue enviada al proveedor.",
            "devolucion_reembolsar": "La devolución fue reembolsada.",
            "devolucion_cerrar": "La devolución fue cerrada.",
        }
        for e in q_all(
            f"""SELECT e.id, e.solicitud_id, e.tipo, e.estado_anterior, e.estado_nuevo,
                       e.por, e.nota, e.created_at, s.folio, s.titulo
                FROM compras_eventos e
                JOIN compras_solicitudes s ON s.id=e.solicitud_id
                WHERE {' AND '.join(ev_conds)}
                ORDER BY e.created_at DESC, e.id DESC LIMIT {limit}""",
                tuple(ev_params)):
            texto = ev_txt_staff.get(e["tipo"])
            if e["tipo"] == "accion":
                texto = {
                    "emitida": "Se emitió un documento de la compra.",
                    "autorizada": "La orden de compra fue autorizada.",
                    "enviada": "La orden de compra fue enviada al proveedor.",
                    "recibida": "La orden de compra fue marcada como recibida.",
                    "cerrada": "El documento de la compra fue cerrado.",
                    "cancelada": "El documento de la compra fue cancelado.",
                }.get(e.get("estado_nuevo") or "")
            if not texto:
                continue
            if e["tipo"] in ("solicitar_cambios", "rechazar") and (e.get("nota") or "").strip():
                texto += " Motivo: " + e["nota"][:300]
            items.append({
                "id": f"cs{e['id']}", "kind": "compra_evento", "ticket_id": None,
                "solicitud_id": e["solicitud_id"], "compras": True, "folio": e["folio"],
                "estado": e.get("estado_nuevo") or None,
                "titulo": f"{e['folio']} · {e['titulo']}",
                "texto": texto, "de": e.get("por") or "Compras", "rol": role,
                "created_at": e["created_at"], "tiene_imagen": False,
            })

    avisos = []
    if role == "compras":
        avisos = q_all(
            f"""SELECT id, folio, titulo, estado, gestor_por, updated_at, cambios_oc_motivo
                FROM compras_solicitudes
                WHERE flujo='nuevo'
                  AND (estado IN ('pendiente','en_revision')
                       OR COALESCE(cambios_oc_motivo,'')!='')
                ORDER BY updated_at DESC LIMIT 12""")
    elif role == "calidad":
        avisos = q_all(
            f"""SELECT id, folio, titulo, estado, gestor_por, updated_at
                FROM compras_solicitudes
                WHERE flujo='nuevo' AND estado='en_revision' AND tipo_compra='calidad'
                  AND COALESCE(calidad_estado,'pendiente') NOT IN ('aprobada','no_requiere')
                ORDER BY updated_at DESC LIMIT 12""")
    elif role != "user" and not admin:
        avisos = q_all(
            f"""SELECT id, folio, titulo, estado, gestor_por, updated_at
                FROM compras_solicitudes
                WHERE user_id={PH} AND estado IN
                  ('cambios_solicitados','rechazada','aprobada','en_compra','recibida')
                ORDER BY updated_at DESC LIMIT 12""", (ident,))
    avisos_txt = {
        "pendiente": "Nueva solicitud recibida. Falta la requisición firmada por la jefatura.",
        "en_revision": "La requisición firmada está lista. Revisa y autoriza la compra.",
        "cambios_solicitados": "Compras pidió cambios. Revisa la conversación y corrige tu solicitud.",
        "rechazada": "La solicitud fue rechazada. Revisa el motivo en la conversación.",
        "aprobada": "La compra fue autorizada. Compras ya puede generar la orden.",
        "en_compra": "La orden de compra fue generada. Sigue el avance en la conversación.",
        "recibida": "La compra fue recibida. Revisa los detalles en la solicitud.",
    }
    for srow in avisos:
        if srow["estado"] == "en_revision" and not _cp_firmado_vigente(srow["id"], "requisicion_firmada"):
            continue
        texto = avisos_txt.get(srow["estado"], "La solicitud se actualizó.")
        if (srow.get("cambios_oc_motivo") or "").strip():
            texto = "La persona solicitante pidió cambios en la OC. Genera una nueva orden con la corrección."
        elif srow["estado"] == "en_compra":
            if not _cp_firmado_vigente(srow["id"], "orden_compra_firmada"):
                texto = "La orden está lista. Descárgala, fírmala con la jefatura y súbela en la solicitud."
            elif not _cp_firmado_vigente(srow["id"], "orden_compra_firmada_final"):
                texto = "La OC firmada por el jefe de área ya está cargada. Falta la firma final del gestor."
            else:
                texto = "La OC ya tiene la firma final. Pueden continuar con la recepción."
        if role == "compras" and srow.get("gestor_por") and srow["gestor_por"] != username:
            texto = f"En proceso por {srow['gestor_por']}. Solo lectura para los demás gestores."
        key = f"cs{srow['id']}-{srow['estado']}-{srow['updated_at']}"
        items.append({
            "id": key, "kind": "compra_solicitud", "ticket_id": None,
            "solicitud_id": srow["id"], "compras": True, "folio": srow["folio"],
            "estado": srow["estado"],
            "titulo": f"{srow['folio']} · {srow['titulo']}",
            "texto": texto,
            "de": "Compras", "rol": "compras",
            "created_at": srow["updated_at"], "tiene_imagen": False,
        })

    # --- catálogo e inventario: cambios recientes por área ---
    nov_conds = [
        "e.solicitud_id IS NULL",
        "(e.tipo LIKE 'catalogo%' OR e.tipo LIKE 'inventario%')",
        f"COALESCE(e.por,'')!={PH}",
    ]
    nov_params = [username]
    if not admin:
        if role in ("calidad", "compras"):
            nov_conds.append("e.tipo LIKE 'catalogo%'")
        else:
            area = _cp_area(ident)
            nov_conds.append(f"(COALESCE(e.area,'')={PH} OR COALESCE(e.areas_extra,'') LIKE {PH})")
            nov_params += [area, f"%|{area}|%"]
    for e in q_all(
        f"""SELECT e.id, e.tipo, e.area, e.areas_extra, e.por, e.nota, e.created_at
            FROM compras_eventos e
            WHERE {' AND '.join(nov_conds)}
            ORDER BY e.created_at DESC, e.id DESC LIMIT {limit}""",
            tuple(nov_params)):
        tipo = e.get("tipo") or ""
        if tipo.startswith("catalogo"):
            if tipo == "catalogo_alta":
                texto = "Se agregó un registro al catálogo."
            elif tipo == "catalogo_baja":
                texto = "Se desactivó un registro del catálogo."
            elif tipo == "catalogo_edicion":
                texto = "Se actualizó un registro del catálogo."
            elif tipo.startswith("catalogo_calidad_"):
                estado_cat = tipo.rsplit("_", 1)[-1]
                texto = {
                    "aprobado": "Calidad aprobó un registro del catálogo.",
                    "rechazado": "Calidad rechazó un registro del catálogo.",
                    "pendiente": "Calidad regresó un registro del catálogo a revisión.",
                }.get(estado_cat, "Calidad actualizó un registro del catálogo.")
            else:
                texto = "El catálogo se actualizó."
            kind = "catalogo"
            titulo = "Catálogo" + (f" · {e['area']}" if e.get("area") else "")
        else:
            texto = {
                "inventario_alta": "Se agregó un artículo al inventario.",
                "inventario_edicion": "Se actualizó un artículo del inventario.",
                "inventario_baja": "Se eliminó un artículo del inventario.",
            }.get(tipo, "El inventario se actualizó.")
            kind = "inventario"
            titulo = "Inventario" + (f" · {e['area']}" if e.get("area") else "")
        detalle = (e.get("nota") or "").strip()
        if detalle:
            texto += " " + detalle[:220]
        items.append({
            "id": f"ci{e['id']}", "kind": kind, "ticket_id": None,
            "solicitud_id": None, "catalogo": kind == "catalogo",
            "inventario": kind == "inventario", "area": e.get("area") or "",
            "titulo": titulo, "texto": texto, "de": e.get("por") or "Sistema",
            "rol": role, "created_at": e["created_at"], "tiene_imagen": False,
        })

    # Recordatorios de acción para el solicitante: firmas pendientes.
    if role == "user" and not admin:
        for srow in q_all(
            f"""SELECT id, folio, titulo, estado, updated_at
                FROM compras_solicitudes
                WHERE user_id={PH} AND flujo='nuevo' AND estado IN
                  ('pendiente','en_revision','cambios_solicitados','aprobada','en_compra',
                   'recibida','con_incidencias','devuelta')
                ORDER BY updated_at DESC LIMIT 12""", (ident,)):
            estado = srow["estado"]
            sid = srow["id"]
            if estado in ("pendiente", "en_revision", "cambios_solicitados"):
                if _cp_firmado_vigente(sid, "requisicion_firmada"):
                    continue
                texto = ("Tu solicitud cambió: descarga la requisición actualizada, fírmala con el jefe de área y súbela."
                         if estado == "cambios_solicitados" else
                         "Falta firmar la requisición. Descárgala, fírmala con el jefe de área y súbela.")
                rid = f"cr{sid}-req"
            else:
                oc = _cp_orden_compra(sid)
                if not oc or _cp_firmado_vigente(sid, "orden_compra_firmada"):
                    continue
                texto = (f"La {oc.get('folio') or 'orden de compra'} está lista. "
                         "Descárgala, fírmala con el jefe de área y súbela.")
                rid = f"cr{sid}-oc"
            items.append({
                "id": rid, "kind": "compra_solicitud", "ticket_id": None,
                "solicitud_id": sid, "compras": True, "folio": srow["folio"],
                "estado": estado,
                "titulo": f"{srow['folio']} · {srow['titulo']}",
                "texto": texto, "de": "Compras", "rol": "compras",
                "created_at": srow["updated_at"], "tiene_imagen": False,
            })

    tids = list({i["ticket_id"] for i in items if i.get("ticket_id") is not None})
    with_img = set()
    if tids:
        ph_list = ",".join([PH] * len(tids))
        for a in q_all(f"SELECT DISTINCT ticket_id FROM ticket_adjuntos WHERE ticket_id IN ({ph_list})", tuple(tids)):
            with_img.add(a["ticket_id"])
    for i in items:
        if i.get("ticket_id") in with_img:
            i["tiene_imagen"] = True
    items.sort(key=lambda x: str(x["created_at"]), reverse=True)
    return jsonify(items[:limit])

@app.delete("/api/notificaciones")
@jwt_required()
def clear_notificaciones():
    # No hay tabla persistente de notificaciones; se genera en tiempo real.
    # El borrado real ocurre en localStorage del cliente.
    return jsonify({"ok": True})

@app.delete("/api/notificaciones/<nid>")
@jwt_required()
def delete_notificacion(nid):
    # Borrado individual: igual que arriba, solo local.
    return jsonify({"ok": True})

# =====================================================================
#  MÓDULO DE COMPRAS
#  Flujo: solicitud -> revisión -> aprobación/rechazo -> requisición ->
#  orden de compra -> autorización -> envío -> recepción -> devolución.
# =====================================================================
# Ver: administración y super administración pueden consultar todo el módulo.
# Gestionar: solo el rol "compras" puede mover el flujo, autorizar, recibir o devolver.
ROLES_COMPRAS_VIEW = ("admin", "super", "compras", "calidad")
ROLES_COMPRAS_MANAGE = ("compras",)
ROLES_COMPRAS_QUALITY = ("calidad",)
CP_LIKE = "ILIKE" if USE_PG else "LIKE"
CP_ESTADOS_SOL = {
    "pendiente", "en_revision", "cambios_solicitados", "aprobada", "rechazada",
    "en_compra", "recibida", "con_incidencias", "devuelta", "cerrada", "cancelada",
}
CP_ESTADOS_DOC = {
    "borrador", "emitida", "autorizada", "enviada", "recibida", "cerrada", "cancelada",
}
CP_ESTADOS_DEV = {
    "solicitada", "aprobada", "rechazada", "enviada", "reembolsada", "cerrada",
}
CP_ESTADOS_CALIDAD = {"pendiente", "en_revision", "aprobada", "rechazada", "no_requiere"}


def _cp_filter_estados(column, raw, valid):
    """Filtro por uno o varios estados: estado=pendiente,en_revision."""
    values = []
    for part in str(raw or "").split(","):
        part = part.strip()
        if part and part in valid and part not in values:
            values.append(part)
    if not values:
        return "", []
    marks = ",".join([PH] * len(values))
    return f"{column} IN ({marks})", values


def _cp_me():
    claims = get_jwt()
    return int(get_jwt_identity()), (claims.get("role") or ""), (claims.get("username") or "")


def _cp_can_view(role):
    return role in ROLES_COMPRAS_VIEW


def _cp_can_manage(role):
    return role in ROLES_COMPRAS_MANAGE


def _cp_can_quality(role):
    return role in ROLES_COMPRAS_QUALITY


_CP_RFC_RE = re.compile(r"^[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{3}$")
_CP_EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]{2,}$")


def _cp_rfc(value):
    return re.sub(r"[^A-ZÑ&0-9]", "", str(value or "").upper())[:13]


def _cp_email_ok(value):
    return bool(_CP_EMAIL_RE.match(str(value or "").strip()))


def _cp_digits(value, max_len=10):
    return re.sub(r"\D", "", str(value or ""))[:max_len]


def _cp_num(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return float(default)


def _cp_int(v, default=0):
    try:
        return int(v)
    except (TypeError, ValueError):
        return int(default)


def _cp_bool(v):
    if isinstance(v, bool):
        return v
    return str(v or "").strip().lower() in ("1", "true", "si", "sí", "yes", "on")


# ---------------------------------------------------------------------
# Catálogo por área (productos y proveedores)
# Regla de visibilidad: cada registro pertenece a un área. Lo ven el área
# dueña (todos sus estados), Calidad (todas las áreas, para autorizar),
# Compras (solo registros aprobados, para poder comprar) y administración.
# ---------------------------------------------------------------------
CATALOGO_ESTADOS = ("pendiente", "aprobado", "rechazado")


def _cp_area(uid):
    row = q_one(f"SELECT area FROM users WHERE id={PH}", (int(uid),))
    return ((row or {}).get("area") or "").strip()


def _cp_catalog_scope(me_id, role):
    """Devuelve (cláusula SQL, parámetros) para listar el catálogo visible.

    Solo administración/superadministración y Calidad ven todas las áreas.
    Cualquier otra cuenta (incluida Compras) ve únicamente el catálogo de su
    propia área, con todos los productos que esa área ha subido.
    """
    if role in ("admin", "super", "calidad"):
        return "", []
    area = _cp_area(me_id)
    if not area:
        return "1=0", []
    return (f"COALESCE(area,'')={PH}", [area])


def _cp_catalog_can_view(row, me_id, role):
    if role in ("admin", "super", "calidad"):
        return True
    area = _cp_area(me_id)
    if not area:
        return False
    return (row.get("area") or "").strip() == area


def _cp_catalog_can_edit(row, me_id, role):
    if role in ("admin", "super", "calidad"):
        return True
    area = _cp_area(me_id)
    return bool(area) and (row.get("area") or "").strip() == area


def _cp_catalog_role_flags(role):
    return {
        "admin": role in ("admin", "super"),
        "quality": role == "calidad",
        "purchases": role == "compras",
    }


def _cp_norm_key(value):
    return re.sub(r"\s+", " ", str(value or "")).strip().lower()


def _cp_catalog_enrich_products(rows, area_filter=None):
    """Agrega uso real de cada producto en solicitudes y datos de su proveedor.

    El catálogo no guarda un id de producto en las partidas históricas, por eso
    el cruce se hace por nombre normalizado. Es una lectura de apoyo para que
    las áreas y Calidad decidan con contexto, nunca para modificar documentos.
    """
    if not rows:
        return rows
    providers = {int(p["id"]): p for p in q_all("SELECT id,nombre,calidad_estado,area,activo FROM proveedores")}
    usage = {}
    if area_filter:
        items = q_all(
            f"""SELECT i.nombre,i.cantidad,i.costo_unitario,i.precio_incluye_iva,
                       i.link,i.imagen,i.motivo,i.solicitud_id,i.created_at
                FROM compras_items i JOIN compras_solicitudes s ON s.id=i.solicitud_id
                WHERE COALESCE(s.area,'')={PH} ORDER BY i.created_at DESC""",
            (area_filter,))
    else:
        items = q_all(
            """SELECT i.nombre,i.cantidad,i.costo_unitario,i.precio_incluye_iva,
                      i.link,i.imagen,i.motivo,i.solicitud_id,i.created_at
               FROM compras_items i ORDER BY i.created_at DESC"""
        )
    for item in items:
        key = _cp_norm_key(item.get("nombre"))
        if not key:
            continue
        bucket = usage.setdefault(key, {
            "solicitudes": set(), "unidades": 0.0, "costos": [], "ultimo_uso": "",
            "ultimo_costo": None, "ultimo_iva": False, "link": "", "imagen": "",
            "motivo": "",
        })
        # Primer valor no vacío = el más reciente (la consulta viene DESC).
        if not bucket["link"] and str(item.get("link") or "").strip():
            bucket["link"] = str(item.get("link")).strip()
        if not bucket["imagen"] and str(item.get("imagen") or "").strip():
            bucket["imagen"] = str(item.get("imagen")).strip()
        if not bucket["motivo"] and str(item.get("motivo") or "").strip():
            bucket["motivo"] = str(item.get("motivo")).strip()
        if item.get("solicitud_id"):
            bucket["solicitudes"].add(int(item["solicitud_id"]))
        bucket["unidades"] += float(item.get("cantidad") or 0)
        costo = float(item.get("costo_unitario") or 0)
        if costo > 0:
            bucket["costos"].append(costo)
        fecha = item.get("created_at")
        fecha_txt = fecha.isoformat() if hasattr(fecha, "isoformat") else str(fecha or "")
        if fecha_txt > bucket["ultimo_uso"]:
            bucket["ultimo_uso"] = fecha_txt
            bucket["ultimo_costo"] = costo
            bucket["ultimo_iva"] = bool(item.get("precio_incluye_iva"))
    for row in rows:
        info = usage.get(_cp_norm_key(row.get("nombre")), {})
        costos = info.get("costos") or []
        if not str(row.get("link") or "").strip() and info.get("link"):
            row["link"] = info["link"]
        if not str(row.get("imagen") or "").strip() and info.get("imagen"):
            row["imagen"] = info["imagen"]
        # Si es Amazon, la imagen real del producto (por ASIN) siempre gana
        # sobre la imagen genérica de categoría que devuelve la página.
        amz = _cp_amazon_image(row.get("link") or "")
        if amz:
            row["imagen"] = amz
        row["motivo"] = info.get("motivo") or ""
        row["usos"] = len(info.get("solicitudes") or [])
        row["unidades_solicitadas"] = round(info.get("unidades") or 0, 4)
        row["costo_promedio"] = round(sum(costos) / len(costos), 4) if costos else 0
        row["ultimo_costo"] = info.get("ultimo_costo")
        row["ultimo_costo_iva"] = info.get("ultimo_iva", False)
        row["ultimo_uso"] = info.get("ultimo_uso") or ""
        pid = row.get("proveedor_id")
        prov = providers.get(int(pid)) if pid not in (None, "", 0, "0") else None
        row["proveedor_nombre"] = (prov or {}).get("nombre") or ""
        row["proveedor_calidad_estado"] = (prov or {}).get("calidad_estado") or ""
        row["proveedor_activo"] = bool((prov or {}).get("activo")) if prov else None
    return rows


def _cp_catalog_enrich_providers(rows, area_filter=None):
    """Agrega actividad de compras y productos vinculados a cada proveedor."""
    if not rows:
        return rows
    if area_filter:
        products = q_all(
            f"""SELECT proveedor_id,nombre,calidad_estado,activo
                FROM compras_productos_certificados
                WHERE COALESCE(area,'')={PH}""", (area_filter,))
        docs = q_all(
            f"""SELECT d.proveedor_id,COUNT(*) AS total,SUM(d.total) AS importe,MAX(d.fecha) AS ultima
                FROM compras_documentos d JOIN compras_solicitudes s ON s.id=d.solicitud_id
                WHERE d.proveedor_id IS NOT NULL AND COALESCE(s.area,'')={PH}
                GROUP BY d.proveedor_id""", (area_filter,))
    else:
        products = q_all(
            "SELECT proveedor_id,nombre,calidad_estado,activo FROM compras_productos_certificados"
        )
        docs = q_all(
            """SELECT proveedor_id,COUNT(*) AS total,SUM(total) AS importe,MAX(fecha) AS ultima
               FROM compras_documentos
               WHERE proveedor_id IS NOT NULL
               GROUP BY proveedor_id"""
        )
    prod_map, doc_map = {}, {}
    for p in products:
        pid = p.get("proveedor_id")
        if pid in (None, "", 0, "0"):
            continue
        key = int(pid)
        bucket = prod_map.setdefault(key, {"total": 0, "aprobados": 0, "nombres": []})
        bucket["total"] += 1
        if (p.get("calidad_estado") or "") == "aprobado" and p.get("activo"):
            bucket["aprobados"] += 1
        if len(bucket["nombres"]) < 3:
            bucket["nombres"].append(p.get("nombre") or "")
    for d in docs:
        pid = d.get("proveedor_id")
        if pid in (None, "", 0, "0"):
            continue
        doc_map[int(pid)] = d
    for row in rows:
        pid = int(row["id"])
        prod = prod_map.get(pid, {})
        doc = doc_map.get(pid, {})
        row["productos_count"] = int(prod.get("total") or 0)
        row["productos_aprobados"] = int(prod.get("aprobados") or 0)
        row["productos_nombres"] = prod.get("nombres") or []
        row["compras_count"] = int(doc.get("total") or 0)
        row["total_comprado"] = float(doc.get("importe") or 0)
        row["ultima_compra"] = doc.get("ultima") or ""
    return rows


def _cp_text(value, label, min_len=0, max_len=180, required=False):
    v = re.sub(r"\s+", " ", str(value or "")).strip()
    if required and not v:
        return None, f"{label} es obligatorio"
    if v and len(v) < min_len:
        return None, f"{label} debe tener al menos {min_len} caracteres"
    if len(v) > max_len:
        return None, f"{label} no puede exceder {max_len} caracteres"
    return v, None


def _cp_longtext(value, label, max_len=1000, required=False):
    v = str(value or "").strip()
    if required and not v:
        return None, f"{label} es obligatorio"
    if len(v) > max_len:
        return None, f"{label} no puede exceder {max_len} caracteres"
    return v, None


def _cp_phone(value):
    raw = str(value or "").strip()
    if not raw:
        return "", None
    digits = _cp_digits(raw, 10)
    if len(digits) < 7:
        return None, "El teléfono debe tener entre 7 y 10 dígitos"
    return digits, None


def _cp_rfc_value(value):
    raw = str(value or "").strip()
    if not raw:
        return "", None
    rfc = _cp_rfc(raw)
    if len(rfc) < 12 or not _CP_RFC_RE.match(rfc):
        return None, "El RFC no tiene un formato válido (12 o 13 caracteres)"
    return rfc, None


def _cp_catalog_area_for(me_id, role, requested):
    """Área dueña del registro. Solo calidad/administración pueden elegirla."""
    own = _cp_area(me_id)
    if role in ("admin", "super", "calidad"):
        area, err = _cp_text(requested or own, "El área", 2, 80, required=True)
        return area, err
    if not own:
        return None, "Tu cuenta no tiene un área asignada; pide a administración que la capture"
    return own, None


# ---------------------------------------------------------------------
# Inventario por área
# Regla: el área dueña administra sus artículos; las áreas involucradas
# pueden consultarlos. Administración y superadministración ven y editan todo.
# ---------------------------------------------------------------------
INV_AREA_SEP = "|"


def _inv_area_for(me_id, role, requested):
    own = _cp_area(me_id)
    if role in ("admin", "super"):
        return _cp_text(requested or own, "El área", 2, 80, required=True)
    if not own:
        return None, "Tu cuenta no tiene un área asignada; pide a administración que la capture"
    return own, None


def _inv_extra_list(value):
    if isinstance(value, (list, tuple)):
        raw = list(value)
    else:
        raw = str(value or "").split(INV_AREA_SEP)
    out = []
    for item in raw:
        v = re.sub(r"\s+", " ", str(item or "")).strip()
        if v and v not in out:
            out.append(v)
    return out


def _inv_extra_dump(value):
    vals = _inv_extra_list(value)
    return (INV_AREA_SEP + INV_AREA_SEP.join(vals) + INV_AREA_SEP) if vals else ""


def _inv_visible(row, me_id, role):
    if role in ("admin", "super"):
        return True
    area = _cp_area(me_id).strip()
    if not area:
        return False
    own = (row.get("area") or "").strip()
    return own == area or area in _inv_extra_list(row.get("areas_extra"))


def _inv_can_edit(row, me_id, role):
    if role in ("admin", "super"):
        return True
    area = _cp_area(me_id).strip()
    return bool(area) and (row.get("area") or "").strip() == area


def _inv_row(row):
    if not row:
        return row
    r = dict(row)
    r["areas_extra"] = _inv_extra_list(r.get("areas_extra"))
    r["cantidad"] = _cp_num(r.get("cantidad"), 0)
    r["minimo"] = _cp_num(r.get("minimo"), 0)
    r["costo_unitario"] = _cp_num(r.get("costo_unitario"), 0)
    r["agotado"] = r["cantidad"] <= 0
    r["bajo_stock"] = r["agotado"] or (r["minimo"] > 0 and r["cantidad"] <= r["minimo"])
    r["valor"] = round(r["cantidad"] * r["costo_unitario"], 2)
    return r


def _inv_date(value):
    v = str(value or "").strip()
    if not v:
        return "", None
    try:
        datetime.strptime(v, "%Y-%m-%d")
    except ValueError:
        return None, "La caducidad debe usar el formato AAAA-MM-DD"
    return v, None


def _cp_adjuntos(solicitud_id):
    rows = q_all(
        f"SELECT * FROM compras_adjuntos WHERE solicitud_id={PH} ORDER BY id DESC",
        (solicitud_id,))
    for r in rows:
        r["vigente"] = _cp_bool(r.get("vigente"))
    return rows


def _cp_firmado_vigente(solicitud_id, tipo):
    return any(a.get("tipo") == tipo and a.get("vigente")
               for a in _cp_adjuntos(solicitud_id))


# ---------- PDF digital generado por la app ----------
_CP_PDF_LOCK = threading.Lock()
_CP_PDF_TIPOS = {"requisicion": "requisicion_generada", "orden_compra": "orden_compra_generada"}


def _cp_web_dir():
    env = (os.getenv("SYLPACK_WEB") or "").strip()
    if env:
        p = Path(env)
        if (p / "compras-doc.html").is_file():
            return p
    # En desarrollo el backend vive en server/ y el frontend en ../src.
    for cand in (BASE.parent / "src", BASE / "src", Path(__file__).resolve().parent.parent / "src"):
        if (cand / "compras-doc.html").is_file():
            return cand
    return None


def _cp_browser_exe():
    if sys.platform != "win32":
        for name in ("google-chrome", "chromium", "chromium-browser", "msedge"):
            found = shutil.which(name)
            if found:
                return found
        return None
    pf = os.environ.get("PROGRAMFILES", r"C:\Program Files")
    pf86 = os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")
    local = os.environ.get("LOCALAPPDATA", str(Path.home()))
    candidates = [
        pf86 + r"\Microsoft\Edge\Application\msedge.exe",
        pf + r"\Microsoft\Edge\Application\msedge.exe",
        pf + r"\Google\Chrome\Application\chrome.exe",
        pf86 + r"\Google\Chrome\Application\chrome.exe",
        local + r"\Google\Chrome\Application\chrome.exe",
    ]
    for exe in candidates:
        if exe and Path(exe).is_file():
            return exe
    for name in ("msedge.exe", "chrome.exe"):
        found = shutil.which(name)
        if found:
            return found
    return None


def _cp_pdf_token_for(doc):
    """Token de servicio para que el navegador headless cargue el documento."""
    try:
        sid = doc.get("solicitud_id")
        row = q_one(
            f"""SELECT u.id, u.username, u.role FROM compras_solicitudes s
                JOIN users u ON u.id=s.user_id WHERE s.id={PH}""", (sid,))
        if not row:
            activo = True if USE_PG else 1
            row = q_one(
                f"SELECT id,username,role FROM users WHERE role='compras' AND active={PH} ORDER BY id LIMIT 1",
                (activo,))
        if not row:
            return ""
        return create_access_token(
            identity=str(row["id"]),
            additional_claims={"role": row["role"], "username": row["username"]})
    except Exception:
        return ""


def _cp_file_slug(value, limit=48):
    text = unicodedata.normalize("NFKD", str(value or ""))
    text = text.encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_")
    return text[:limit].strip("_")


def _cp_attachment_display_name(sol, doc, tipo):
    """Nombre visible uniforme: REQ/OC + emitida/firmada + versión.

    Independientemente del nombre que haya elegido la persona usuaria, el
    expediente guarda: "REQ-2026-0001 firmada.pdf", "OC-2026-0001 emitida.pdf",
    y si se vuelve a subir el mismo documento: "..._v2.pdf", "..._v3.pdf".
    """
    tipo = str(tipo or "")
    sid = int((doc or {}).get("solicitud_id") or (sol or {}).get("id") or 0)
    folio = (doc or {}).get("folio") or ""
    if not folio:
        if tipo.startswith("orden_compra"):
            found = _cp_orden_compra(sid) if sid else None
        elif tipo.startswith("requisicion"):
            found = _cp_requisicion(sid) if sid else None
        else:
            found = None
        folio = (found or {}).get("folio") or (sol or {}).get("folio") or f"SOL-{sid or 'DOC'}"
    if tipo.endswith("_generada"):
        accion = "emitida"
    elif tipo in ("firmado", "documento_firmado"):
        accion = "firmado"
    else:
        accion = "firmada"
    base = f"{folio} {accion}"
    usados = 0
    if sid:
        for row in q_all(f"SELECT nombre FROM compras_adjuntos WHERE solicitud_id={PH}", (sid,)):
            stem = Path(str((row or {}).get("nombre") or "")).stem
            if stem == base or stem.startswith(base + "_v"):
                usados += 1
    version = f"_v{usados + 1}" if usados else ""
    return f"{base}{version}.pdf"


def _cp_pdf_filename(doc):
    """Nombre descriptivo y versionado del PDF generado por el sistema."""
    return _cp_attachment_display_name(None, doc, _CP_PDF_TIPOS.get(doc.get("tipo"), ""))


def _cp_pdf_generate(did, keep=False):
    """Renderiza compras-doc.html?digital=1 y guarda el PDF en compras_adjuntos.

    Es un proceso best-effort: si no hay Edge/Chrome o falla el render, no se
    interrumpe la operación de compras (solo se registra en el log).
    """
    doc = q_one(f"SELECT * FROM compras_documentos WHERE id={PH}", (did,))
    if not doc:
        return None
    web = _cp_web_dir()
    browser = _cp_browser_exe()
    if not web or not browser:
        app.logger.info("PDF digital omitido para #%s: %s",
                        did, "sin frontend" if not web else "sin Edge/Chrome")
        return None
    token = _cp_pdf_token_for(doc)
    if not token:
        return None
    tipo = _CP_PDF_TIPOS.get(doc.get("tipo"))
    if not tipo:
        return None
    folio = re.sub(r"[^A-Za-z0-9._-]+", "_", (doc.get("folio") or f"doc-{did}"))[:80]
    nombre_pdf = _cp_pdf_filename(doc)
    safe = f"{tipo}_{did}_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}_{secrets.token_hex(3)}.pdf"
    out = UPLOAD_DIR / safe
    url = (web / "compras-doc.html").as_uri() + "?" + urlencode(
        {"id": str(did), "token": token, "digital": "1"})
    cmd = [
        browser, "--headless=new", "--disable-gpu", "--no-first-run",
        "--disable-extensions", "--allow-file-access-from-files",
        "--run-all-compositor-stages-before-draw",
        "--virtual-time-budget=15000", "--no-pdf-header-footer",
        f"--print-to-pdf={out}", url,
    ]
    try:
        with _CP_PDF_LOCK:
            subprocess.run(cmd, timeout=60, stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, check=False)
        if not out.is_file() or out.stat().st_size < 800:
            app.logger.warning("PDF digital vacío para #%s", did)
            try:
                out.unlink(missing_ok=True)
            except Exception:
                pass
            return None
        now = _cp_now()
        # Solo queda vigente la última versión generada de este tipo.
        q_exec(
            f"UPDATE compras_adjuntos SET vigente={PH} WHERE solicitud_id={PH} AND tipo={PH}",
            (False if USE_PG else 0, doc["solicitud_id"], tipo))
        q_exec(
            f"""INSERT INTO compras_adjuntos(solicitud_id,documento_id,path,nombre,tipo,
                subido_por,created_at,vigente)
                VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH})""",
            (doc["solicitud_id"], did, safe, nombre_pdf, tipo,
             "Sistema · PDF digital", now, True if USE_PG else 1))
        _cp_event(solicitud_id=doc["solicitud_id"], documento_id=did,
                  tipo="pdf_generado", por="Sistema",
                  nota=f"{nombre_pdf} guardado con enlaces, imágenes y variantes")
        return safe
    except Exception as e:
        app.logger.warning("No se pudo generar el PDF digital #%s: %s", did, e)
        return None


def _cp_pdf_autogen(did):
    """Lanza la generación del PDF digital sin bloquear la petición."""
    def _run():
        # El hilo no hereda el contexto de la petición y create_access_token
        # lo necesita para firmar el token con el que carga el documento.
        try:
            with app.app_context():
                _cp_pdf_generate(did)
        except Exception as e:
            app.logger.warning("PDF digital automático falló #%s: %s", did, e)
    threading.Thread(target=_run, daemon=True).start()


def _cp_requisicion(sid):
    return q_one(
        f"SELECT * FROM compras_documentos WHERE solicitud_id={PH} AND tipo='requisicion' ORDER BY id DESC LIMIT 1",
        (sid,))


def _cp_orden_compra(sid):
    return q_one(
        f"SELECT * FROM compras_documentos WHERE solicitud_id={PH} AND tipo='orden_compra' "
        f"AND estado!='cancelada' ORDER BY id DESC LIMIT 1",
        (sid,))


def _cp_opciones(item_id):
    return q_all(
        f"SELECT * FROM compras_item_opciones WHERE item_id={PH} ORDER BY orden,id",
        (item_id,))


def _cp_item_opciones_map(items):
    for it in items:
        opts = _cp_opciones(it["id"])
        for o in opts:
            o["calidad_aprobada"] = _cp_bool(o.get("calidad_aprobada"))
            o["precio_incluye_iva"] = _cp_bool(o.get("precio_incluye_iva"))
        it["opciones"] = opts
    return items


_CP_OC_FIRMAS = (
    ("orden_compra_firmada", "Firma del jefe de área"),
    ("orden_compra_firmada_calidad", "Firma de Calidad"),
    ("orden_compra_firmada_sandra", "Firma de Sandra Limones"),
    ("orden_compra_firmada_lucio", "Firma de Lucío Limones"),
)
_CP_OC_FINAL = "orden_compra_firmada_final"
_CP_OC_TIPOS = tuple(t for t, _ in _CP_OC_FIRMAS) + (_CP_OC_FINAL,)


def _cp_oc_tipos_requeridos(s):
    tipos = ["orden_compra_firmada"]
    if (s.get("tipo_compra") or "normal") == "calidad":
        tipos.append("orden_compra_firmada_calidad")
    tipos += ["orden_compra_firmada_sandra", "orden_compra_firmada_lucio"]
    return tipos


def _cp_oc_firma_label(tipo):
    if tipo == _CP_OC_FINAL:
        return "OC completa con todas las firmas"
    return dict(_CP_OC_FIRMAS).get(tipo, tipo)


def _cp_oc_firmas_completas(s):
    if not s:
        return False
    sid = int(s["id"])
    return all(_cp_firmado_vigente(sid, t) for t in _cp_oc_tipos_requeridos(s))


def _cp_oc_firmas_status(s):
    if not s:
        return []
    sid = int(s["id"])
    vigentes = {a.get("tipo"): a for a in _cp_adjuntos(sid) if a.get("vigente")}
    out = []
    for tipo in _cp_oc_tipos_requeridos(s):
        a = vigentes.get(tipo)
        out.append({
            "tipo": tipo,
            "label": _cp_oc_firma_label(tipo),
            "firmada": bool(a),
            "subido_por": (a or {}).get("subido_por") or "",
            "created_at": (a or {}).get("created_at") or "",
            "nombre": (a or {}).get("nombre") or "",
            "path": (a or {}).get("path") or "",
        })
    a = vigentes.get(_CP_OC_FINAL)
    out.append({
        "tipo": _CP_OC_FINAL,
        "label": _cp_oc_firma_label(_CP_OC_FINAL),
        "firmada": bool(a),
        "subido_por": (a or {}).get("subido_por") or "",
        "created_at": (a or {}).get("created_at") or "",
        "nombre": (a or {}).get("nombre") or "",
        "path": (a or {}).get("path") or "",
    })
    return out


def _cp_oc_tipo_siguiente(s):
    for tipo in _cp_oc_tipos_requeridos(s) + [_CP_OC_FINAL]:
        if not _cp_firmado_vigente(int(s["id"]), tipo):
            return tipo
    return _CP_OC_FINAL


def _cp_oc_firma_anterior_faltante(s, tipo):
    requeridos = _cp_oc_tipos_requeridos(s)
    if tipo in requeridos:
        previos = requeridos[:requeridos.index(tipo)]
    elif tipo == _CP_OC_FINAL:
        previos = requeridos
    else:
        previos = []
    for t in previos:
        if not _cp_firmado_vigente(int(s["id"]), t):
            return _cp_oc_firma_label(t)
    return ""


def _cp_invalidar_firmados(sid, tipos=None, por=""):
    tipos = set(tipos or (("requisicion_firmada",) + _CP_OC_TIPOS))
    vigentes = [a for a in _cp_adjuntos(sid)
                if a.get("vigente") and a.get("tipo") in tipos]
    for a in vigentes:
        q_exec(f"UPDATE compras_adjuntos SET vigente={PH} WHERE id={PH}",
               (False if USE_PG else 0, a["id"]))
    if vigentes:
        _cp_event(solicitud_id=sid, tipo="firmados_invalidados", por=por,
                  nota=f"{len(vigentes)} documento(s) firmado(s) invalidado(s) por cambios")


def _cp_reset_calidad(sid, por=""):
    rows = q_all(
        f"""SELECT o.id FROM compras_item_opciones o
            JOIN compras_items i ON i.id=o.item_id WHERE i.solicitud_id={PH}""", (sid,))
    for r in rows:
        q_exec(f"UPDATE compras_item_opciones SET calidad_aprobada={PH}, calidad_por='', calidad_at=NULL WHERE id={PH}",
               ((False if USE_PG else 0), r["id"]))
    if rows:
        _cp_event(solicitud_id=sid, tipo="calidad_reiniciada", por=por,
                  nota="Las opciones deberán revisarse de nuevo por Calidad")


def _cp_etapa_actual(s):
    estado = s.get("estado") or "pendiente"
    if estado in ("cerrada", "cancelada", "rechazada", "cambios_solicitados"):
        return estado
    tipo = s.get("tipo_compra") or "normal"
    req = _cp_requisicion(s["id"])
    if not req:
        return "requisicion"
    if (s.get("flujo") or "legado") == "nuevo" and not _cp_firmado_vigente(s["id"], "requisicion_firmada"):
        return "firma_requisicion"
    if tipo == "calidad" and s.get("calidad_estado") not in ("aprobada", "no_requiere"):
        return "calidad_" + (s.get("calidad_estado") or "pendiente")
    if estado in ("pendiente", "en_revision"):
        return "revision_compras"
    if estado in ("aprobada", "en_compra") and (s.get("cambios_oc_motivo") or "").strip():
        return "ajuste_oc"
    if estado in ("aprobada", "en_compra"):
        if (s.get("flujo") or "legado") == "nuevo" and _cp_orden_compra(s["id"]):
            if not _cp_firmado_vigente(s["id"], "orden_compra_firmada"):
                return "firma_orden"
            if (s.get("tipo_compra") or "normal") == "calidad" and not _cp_firmado_vigente(
                    s["id"], "orden_compra_firmada_calidad"):
                return "firma_orden_calidad"
            if not _cp_firmado_vigente(s["id"], "orden_compra_firmada_sandra"):
                return "firma_orden_sandra"
            if not _cp_firmado_vigente(s["id"], "orden_compra_firmada_lucio"):
                return "firma_orden_lucio"
            if not _cp_firmado_vigente(s["id"], _CP_OC_FINAL):
                return "firma_orden_final"
            return "recepcion"
        return "orden_compra"
    if estado in ("recibida", "con_incidencias", "devuelta"):
        return "recepcion"
    return estado


def _cp_puede_revisar_compras(s):
    if not s:
        return False, "No existe la solicitud"
    if (s.get("flujo") or "legado") == "nuevo" and not _cp_firmado_vigente(s["id"], "requisicion_firmada"):
        return False, "Falta que la persona solicitante suba la requisición firmada por la jefatura de su área"
    if (s.get("tipo_compra") or "normal") == "calidad" and s.get("calidad_estado") != "aprobada":
        return False, "La compra todavía no ha sido aprobada por Calidad"
    return True, ""


def _cp_propuesta_proveedor(d):
    d = d if isinstance(d, dict) else {}
    out = {}
    for f, lim in (("nombre", 180), ("rfc", 13), ("razon_social", 220),
                   ("domicilio", 400), ("contacto", 120), ("email", 140),
                   ("telefono", 10), ("condiciones_pago", 120)):
        out[f] = (d.get(f) or "").strip()[:lim]
    out["rfc"] = _cp_rfc(out.get("rfc"))
    out["email"] = out.get("email", "").lower()
    out["telefono"] = _cp_digits(out.get("telefono"), 10)
    return out


def _cp_item_payload(it, orden):
    it = it if isinstance(it, dict) else {}
    nombre = (it.get("nombre") or "").strip()[:180]
    if not nombre:
        return None
    opciones = []
    for oi, o in enumerate((it.get("opciones") or [])[:12]):
        o = o if isinstance(o, dict) else {}
        etiqueta = (o.get("etiqueta") or o.get("nombre") or "").strip()[:120]
        if not etiqueta and not (o.get("link") or o.get("diferencia")):
            continue
        if not etiqueta:
            etiqueta = f"Opción {oi + 1}"
        opciones.append({
            "etiqueta": etiqueta,
            "diferencia": (o.get("diferencia") or "").strip()[:800],
            "link": (o.get("link") or "").strip()[:800],
            "imagen": _cp_image_url(o.get("imagen")),
            "proveedor": (o.get("proveedor") or "").strip()[:180],
            "costo_unitario": max(0.0, _cp_num(o.get("costo_unitario"), 0)),
            "precio_incluye_iva": _cp_bool(o.get("precio_incluye_iva")),
            "orden": oi,
        })
    primera = opciones[0] if opciones else {}
    return {
        "nombre": nombre,
        "descripcion": (it.get("descripcion") or "").strip()[:1000],
        "motivo": (it.get("motivo") or it.get("para_que") or "").strip()[:1000],
        "requisitos_calidad": (it.get("requisitos_calidad") or "").strip()[:1000],
        "id_fabricacion": (it.get("id_fabricacion") or "").strip()[:120],
        "cantidad": max(0.0001, _cp_num(it.get("cantidad"), 1)),
        "unidad": (it.get("unidad") or "pza").strip()[:20] or "pza",
        "link": (it.get("link") or primera.get("link") or "").strip()[:800],
        "imagen": _cp_image_url(it.get("imagen") or primera.get("imagen") or ""),
        "proveedor": (it.get("proveedor") or primera.get("proveedor") or "").strip()[:180],
        "costo_unitario": max(0.0, _cp_num(it.get("costo_unitario"), primera.get("costo_unitario") or 0)),
        "precio_incluye_iva": _cp_bool(it.get("precio_incluye_iva") if "precio_incluye_iva" in it else primera.get("precio_incluye_iva")),
        "orden": orden,
        "opciones": opciones,
    }


def _cp_producto_certificado(nombre, area=""):
    """True si el producto está aprobado y pertenece al área de la solicitud."""
    nombre = (nombre or "").strip()
    if not nombre:
        return False
    area = (area or "").strip()
    row = q_one(
        f"""SELECT id FROM compras_productos_certificados
            WHERE activo={PH} AND calidad_estado={PH}
              AND LOWER(TRIM(nombre))=LOWER(TRIM({PH}))
              AND COALESCE(area,'')={PH} LIMIT 1""",
        (True if USE_PG else 1, "aprobado", nombre, area))
    return bool(row)


def _cp_catalog_autosave_item(area, it, username="", requiere_calidad=False):
    """Guarda en el catálogo del área el producto capturado en una solicitud.

    Si la compra NO pidió revisión de Calidad, el producto queda aprobado y
    disponible de inmediato. Solo las compras con revisión de Calidad dejan el
    producto pendiente. Nunca cambia el estado de un registro existente.
    """
    area = (area or "").strip()
    nombre = (it or {}).get("nombre") or ""
    if not area or not nombre.strip():
        return None
    now = _cp_now()
    row = q_one(
        f"""SELECT * FROM compras_productos_certificados
            WHERE LOWER(TRIM(nombre))=LOWER(TRIM({PH})) AND COALESCE(area,'')={PH}
            LIMIT 1""", (nombre, area))
    if row:
        sets, params = [], []
        for field in ("descripcion", "unidad", "id_fabricacion", "requisitos_calidad", "link", "imagen"):
            new = str((it or {}).get(field) or "").strip()
            if new and not str(row.get(field) or "").strip():
                sets.append(f"{field}={PH}")
                params.append(new)
        if not row.get("proveedor_id") and (it or {}).get("proveedor"):
            prov = q_one(
                f"""SELECT id FROM proveedores
                    WHERE LOWER(TRIM(nombre))=LOWER(TRIM({PH})) AND COALESCE(area,'')={PH}
                    LIMIT 1""", ((it or {}).get("proveedor"), area))
            if prov:
                sets.append(f"proveedor_id={PH}")
                params.append(prov["id"])
        if sets:
            sets += [f"updated_by={PH}", f"updated_at={PH}"]
            params += [username, now]
            q_exec(
                f"UPDATE compras_productos_certificados SET {', '.join(sets)} WHERE id={PH}",
                tuple(params) + (row["id"],))
        return row["id"]
    proveedor_id = None
    if (it or {}).get("proveedor"):
        prov = q_one(
            f"""SELECT id FROM proveedores
                WHERE LOWER(TRIM(nombre))=LOWER(TRIM({PH})) AND COALESCE(area,'')={PH}
                LIMIT 1""", ((it or {}).get("proveedor"), area))
        proveedor_id = prov["id"] if prov else None
    estado = "pendiente" if requiere_calidad else "aprobado"
    # Los productos normales quedan aprobados sin registrar una revisión de
    # Calidad que en realidad no ocurrió.
    calidad_por = ""
    calidad_at = None
    return q_exec(
        f"""INSERT INTO compras_productos_certificados(nombre,descripcion,categoria,unidad,
            id_fabricacion,requisitos_calidad,link,imagen,proveedor_id,area,calidad_estado,
            calidad_por,calidad_at,calidad_nota,activo,created_by,updated_by,created_at,updated_at)
            VALUES({PH},{PH},'',{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},'',{PH},{PH},{PH},{PH},{PH})"""
        + (" RETURNING id" if USE_PG else ""),
        (nombre, (it or {}).get("descripcion") or "", (it or {}).get("unidad") or "pza",
         (it or {}).get("id_fabricacion") or "", (it or {}).get("requisitos_calidad") or "",
         (it or {}).get("link") or "", (it or {}).get("imagen") or "",
         proveedor_id, area, estado, calidad_por, calidad_at,
         True if USE_PG else 1, username, username, now, now),
        returning_id=True)


def _cp_reemplazar_items(sid, items_in, username=""):
    old = q_all(f"SELECT id FROM compras_items WHERE solicitud_id={PH}", (sid,))
    for r in old:
        q_exec(f"DELETE FROM compras_item_opciones WHERE item_id={PH}", (r["id"],))
    q_exec(f"DELETE FROM compras_items WHERE solicitud_id={PH}", (sid,))
    sol = q_one(f"SELECT area,tipo_compra FROM compras_solicitudes WHERE id={PH}", (sid,)) or {}
    sol_area = (sol.get("area") or "")
    requiere_calidad = (sol.get("tipo_compra") or "normal") == "calidad"
    now = _cp_now()
    saved = []
    for orden, raw in enumerate((items_in or [])[:40]):
        it = _cp_item_payload(raw, orden)
        if not it:
            continue
        it["certificado"] = _cp_producto_certificado(it["nombre"], sol_area)
        iid = q_exec(
            f"""INSERT INTO compras_items(solicitud_id,nombre,descripcion,motivo,requisitos_calidad,
                id_fabricacion,cantidad,unidad,link,imagen,proveedor,costo_unitario,
                precio_incluye_iva,orden,certificado,created_at)
                VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH})"""
            + (" RETURNING id" if USE_PG else ""),
            (sid, it["nombre"], it["descripcion"], it["motivo"], it["requisitos_calidad"],
             it["id_fabricacion"], it["cantidad"], it["unidad"], it["link"], it["imagen"],
             it["proveedor"], it["costo_unitario"], it["precio_incluye_iva"], it["orden"],
             it["certificado"], now),
            returning_id=True)
        for o in it["opciones"]:
            q_exec(
                f"""INSERT INTO compras_item_opciones(item_id,etiqueta,diferencia,link,imagen,
                    proveedor,costo_unitario,precio_incluye_iva,orden,created_at)
                    VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH})""",
                (iid, o["etiqueta"], o["diferencia"], o["link"], o["imagen"], o["proveedor"],
                 o["costo_unitario"], o["precio_incluye_iva"], o["orden"], now))
        _cp_catalog_autosave_item(sol_area, it, username, requiere_calidad)
        it["id"] = iid
        saved.append(it)
    return saved


def _cp_sync_requisicion(sid, s, items, username):
    """Crea o actualiza la requisición del flujo nuevo, sin exigir datos fiscales."""
    req = _cp_requisicion(sid)
    emp = _cp_empresa() or {}
    propuesta = _cp_propuesta_proveedor(_cp_parse(s.get("proveedor_propuesto")))
    subtotal, _dp, iva_pct, _iva, total, _modo = _cp_doc_totals(items, 0)
    now = _cp_now()
    fields = {
        "tipo_compra": s.get("tipo_compra") or "normal",
        "jefe_area": s.get("jefe_area") or "",
        "calidad_por": s.get("calidad_por") or "",
        "total": total,
        "subtotal": subtotal,
        "iva_pct": iva_pct,
        "fecha": _cp_today(),
        "entregar_a": username,
        "elaborado_por": username,
        "empresa_snapshot": _cp_dump(emp),
        "proveedor_snapshot": _cp_dump(propuesta),
        "updated_at": now,
    }
    if req:
        sets = ", ".join(f"{k}={PH}" for k in fields)
        q_exec(f"UPDATE compras_documentos SET {sets} WHERE id={PH}",
               tuple(fields.values()) + (req["id"],))
        did = req["id"]
        q_exec(f"DELETE FROM compras_documento_items WHERE documento_id={PH}", (did,))
    else:
        did = q_exec(
            f"""INSERT INTO compras_documentos(folio,tipo,tipo_compra,solicitud_id,estado,
                jefe_area,calidad_por,fecha,moneda,subtotal,descuento_pct,iva_pct,total,
                condiciones,notas,almacen,entregar_a,elaborado_por,empresa_snapshot,
                proveedor_snapshot,created_at,updated_at)
                VALUES('', 'requisicion',{PH},{PH},'emitida',{PH},{PH},{PH},'MXN',{PH},0,{PH},{PH},
                '','','','',{PH},{PH},{PH},{PH},{PH})"""
            + (" RETURNING id" if USE_PG else ""),
            (s.get("tipo_compra") or "normal", sid, s.get("jefe_area") or "",
             s.get("calidad_por") or "", fields["fecha"], subtotal, iva_pct, total,
             username, fields["empresa_snapshot"], fields["proveedor_snapshot"], now, now),
            returning_id=True)
        folio = f"REQ-{datetime.now(TZ).year}-{int(did):04d}"
        q_exec(f"UPDATE compras_documentos SET folio={PH} WHERE id={PH}", (folio, did))
        _cp_event(solicitud_id=sid, documento_id=did, tipo="requisicion_creada",
                  despues="emitida", por=username, nota=f"{folio} generada automáticamente")
    for idx, it in enumerate(items):
        precio = _cp_num(it["costo_unitario"])
        importe = round(_cp_num(it["cantidad"]) * precio, 2)
        q_exec(
            f"""INSERT INTO compras_documento_items(documento_id,item_id,nombre,descripcion,
                id_fabricacion,cantidad,unidad,costo_unitario,descuento_pct,importe,
                precio_incluye_iva,created_at)
                VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},0,{PH},{PH},{PH})""",
            (did, it["id"], it["nombre"], it["descripcion"], it["id_fabricacion"],
             it["cantidad"], it["unidad"], precio, importe,
             it["precio_incluye_iva"], now))
    _cp_pdf_autogen(did)
    return _cp_doc_full(did)


def _cp_now():
    return datetime.now(timezone.utc).isoformat()


def _cp_claim_gestor(sid, username):
    """Asigna la solicitud al primer gestor que actúa y bloquea a los demás."""
    s = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (sid,))
    if not s:
        return None, "No existe la solicitud"
    actual = (s.get("gestor_por") or "").strip()
    if actual and actual != username:
        return None, f"Esta solicitud ya está siendo atendida por {actual}"
    if not actual:
        now = _cp_now()
        q_exec(
            f"""UPDATE compras_solicitudes SET gestor_por={PH},
                gestor_at=COALESCE(gestor_at,{PH}) WHERE id={PH}
                AND (gestor_por IS NULL OR gestor_por='')""",
            (username, now, sid))
        s = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (sid,))
        actual = (s.get("gestor_por") or "").strip() if s else ""
        if actual != username:
            return None, f"Esta solicitud ya está siendo atendida por {actual or 'otro gestor'}"
    return s, ""


def _cp_today():
    # La fecha oficial de la compra debe ser la del usuario (Ciudad de México),
    # no la del servidor en UTC: evita que después de las 18:00 se registre el
    # día siguiente en requisiciones y órdenes.
    return datetime.now(TZ).strftime("%Y-%m-%d")


def _cp_fecha_iso(valor):
    v = str(valor or "").strip()[:10]
    if not v:
        return ""
    try:
        datetime.strptime(v, "%Y-%m-%d")
        return v
    except ValueError:
        return None


def _cp_parse(txt):
    try:
        return json.loads(txt or "{}")
    except Exception:
        return {}


def _cp_dump(obj):
    try:
        return json.dumps(obj or {}, ensure_ascii=False, default=str)
    except Exception:
        return "{}"


def _cp_event(solicitud_id=None, documento_id=None, tipo="", antes="", despues="", por="", nota="", area="", areas_extra=""):
    try:
        q_exec(
            f"INSERT INTO compras_eventos(solicitud_id,documento_id,tipo,estado_anterior,estado_nuevo,por,area,areas_extra,nota,created_at)"
            f" VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH})",
            (solicitud_id, documento_id, tipo, antes, despues, por, area or "",
             _inv_extra_dump(areas_extra), (nota or "")[:1200], _cp_now()))
    except Exception:
        pass


def _cp_notify(payload):
    try:
        to = payload.get("to")
        if isinstance(to, list) and payload.get("solicitud_id"):
            owner = q_one(
                f"""SELECT u.username FROM compras_solicitudes s
                    JOIN users u ON u.id=s.user_id WHERE s.id={PH}""",
                (payload["solicitud_id"],))
            destinos = []
            for destino in to:
                if destino == "solicitante":
                    if owner and owner.get("username"):
                        destinos.append(owner["username"])
                elif destino == "admin":
                    destinos.extend(["admin", "super"])
                else:
                    destinos.append(destino)
            payload["to"] = list(dict.fromkeys(destinos))
        socketio.emit("compras_update", payload)
    except Exception:
        pass


def _cp_auto_user():
    """Cuenta que firma los mensajes automáticos de Compras (Sandra)."""
    activo = True if USE_PG else 1
    row = q_one(
        f"SELECT id,username FROM users WHERE LOWER(username)='sandra' AND active={PH} LIMIT 1",
        (activo,))
    if row:
        return row
    return q_one(
        f"SELECT id,username FROM users WHERE role='compras' AND active={PH} ORDER BY id LIMIT 1",
        (activo,))


def _cp_auto_message(sid, folio, texto, para="solicitante", notificar=True):
    """Inserta un mensaje automático de Sandra y avisa en vivo a la conversación."""
    autor = _cp_auto_user()
    if not autor:
        return None
    now = _cp_now()
    mid = q_exec(
        f"INSERT INTO compras_mensajes(solicitud_id,user_id,mensaje,created_at) VALUES({PH},{PH},{PH},{PH})"
        + (" RETURNING id" if USE_PG else ""),
        (sid, autor["id"], (texto or "")[:1000], now), returning_id=True)
    if notificar:
        _cp_notify({"tipo": "mensaje", "solicitud_id": sid, "id": mid, "folio": folio,
                    "de": autor["username"], "role": "compras", "mensaje": (texto or "")[:180],
                    "created_at": now, "to": [para], "auto": True})
    return mid


def _cp_empresa():
    return q_one("SELECT * FROM compras_empresa WHERE id=1") or {
        "nombre": "Sylpack Alimentos", "rfc": "", "razon_social": "",
        "domicilio": "", "telefono": "", "email": "", "logo": "assets/logo-sylpack.png"}


def _cp_proveedor(pid):
    if not pid:
        return None
    return q_one(f"SELECT * FROM proveedores WHERE id={PH}", (pid,))


def _cp_items(sid):
    rows = q_all(f"SELECT * FROM compras_items WHERE solicitud_id={PH} ORDER BY orden,id", (sid,))
    for r in rows:
        r["importe"] = round(_cp_num(r.get("cantidad")) * _cp_num(r.get("costo_unitario")), 2)
    return _cp_item_opciones_map(rows)


def _cp_prov_nombre(row):
    """Nombre visible del proveedor; en compras en línea viene del snapshot."""
    if row and not (row.get("proveedor_nombre") or "").strip():
        snap = _cp_parse(row.get("proveedor_snapshot"))
        row["proveedor_nombre"] = (snap.get("nombre") or "").strip()
    return row


def _cp_docs_solicitud(sid):
    rows = q_all(
        f"""SELECT d.*, COALESCE(p.nombre,'') AS proveedor_nombre
            FROM compras_documentos d LEFT JOIN proveedores p ON p.id=d.proveedor_id
            WHERE d.solicitud_id={PH} AND d.estado!='cancelada' ORDER BY d.id""", (sid,))
    return [_cp_prov_nombre(r) for r in rows]


def _cp_full_solicitud(sid):
    s = q_one(
        f"""SELECT s.*, COALESCE(u.username,'(cuenta eliminada)') AS username,
                   COALESCE(u.area,'') AS user_area, COALESCE(u.role,'user') AS user_role
            FROM compras_solicitudes s LEFT JOIN users u ON u.id=s.user_id
            WHERE s.id={PH}""", (sid,))
    if not s:
        return None
    s["items"] = _cp_items(sid)
    s["proveedor_propuesto"] = _cp_propuesta_proveedor(_cp_parse(s.get("proveedor_propuesto")))
    s["total_estimado"] = round(sum(_cp_num(i.get("importe")) for i in s["items"]), 2)
    s["documentos"] = _cp_docs_solicitud(sid)
    s["eventos"] = q_all(
        f"SELECT * FROM compras_eventos WHERE solicitud_id={PH} ORDER BY id DESC", (sid,))
    s["recepciones"] = q_all(
        f"SELECT * FROM compras_recepciones WHERE solicitud_id={PH} ORDER BY id DESC", (sid,))
    for r in s["recepciones"]:
        r["items"] = q_all(
            f"SELECT ri.*, di.nombre AS item_nombre, di.unidad AS item_unidad "
            f"FROM compras_recepcion_items ri "
            f"LEFT JOIN compras_documento_items di ON di.id=ri.item_id "
            f"WHERE ri.recepcion_id={PH} ORDER BY ri.id", (r["id"],))
    s["devoluciones"] = q_all(
        f"SELECT * FROM compras_devoluciones WHERE solicitud_id={PH} ORDER BY id DESC", (sid,))
    for dv in s["devoluciones"]:
        dv["items"] = q_all(
            f"SELECT dvi.*, di.nombre AS item_nombre, di.unidad AS item_unidad "
            f"FROM compras_devolucion_items dvi "
            f"LEFT JOIN compras_documento_items di ON di.id=dvi.item_id "
            f"WHERE dvi.devolucion_id={PH} ORDER BY dvi.id", (dv["id"],))
    s["firmados"] = _cp_adjuntos(sid)
    s["requisicion_firmada"] = _cp_firmado_vigente(sid, "requisicion_firmada")
    for tipo in _CP_OC_TIPOS:
        s[tipo] = _cp_firmado_vigente(sid, tipo)
    s["firmas_oc"] = _cp_oc_firmas_status(s)
    s["firmas_oc_completas"] = _cp_oc_firmas_completas(s)
    s["etapa_actual"] = _cp_etapa_actual(s)
    s["requisicion"] = _cp_requisicion(sid)
    s["orden_compra"] = _cp_orden_compra(sid)
    return s


def _cp_doc_full(did):
    d = q_one(
        f"""SELECT d.*, COALESCE(p.nombre,'') AS proveedor_nombre,
                   COALESCE(p.rfc,'') AS proveedor_rfc,
                   COALESCE(p.razon_social,'') AS proveedor_razon,
                   COALESCE(p.domicilio,'') AS proveedor_domicilio,
                   COALESCE(p.contacto,'') AS proveedor_contacto,
                   COALESCE(p.email,'') AS proveedor_email,
                   COALESCE(p.telefono,'') AS proveedor_telefono,
                   COALESCE(p.condiciones_pago,'') AS proveedor_condiciones
            FROM compras_documentos d LEFT JOIN proveedores p ON p.id=d.proveedor_id
            WHERE d.id={PH}""", (did,))
    if not d:
        return None
    d["items"] = q_all(
        f"SELECT * FROM compras_documento_items WHERE documento_id={PH} ORDER BY id", (did,))
    d["solicitud"] = q_one(
        f"""SELECT s.*, COALESCE(u.username,'(cuenta eliminada)') AS username,
                   COALESCE(u.area,'') AS user_area
            FROM compras_solicitudes s LEFT JOIN users u ON u.id=s.user_id WHERE s.id={PH}""",
        (d["solicitud_id"],))
    if d["solicitud"]:
        s = d["solicitud"]
        s["items"] = _cp_items(d["solicitud_id"])
        s["requisicion_firmada"] = _cp_firmado_vigente(d["solicitud_id"], "requisicion_firmada")
        for tipo in _CP_OC_TIPOS:
            s[tipo] = _cp_firmado_vigente(d["solicitud_id"], tipo)
        s["firmas_oc"] = _cp_oc_firmas_status(s)
        s["firmas_oc_completas"] = _cp_oc_firmas_completas(s)
        s["etapa_actual"] = _cp_etapa_actual(s)
        s["documentos"] = _cp_docs_solicitud(d["solicitud_id"])
    _cp_prov_nombre(d)
    d["empresa"] = _cp_empresa()
    d["empresa_snapshot"] = _cp_parse(d.get("empresa_snapshot"))
    d["proveedor_snapshot"] = _cp_parse(d.get("proveedor_snapshot"))
    d["eventos"] = q_all(
        f"SELECT * FROM compras_eventos WHERE documento_id={PH} ORDER BY id DESC", (did,))
    d["recepciones"] = q_all(
        f"SELECT * FROM compras_recepciones WHERE documento_id={PH} ORDER BY id DESC", (did,))
    for r in d["recepciones"]:
        r["items"] = q_all(
            f"SELECT ri.*, di.nombre AS item_nombre FROM compras_recepcion_items ri "
            f"LEFT JOIN compras_documento_items di ON di.id=ri.item_id "
            f"WHERE ri.recepcion_id={PH} ORDER BY ri.id", (r["id"],))
    d["devoluciones"] = q_all(
        f"SELECT * FROM compras_devoluciones WHERE documento_id={PH} ORDER BY id DESC", (did,))
    for dv in d["devoluciones"]:
        dv["items"] = q_all(
            f"SELECT dvi.*, di.nombre AS item_nombre FROM compras_devolucion_items dvi "
            f"LEFT JOIN compras_documento_items di ON di.id=dvi.item_id "
            f"WHERE dvi.devolucion_id={PH} ORDER BY dvi.id", (dv["id"],))
    d["firmados"] = _cp_adjuntos(d["solicitud_id"])
    _cp_doc_totals_info(d)
    return d


def _cp_quality_involved(s, me):
    if not s or s.get("tipo_compra") != "calidad":
        return False
    if int(s.get("user_id") or 0) == int(me):
        return True
    asignado = (s.get("calidad_por") or "").strip()
    if not asignado:
        return True
    u = q_one(f"SELECT username FROM users WHERE id={PH}", (me,))
    return bool(u and asignado == (u.get("username") or ""))


def _cp_user_can_view_solicitud(s, me, role):
    if not s:
        return False
    if _cp_can_quality(role):
        return int(s.get("user_id") or 0) == int(me) or _cp_quality_involved(s, me)
    return _cp_can_view(role) or int(s.get("user_id") or 0) == int(me)


def _cp_user_can_view_doc(d, me, role):
    if not d:
        return False
    s = d.get("solicitud") or {}
    if _cp_can_quality(role):
        return int(s.get("user_id") or 0) == int(me) or _cp_quality_involved(s, me)
    return _cp_can_view(role) or int(s.get("user_id") or 0) == int(me)


def _cp_user_can_sign(s, me, role):
    """Compatibilidad: el gestor puede subir cualquier firmado de la compra."""
    return bool(s) and _cp_can_manage(role)


def _cp_user_can_upload(s, me, role, tipo):
    if not s:
        return False
    flujo = s.get("flujo") or "legado"
    owner = int(s.get("user_id") or 0) == int(me)
    if flujo != "nuevo":
        return False
    if tipo == "requisicion_firmada":
        return owner
    if tipo == "orden_compra_firmada":
        return owner
    if tipo == "orden_compra_firmada_calidad":
        return _cp_can_manage(role) or (_cp_can_quality(role) and _cp_quality_involved(s, me))
    if tipo in ("orden_compra_firmada_sandra", "orden_compra_firmada_lucio", _CP_OC_FINAL):
        return _cp_can_manage(role)
    return False


_CP_IVA_FACTOR = 1.16


def _cp_doc_totals(items, desc_pct=0.0):
    """Totales respetando si el precio capturado ya incluye IVA.

    - Todas las partidas con IVA incluido: se conserva el precio bruto, se
      guarda iva_pct=0 y el documento no agrega una línea de IVA.
    - Todas sin IVA incluido: comportamiento normal (subtotal + 16%).
    - Mezcla: solo se agrega IVA a las partidas que no lo incluyen.

    Devuelve (subtotal, descuento_pct, iva_pct, iva, total, modo).
    """
    rows = [it for it in (items or []) if isinstance(it, dict)]
    desc_pct = max(0.0, min(100.0, _cp_num(desc_pct)))
    subtotal = 0.0
    iva_bruto = 0.0
    incluidas = 0
    for it in rows:
        cant = max(0.0, _cp_num(it.get("cantidad"), 1))
        precio = max(0.0, _cp_num(it.get("costo_unitario")))
        dp = max(0.0, min(100.0, _cp_num(it.get("descuento_pct"))))
        importe = round(cant * precio * (1 - dp / 100.0), 2)
        subtotal += importe
        if _cp_bool(it.get("precio_incluye_iva")):
            incluidas += 1
            iva_bruto += importe - importe / _CP_IVA_FACTOR
        else:
            iva_bruto += importe * 0.16
    subtotal = round(subtotal, 2)
    todas_incluyen = bool(rows) and incluidas == len(rows)
    modo = "incluido" if todas_incluyen else ("neto" if incluidas == 0 else "mixto")
    iva_pct = 0.0 if todas_incluyen else 16.0
    desc = round(subtotal * desc_pct / 100.0, 2)
    iva = round(iva_bruto * (1 - desc_pct / 100.0), 2) if iva_pct else 0.0
    total = round(subtotal - desc + iva, 2)
    return subtotal, desc_pct, iva_pct, iva, total, modo


def _cp_doc_totals_info(d):
    """Expone al frontend el IVA efectivo y el modo usado en el documento."""
    items = d.get("items") or []
    incluidas = sum(1 for it in items if _cp_bool(it.get("precio_incluye_iva")))
    if items and incluidas == len(items):
        d["iva_modo"] = "incluido"
    elif incluidas:
        d["iva_modo"] = "mixto"
    else:
        d["iva_modo"] = "neto"
    subtotal = _cp_num(d.get("subtotal"))
    dp = _cp_num(d.get("descuento_pct"))
    base = round(subtotal - subtotal * dp / 100.0, 2)
    total = _cp_num(d.get("total"))
    d["base_gravable"] = base
    # Si el documento no cobra IVA extra, la diferencia debe ser cero aunque
    # existan redondeos de centavos.
    d["iva_monto"] = round(max(0.0, total - base), 2) if total else 0.0
    return d


def _cp_calc(subtotal, desc_pct, iva_pct):
    subtotal = round(_cp_num(subtotal), 2)
    desc_pct = max(0.0, min(100.0, _cp_num(desc_pct)))
    iva_pct = max(0.0, min(100.0, _cp_num(iva_pct, 16)))
    desc = round(subtotal * desc_pct / 100.0, 2)
    base = round(subtotal - desc, 2)
    iva = round(base * iva_pct / 100.0, 2)
    return subtotal, desc, iva, round(base + iva, 2)


def _cp_log(me, role, accion, detalle):
    _audit(me, role, accion, detalle)


def _cp_empresa_public():
    e = _cp_empresa()
    for k in ("updated_at",):
        if e.get(k) is not None and not isinstance(e.get(k), str):
            e[k] = str(e[k])
    return e


# ---------- vista previa de enlaces de producto ----------
# Se obtiene la imagen social (OpenGraph/Twitter/JSON-LD) de cualquier página
# pública. La imagen se sirve mediante un proxy autenticado para evitar
# bloqueos por referrer y para que no se expongan recursos internos de la LAN.
_CP_PREVIEW_TTL = 900
_CP_PREVIEW_CACHE = {}
_CP_PREVIEW_LOCK = threading.Lock()
_CP_HTML_MAX = 2 * 1024 * 1024
_CP_IMG_MAX = 8 * 1024 * 1024
_CP_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
          "(KHTML, like Gecko) Chrome/124.0 Safari/537.36 SylpackTickets/1.0")


def _cp_is_gif_url(value):
    try:
        return (urlparse(str(value or "").strip()).path or "").lower().endswith(".gif")
    except Exception:
        return False


def _cp_is_gif_bytes(data):
    return (data or b"")[:6] in (b"GIF87a", b"GIF89a")


def _cp_still_proxy(value):
    """URL interna que sirve un GIF como imagen fija (primer cuadro)."""
    return "/api/compras/imagen?url=" + quote(str(value or "").strip(), safe="")


def _cp_still_image(data, ctype):
    """Convierte un GIF animado a PNG con su primer cuadro."""
    if ctype != "image/gif" and not _cp_is_gif_bytes(data):
        return data, ctype
    try:
        from PIL import Image
        import io as _io
        im = Image.open(_io.BytesIO(data))
        im.seek(0)
        im = im.convert("RGBA") if im.mode in ("RGBA", "LA", "P") else im.convert("RGB")
        out = _io.BytesIO()
        im.save(out, format="PNG", optimize=True)
        return out.getvalue(), "image/png"
    except Exception:
        raise ValueError("No se pudo convertir la imagen animada")


class _CPNoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _cp_public_host(host):
    host = (host or "").strip().lower()
    if not host or host in ("localhost", "localhost.localdomain") or host.endswith(".local"):
        return False
    try:
        infos = socket.getaddrinfo(host, None)
    except Exception:
        return False
    if not infos:
        return False
    for info in infos:
        try:
            ip = ipaddress.ip_address(info[4][0])
        except Exception:
            return False
        if (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved
                or ip.is_multicast or ip.is_unspecified):
            return False
    return True


def _cp_safe_remote(url):
    try:
        p = urlparse(str(url or "").strip())
    except Exception:
        return None
    if p.scheme not in ("http", "https") or not p.hostname:
        return None
    if not _cp_public_host(p.hostname):
        return None
    return p


def _cp_remote_open(url, accept_prefix, max_bytes, ua=None, referer=None):
    current = str(url or "").strip()
    opener = build_opener(_CPNoRedirect)
    for _ in range(5):
        parsed = _cp_safe_remote(current)
        if not parsed:
            raise ValueError("Ese enlace no es una dirección pública válida")
        ref = referer
        if not ref and accept_prefix.startswith("image/"):
            # Muchos CDN exigen un referer de la tienda para no bloquear la imagen.
            ref = f"{parsed.scheme}://{parsed.hostname}/"
        headers = {
            "User-Agent": ua or _CP_UA,
            "Accept": accept_prefix + ",*/*;q=0.8",
            "Accept-Language": "es-MX,es;q=0.9,en;q=0.7",
        }
        if ref and _cp_safe_remote(ref):
            headers["Referer"] = ref
        req = URLRequest(current, headers=headers)
        try:
            resp = opener.open(req, timeout=8)
        except HTTPError as e:
            if e.code in (301, 302, 303, 307, 308):
                loc = e.headers.get("Location") if e.headers else ""
                if not loc:
                    raise ValueError("El enlace redirige sin destino")
                current = urljoin(current, loc)
                continue
            raise ValueError("La página no permitió leer el producto")
        except (URLError, TimeoutError, OSError):
            raise ValueError("No se pudo abrir el enlace del producto")
        try:
            final = resp.geturl() or current
            if not _cp_safe_remote(final):
                raise ValueError("El enlace redirige a una dirección no permitida")
            ctype = (resp.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            if accept_prefix and not ctype.startswith(accept_prefix):
                raise ValueError("El enlace no devolvió una imagen válida")
            data = resp.read(max_bytes + 1)
        finally:
            try: resp.close()
            except Exception: pass
        if len(data) > max_bytes:
            raise ValueError("El contenido del enlace es demasiado grande")
        return data, ctype, final
    raise ValueError("El enlace tiene demasiadas redirecciones")


def _cp_html_meta(html):
    metas, links = {}, {}
    for tag in re.findall(r"<meta\b[^>]*>", html, re.I | re.S):
        attrs = {k.lower(): html_unescape(v) for k, v in
                 re.findall(r"([\w:.-]+)\s*=\s*[\"']([^\"']*)[\"']", tag)}
        key = (attrs.get("property") or attrs.get("name") or attrs.get("itemprop") or "").strip().lower()
        val = (attrs.get("content") or "").strip()
        if key and val and key not in metas:
            metas[key] = val
    for tag in re.findall(r"<link\b[^>]*>", html, re.I | re.S):
        attrs = {k.lower(): html_unescape(v) for k, v in
                 re.findall(r"([\w:.-]+)\s*=\s*[\"']([^\"']*)[\"']", tag)}
        rel = (attrs.get("rel") or "").strip().lower()
        href = (attrs.get("href") or "").strip()
        if rel and href and rel not in links:
            links[rel] = href
    title = ""
    m = re.search(r"<title[^>]*>(.*?)</title>", html, re.I | re.S)
    if m:
        title = re.sub(r"\s+", " ", html_unescape(m.group(1))).strip()
    return metas, links, title


_CP_UAS = (
    _CP_UA,
    ("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) "
     "Gecko/20100101 Firefox/125.0"),
    ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
     "(KHTML, like Gecko) Version/17.4 Safari/605.1.15"),
    ("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
     "(KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"),
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
)
_CP_BAD_IMG = ("logo", "favicon", "sprite", "icon", "placeholder", "blank", "transparent",
               "pixel", "loading", "banner")


def _cp_extra_images(html):
    """Imágenes que muchas tiendas esconden en atributos/JSON (Amazon, ML...)."""
    out = []
    for regex in (
        r'data-old-hires\s*=\s*["\']([^"\']+)["\']',
        r'"hiRes"\s*:\s*"([^"\\]+)"',
        r'"large"\s*:\s*"([^"\\]+)"',
        r'"imageUrl"\s*:\s*"([^"\\]+)"',
        r'"image_url"\s*:\s*"([^"\\]+)"',
        r'"thumbnail"\s*:\s*"([^"\\]+)"',
        r'"url"\s*:\s*"([^"\\]+\.(?:jpg|jpeg|png|webp)[^"\\]*)"',
        r'"image"\s*:\s*"([^"\\]+)"',
    ):
        out.extend(re.findall(regex, html, re.I))
    # data-a-dynamic-image='{"https://...jpg":[640,640]}'
    for blob in re.findall(r'data-a-dynamic-image\s*=\s*["\']([^"\']+)["\']', html, re.I):
        out.extend(re.findall(r'(https?://[^"\']+?\.(?:jpg|jpeg|png|webp)[^"\']*)', html_unescape(blob), re.I))
    # srcset / src de imágenes de producto
    for tag in re.findall(r"<img\b[^>]*>", html, re.I | re.S):
        attrs = {k.lower(): html_unescape(v) for k, v in
                 re.findall(r"([\w:.-]+)\s*=\s*[\"']([^\"']*)[\"']", tag)}
        hint = " ".join((attrs.get("id", ""), attrs.get("class", ""),
                         attrs.get("alt", ""), attrs.get("itemprop", ""))).lower()
        if any(x in hint for x in ("logo", "icon", "sprite", "avatar", "flag")):
            continue
        for key in ("data-old-hires", "data-src", "data-lazy-src", "src", "srcset"):
            val = attrs.get(key, "")
            if key == "srcset":
                val = val.split(",")[0].strip().split(" ")[0] if val else ""
            if val:
                out.append(val)
    # og:image puede venir como URL relativa o con parámetros de CDN.
    return [str(x).strip() for x in out if x and not str(x).startswith("data:")]


def _cp_pick_image(final, metas, links, html):
    candidates = [
        metas.get("og:image:secure_url"), metas.get("og:image"), metas.get("og:image:url"),
        metas.get("twitter:image"), metas.get("twitter:image:src"),
        metas.get("image"), metas.get("thumbnail"), metas.get("thumbnailurl"),
        metas.get("product:image"), metas.get("product:image:url"),
    ]
    for match in re.findall(r"<script[^>]+application/ld\+json[^>]*>(.*?)</script>", html, re.I | re.S):
        txt = html_unescape(match)
        candidates.extend(re.findall(r'"image"\s*:\s*"([^"\\]+)"', txt))
        candidates.extend(re.findall(r'"image"\s*:\s*\[\s*"([^"\\]+)"', txt))
    candidates.extend(_cp_extra_images(html))
    seen = set()
    fallback = ""
    gif_fallback = ""
    for candidate in candidates:
        if not candidate:
            continue
        resolved = urljoin(final, str(candidate).strip())
        if resolved in seen:
            continue
        seen.add(resolved)
        if not _cp_safe_remote(resolved):
            continue
        low = resolved.lower()
        if _cp_is_gif_url(resolved):
            if not gif_fallback:
                gif_fallback = resolved
            continue
        if any(bad in low for bad in _CP_BAD_IMG):
            if not fallback and re.search(r"\.(?:jpg|jpeg|png|webp)(?:\?|$)", low):
                fallback = resolved
            continue
        if re.search(r"\.(?:jpg|jpeg|png|webp)(?:\?|$)", low) or "mlstatic" in low or "media-amazon" in low:
            return resolved
        if not fallback:
            fallback = resolved
    return fallback or gif_fallback


def _cp_translate_url(url):
    """URL equivalente a través del proxy de Google Translate.

    Algunas tiendas (Mercado Libre, Amazon, etc.) bloquean las peticiones
    directas desde el servidor y devuelven una pantalla de verificación.
    Google Translate sí puede leer la página pública y conserva las etiquetas
    og:image, por lo que se usa como respaldo para encontrar la imagen.
    """
    p = _cp_safe_remote(url)
    if not p or not p.hostname:
        return ""
    host = p.hostname.lower()
    if host.endswith(".translate.goog") or host.endswith("google.com"):
        return ""
    proxy_host = host.replace(".", "-") + ".translate.goog"
    q = [(k, v) for k, v in parse_qsl(p.query, keep_blank_values=True)
         if not k.startswith("_x_tr_")]
    q.extend((("_x_tr_sl", "auto"), ("_x_tr_tl", "es"), ("_x_tr_hl", "es")))
    return urlunparse(("https", proxy_host, p.path or "/", "", urlencode(q), ""))


def _cp_preview_fetch(url):
    last_error = None
    for ua in _CP_UAS:
        try:
            return _cp_remote_open(url, "text/html", _CP_HTML_MAX, ua=ua)
        except ValueError as e:
            last_error = e
        except Exception as e:
            last_error = ValueError(str(e))
    raise last_error or ValueError("No se pudo abrir el enlace del producto")


def _cp_preview_fetch_image(url):
    """Respaldo para enlaces que apuntan directamente a una imagen."""
    last_error = None
    for ua in _CP_UAS:
        try:
            return _cp_remote_open(url, "image/", _CP_IMG_MAX, ua=ua)
        except ValueError as e:
            last_error = e
        except Exception as e:
            last_error = ValueError(str(e))
    raise last_error or ValueError("No se pudo abrir la imagen del producto")


def _cp_preview_parse(url, final, html):
    metas, links, title = _cp_html_meta(html)
    image = _cp_pick_image(final, metas, links, html)
    icon = ""
    for rel in ("icon", "shortcut icon", "apple-touch-icon", "apple-touch-icon-precomposed"):
        if links.get(rel):
            icon = urljoin(final, links[rel])
            break
    return {
        "url": url, "page": final,
        "title": (metas.get("og:title") or metas.get("twitter:title") or title or "")[:240],
        "site": urlparse(final).hostname or "",
        "image": image, "icon": icon,
    }


def _cp_preview_blocked(final, html):
    low = (final + " " + html[:200000]).lower()
    return any(x in low for x in (
        "account-verification", "captcha", "robot-check", "verify you are human",
        "verifica que eres humano", "unusual traffic", "access denied",
    ))


def _cp_amazon_image(url):
    """Imagen pública de Amazon a partir del ASIN, sin depender del HTML."""
    p = urlparse(url)
    host = (p.hostname or "").lower()
    if "amazon." not in host:
        return ""
    m = re.search(r"/(?:dp|gp/product|gp/aw/d)/([A-Z0-9]{10})(?:[/?]|$)", p.path, re.I)
    if not m:
        m = re.search(r"(?:^|[?&])asin=([A-Z0-9]{10})(?:&|$)", p.query, re.I)
    if not m:
        return ""
    return f"https://m.media-amazon.com/images/P/{m.group(1).upper()}.01._SCLZZZZZZZ_SX500_.jpg"


def _cp_preview(url):
    url = str(url or "").strip()[:1200]
    if not _cp_safe_remote(url):
        raise ValueError("Escribe un enlace que empiece con http:// o https://")
    now = time.time()
    with _CP_PREVIEW_LOCK:
        hit = _CP_PREVIEW_CACHE.get(url)
        if hit and hit[0] > now:
            return dict(hit[1])

    original_host = urlparse(url).hostname or ""
    translated = _cp_translate_url(url)
    data = ctype = final = None
    direct_error = None
    try:
        data, ctype, final = _cp_preview_fetch(url)
    except Exception as e:
        direct_error = e

    if data is None:
        result = None
        try:
            idata, ictype, ifinal = _cp_preview_fetch_image(url)
            still = ictype == "image/gif" or _cp_is_gif_bytes(idata)
            result = {"url": url, "page": ifinal, "title": "", "site": original_host,
                      "image": _cp_still_proxy(ifinal) if still else ifinal, "icon": ""}
        except Exception:
            result = None
        if result is None and translated:
            try:
                tdata, tctype, tfinal = _cp_preview_fetch(translated)
                if tctype.startswith("image/"):
                    still = tctype == "image/gif" or _cp_is_gif_bytes(tdata)
                    result = {"url": url, "page": url, "title": "", "site": original_host,
                              "image": _cp_still_proxy(tfinal) if still else tfinal, "icon": ""}
                else:
                    result = _cp_preview_parse(url, tfinal, tdata.decode("utf-8", "replace"))
                    result["page"] = url
                    result["site"] = original_host
            except Exception:
                result = None
        if result is None:
            amazon = _cp_amazon_image(url)
            if not amazon:
                raise direct_error or ValueError("No se pudo abrir el enlace del producto")
            result = {"url": url, "page": url, "title": "", "site": original_host,
                      "image": amazon, "icon": ""}
    elif ctype.startswith("image/"):
        still = ctype == "image/gif" or _cp_is_gif_bytes(data)
        result = {"url": url, "page": final, "title": "", "site": original_host,
                  "image": _cp_still_proxy(final) if still else final, "icon": ""}
    else:
        html = data.decode("utf-8", "replace")
        result = _cp_preview_parse(url, final, html)
        if (not result["image"] or _cp_preview_blocked(final, html)) and translated:
            try:
                tdata, tctype, tfinal = _cp_preview_fetch(translated)
                if tctype.startswith("text/html"):
                    translated_result = _cp_preview_parse(url, tfinal, tdata.decode("utf-8", "replace"))
                    if translated_result["image"]:
                        result["image"] = translated_result["image"]
                    if translated_result["title"] and translated_result["title"] != "Mercado Libre":
                        result["title"] = translated_result["title"]
                    if not result["icon"]:
                        result["icon"] = translated_result["icon"]
            except Exception:
                pass
    # Amazon suele devolver una imagen genérica de categoría en og:image.
    # Si el enlace trae ASIN, la imagen real del producto tiene prioridad.
    amazon = _cp_amazon_image(url) or _cp_amazon_image(result.get("page") or "")
    if amazon:
        result["image"] = amazon
    if not result["title"]:
        slug = urlparse(url).path.rstrip("/").split("/")[-1]
        result["title"] = re.sub(r"[-_]+", " ", slug)[:240]
    if result.get("image") and _cp_is_gif_url(result["image"]):
        # No se guarda el GIF: se referencia el proxy que entrega el primer
        # cuadro como PNG estático.
        result["image"] = _cp_still_proxy(result["image"])
    with _CP_PREVIEW_LOCK:
        _CP_PREVIEW_CACHE[url] = (now + _CP_PREVIEW_TTL, dict(result))
    return result


def _cp_image_url(value):
    url = str(value or "").strip()[:1200]
    if not url:
        return ""
    if url.startswith("/api/compras/imagen?"):
        try:
            embedded = (parse_qs(urlparse(url).query).get("url") or [""])[0].strip()
        except Exception:
            embedded = ""
        return _cp_still_proxy(embedded) if embedded and _cp_safe_remote(embedded) else ""
    if not _cp_safe_remote(url):
        return ""
    return _cp_still_proxy(url) if _cp_is_gif_url(url) else url


@app.get("/api/compras/link-preview")
@jwt_required()
def cp_link_preview():
    url = (request.args.get("url") or "").strip()
    if not url:
        return jsonify({"msg": "Falta el enlace"}), 400
    try:
        return jsonify(_cp_preview(url))
    except ValueError as e:
        return jsonify({"msg": str(e)}), 422
    except Exception:
        return jsonify({"msg": "No se pudo leer la imagen de ese enlace"}), 422


def _cp_image_cache_file(url):
    return IMAGE_CACHE_DIR / (hashlib.sha256(str(url).encode("utf-8")).hexdigest() + ".img")


def _cp_image_cache_get(url):
    p = _cp_image_cache_file(url)
    if not p.is_file():
        return None
    try:
        data = p.read_bytes()
    except Exception:
        return None
    kind = _cp_image_kind(data)
    return (data, f"image/{kind}") if kind else None


def _cp_image_cache_put(url, data):
    try:
        _cp_image_cache_file(url).write_bytes(data)
    except Exception:
        pass


@app.get("/api/compras/imagen")
@jwt_required()
def cp_imagen():
    url = (request.args.get("url") or "").strip()
    if not url:
        return jsonify({"msg": "Falta la imagen"}), 400
    cached = _cp_image_cache_get(url)
    if cached:
        resp = Response(cached[0], mimetype=cached[1])
        resp.headers["Cache-Control"] = "private, max-age=86400"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        return resp
    ref = (request.args.get("ref") or "").strip() or None
    if ref and not _cp_safe_remote(ref):
        ref = None
    try:
        data, ctype, final = _cp_remote_open(url, "image/", _CP_IMG_MAX, referer=ref)
        data, ctype = _cp_still_image(data, ctype)
        compressed, new_ext = _cp_compress_image(data)
        if new_ext:
            data, ctype = compressed, "image/webp"
    except ValueError as e:
        return jsonify({"msg": str(e)}), 422
    except Exception:
        return jsonify({"msg": "No se pudo cargar la imagen"}), 422
    if not ctype.startswith("image/"):
        return jsonify({"msg": "El enlace no es una imagen"}), 415
    if _cp_image_kind(data):
        _cp_image_cache_put(url, data)
    resp = Response(data, mimetype=ctype)
    resp.headers["Cache-Control"] = "private, max-age=86400"
    resp.headers["X-Content-Type-Options"] = "nosniff"
    return resp


# ---------- resumen / KPIs ----------
@app.get("/api/compras/resumen")
@jwt_required()
def cp_resumen():
    me, role, username = _cp_me()
    mine = (request.args.get("mine") or "").lower() in ("1", "true", "si", "sí")
    if _cp_can_quality(role) and not mine:
        rows = q_all(
            f"SELECT id,estado,calidad_estado FROM compras_solicitudes "
            f"WHERE tipo_compra='calidad' AND (COALESCE(calidad_por,'')='' "
            f"OR calidad_por={PH} OR user_id={PH})", (username, me))
        cal = {"pendientes": 0, "aprobadas": 0, "sin_firma": 0}
        est = {}
        for r in rows:
            est[r["estado"]] = est.get(r["estado"], 0) + 1
            if r.get("calidad_estado") in ("pendiente", "en_revision"):
                cal["pendientes"] += 1
            if r.get("calidad_estado") == "aprobada":
                cal["aprobadas"] += 1
            if r["estado"] in ("pendiente", "en_revision") and not _cp_firmado_vigente(r["id"], "requisicion_firmada"):
                cal["sin_firma"] += 1
        return jsonify({"solicitudes": est, "documentos": {}, "devoluciones": {},
                        "proveedores": 0, "por_autorizar": 0, "calidad": cal})
    view_all = _cp_can_view(role) and not mine
    if view_all:
        sc = {r["estado"]: r["n"] for r in q_all(
            "SELECT estado, COUNT(*) AS n FROM compras_solicitudes GROUP BY estado")}
        docs = {r["estado"]: r["n"] for r in q_all(
            "SELECT estado, COUNT(*) AS n FROM compras_documentos GROUP BY estado")}
        devs = {r["estado"]: r["n"] for r in q_all(
            "SELECT estado, COUNT(*) AS n FROM compras_devoluciones GROUP BY estado")}
        prov = q_one("SELECT COUNT(*) AS n FROM proveedores WHERE activo")["n"]
        por_aut = q_one(
            "SELECT COUNT(*) AS n FROM compras_documentos WHERE tipo='orden_compra' AND estado='emitida'")["n"]
    else:
        sc = {r["estado"]: r["n"] for r in q_all(
            f"SELECT estado, COUNT(*) AS n FROM compras_solicitudes WHERE user_id={PH} GROUP BY estado", (me,))}
        docs = {r["estado"]: r["n"] for r in q_all(
            f"""SELECT d.estado, COUNT(*) AS n FROM compras_documentos d
                JOIN compras_solicitudes s ON s.id=d.solicitud_id
                WHERE s.user_id={PH} GROUP BY d.estado""", (me,))}
        devs = {r["estado"]: r["n"] for r in q_all(
            f"""SELECT dv.estado, COUNT(*) AS n FROM compras_devoluciones dv
                JOIN compras_solicitudes s ON s.id=dv.solicitud_id
                WHERE s.user_id={PH} GROUP BY dv.estado""", (me,))}
        prov = 0
        por_aut = q_one(
            f"""SELECT COUNT(*) AS n FROM compras_documentos d
                JOIN compras_solicitudes s ON s.id=d.solicitud_id
                WHERE s.user_id={PH} AND d.tipo='orden_compra' AND d.estado='emitida'""", (me,))["n"]
    return jsonify({
        "solicitudes": sc,
        "documentos": docs,
        "devoluciones": devs,
        "proveedores": prov,
        "por_autorizar": por_aut,
    })


# ---------- solicitudes ----------
@app.get("/api/compras/solicitudes")
@jwt_required()
def cp_list_solicitudes():
    me, role, username = _cp_me()
    mine = (request.args.get("mine") or "").lower() in ("1", "true", "si", "sí")
    conds, params = [], []
    if mine or not _cp_can_view(role):
        conds.append(f"s.user_id={PH}"); params.append(me)
    if _cp_can_quality(role) and not mine:
        conds.append(f"((s.tipo_compra='calidad' AND (COALESCE(s.calidad_por,'')='' "
                     f"OR s.calidad_por={PH} OR s.user_id={PH})) OR s.user_id={PH})")
        params += [username, me, me]
    tipo = (request.args.get("tipo") or "").strip()
    if tipo in ("normal", "calidad"):
        conds.append(f"s.tipo_compra={PH}"); params.append(tipo)
    cond_cal, vals_cal = _cp_filter_estados("s.calidad_estado", request.args.get("calidad"), CP_ESTADOS_CALIDAD)
    if cond_cal:
        conds.append(cond_cal); params.extend(vals_cal)
    cond, vals = _cp_filter_estados("s.estado", request.args.get("estado"), CP_ESTADOS_SOL)
    if cond:
        conds.append(cond); params.extend(vals)
    q = (request.args.get("q") or "").strip()[:120]
    if q:
        conds.append(
            f"(s.folio {CP_LIKE} {PH} OR s.titulo {CP_LIKE} {PH} OR "
            f"s.justificacion {CP_LIKE} {PH} OR u.username {CP_LIKE} {PH})")
        params += [f"%{q}%"] * 4
    where = (" WHERE " + " AND ".join(conds)) if conds else ""
    rows = q_all(
        f"""SELECT s.*, COALESCE(u.username,'(cuenta eliminada)') AS username,
                   COALESCE(u.area,'') AS user_area, COALESCE(u.role,'user') AS user_role,
                   (SELECT COUNT(*) FROM compras_items i WHERE i.solicitud_id=s.id) AS n_items,
                   (SELECT COALESCE(SUM(i.cantidad*i.costo_unitario),0) FROM compras_items i
                     WHERE i.solicitud_id=s.id) AS total_estimado,
                   (SELECT COALESCE(i.imagen,'') FROM compras_items i
                     WHERE i.solicitud_id=s.id AND COALESCE(i.imagen,'')<>'' ORDER BY i.id LIMIT 1) AS imagen,
                   (SELECT COALESCE(i.link,'') FROM compras_items i
                     WHERE i.solicitud_id=s.id AND COALESCE(i.link,'')<>'' ORDER BY i.id LIMIT 1) AS primer_link,
                   (SELECT COUNT(*) FROM compras_documentos d WHERE d.solicitud_id=s.id) AS n_docs,
                   (SELECT COUNT(*) FROM compras_mensajes m WHERE m.solicitud_id=s.id) AS n_mensajes
            FROM compras_solicitudes s LEFT JOIN users u ON u.id=s.user_id
            {where} ORDER BY s.created_at DESC LIMIT 300""", tuple(params))
    for r in rows:
        r["documentos"] = q_all(
            f"SELECT id,tipo,folio,estado,total FROM compras_documentos WHERE solicitud_id={PH} ORDER BY id",
            (r["id"],))
        r["requisicion_firmada"] = _cp_firmado_vigente(r["id"], "requisicion_firmada")
        r["orden_compra_firmada"] = _cp_firmado_vigente(r["id"], "orden_compra_firmada")
        r["etapa_actual"] = _cp_etapa_actual(r)
    return jsonify(rows)


@app.post("/api/compras/solicitudes")
@jwt_required()
def cp_create_solicitud():
    me, role, username = _cp_me()
    if role not in ("user", "compras", "calidad"):
        return jsonify({"msg": "Solo el personal usuario, Calidad y el gestor de compras pueden crear solicitudes"}), 403
    d = request.get_json(force=True, silent=True) or {}
    tipo_compra = d.get("tipo_compra") if d.get("tipo_compra") in ("normal", "calidad") else "normal"
    justificacion = (d.get("justificacion") or "").strip()[:4000]
    prioridad = d.get("prioridad") if d.get("prioridad") in ("baja", "media", "alta", "urgente") else "media"
    items_in = d.get("items") or []
    parsed = []
    for idx, it in enumerate(items_in[:40]):
        p = _cp_item_payload(it, idx)
        if p:
            parsed.append(p)
    if not parsed:
        return jsonify({"msg": "Agrega al menos un producto o material"}), 400
    if tipo_compra == "calidad" and any(not it["opciones"] for it in parsed):
        return jsonify({"msg": "En compras con calidad agrega al menos una opción o proveedor por producto"}), 400
    propuesta = _cp_propuesta_proveedor(d.get("proveedor_propuesto") or {})
    if tipo_compra == "calidad":
        if not propuesta.get("nombre"):
            return jsonify({"msg": "Captura el nombre del proveedor propuesto para Calidad"}), 400
        if propuesta.get("rfc") and not _CP_RFC_RE.match(propuesta["rfc"]):
            return jsonify({"msg": "El RFC del proveedor propuesto no es válido"}), 400
        if propuesta.get("email") and not _cp_email_ok(propuesta["email"]):
            return jsonify({"msg": "El correo del proveedor propuesto no es válido"}), 400
    urow = q_one(f"SELECT area,jefe_area FROM users WHERE id={PH}", (me,)) or {}
    # Si el perfil no define jefatura de área, la propia persona solicitante firma
    # como jefatura de área (no se bloquea la creación de la compra).
    jefe_area = (urow.get("jefe_area") or "").strip()[:120] or (username or "").strip()[:120]
    nombres = [it["nombre"] for it in parsed]
    titulo = (d.get("titulo") or "").strip()[:160]
    if not titulo:
        titulo = nombres[0] if len(nombres) == 1 else f"{nombres[0]} + {len(nombres) - 1} más"
    area = (d.get("area") or urow.get("area") or "").strip()[:80]
    now = _cp_now()
    calidad_estado = "pendiente" if tipo_compra == "calidad" else "no_requiere"
    sid = q_exec(
        f"""INSERT INTO compras_solicitudes(user_id,area,titulo,justificacion,prioridad,estado,
            tipo_compra,flujo,jefe_area,calidad_estado,proveedor_propuesto,proveedor_sugerido,
            notas,created_at,updated_at)
            VALUES({PH},{PH},{PH},{PH},{PH},'pendiente',{PH},'nuevo',{PH},{PH},{PH},{PH},{PH},{PH},{PH})""" +
        (" RETURNING id" if USE_PG else ""),
        (me, area, titulo, justificacion, prioridad, tipo_compra, jefe_area, calidad_estado,
         _cp_dump(propuesta), propuesta.get("nombre") or (d.get("proveedor_sugerido") or "").strip()[:180],
         (d.get("notas") or "").strip()[:2000], now, now), returning_id=True)
    folio = f"SOL-{datetime.now(TZ).year}-{int(sid):04d}"
    q_exec(f"UPDATE compras_solicitudes SET folio={PH} WHERE id={PH}", (folio, sid))
    items = _cp_reemplazar_items(sid, d.get("items") or [], username)
    if not items:
        q_exec(f"DELETE FROM compras_solicitudes WHERE id={PH}", (sid,))
        return jsonify({"msg": "Agrega al menos un producto o material"}), 400
    srow = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (sid,))
    _cp_sync_requisicion(sid, srow, items, username)
    _cp_event(solicitud_id=sid, tipo="creada", despues="pendiente", por=username,
              nota=f"Solicitud {tipo_compra} creada con {len(items)} producto(s). Requisición generada.")
    _est = round(sum(_cp_num(i.get("cantidad")) * _cp_num(i.get("costo_unitario")) for i in items), 2)
    _cp_log(me, username, "compra_solicitud",
            f"{folio} · {titulo} · {tipo_compra} · prioridad {prioridad} · {len(items)} producto(s) · estimado ${_est:,.2f}")
    ahora_local = datetime.now(TZ)
    _cp_auto_message(
        sid, folio,
        f"Hola {username}. Recibí tu solicitud {folio} ({titulo}). Para continuar, descarga la "
        "requisición, fírmala con la jefatura de tu área y súbela en la sección "
        "Requisición firmada de esta solicitud.",
        para="solicitante", notificar=False)
    _cp_auto_message(
        sid, folio,
        f"Nueva solicitud de compra {folio} creada por {username} el "
        f"{ahora_local.strftime('%d/%m/%Y')} a las {ahora_local.strftime('%H:%M')}. "
        "Revisa los productos y las opciones capturadas.",
        para="compras")
    _cp_notify({"tipo": "solicitud", "id": sid, "estado": "pendiente", "folio": folio,
                "por": username, "etapa": "firma_requisicion", "to": ["solicitante", "compras"]})
    return jsonify(_cp_full_solicitud(sid)), 201


@app.get("/api/compras/solicitudes/<int:sid>")
@jwt_required()
def cp_get_solicitud(sid):
    me, role, _ = _cp_me()
    s = _cp_full_solicitud(sid)
    if not s:
        return jsonify({"msg": "No existe la solicitud"}), 404
    if not _cp_user_can_view_solicitud(s, me, role):
        return jsonify({"msg": "No tienes acceso a esta solicitud"}), 403
    return jsonify(s)


# --- conversación por solicitud de compra (usuario/a <-> gestor de compras) ---
@app.get("/api/compras/solicitudes/<int:sid>/mensajes")
@jwt_required()
def cp_list_mensajes(sid):
    me, role, _ = _cp_me()
    s = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (sid,))
    if not s:
        return jsonify({"msg": "No existe la solicitud"}), 404
    if not _cp_user_can_view_solicitud(s, me, role):
        return jsonify({"msg": "No tienes acceso a esta solicitud"}), 403
    rows = q_all(
        f"""SELECT m.id, m.solicitud_id, m.mensaje, m.created_at,
                   COALESCE(u.username,'(cuenta eliminada)') AS username,
                   COALESCE(u.role,'user') AS role, COALESCE(u.area,'') AS area
            FROM compras_mensajes m LEFT JOIN users u ON u.id=m.user_id
            WHERE m.solicitud_id={PH} ORDER BY m.created_at ASC, m.id ASC LIMIT 300""", (sid,))
    return jsonify(rows)


@app.post("/api/compras/solicitudes/<int:sid>/mensajes")
@jwt_required()
def cp_post_mensaje(sid):
    me, role, username = _cp_me()
    s = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (sid,))
    if not s:
        return jsonify({"msg": "No existe la solicitud"}), 404
    # Administración puede leer todo, pero no intervenir en la compra.
    puede_escribir = role == "compras" or (role in ("user", "calidad") and int(s["user_id"]) == me)
    if role == "calidad" and (s.get("tipo_compra") or "normal") == "calidad":
        puede_escribir = True
    if not puede_escribir:
        return jsonify({"msg": "No puedes escribir en esta conversación"}), 403
    if s["estado"] in ("cancelada",):
        return jsonify({"msg": "Esta solicitud fue cancelada; la conversación está cerrada"}), 400
    d = request.get_json(force=True, silent=True) or {}
    msg = (d.get("mensaje") or "").strip()
    if len(msg) < 1 or len(msg) > 800:
        return jsonify({"msg": "Escribe un mensaje de 1 a 800 caracteres"}), 400
    if role == "compras":
        s, err = _cp_claim_gestor(sid, username)
        if err:
            return jsonify({"msg": err}), 403
    now = _cp_now()
    mid = q_exec(
        f"INSERT INTO compras_mensajes(solicitud_id,user_id,mensaje,created_at) VALUES({PH},{PH},{PH},{PH})"
        + (" RETURNING id" if USE_PG else ""),
        (sid, me, msg, now), returning_id=True)
    _cp_log(me, username, "compra_mensaje", f"{s['folio']} · {msg[:100]}")
    owner = q_one(f"SELECT username FROM users WHERE id={PH}", (s["user_id"],))
    destinos_msg = [owner["username"]] if owner and owner.get("username") else []
    destinos_msg.append("compras")
    if (s.get("tipo_compra") or "normal") == "calidad":
        destinos_msg.append("calidad")
    _cp_notify({"tipo": "mensaje", "solicitud_id": sid, "id": mid, "folio": s["folio"],
                "de": username, "role": role, "area": _cp_area(me),
                "mensaje": msg[:180], "created_at": now, "to": destinos_msg})
    return jsonify({"ok": True, "id": mid, "created_at": now}), 201


@app.patch("/api/compras/solicitudes/<int:sid>")
@jwt_required()
def cp_update_solicitud(sid):
    me, role, username = _cp_me()
    s = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (sid,))
    if not s:
        return jsonify({"msg": "No existe la solicitud"}), 404
    # El gestor de compras NO edita los datos: solo observa, pide cambios o
    # conversa con la persona solicitante. La edición es exclusiva de quien pidió.
    if int(s["user_id"]) != me:
        return jsonify({"msg": "Solo quien creó la solicitud puede editar sus datos"}), 403
    if s["estado"] not in ("pendiente", "cambios_solicitados", "rechazada"):
        return jsonify({"msg": "Solo puedes editar una solicitud pendiente, con cambios solicitados o rechazada"}), 400
    d = request.get_json(force=True, silent=True) or {}
    urow = q_one(f"SELECT area,jefe_area FROM users WHERE id={PH}", (me,)) or {}
    # Sin jefatura de área configurada, la persona solicitante firma por su área.
    jefe_area = ((urow.get("jefe_area") or s.get("jefe_area") or "").strip()[:120]) or (username or "").strip()[:120]
    sets, params = [], []
    for field, limit in (("titulo", 160), ("justificacion", 4000),
                         ("notas", 2000), ("area", 80)):
        if field in d:
            sets.append(f"{field}={PH}"); params.append((d.get(field) or "").strip()[:limit])
    if "prioridad" in d and d.get("prioridad") in ("baja", "media", "alta", "urgente"):
        sets.append(f"prioridad={PH}"); params.append(d["prioridad"])
    tipo_compra = s.get("tipo_compra") or "normal"
    propuesta = _cp_parse(s.get("proveedor_propuesto"))
    if isinstance(d.get("proveedor_propuesto"), dict):
        propuesta = _cp_propuesta_proveedor(d["proveedor_propuesto"])
        if tipo_compra == "calidad":
            if not propuesta.get("nombre"):
                return jsonify({"msg": "Captura el nombre del proveedor propuesto para Calidad"}), 400
            if propuesta.get("rfc") and not _CP_RFC_RE.match(propuesta["rfc"]):
                return jsonify({"msg": "El RFC del proveedor propuesto no es válido"}), 400
            if propuesta.get("email") and not _cp_email_ok(propuesta["email"]):
                return jsonify({"msg": "El correo del proveedor propuesto no es válido"}), 400
    propuesta = _cp_propuesta_proveedor(propuesta)
    sets += [f"jefe_area={PH}", f"proveedor_propuesto={PH}",
             f"proveedor_sugerido={PH}"]
    params += [jefe_area, _cp_dump(propuesta), propuesta.get("nombre") or s.get("proveedor_sugerido") or ""]
    items = _cp_items(sid)
    if isinstance(d.get("items"), list) and d["items"]:
        parsed = []
        for idx, it in enumerate(d["items"][:40]):
            p = _cp_item_payload(it, idx)
            if p:
                parsed.append(p)
        if not parsed:
            return jsonify({"msg": "Agrega al menos un producto o material"}), 400
        if tipo_compra == "calidad" and any(not it["opciones"] for it in parsed):
            return jsonify({"msg": "En compras con calidad agrega al menos una opción o proveedor por producto"}), 400
        items = _cp_reemplazar_items(sid, d["items"], username)
    if not items:
        return jsonify({"msg": "Agrega al menos un producto o material"}), 400
    reenviada = s["estado"] in ("cambios_solicitados", "rechazada")
    calidad_estado = "pendiente" if tipo_compra == "calidad" else "no_requiere"
    sets += [f"estado={PH}", f"motivo_cambios={PH}", f"motivo_rechazo={PH}",
             f"calidad_estado={PH}", f"calidad_por=''", f"calidad_at={PH}",
             f"calidad_nota=''"]
    params += ["pendiente", "", "", calidad_estado, None]
    sets.append(f"updated_at={PH}"); params.append(_cp_now())
    q_exec(f"UPDATE compras_solicitudes SET {', '.join(sets)} WHERE id={PH}", tuple(params) + (sid,))
    _cp_invalidar_firmados(sid, ("requisicion_firmada",), por=username)
    if tipo_compra == "calidad":
        _cp_reset_calidad(sid, por=username)
    srow = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (sid,))
    _cp_sync_requisicion(sid, srow, items, s.get("username") or username)
    _cp_event(solicitud_id=sid, tipo="reenviada" if reenviada else "editada", por=username,
              nota="La persona solicitante corrigió y reenvió la solicitud; debe firmar de nuevo la requisición."
              if reenviada else "Solicitud actualizada; debe firmar de nuevo la requisición.")
    _cp_log(me, username, "compra_solicitud",
            (f"{s['folio']} reenviada por la persona solicitante" if reenviada
             else f"{s['folio']} editada") + " · requisición reiniciada")
    _cp_notify({"tipo": "solicitud", "id": sid, "estado": "pendiente",
                "folio": s["folio"], "por": username, "accion": "reenviada" if reenviada else "editada",
                "etapa": "firma_requisicion", "to": ["solicitante"]})
    return jsonify(_cp_full_solicitud(sid))


@app.post("/api/compras/solicitudes/<int:sid>/accion")
@jwt_required()
def cp_accion_solicitud(sid):
    me, role, username = _cp_me()
    s = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (sid,))
    if not s:
        return jsonify({"msg": "No existe la solicitud"}), 404
    d = request.get_json(force=True, silent=True) or {}
    accion = (d.get("accion") or "").strip()
    motivo = (d.get("motivo") or "").strip()[:1000]
    manage = _cp_can_manage(role)
    if not manage and int(s["user_id"]) != me:
        return jsonify({"msg": "No tienes acceso a esta solicitud"}), 403
    if accion == "solicitar_cambios_oc":
        if int(s["user_id"]) != me:
            return jsonify({"msg": "Solo la persona solicitante puede pedir cambios a la OC"}), 403
    elif not manage and accion not in ("cancelar",):
        return jsonify({"msg": "Solo el gestor de compras puede realizar esta acción"}), 403

    antes = s["estado"]
    nuevo = antes
    if accion in ("tomar", "aprobar"):
        ok_rev, msg_rev = _cp_puede_revisar_compras(s)
        if (s.get("flujo") or "legado") == "nuevo" and not ok_rev:
            return jsonify({"msg": msg_rev}), 400
    if accion == "tomar":
        if antes != "pendiente":
            return jsonify({"msg": "Solo se pueden tomar solicitudes pendientes"}), 400
        nuevo = "en_revision"
    elif accion == "aprobar":
        if antes not in ("pendiente", "en_revision"):
            return jsonify({"msg": "Esta solicitud ya no se puede aprobar"}), 400
        nuevo = "aprobada"
    elif accion == "rechazar":
        if antes not in ("pendiente", "en_revision"):
            return jsonify({"msg": "Esta solicitud ya no se puede rechazar"}), 400
        if not motivo:
            return jsonify({"msg": "Escribe el motivo del rechazo"}), 400
        nuevo = "rechazada"
    elif accion == "solicitar_cambios":
        if antes not in ("pendiente", "en_revision"):
            return jsonify({"msg": "Solo puedes pedir cambios a una solicitud pendiente o en revisión"}), 400
        if not motivo:
            return jsonify({"msg": "Escribe qué datos debe cambiar la persona solicitante"}), 400
        nuevo = "cambios_solicitados"
    elif accion == "solicitar_cambios_oc":
        if (s.get("flujo") or "legado") != "nuevo":
            return jsonify({"msg": "Esta solicitud usa el flujo anterior de documentos"}), 400
        if antes not in ("aprobada", "en_compra"):
            return jsonify({"msg": "La orden de compra ya no se puede ajustar en esta etapa"}), 400
        if (s.get("cambios_oc_motivo") or "").strip():
            return jsonify({"msg": "Ya hay una solicitud de cambios pendiente para la orden de compra"}), 400
        if not motivo:
            return jsonify({"msg": "Escribe qué debe cambiar la orden de compra"}), 400
        if _cp_firmado_vigente(sid, "orden_compra_firmada") or _cp_firmado_vigente(sid, "orden_compra_firmada_final"):
            return jsonify({"msg": "La OC ya fue firmada; solicita el ajuste directamente a Compras"}), 400
        if not _cp_orden_compra(sid):
            return jsonify({"msg": "Todavía no existe una orden de compra para ajustar"}), 400
        nuevo = antes
    elif accion == "cancelar":
        if antes in ("cerrada", "cancelada"):
            return jsonify({"msg": "La solicitud ya está cerrada"}), 400
        if not manage and antes not in ("pendiente", "en_revision", "cambios_solicitados"):
            return jsonify({"msg": "Ya no puedes cancelar esta solicitud"}), 403
        nuevo = "cancelada"
    elif accion == "reabrir":
        if antes not in ("rechazada", "cancelada", "cerrada"):
            return jsonify({"msg": "Solo se pueden reabrir solicitudes rechazadas, canceladas o cerradas"}), 400
        nuevo = "en_revision"
    elif accion == "cerrar":
        if antes not in ("recibida", "con_incidencias", "devuelta"):
            return jsonify({"msg": "Solo se puede cerrar una compra recibida o en devolución"}), 400
        if (s.get("flujo") or "legado") == "nuevo":
            if not _cp_oc_firmas_completas(s):
                faltan = [_cp_oc_firma_label(t) for t in _cp_oc_tipos_requeridos(s)
                          if not _cp_firmado_vigente(sid, t)]
                return jsonify({"msg": "Antes de cerrar, faltan firmas de la OC: " + ", ".join(faltan)}), 400
            if not _cp_firmado_vigente(sid, _CP_OC_FINAL):
                return jsonify({"msg": "Antes de cerrar, sube el documento final con todas las firmas"}), 400
        elif not _cp_adjuntos(sid):
            return jsonify({"msg": "Antes de cerrar, sube los documentos firmados de la compra"}), 400
        nuevo = "cerrada"
    else:
        return jsonify({"msg": "Acción no válida"}), 400

    if manage:
        s, err = _cp_claim_gestor(sid, username)
        if err:
            return jsonify({"msg": err}), 403
    sets = [f"estado={PH}", f"updated_at={PH}"]
    params = [nuevo, _cp_now()]
    if manage:
        sets += [f"revisado_por={PH}", f"revisado_at={PH}"]
        params += [username, _cp_now()]
    if accion == "rechazar":
        sets.append(f"motivo_rechazo={PH}"); params.append(motivo)
        sets.append(f"motivo_cambios={PH}"); params.append("")
    elif accion == "solicitar_cambios":
        sets.append(f"motivo_cambios={PH}"); params.append(motivo)
        sets.append(f"motivo_rechazo={PH}"); params.append("")
    elif accion == "solicitar_cambios_oc":
        sets.append(f"cambios_oc_motivo={PH}"); params.append(motivo)
    elif accion in ("aprobar", "tomar", "reabrir"):
        sets.append(f"motivo_rechazo={PH}"); params.append("")
        sets.append(f"motivo_cambios={PH}"); params.append("")
    if accion == "solicitar_cambios" and (s.get("flujo") or "legado") == "nuevo":
        sets += [f"calidad_estado={PH}", f"calidad_por=''", f"calidad_at={PH}", f"calidad_nota=''"]
        params += ["pendiente" if (s.get("tipo_compra") or "normal") == "calidad" else "no_requiere", None]
    q_exec(f"UPDATE compras_solicitudes SET {', '.join(sets)} WHERE id={PH}", tuple(params) + (sid,))
    if accion == "solicitar_cambios_oc":
        # La OC anterior pierde validez: se cancela y se conserva en el historial.
        _cp_invalidar_firmados(sid, _CP_OC_TIPOS, por=username)
        q_exec(
            f"UPDATE compras_documentos SET estado='cancelada', updated_at={PH} "
            f"WHERE solicitud_id={PH} AND tipo='orden_compra' AND estado!='cancelada'",
            (_cp_now(), sid))
        _cp_event(solicitud_id=sid, tipo="orden_compra_cancelada", antes="emitida",
                  despues="cancelada", por=username,
                  nota="OC cancelada para ajuste a petición de la persona solicitante")
    if accion == "cerrar":
        # Al cerrar la compra, la orden de compra también queda cerrada para que
        # el expediente y el avance del proceso sean consistentes.
        q_exec(
            f"UPDATE compras_documentos SET estado='cerrada', updated_at={PH} "
            f"WHERE solicitud_id={PH} AND estado NOT IN ('cancelada')",
            (_cp_now(), sid))
    if accion == "solicitar_cambios" and (s.get("flujo") or "legado") == "nuevo":
        _cp_invalidar_firmados(sid, ("requisicion_firmada",), por=username)
        if (s.get("tipo_compra") or "normal") == "calidad":
            _cp_reset_calidad(sid, por=username)
    _cp_event(solicitud_id=sid, tipo=accion, antes=antes, despues=nuevo, por=username, nota=motivo)
    _cp_log(me, username, "compra_estado",
            f"{s['folio']} · {antes} -> {nuevo}" + (f" · motivo: {motivo[:150]}" if motivo else ""))
    _cp_notify({"tipo": "solicitud", "id": sid, "estado": nuevo, "folio": s["folio"],
                "por": username, "accion": accion})
    return jsonify(_cp_full_solicitud(sid))


@app.post("/api/compras/solicitudes/<int:sid>/calidad")
@jwt_required()
def cp_accion_calidad(sid):
    me, role, username = _cp_me()
    if not _cp_can_quality(role):
        return jsonify({"msg": "Solo Calidad puede revisar estas compras"}), 403
    s = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (sid,))
    if not s:
        return jsonify({"msg": "No existe la solicitud"}), 404
    if (s.get("tipo_compra") or "normal") != "calidad":
        return jsonify({"msg": "Esta compra no requiere revisión de Calidad"}), 400
    if (s.get("calidad_por") or "").strip() and s.get("calidad_por") != username:
        return jsonify({"msg": "Esta compra está asignada a otro usuario de Calidad"}), 403
    if (s.get("flujo") or "legado") != "nuevo":
        return jsonify({"msg": "Esta solicitud pertenece al flujo anterior"}), 400
    if s.get("estado") in ("cerrada", "cancelada", "rechazada"):
        return jsonify({"msg": "Esta solicitud ya no se puede revisar"}), 400
    if not _cp_firmado_vigente(sid, "requisicion_firmada"):
        return jsonify({"msg": "Falta que el solicitante suba la requisición firmada"}), 400
    d = request.get_json(force=True, silent=True) or {}
    accion = (d.get("accion") or "").strip()
    nota = (d.get("nota") or "").strip()[:1000]
    ahora = _cp_now()
    if accion == "tomar":
        if s.get("calidad_estado") not in ("pendiente", "en_revision"):
            return jsonify({"msg": "Esta compra no está pendiente de Calidad"}), 400
        q_exec(
            f"UPDATE compras_solicitudes SET calidad_estado='en_revision', calidad_por={PH}, "
            f"calidad_at={PH}, updated_at={PH} WHERE id={PH}",
            (username, ahora, ahora, sid))
        nuevo = "en_revision"
    elif accion == "aprobar":
        if s.get("calidad_estado") not in ("pendiente", "en_revision"):
            return jsonify({"msg": "Esta compra no está pendiente de Calidad"}), 400
        ids = []
        for x in (d.get("opciones_aprobadas") or []):
            v = _cp_int(x, 0)
            if v and v not in ids:
                ids.append(v)
        if not ids:
            return jsonify({"msg": "Selecciona al menos una opción aprobada por producto"}), 400
        opciones = q_all(
            f"""SELECT o.id,o.item_id FROM compras_item_opciones o
                JOIN compras_items i ON i.id=o.item_id WHERE i.solicitud_id={PH}""", (sid,))
        valid_ids = {int(o["id"]) for o in opciones}
        if any(x not in valid_ids for x in ids):
            return jsonify({"msg": "Una de las opciones seleccionadas no pertenece a esta solicitud"}), 400
        items = q_all(f"SELECT id FROM compras_items WHERE solicitud_id={PH}", (sid,))
        aprobadas_por_item = {}
        for o in opciones:
            if int(o["id"]) in ids:
                aprobadas_por_item.setdefault(int(o["item_id"]), 0)
                aprobadas_por_item[int(o["item_id"])] += 1
        faltan = [str(i["id"]) for i in items if not aprobadas_por_item.get(int(i["id"]))]
        if faltan:
            return jsonify({"msg": "Aprueba al menos una opción de cada producto"}), 400
        for o in opciones:
            aprobada = o["id"] in ids
            q_exec(
                f"UPDATE compras_item_opciones SET calidad_aprobada={PH}, calidad_por={PH}, calidad_at={PH} WHERE id={PH}",
                ((True if USE_PG else 1) if aprobada else (False if USE_PG else 0),
                 username if aprobada else "", ahora if aprobada else None, o["id"]))
        q_exec(
            f"""UPDATE compras_solicitudes SET estado='pendiente',calidad_estado='aprobada',
                calidad_por={PH},calidad_at={PH},calidad_nota={PH},updated_at={PH} WHERE id={PH}""",
            (username, ahora, nota, ahora, sid))
        nuevo = "aprobada"
    elif accion in ("solicitar_cambios", "rechazar"):
        if not nota:
            return jsonify({"msg": "Escribe la observación de Calidad"}), 400
        estado = "cambios_solicitados" if accion == "solicitar_cambios" else "rechazada"
        q_exec(
            f"""UPDATE compras_solicitudes SET estado={PH},calidad_estado={PH},calidad_por={PH},
                calidad_at={PH},calidad_nota={PH},motivo_cambios={PH},motivo_rechazo={PH},
                updated_at={PH} WHERE id={PH}""",
            (estado, "pendiente" if accion == "solicitar_cambios" else "rechazada",
             username, ahora, nota, nota if accion == "solicitar_cambios" else "",
             nota if accion == "rechazar" else "", ahora, sid))
        if accion == "solicitar_cambios":
            _cp_invalidar_firmados(sid, ("requisicion_firmada",), por=username)
            _cp_reset_calidad(sid, por=username)
        nuevo = estado
    else:
        return jsonify({"msg": "Acción de Calidad no válida"}), 400

    _cp_event(solicitud_id=sid, tipo="calidad_" + accion, antes=s.get("calidad_estado") or "",
              despues=nuevo, por=username, nota=nota)
    _cp_log(me, username, "compra_calidad", f"{s['folio']} · Calidad: {accion} · {nuevo}")
    _cp_notify({"tipo": "solicitud", "id": sid, "estado": s.get("estado"),
                "folio": s["folio"], "por": username, "accion": "calidad_" + accion,
                "etapa": "revision_compras" if accion == "aprobar" else "calidad",
                "to": ["compras", "solicitante"] if accion == "aprobar" else ["solicitante"]})
    return jsonify(_cp_full_solicitud(sid))


# ---------- documentos (requisición / orden de compra) ----------
def _cp_guardar_empresa(datos):
    """Guarda los datos fiscales capturados por el gestor antes de emitir."""
    if not isinstance(datos, dict):
        return
    if "rfc" in datos:
        datos["rfc"] = _cp_rfc(datos.get("rfc"))
    if "email" in datos:
        datos["email"] = str(datos.get("email") or "").strip().lower()
    if "telefono" in datos:
        datos["telefono"] = _cp_digits(datos.get("telefono"), 10)
    sets, params = [], []
    for f, lim in (("nombre", 180), ("rfc", 13), ("razon_social", 220),
                   ("domicilio", 400), ("telefono", 10), ("email", 140), ("logo", 300)):
        if f in datos:
            sets.append(f"{f}={PH}")
            params.append((datos.get(f) or "").strip()[:lim])
    if sets:
        sets.append(f"updated_at={PH}")
        params.append(_cp_now())
        q_exec(f"UPDATE compras_empresa SET {', '.join(sets)} WHERE id=1", tuple(params))


def _cp_guardar_proveedor(pid, datos):
    """Crea o actualiza el proveedor con los datos capturados en el formulario."""
    if not isinstance(datos, dict):
        return _cp_proveedor(pid)
    campos = {}
    for f, lim in (("nombre", 180), ("rfc", 13), ("razon_social", 180), ("domicilio", 400),
                   ("contacto", 120), ("email", 120), ("telefono", 10), ("condiciones_pago", 120)):
        if f in datos:
            campos[f] = (datos.get(f) or "").strip()[:lim]
    if "rfc" in campos:
        campos["rfc"] = _cp_rfc(campos["rfc"])
    if "email" in campos:
        campos["email"] = campos["email"].lower()
    if "telefono" in campos:
        campos["telefono"] = _cp_digits(campos["telefono"], 10)
    nombre = campos.get("nombre", "")
    if not pid and not nombre:
        return None
    if not pid:
        now = _cp_now()
        pid = q_exec(
            f"""INSERT INTO proveedores(nombre,rfc,razon_social,domicilio,contacto,email,telefono,
                condiciones_pago,area,calidad_estado,created_by,updated_by,updated_at,activo,created_at)
                VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},'', 'aprobado', 'Compras', 'Compras', {PH}, {PH}, {PH})"""
            + (" RETURNING id" if USE_PG else ""),
            (nombre, campos.get("rfc", ""), campos.get("razon_social", ""),
             campos.get("domicilio", ""), campos.get("contacto", ""), campos.get("email", ""),
             campos.get("telefono", ""), campos.get("condiciones_pago", ""), now, True, now),
            returning_id=True)
    elif campos:
        sets = [f"{k}={PH}" for k in campos]
        params = list(campos.values()) + [pid]
        q_exec(f"UPDATE proveedores SET {', '.join(sets)}, updated_at={PH}, updated_by='Compras' WHERE id={PH}",
               tuple(params) + (_cp_now(),))
    return _cp_proveedor(pid)


@app.post("/api/compras/solicitudes/<int:sid>/orden")
@jwt_required()
def cp_crear_orden_compra(sid):
    me, role, username = _cp_me()
    if not _cp_can_manage(role):
        return jsonify({"msg": "Solo el gestor de compras puede generar la orden de compra"}), 403
    s = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (sid,))
    if not s:
        return jsonify({"msg": "No existe la solicitud"}), 404
    if (s.get("flujo") or "legado") != "nuevo":
        return jsonify({"msg": "Esta solicitud usa el flujo anterior de documentos"}), 400
    if s["estado"] not in ("aprobada", "en_compra"):
        return jsonify({"msg": "Primero autoriza la compra; después podrás generar la orden de compra"}), 400
    # Solo se regenera cuando la persona solicitante pidió un ajuste de la OC.
    if s["estado"] == "en_compra" and not (s.get("cambios_oc_motivo") or "").strip():
        return jsonify({"msg": "La orden de compra ya existe"}), 409
    ok_rev, msg_rev = _cp_puede_revisar_compras(s)
    if not ok_rev:
        return jsonify({"msg": msg_rev}), 400
    if _cp_orden_compra(sid):
        return jsonify({"msg": "La orden de compra ya existe"}), 409
    d = request.get_json(force=True, silent=True) or {}
    fecha_entrega = _cp_fecha_iso(d.get("fecha_entrega"))
    if fecha_entrega is None:
        return jsonify({"msg": "La fecha de entrega no tiene un formato válido"}), 400
    misma_fecha_entrega = _cp_bool(d.get("misma_fecha_entrega"))

    emp_in = d.get("empresa") if isinstance(d.get("empresa"), dict) else {}
    if emp_in.get("rfc") and not _CP_RFC_RE.match(_cp_rfc(emp_in.get("rfc"))):
        return jsonify({"msg": "El RFC de la empresa no tiene un formato válido"}), 400
    if emp_in.get("email") and not _cp_email_ok(emp_in.get("email")):
        return jsonify({"msg": "El correo de la empresa no es válido"}), 400
    _cp_guardar_empresa(emp_in)
    emp = _cp_empresa() or {}
    if not (emp.get("rfc") or "").strip() or not _CP_RFC_RE.match(_cp_rfc(emp.get("rfc"))):
        return jsonify({"msg": "Captura un RFC válido de la empresa antes de generar la orden"}), 400
    if not ((emp.get("razon_social") or "").strip() or (emp.get("nombre") or "").strip()):
        return jsonify({"msg": "Captura la razón social de la empresa antes de generar la orden"}), 400

    sin_proveedor = _cp_bool(d.get("sin_proveedor") or d.get("compra_en_linea"))
    proveedor_id = _cp_int(d.get("proveedor_id"), 0) or None
    prov = None
    if not sin_proveedor:
        prov = _cp_guardar_proveedor(proveedor_id, d.get("proveedor"))
        if not prov and (d.get("proveedor_nombre") or "").strip():
            prov = _cp_guardar_proveedor(None, {
                "nombre": d.get("proveedor_nombre"), "rfc": d.get("proveedor_rfc"),
                "razon_social": d.get("proveedor_razon"), "domicilio": d.get("proveedor_domicilio"),
                "contacto": d.get("proveedor_contacto"), "email": d.get("proveedor_email"),
                "telefono": d.get("proveedor_telefono"), "condiciones_pago": d.get("proveedor_condiciones"),
            })
        if not prov:
            return jsonify({"msg": "Selecciona o captura el proveedor de la orden de compra"}), 400
        if not (prov.get("rfc") or "").strip() or not _CP_RFC_RE.match(_cp_rfc(prov.get("rfc"))):
            return jsonify({"msg": "El proveedor debe tener un RFC válido para generar la orden"}), 400
    online_name = (d.get("proveedor_nombre") or "Compra en línea").strip()[:180] or "Compra en línea"
    prov_snap = prov or {"nombre": online_name, "rfc": "", "razon_social": "",
                         "domicilio": "", "contacto": "", "email": "", "telefono": "",
                         "condiciones_pago": ""}

    base_items = _cp_items(sid)
    if not base_items:
        return jsonify({"msg": "La solicitud no tiene productos"}), 400
    item_map = {int(it["id"]): it for it in base_items}
    opcion_map = {}
    for it in base_items:
        for op in (it.get("opciones") or []):
            opcion_map[int(op["id"])] = (it, op)

    raw = d.get("items")
    if not isinstance(raw, list) or not raw:
        raw = []
        for it in base_items:
            opciones = it.get("opciones") or []
            if (s.get("tipo_compra") or "normal") == "calidad":
                aprobadas = [o for o in opciones if o.get("calidad_aprobada")]
                if not aprobadas:
                    return jsonify({"msg": f"El producto {it['nombre']} no tiene opciones aprobadas"}), 400
                op = aprobadas[0]
            else:
                op = None
            raw.append({"item_id": it["id"], "opcion_id": op["id"] if op else None,
                        "cantidad": it.get("cantidad") or 1})

    seleccion = []
    cantidades = {}
    for row in raw[:120]:
        if not isinstance(row, dict):
            continue
        opcion = None
        item = None
        oid = _cp_int(row.get("opcion_id"), 0) or None
        if (s.get("tipo_compra") or "normal") == "calidad" and not oid:
            return jsonify({"msg": "En compras de Calidad debes elegir una opción aprobada para cada producto"}), 400
        if oid:
            if oid not in opcion_map:
                return jsonify({"msg": "Una de las opciones seleccionadas no pertenece a esta solicitud"}), 400
            item, opcion = opcion_map[oid]
        item_id = _cp_int(row.get("item_id"), 0) or (int(item["id"]) if item else 0)
        if not item_id or item_id not in item_map:
            return jsonify({"msg": "Una de las partidas no pertenece a esta solicitud"}), 400
        item = item_map[item_id]
        if opcion and int(opcion.get("item_id") or 0) != int(item["id"]):
            return jsonify({"msg": "La opción no corresponde al producto seleccionado"}), 400
        if opcion and (s.get("tipo_compra") or "normal") == "calidad" and not opcion.get("calidad_aprobada"):
            return jsonify({"msg": f"La opción {opcion.get('etiqueta') or oid} no fue aprobada por Calidad"}), 400
        cant = max(0.0001, _cp_num(row.get("cantidad"), item.get("cantidad") or 1))
        costo = _cp_num(row.get("costo_unitario"), opcion.get("costo_unitario") if opcion else item.get("costo_unitario"))
        costo = max(0.0, costo)
        incluye = _cp_bool(row.get("precio_incluye_iva")) if "precio_incluye_iva" in row else bool(
            opcion.get("precio_incluye_iva") if opcion else item.get("precio_incluye_iva"))
        desc_item = max(0.0, min(100.0, _cp_num(row.get("descuento_pct"), 0)))
        fecha_llegada = _cp_fecha_iso(fecha_entrega if misma_fecha_entrega else row.get("fecha_llegada"))
        if fecha_llegada is None:
            return jsonify({"msg": f"La fecha de llegada de {item['nombre']} no es válida"}), 400
        seleccion.append({
            "item_id": int(item["id"]), "opcion_id": int(opcion["id"]) if opcion else None,
            "nombre": item["nombre"], "descripcion": item.get("descripcion") or "",
            "id_fabricacion": item.get("id_fabricacion") or "",
            "opcion_etiqueta": (opcion.get("etiqueta") or "") if opcion else "",
            "link": (opcion.get("link") or item.get("link") or "") if opcion else (item.get("link") or ""),
            "diferencia": (opcion.get("diferencia") or "") if opcion else "",
            "cantidad": cant, "unidad": item.get("unidad") or "pza",
            "costo_unitario": costo, "descuento_pct": desc_item,
            "precio_incluye_iva": incluye, "fecha_llegada": fecha_llegada,
        })
        cantidades[item_id] = cantidades.get(item_id, 0.0) + cant
    if not seleccion:
        return jsonify({"msg": "Selecciona al menos una partida para la orden de compra"}), 400
    for it in base_items:
        solicitado = _cp_num(it.get("cantidad"), 0)
        autorizado = cantidades.get(int(it["id"]), 0.0)
        if autorizado > solicitado + 0.001:
            return jsonify({"msg": f"La cantidad de {it['nombre']} no puede superar lo solicitado"}), 400

    desc_pct = max(0.0, min(100.0, _cp_num(d.get("descuento_pct"), 0)))
    for it in seleccion:
        it["importe"] = round(
            it["cantidad"] * it["costo_unitario"] * (1 - it["descuento_pct"] / 100.0), 2)
    subtotal, desc_pct, iva_pct, iva, total, _modo = _cp_doc_totals(seleccion, desc_pct)
    s, err = _cp_claim_gestor(sid, username)
    if err:
        return jsonify({"msg": err}), 403
    now = _cp_now()
    fecha = (d.get("fecha") or _cp_today())[:10]
    req = _cp_requisicion(sid)
    did = q_exec(
        f"""INSERT INTO compras_documentos(folio,tipo,solicitud_id,origen_id,proveedor_id,estado,fecha,
            moneda,subtotal,descuento_pct,iva_pct,total,condiciones,notas,fecha_entrega,misma_fecha_entrega,
            almacen,entregar_a,elaborado_por,empresa_snapshot,proveedor_snapshot,created_at,updated_at,
            tipo_compra,jefe_area,calidad_por,calidad_at)
            VALUES({PH},{PH},{PH},{PH},{PH},'emitida',
            {PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},
            {PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH})"""
        + (" RETURNING id" if USE_PG else ""),
        ("", "orden_compra", sid, req["id"] if req else None, prov["id"] if prov else None, fecha,
         (d.get("moneda") or "MXN")[:8], subtotal, desc_pct, iva_pct, total,
         (d.get("condiciones") or "").strip()[:800], (d.get("notas") or "").strip()[:2000],
         fecha_entrega, misma_fecha_entrega,
         (d.get("almacen") or "").strip()[:160], (d.get("entregar_a") or "").strip()[:160],
         username, _cp_dump(emp), _cp_dump(prov_snap), now, now,
         s.get("tipo_compra") or "normal", s.get("jefe_area") or "",
         s.get("calidad_por") or "", s.get("calidad_at")), returning_id=True)
    folio = f"OC-{datetime.now(TZ).year}-{int(did):04d}"
    q_exec(f"UPDATE compras_documentos SET folio={PH} WHERE id={PH}", (folio, did))
    for it in seleccion:
        q_exec(
            f"""INSERT INTO compras_documento_items(documento_id,item_id,opcion_id,opcion_etiqueta,link,
                diferencia,nombre,descripcion,id_fabricacion,cantidad,unidad,costo_unitario,
                descuento_pct,importe,precio_incluye_iva,fecha_llegada,created_at)
                VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH})""",
            (did, it["item_id"], it["opcion_id"], it["opcion_etiqueta"], it["link"],
             it["diferencia"], it["nombre"], it["descripcion"], it["id_fabricacion"],
             it["cantidad"], it["unidad"], it["costo_unitario"], it["descuento_pct"],
             it["importe"], it["precio_incluye_iva"], it["fecha_llegada"], now))
        _cp_catalog_autosave_item(s.get("area") or "", it, username,
                                  (s.get("tipo_compra") or "normal") == "calidad")
    q_exec(
        f"""UPDATE compras_solicitudes SET estado='en_compra',cambios_oc_motivo='',
            revisado_por={PH},revisado_at={PH},
            updated_at={PH} WHERE id={PH}""", (username, now, now, sid))
    nota_oc = f"{folio} · {len(seleccion)} partida(s)"
    if (s.get("cambios_oc_motivo") or "").strip():
        nota_oc += " · ajuste a petición de la persona solicitante"
    _cp_event(solicitud_id=sid, documento_id=did, tipo="orden_compra_creada", despues="emitida",
              por=username, nota=nota_oc)
    _cp_log(me, username, "compra_documento",
            f"{folio} creada para {s['folio']} · proveedor: {prov['nombre'] if prov else 'Compra en línea'} · total ${total:,.2f}")
    partes_msg = []
    for it in seleccion[:8]:
        extra = f" (llega {it['fecha_llegada']})" if it.get("fecha_llegada") else ""
        partes_msg.append(f"{it['nombre']} x{it['cantidad']:g}{extra}")
    resumen_msg = "; ".join(partes_msg)
    if len(seleccion) > 8:
        resumen_msg += f"; y {len(seleccion) - 8} producto(s) más"
    condiciones_msg = (d.get("condiciones") or "").strip()
    _cp_auto_message(
        sid, s["folio"],
        f"Tu orden de compra {folio} ya está generada. Incluye: {resumen_msg[:520]}. "
        f"Condiciones comerciales: {(condiciones_msg or 'sin condiciones adicionales')[:240]}. "
        "Descárgala, recaba únicamente la firma del jefe de tu área y súbela en "
        "“OC firmada por el jefe de área”. No necesitas buscar las firmas de Compras: "
        "Sandra Limones y Lucío Limones las recabarán después.",
        para="solicitante")
    _cp_notify({"tipo": "documento", "id": did, "estado": "emitida", "folio": folio,
                "solicitud_id": sid, "etapa": "firma_orden", "to": ["compras", "solicitante"]})
    _cp_pdf_autogen(did)
    return jsonify(_cp_doc_full(did)), 201


@app.post("/api/compras/solicitudes/<int:sid>/documento")
@jwt_required()
def cp_create_documento(sid):
    me, role, username = _cp_me()
    if not _cp_can_manage(role):
        return jsonify({"msg": "Solo el gestor de compras puede generar documentos"}), 403
    s = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (sid,))
    if not s:
        return jsonify({"msg": "No existe la solicitud"}), 404
    if (s.get("flujo") or "legado") == "nuevo":
        return jsonify({"msg": "Usa el formulario de orden de compra del flujo nuevo"}), 400
    if s["estado"] not in ("aprobada", "en_compra", "recibida", "con_incidencias"):
        return jsonify({"msg": "Primero aprueba la solicitud"}), 400
    d = request.get_json(force=True, silent=True) or {}
    tipo = d.get("tipo") or "ambos"
    if tipo not in ("requisicion", "orden_compra", "ambos"):
        return jsonify({"msg": "Tipo de documento inválido"}), 400

    # El gestor captura (o confirma) los datos fiscales de la empresa.
    emp_in = d.get("empresa") if isinstance(d.get("empresa"), dict) else {}
    if emp_in.get("rfc") and not _CP_RFC_RE.match(_cp_rfc(emp_in.get("rfc"))):
        return jsonify({"msg": "El RFC de la empresa no tiene un formato válido"}), 400
    if emp_in.get("email") and not _cp_email_ok(emp_in.get("email")):
        return jsonify({"msg": "El correo de la empresa no es válido"}), 400
    _cp_guardar_empresa(emp_in)
    emp = _cp_empresa() or {}
    if not (emp.get("rfc") or "").strip():
        return jsonify({"msg": "Captura el RFC de la empresa antes de generar documentos oficiales"}), 400
    if not _CP_RFC_RE.match(_cp_rfc(emp.get("rfc"))):
        return jsonify({"msg": "El RFC de la empresa no tiene un formato válido"}), 400
    if not ((emp.get("razon_social") or "").strip() or (emp.get("nombre") or "").strip()):
        return jsonify({"msg": "Captura la razón social de la empresa antes de generar documentos oficiales"}), 400

    # Proveedor: se puede elegir uno existente o capturarlo aquí mismo.
    proveedor_id = _cp_int(d.get("proveedor_id"), 0) or None
    prov = _cp_guardar_proveedor(proveedor_id, d.get("proveedor"))
    if not prov and (d.get("proveedor_nombre") or "").strip():
        prov = _cp_guardar_proveedor(None, {
            "nombre": d.get("proveedor_nombre"), "rfc": d.get("proveedor_rfc"),
            "razon_social": d.get("proveedor_razon"), "domicilio": d.get("proveedor_domicilio"),
            "contacto": d.get("proveedor_contacto"), "email": d.get("proveedor_email"),
            "telefono": d.get("proveedor_telefono"), "condiciones_pago": d.get("proveedor_condiciones"),
        })
    if tipo in ("orden_compra", "ambos") and not prov:
        return jsonify({"msg": "Selecciona o captura el proveedor de la orden de compra"}), 400
    if prov and not (prov.get("rfc") or "").strip():
        return jsonify({"msg": "El proveedor debe tener RFC para generar la orden de compra"}), 400
    if prov and not _CP_RFC_RE.match(_cp_rfc(prov.get("rfc"))):
        return jsonify({"msg": "El RFC del proveedor no tiene un formato válido"}), 400

    req_prev = q_one(
        f"SELECT id,folio FROM compras_documentos WHERE solicitud_id={PH} AND tipo='requisicion' ORDER BY id DESC LIMIT 1",
        (sid,))
    oc_prev = q_one(
        f"SELECT id,folio FROM compras_documentos WHERE solicitud_id={PH} AND tipo='orden_compra' ORDER BY id DESC LIMIT 1",
        (sid,))
    if tipo == "requisicion" and req_prev:
        return jsonify({"msg": f"Ya existe la requisición {req_prev['folio']}", "documento_id": req_prev["id"]}), 409
    if tipo == "orden_compra" and oc_prev:
        return jsonify({"msg": f"Ya existe la orden de compra {oc_prev['folio']}", "documento_id": oc_prev["id"]}), 409
    if tipo == "ambos":
        if req_prev and oc_prev:
            return jsonify({"msg": f"Ya existen los documentos {req_prev['folio']} y {oc_prev['folio']}",
                            "documento_id": oc_prev["id"]}), 409
        if req_prev:
            return jsonify({"msg": f"Ya existe la requisición {req_prev['folio']}; falta la orden de compra",
                            "documento_id": req_prev["id"], "faltante": "orden_compra"}), 409
        if oc_prev:
            return jsonify({"msg": f"Ya existe la orden de compra {oc_prev['folio']}",
                            "documento_id": oc_prev["id"]}), 409

    items_in = d.get("items")
    items = []
    if isinstance(items_in, list) and items_in:
        for it in items_in[:60]:
            nombre = (it.get("nombre") or "").strip()[:180]
            if not nombre:
                continue
            items.append({
                "item_id": _cp_int(it.get("item_id"), 0) or None,
                "nombre": nombre,
                "descripcion": (it.get("descripcion") or "").strip()[:1000],
                "id_fabricacion": (it.get("id_fabricacion") or "").strip()[:120],
                "cantidad": max(0.0001, _cp_num(it.get("cantidad"), 1)),
                "unidad": (it.get("unidad") or "pza").strip()[:20] or "pza",
                "costo_unitario": max(0.0, _cp_num(it.get("costo_unitario"), 0)),
                "descuento_pct": max(0.0, min(100.0, _cp_num(it.get("descuento_pct"), 0))),
                "precio_incluye_iva": _cp_bool(it.get("precio_incluye_iva")),
            })
    else:
        for it in _cp_items(sid):
            items.append({
                "item_id": it["id"], "nombre": it["nombre"],
                "descripcion": it.get("descripcion") or "",
                "id_fabricacion": it.get("id_fabricacion") or "",
                "cantidad": _cp_num(it.get("cantidad"), 1),
                "unidad": it.get("unidad") or "pza",
                "costo_unitario": _cp_num(it.get("costo_unitario"), 0),
                "descuento_pct": 0.0,
                "precio_incluye_iva": _cp_bool(it.get("precio_incluye_iva")),
            })
    if not items:
        return jsonify({"msg": "La solicitud no tiene productos"}), 400

    desc_pct = max(0.0, min(100.0, _cp_num(d.get("descuento_pct"), 0)))
    for it in items:
        # El precio capturado se conserva tal cual. Si ya incluye IVA, el
        # documento no vuelve a sumarlo (ver _cp_doc_totals).
        it["importe"] = round(
            it["cantidad"] * it["costo_unitario"] * (1 - it["descuento_pct"] / 100.0), 2)
    subtotal, desc_pct, iva_pct, iva, total, _modo = _cp_doc_totals(items, desc_pct)

    now = _cp_now()
    fecha = (d.get("fecha") or _cp_today())[:10]
    moneda = (d.get("moneda") or "MXN")[:8]
    condiciones = (d.get("condiciones") or "").strip()[:800]
    notas = (d.get("notas") or "").strip()[:2000]
    almacen = (d.get("almacen") or "").strip()[:160]
    entregar_a = (d.get("entregar_a") or "").strip()[:160]
    empresa_snap = _cp_dump(emp)
    prov_snap = _cp_dump(prov or {})

    def crear(tipo_doc, estado_doc, origen_id=None):
        did = q_exec(
            f"""INSERT INTO compras_documentos(folio,tipo,solicitud_id,origen_id,proveedor_id,estado,fecha,
                moneda,subtotal,descuento_pct,iva_pct,total,condiciones,notas,almacen,entregar_a,
                elaborado_por,empresa_snapshot,proveedor_snapshot,created_at,updated_at)
                VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH})"""
            + (" RETURNING id" if USE_PG else ""),
            ("", tipo_doc, sid, origen_id, prov["id"] if prov else None, estado_doc, fecha,
             moneda, subtotal, desc_pct, iva_pct, total, condiciones, notas,
             almacen, entregar_a, username, empresa_snap, prov_snap, now, now), returning_id=True)
        folio = f"{'REQ' if tipo_doc == 'requisicion' else 'OC'}-{datetime.now(TZ).year}-{int(did):04d}"
        q_exec(f"UPDATE compras_documentos SET folio={PH} WHERE id={PH}", (folio, did))
        for it in items:
            q_exec(
                f"""INSERT INTO compras_documento_items(documento_id,item_id,nombre,descripcion,
                    id_fabricacion,cantidad,unidad,costo_unitario,descuento_pct,importe,precio_incluye_iva,created_at)
                    VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH})""",
                (did, it["item_id"], it["nombre"], it["descripcion"], it["id_fabricacion"],
                 it["cantidad"], it["unidad"], it["costo_unitario"], it["descuento_pct"],
                 it["importe"], it["precio_incluye_iva"], now))
            _cp_catalog_autosave_item(s.get("area") or "", it, username,
                                      (s.get("tipo_compra") or "normal") == "calidad")
        return did, folio

    generados = []
    req_did = req_prev["id"] if req_prev else None
    if tipo in ("requisicion", "ambos") and not req_prev:
        req_did, req_folio = crear("requisicion", "emitida")
        generados.append((req_did, req_folio))
    if tipo in ("orden_compra", "ambos") and not oc_prev:
        estado_oc = "emitida" if tipo == "ambos" else "borrador"
        oc_did, oc_folio = crear("orden_compra", estado_oc, req_did)
        generados.append((oc_did, oc_folio))
        oc_prev = {"id": oc_did, "folio": oc_folio}

    if s["estado"] == "aprobada":
        q_exec(f"UPDATE compras_solicitudes SET estado='en_compra', updated_at={PH} WHERE id={PH}",
               (now, sid))
    for did, folio in generados:
        _cp_event(solicitud_id=sid, documento_id=did, tipo="documento_creado", despues="emitida",
                  por=username, nota=f"{folio} · {tipo}")
    _cp_log(me, username, "compra_documento",
            f"{' + '.join(f for _, f in generados)} creados para {s['folio']} · "
            f"proveedor: {prov['nombre'] if prov else '—'} · total ${total:,.2f} · {len(items)} partida(s)")
    for did, folio in generados:
        _cp_pdf_autogen(did)
        _cp_notify({"tipo": "documento", "id": did, "estado": "emitida", "folio": folio,
                    "solicitud_id": sid})
    if tipo == "ambos":
        return jsonify({"requisicion": _cp_doc_full(req_did),
                        "orden_compra": _cp_doc_full(oc_prev["id"])}), 201
    return jsonify(_cp_doc_full(generados[0][0] if generados else (oc_prev or req_prev)["id"])), 201


@app.get("/api/compras/documentos")
@jwt_required()
def cp_list_documentos():
    me, role, username = _cp_me()
    mine = (request.args.get("mine") or "").lower() in ("1", "true", "si", "sí")
    conds, params = [], []
    if mine or not _cp_can_view(role):
        conds.append(f"s.user_id={PH}"); params.append(me)
    if _cp_can_quality(role) and not mine:
        conds.append(f"((s.tipo_compra='calidad' AND (COALESCE(s.calidad_por,'')='' "
                     f"OR s.calidad_por={PH} OR s.user_id={PH})) OR s.user_id={PH})")
        params += [username, me, me]
    tipo = (request.args.get("tipo") or "").strip()
    if tipo in ("requisicion", "orden_compra"):
        conds.append(f"d.tipo={PH}"); params.append(tipo)
    cond, vals = _cp_filter_estados("d.estado", request.args.get("estado"), CP_ESTADOS_DOC)
    if cond:
        conds.append(cond); params.extend(vals)
    q = (request.args.get("q") or "").strip()[:120]
    if q:
        conds.append(
            f"(d.folio {CP_LIKE} {PH} OR COALESCE(p.nombre,'') {CP_LIKE} {PH} OR "
            f"d.proveedor_snapshot {CP_LIKE} {PH} OR "
            f"s.folio {CP_LIKE} {PH} OR s.titulo {CP_LIKE} {PH})")
        params += [f"%{q}%"] * 5
    where = (" WHERE " + " AND ".join(conds)) if conds else ""
    rows = q_all(
        f"""SELECT d.*, COALESCE(p.nombre,'') AS proveedor_nombre,
                   s.folio AS solicitud_folio, s.titulo AS solicitud_titulo,
                   COALESCE(u.username,'') AS username
            FROM compras_documentos d
            LEFT JOIN proveedores p ON p.id=d.proveedor_id
            JOIN compras_solicitudes s ON s.id=d.solicitud_id
            LEFT JOIN users u ON u.id=s.user_id
            {where} ORDER BY d.created_at DESC LIMIT 300""", tuple(params))
    rows = [_cp_prov_nombre(r) for r in rows]
    # Adjuntos firmados por solicitud: se muestran junto al documento que
    # corresponda para que el expediente sea visible desde "Documentos".
    ids = sorted({int(r["solicitud_id"]) for r in rows if r.get("solicitud_id")})
    adjuntos = {}
    if ids:
        marks = ",".join(PH for _ in ids)
        for a in q_all(
                f"SELECT * FROM compras_adjuntos WHERE solicitud_id IN ({marks}) "
                f"ORDER BY id DESC", tuple(ids)):
            a["vigente"] = _cp_bool(a.get("vigente"))
            adjuntos.setdefault(int(a["solicitud_id"]), []).append(a)
    for r in rows:
        tipo = r.get("tipo")
        adj = adjuntos.get(int(r["solicitud_id"]), [])
        if tipo == "requisicion":
            r["firmados"] = [a for a in adj if a.get("tipo") == "requisicion_firmada"]
        else:
            r["firmados"] = [a for a in adj
                             if a.get("tipo") in _CP_OC_TIPOS or a.get("tipo") == "firmado"]
    return jsonify(rows)


@app.get("/api/compras/documentos/<int:did>")
@jwt_required()
def cp_get_documento(did):
    me, role, _ = _cp_me()
    d = _cp_doc_full(did)
    if not d:
        return jsonify({"msg": "No existe el documento"}), 404
    if not _cp_user_can_view_doc(d, me, role):
        return jsonify({"msg": "No tienes acceso a este documento"}), 403
    return jsonify(d)


@app.post("/api/compras/documentos/<int:did>/pdf")
@jwt_required()
def cp_generar_pdf_documento(did):
    """Regenera el PDF digital (con enlaces, imágenes y variantes) y lo guarda."""
    me, role, username = _cp_me()
    doc = _cp_doc_full(did)
    if not doc:
        return jsonify({"msg": "No existe el documento"}), 404
    if not _cp_user_can_view_doc(doc, me, role):
        return jsonify({"msg": "No tienes acceso a este documento"}), 403
    safe = _cp_pdf_generate(did, keep=True)
    if not safe:
        return jsonify({"msg": "No se pudo generar el PDF digital. Verifica que Edge o Chrome estén instalados."}), 503
    _cp_log(me, username, "compra_documento", f"{doc.get('folio')} · PDF digital regenerado")
    refreshed = _cp_doc_full(did)
    refreshed["pdf_generado"] = safe
    return jsonify(refreshed), 200


@app.patch("/api/compras/documentos/<int:did>")
@jwt_required()
def cp_update_documento(did):
    me, role, username = _cp_me()
    if not _cp_can_manage(role):
        return jsonify({"msg": "Solo el gestor de compras puede editar documentos"}), 403
    d0 = q_one(f"SELECT * FROM compras_documentos WHERE id={PH}", (did,))
    if not d0:
        return jsonify({"msg": "No existe el documento"}), 404
    if d0["estado"] not in ("borrador", "emitida"):
        return jsonify({"msg": "Solo se puede editar un documento en borrador o emitido"}), 400
    srow = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (d0["solicitud_id"],))
    if srow:
        srow, err = _cp_claim_gestor(d0["solicitud_id"], username)
        if err:
            return jsonify({"msg": err}), 403
    if srow and (srow.get("flujo") or "legado") == "nuevo" and d0["tipo"] == "requisicion":
        return jsonify({"msg": "La requisición se corrige desde la solicitud, no desde el documento"}), 400
    d = request.get_json(force=True, silent=True) or {}
    sets, params = [], []
    for f, lim in (("fecha", 10), ("condiciones", 800), ("notas", 2000),
                   ("almacen", 160), ("entregar_a", 160), ("moneda", 8)):
        if f in d:
            sets.append(f"{f}={PH}"); params.append((d.get(f) or "").strip()[:lim])
    if "fecha_entrega" in d:
        fecha_entrega = _cp_fecha_iso(d.get("fecha_entrega"))
        if fecha_entrega is None:
            return jsonify({"msg": "La fecha de entrega no tiene un formato válido"}), 400
        sets.append(f"fecha_entrega={PH}"); params.append(fecha_entrega)
    if "misma_fecha_entrega" in d:
        sets.append(f"misma_fecha_entrega={PH}"); params.append(_cp_bool(d.get("misma_fecha_entrega")))
    if "proveedor_id" in d:
        pid = _cp_int(d.get("proveedor_id"), 0) or None
        sets.append(f"proveedor_id={PH}"); params.append(pid)
        sets.append(f"proveedor_snapshot={PH}"); params.append(_cp_dump(_cp_proveedor(pid)))
    if "descuento_pct" in d:
        sets.append(f"descuento_pct={PH}"); params.append(max(0, min(100, _cp_num(d.get("descuento_pct")))))
    if isinstance(d.get("items"), list) and d["items"]:
        now = _cp_now()
        nuevos, cantidades = [], {}
        for it in d["items"][:60]:
            oid = _cp_int(it.get("opcion_id"), 0) or None
            op = None
            if oid:
                op = q_one(f"SELECT * FROM compras_item_opciones WHERE id={PH}", (oid,))
                if not op:
                    return jsonify({"msg": "Una de las opciones ya no existe"}), 400
                if srow and int(op["item_id"]) not in {int(x["id"]) for x in _cp_items(srow["id"])}:
                    return jsonify({"msg": "La opción no pertenece a esta solicitud"}), 400
                if srow and (srow.get("tipo_compra") or "normal") == "calidad" and not op.get("calidad_aprobada"):
                    return jsonify({"msg": f"La opción {op.get('etiqueta') or oid} no fue aprobada por Calidad"}), 400
            item_id = _cp_int(it.get("item_id"), 0) or (int(op["item_id"]) if op else 0)
            nombre = (it.get("nombre") or "").strip()[:180]
            if not nombre:
                return jsonify({"msg": "Cada partida debe tener nombre"}), 400
            cant = max(0.0001, _cp_num(it.get("cantidad"), 1))
            costo = max(0.0, _cp_num(it.get("costo_unitario"), op.get("costo_unitario") if op else 0))
            dp = max(0.0, min(100.0, _cp_num(it.get("descuento_pct"), 0)))
            incluye = _cp_bool(it.get("precio_incluye_iva")) if "precio_incluye_iva" in it else bool(
                op.get("precio_incluye_iva") if op else False)
            fecha_llegada = _cp_fecha_iso(it.get("fecha_llegada"))
            if fecha_llegada is None:
                return jsonify({"msg": f"La fecha de llegada de {nombre} no es válida"}), 400
            nuevos.append({
                "item_id": item_id or None, "opcion_id": oid,
                "opcion_etiqueta": (op.get("etiqueta") or "") if op else "",
                "link": (op.get("link") or "") if op else "",
                "diferencia": (op.get("diferencia") or "") if op else "",
                "nombre": nombre, "descripcion": (it.get("descripcion") or "").strip()[:1000],
                "id_fabricacion": (it.get("id_fabricacion") or "").strip()[:120],
                "cantidad": cant, "unidad": (it.get("unidad") or "pza").strip()[:20] or "pza",
                "costo_unitario": costo, "descuento_pct": dp, "precio_incluye_iva": incluye,
                "fecha_llegada": fecha_llegada,
            })
            if item_id:
                cantidades[item_id] = cantidades.get(item_id, 0.0) + cant
        if not nuevos:
            return jsonify({"msg": "El documento debe tener al menos una partida"}), 400
        if srow and (srow.get("flujo") or "legado") == "nuevo" and d0["tipo"] == "orden_compra":
            for base in _cp_items(srow["id"]):
                if abs(cantidades.get(int(base["id"]), 0.0) - _cp_num(base.get("cantidad"), 0)) > 0.001:
                    return jsonify({"msg": f"La cantidad de {base['nombre']} no coincide con lo solicitado"}), 400
        q_exec(f"DELETE FROM compras_documento_items WHERE documento_id={PH}", (did,))
        for it in nuevos:
            imp = round(it["cantidad"] * it["costo_unitario"] * (1 - it["descuento_pct"] / 100.0), 2)
            q_exec(
                f"""INSERT INTO compras_documento_items(documento_id,item_id,opcion_id,opcion_etiqueta,link,
                    diferencia,nombre,descripcion,id_fabricacion,cantidad,unidad,costo_unitario,
                    descuento_pct,importe,precio_incluye_iva,fecha_llegada,created_at)
                    VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH})""",
                (did, it["item_id"], it["opcion_id"], it["opcion_etiqueta"], it["link"],
                 it["diferencia"], it["nombre"], it["descripcion"], it["id_fabricacion"],
                 it["cantidad"], it["unidad"], it["costo_unitario"], it["descuento_pct"], imp,
                 it["precio_incluye_iva"], it["fecha_llegada"], now))
    # recalcular totales con lo que quedó en la BD
    rows = q_all(f"SELECT * FROM compras_documento_items WHERE documento_id={PH}", (did,))
    dp = _cp_num(d.get("descuento_pct"), d0.get("descuento_pct") or 0)
    sub2, dp, iv, iva, total, _modo = _cp_doc_totals(rows, dp)
    sets += [f"subtotal={PH}", f"iva_pct={PH}", f"total={PH}", f"updated_at={PH}"]
    params += [sub2, iv, total, _cp_now()]
    q_exec(f"UPDATE compras_documentos SET {', '.join(sets)} WHERE id={PH}", tuple(params) + (did,))
    if srow and (srow.get("flujo") or "legado") == "nuevo" and d0["tipo"] == "orden_compra":
        _cp_invalidar_firmados(d0["solicitud_id"], _CP_OC_TIPOS, por=username)
        _cp_auto_message(
            d0["solicitud_id"], srow["folio"],
            "La orden de compra fue actualizada. Descarga la versión nueva y vuelve a recabar las firmas: "
            "primero la jefatura de área y después Compras completará las firmas restantes.",
            para="solicitante")
    _cp_event(solicitud_id=d0["solicitud_id"], documento_id=did, tipo="documento_editado",
              por=username, nota="Documento actualizado")
    _cp_log(me, username, "compra_documento", f"editado #{did}")
    _cp_pdf_autogen(did)
    return jsonify(_cp_doc_full(did))


@app.post("/api/compras/documentos/<int:did>/accion")
@jwt_required()
def cp_accion_documento(did):
    me, role, username = _cp_me()
    d0 = q_one(f"SELECT * FROM compras_documentos WHERE id={PH}", (did,))
    if not d0:
        return jsonify({"msg": "No existe el documento"}), 404
    d = request.get_json(force=True, silent=True) or {}
    accion = (d.get("accion") or "").strip()
    manage = _cp_can_manage(role)
    if not manage:
        return jsonify({"msg": "Solo el gestor de compras puede realizar esta acción"}), 403
    antes = d0["estado"]
    nuevo = antes
    if accion == "emitir":
        if antes != "borrador":
            return jsonify({"msg": "Solo un borrador se puede emitir"}), 400
        nuevo = "emitida"
    elif accion == "autorizar":
        if antes not in ("emitida", "borrador"):
            return jsonify({"msg": "Esta orden ya no se puede autorizar"}), 400
        srow = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (d0["solicitud_id"],))
        if srow and (srow.get("flujo") or "legado") == "nuevo":
            if d0["tipo"] != "orden_compra":
                return jsonify({"msg": "La requisición no se autoriza desde el documento: debe subirse firmada por la jefatura"}), 400
            if not _cp_firmado_vigente(srow["id"], "requisicion_firmada"):
                return jsonify({"msg": "Antes de autorizar la OC, la persona solicitante debe subir la requisición firmada por la jefatura de su área"}), 400
            if not _cp_firmado_vigente(srow["id"], "orden_compra_firmada"):
                return jsonify({"msg": "Antes de autorizar la OC, la persona solicitante debe subir la OC firmada por la jefatura de su área"}), 400
        nuevo = "autorizada"
    elif accion == "enviar":
        if antes not in ("autorizada", "emitida"):
            return jsonify({"msg": "Primero debe estar autorizada"}), 400
        srow = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (d0["solicitud_id"],))
        if srow and (srow.get("flujo") or "legado") == "nuevo" \
                and not _cp_firmado_vigente(srow["id"], "orden_compra_firmada"):
            return jsonify({"msg": "Falta que la persona solicitante suba la OC firmada por la jefatura antes de enviarla"}), 400
        nuevo = "enviada"
    elif accion == "cancelar":
        if antes in ("recibida", "cerrada", "cancelada"):
            return jsonify({"msg": "Este documento ya no se puede cancelar"}), 400
        nuevo = "cancelada"
    elif accion == "cerrar":
        if antes != "recibida":
            return jsonify({"msg": "Solo se puede cerrar un documento recibido"}), 400
        srow = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (d0["solicitud_id"],))
        if srow and (srow.get("flujo") or "legado") == "nuevo":
            if not _cp_oc_firmas_completas(srow):
                faltan = [_cp_oc_firma_label(t) for t in _cp_oc_tipos_requeridos(srow)
                          if not _cp_firmado_vigente(d0["solicitud_id"], t)]
                return jsonify({"msg": "Antes de cerrar, faltan firmas de la OC: " + ", ".join(faltan)}), 400
            if not _cp_firmado_vigente(d0["solicitud_id"], _CP_OC_FINAL):
                return jsonify({"msg": "Antes de cerrar, sube el documento final con todas las firmas"}), 400
        elif not _cp_adjuntos(d0["solicitud_id"]):
            return jsonify({"msg": "Primero sube los documentos firmados que entrega cada área"}), 400
        nuevo = "cerrada"
    else:
        return jsonify({"msg": "Acción no válida"}), 400

    s, err = _cp_claim_gestor(d0["solicitud_id"], username)
    if err:
        return jsonify({"msg": err}), 403
    sets = [f"estado={PH}", f"updated_at={PH}"]
    params = [nuevo, _cp_now()]
    if accion == "autorizar":
        sets += [f"autorizado_por={PH}", f"autorizado_at={PH}"]
        params += [username, _cp_now()]
    q_exec(f"UPDATE compras_documentos SET {', '.join(sets)} WHERE id={PH}", tuple(params) + (did,))
    sid = d0["solicitud_id"]
    s = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (sid,))
    if accion == "cancelar" and s:
        activos = q_one(
            f"SELECT COUNT(*) AS n FROM compras_documentos WHERE solicitud_id={PH} AND estado NOT IN ('cancelada','cerrada')",
            (sid,))["n"]
        if not activos:
            q_exec(f"UPDATE compras_solicitudes SET estado='aprobada', updated_at={PH} WHERE id={PH}",
                   (_cp_now(), sid))
    if accion == "cerrar" and s:
        q_exec(f"UPDATE compras_solicitudes SET estado='cerrada', updated_at={PH} WHERE id={PH}",
               (_cp_now(), sid))
    _cp_event(solicitud_id=sid, documento_id=did, tipo=accion, antes=antes, despues=nuevo,
              por=username, nota=(d.get("nota") or "")[:1000])
    _cp_log(me, username, "compra_documento", f"{d0['folio']} · {antes} -> {nuevo}")
    _cp_notify({"tipo": "documento", "id": did, "estado": nuevo, "folio": d0["folio"],
                "solicitud_id": sid})
    return jsonify(_cp_doc_full(did))


# ---------- documentos firmados (cierre del proceso) ----------
@app.get("/api/compras/solicitudes/<int:sid>/firmados")
@jwt_required()
def cp_list_firmados(sid):
    me, role, _ = _cp_me()
    s = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (sid,))
    if not s:
        return jsonify({"msg": "No existe la solicitud"}), 404
    if not _cp_user_can_view_solicitud(s, me, role):
        return jsonify({"msg": "No tienes acceso a esta solicitud"}), 403
    return jsonify(_cp_adjuntos(sid))


@app.post("/api/compras/solicitudes/<int:sid>/firmados")
@jwt_required()
def cp_upload_firmados(sid):
    me, role, username = _cp_me()
    s = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (sid,))
    if not s:
        return jsonify({"msg": "No existe la solicitud"}), 404
    if s["estado"] in ("cerrada", "cancelada"):
        return jsonify({"msg": "La solicitud ya está cerrada o cancelada"}), 400
    flujo = s.get("flujo") or "legado"
    tipo = (request.form.get("tipo") or "").strip()
    if not tipo:
        if flujo == "legado":
            tipo = "firmado"
        elif _cp_orden_compra(sid):
            if int(s.get("user_id") or 0) == int(me) and not _cp_firmado_vigente(sid, "orden_compra_firmada"):
                tipo = "orden_compra_firmada"
            elif _cp_can_manage(role) and _cp_firmado_vigente(sid, "orden_compra_firmada"):
                tipo = _cp_oc_tipo_siguiente(s)
            else:
                tipo = "orden_compra_firmada"
        else:
            tipo = "requisicion_firmada"
    if flujo == "nuevo" and tipo not in (("requisicion_firmada",) + _CP_OC_TIPOS):
        return jsonify({"msg": "Tipo de documento firmado no válido"}), 400
    if flujo == "legado" and tipo != "firmado":
        return jsonify({"msg": "Esta solicitud usa el flujo anterior de documentos firmados"}), 400
    if flujo == "nuevo" and tipo in _CP_OC_TIPOS \
            and (s.get("cambios_oc_motivo") or "").strip():
        return jsonify({"msg": "Solicitaste cambios en la OC: espera la nueva orden antes de firmar"}), 400
    if tipo == "firmado":
        if not _cp_user_can_sign(s, me, role):
            return jsonify({"msg": "Solo el gestor de compras puede subir los documentos firmados"}), 403
        doc = None
    elif not _cp_user_can_upload(s, me, role, tipo):
        return jsonify({"msg": "No tienes permiso para subir este documento firmado"}), 403
    elif tipo == "requisicion_firmada":
        if s["estado"] in ("aprobada", "en_compra", "recibida", "con_incidencias", "devuelta"):
            return jsonify({"msg": "La requisición ya no se puede reemplazar en esta etapa"}), 400
        doc = _cp_requisicion(sid)
        if not doc:
            _cp_sync_requisicion(sid, s, _cp_items(sid), username)
            doc = _cp_requisicion(sid)
        if not doc:
            return jsonify({"msg": "No se pudo preparar la requisición"}), 500
    else:
        doc = _cp_orden_compra(sid)
        if not doc:
            return jsonify({"msg": "Primero genera la orden de compra"}), 400
        anterior = _cp_oc_firma_anterior_faltante(s, tipo)
        if anterior:
            return jsonify({"msg": f"Primero debe subirse: {anterior}"}), 400
    incoming = [f for f in request.files.getlist("archivos") if f and f.filename]
    single = request.files.get("archivo")
    if single and single.filename:
        incoming.append(single)
    if not incoming:
        return jsonify({"msg": "Selecciona al menos un archivo firmado"}), 400
    if flujo == "nuevo" and len(incoming) > 1:
        return jsonify({"msg": "Sube un solo PDF; si necesitas varias páginas, intégralas en el mismo archivo"}), 400
    if len(incoming) > 5:
        return jsonify({"msg": "Máximo 5 archivos por carga"}), 400
    prepared = []
    for f in incoming:
        data = f.read()
        ok, msg = valid_signed_file(f.filename, data)
        if not ok:
            return jsonify({"msg": f"{f.filename}: {msg}"}), 400
        prepared.append((f, data, Path(f.filename).suffix.lower()))
    now = _cp_now()
    posteriores = ()
    if tipo == "orden_compra_firmada":
        posteriores = _CP_OC_TIPOS[1:]
    elif tipo == "orden_compra_firmada_calidad":
        posteriores = ("orden_compra_firmada_sandra", "orden_compra_firmada_lucio", _CP_OC_FINAL)
    elif tipo == "orden_compra_firmada_sandra":
        posteriores = ("orden_compra_firmada_lucio", _CP_OC_FINAL)
    elif tipo == "orden_compra_firmada_lucio":
        posteriores = (_CP_OC_FINAL,)
    _cp_invalidar_firmados(sid, tuple(posteriores) + (tipo,), por=username)
    saved = []
    for f, data, ext in prepared:
        data = _cp_compress_pdf(data)
        safe = f"{tipo}_{sid}_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}_{secrets.token_hex(4)}{ext}"
        safe = "".join(ch for ch in safe if ch.isalnum() or ch in ("-", "_", "."))
        (UPLOAD_DIR / safe).write_bytes(data)
        nombre = _cp_attachment_display_name(s, doc, tipo)
        aid = q_exec(
            f"""INSERT INTO compras_adjuntos(solicitud_id,documento_id,path,nombre,tipo,subido_por,created_at,vigente)
                VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH})"""
            + (" RETURNING id" if USE_PG else ""),
            (sid, doc["id"] if doc else None, safe, nombre, tipo, username, now,
             True if USE_PG else 1), returning_id=True)
        saved.append({"id": aid, "path": safe, "nombre": nombre,
                      "tipo": tipo, "subido_por": username, "created_at": now})
    estado_notif = s["estado"]
    if tipo == "requisicion_firmada":
        estado_notif = "en_revision"
        sets = [f"estado='en_revision'", f"updated_at={PH}"]
        params = [now]
        if (s.get("tipo_compra") or "normal") == "calidad":
            sets += [f"calidad_estado='pendiente'", f"calidad_por=''", f"calidad_at={PH}", f"calidad_nota=''"]
            params.append(None)
        q_exec(f"UPDATE compras_solicitudes SET {', '.join(sets)} WHERE id={PH}", tuple(params) + (sid,))
        _cp_reset_calidad(sid, por=username)
    _cp_event(solicitud_id=sid, tipo="firmado_" + tipo, antes=s["estado"], despues=estado_notif,
              por=username, nota=f"{len(saved)} archivo(s) · {tipo}")
    _cp_log(me, username, "compra_solicitud",
            f"{s['folio']} · firmado cargado: {tipo} ({len(saved)} archivo(s))")
    destinos = ["compras", "solicitante"]
    etapa = "revision_compras"
    if tipo == "requisicion_firmada" and (s.get("tipo_compra") or "normal") == "calidad":
        destinos = ["calidad", "compras", "solicitante"]
        etapa = "revision_calidad"
    elif tipo == "orden_compra_firmada":
        destinos = ["compras", "solicitante"]
        etapa = "firma_orden_calidad" if (s.get("tipo_compra") or "normal") == "calidad" else "firma_orden_sandra"
        _cp_auto_message(
            sid, s["folio"],
            "La OC ya tiene la firma del jefe de área. La persona solicitante terminó su parte. "
            "Compras debe continuar con las firmas de gestión.",
            para="compras")
        _cp_auto_message(
            sid, s["folio"],
            "Tu parte está lista: la OC ya tiene la firma del jefe de área. "
            "No necesitas subir más documentos; Compras recabará las firmas restantes.",
            para="solicitante")
    elif tipo == "orden_compra_firmada_calidad":
        destinos = ["calidad", "compras", "solicitante"]
        etapa = "firma_orden_sandra"
        _cp_auto_message(
            sid, s["folio"],
            "La firma de Calidad ya está cargada. Continúa la firma de Sandra Limones.",
            para="compras")
    elif tipo == "orden_compra_firmada_sandra":
        destinos = ["compras", "solicitante"]
        etapa = "firma_orden_lucio"
        _cp_auto_message(
            sid, s["folio"],
            "La firma de Sandra Limones ya está cargada. Continúa la firma de Lucío Limones.",
            para="compras")
    elif tipo == "orden_compra_firmada_lucio":
        destinos = ["compras", "solicitante"]
        etapa = "firma_orden_final"
        _cp_auto_message(
            sid, s["folio"],
            "La firma de Lucío Limones ya está cargada. Sube el documento final que integre todas las firmas.",
            para="compras")
    elif tipo == _CP_OC_FINAL:
        destinos = ["solicitante", "compras"]
        etapa = "recepcion"
        _cp_auto_message(
            sid, s["folio"],
            "La OC ya tiene todas las firmas. Pueden continuar con la recepción de los productos; "
            "después de registrar la recepción se podrá cerrar la compra.",
            para="solicitante")
    _cp_notify({"tipo": "solicitud", "id": sid, "estado": estado_notif,
                "folio": s["folio"], "por": username, "accion": "firmado_" + tipo,
                "etapa": etapa, "to": destinos})
    return jsonify(saved), 201


@app.get("/api/compras/firmados/<path:name>")
@jwt_required()
def cp_download_firmado(name):
    me, role, _ = _cp_me()
    safe = Path(name).name
    row = q_one(f"SELECT * FROM compras_adjuntos WHERE path={PH} LIMIT 1", (safe,))
    if not row:
        return jsonify({"msg": "No existe el documento"}), 404
    s = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (row["solicitud_id"],))
    if not _cp_user_can_view_solicitud(s, me, role):
        return jsonify({"msg": "Sin acceso"}), 403
    return send_from_directory(str(UPLOAD_DIR), safe, as_attachment=True,
                               download_name=row.get("nombre") or safe)


@app.delete("/api/compras/firmados/id/<int:aid>")
@jwt_required()
def cp_delete_firmado(aid):
    # Los documentos firmados son evidencia permanente: no se eliminan.
    return jsonify({"msg": "Los documentos firmados no se pueden eliminar"}), 403
    me, role, username = _cp_me()
    row = q_one(f"SELECT * FROM compras_adjuntos WHERE id={PH}", (aid,))
    if not row:
        return jsonify({"msg": "No existe el documento"}), 404
    s = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (row["solicitud_id"],))
    if not s:
        return jsonify({"msg": "No existe la solicitud"}), 404
    tipo = row.get("tipo") or "firmado"
    flujo = s.get("flujo") or "legado"
    if flujo == "nuevo" and s["estado"] in ("cerrada", "cancelada"):
        return jsonify({"msg": "La solicitud ya está cerrada o cancelada"}), 400
    # El solicitante no puede modificar ni quitar un documento firmado:
    # debe subir una nueva versión (que reemplaza la anterior).
    if (flujo == "nuevo" and tipo in ("requisicion_firmada", "orden_compra_firmada")
            and int(s.get("user_id") or 0) == me and not _cp_can_manage(role)):
        return jsonify({"msg": "Los documentos firmados no se pueden quitar. Sube una nueva versión."}), 403
    if flujo == "legado" or tipo == "firmado":
        if not _cp_user_can_sign(s, me, role):
            return jsonify({"msg": "Sin permiso"}), 403
    else:
        if not _cp_user_can_upload(s, me, role, tipo):
            return jsonify({"msg": "Sin permiso"}), 403
        posteriores = {
            "orden_compra_firmada": _CP_OC_TIPOS[1:],
            "orden_compra_firmada_calidad": ("orden_compra_firmada_sandra", "orden_compra_firmada_lucio", _CP_OC_FINAL),
            "orden_compra_firmada_sandra": ("orden_compra_firmada_lucio", _CP_OC_FINAL),
            "orden_compra_firmada_lucio": (_CP_OC_FINAL,),
        }.get(tipo, ())
        if any(_cp_firmado_vigente(int(s["id"]), t) for t in posteriores):
            return jsonify({"msg": "Primero quita las firmas posteriores en orden inverso"}), 400
        if tipo == "requisicion_firmada" and s["estado"] in (
                "aprobada", "en_compra", "recibida", "con_incidencias", "devuelta"):
            return jsonify({"msg": "La requisición ya no se puede eliminar en esta etapa"}), 400
    q_exec(f"DELETE FROM compras_adjuntos WHERE id={PH}", (aid,))
    try:
        (UPLOAD_DIR / row["path"]).unlink(missing_ok=True)
    except Exception:
        pass
    estado_notif = s["estado"]
    if flujo == "nuevo" and tipo == "requisicion_firmada":
        estado_notif = "pendiente"
        sets = [f"estado='pendiente'", f"updated_at={PH}"]
        params = [_cp_now()]
        if (s.get("tipo_compra") or "normal") == "calidad":
            sets += [f"calidad_estado='pendiente'", f"calidad_por=''", f"calidad_at={PH}", f"calidad_nota=''"]
            params.append(None)
        q_exec(f"UPDATE compras_solicitudes SET {', '.join(sets)} WHERE id={PH}", tuple(params) + (int(s["id"]),))
        _cp_reset_calidad(int(s["id"]), por=username)
    _cp_event(solicitud_id=int(s["id"]), tipo="firmado_eliminado", antes=s["estado"], despues=estado_notif,
              por=username, nota=f"{tipo}: {row.get('nombre') or ''}")
    _cp_log(me, username, "compra_solicitud",
            f"{s['folio']} · documento firmado eliminado: {row.get('nombre')}")
    _cp_notify({"tipo": "solicitud", "id": s["id"], "estado": estado_notif, "folio": s["folio"],
                "por": username, "accion": "firmado_eliminado", "to": ["solicitante", "compras"]})
    return jsonify({"ok": True})


# ---------- recepción ----------
@app.post("/api/compras/documentos/<int:did>/recepcion")
@jwt_required()
def cp_recepcion(did):
    me, role, username = _cp_me()
    if not _cp_can_manage(role):
        return jsonify({"msg": "Solo el gestor de compras puede registrar recepciones"}), 403
    d0 = q_one(f"SELECT * FROM compras_documentos WHERE id={PH}", (did,))
    if not d0:
        return jsonify({"msg": "No existe el documento"}), 404
    if d0["estado"] not in ("autorizada", "enviada", "recibida"):
        return jsonify({"msg": "La orden debe estar autorizada o enviada para recibirla"}), 400
    srow = q_one(f"SELECT * FROM compras_solicitudes WHERE id={PH}", (d0["solicitud_id"],))
    if srow and (srow.get("flujo") or "legado") == "nuevo" \
            and not _cp_firmado_vigente(srow["id"], "orden_compra_firmada"):
        return jsonify({"msg": "Falta que la persona solicitante suba la OC firmada por la jefatura antes de recibirla"}), 400
    d = request.get_json(force=True, silent=True) or {}
    estado = d.get("estado") if d.get("estado") in ("completa", "parcial", "con_incidencias") else "completa"
    notas = (d.get("notas") or "").strip()[:2000]
    items_in = d.get("items") or []
    s, err = _cp_claim_gestor(d0["solicitud_id"], username)
    if err:
        return jsonify({"msg": err}), 403
    now = _cp_now()
    rid = q_exec(
        f"""INSERT INTO compras_recepciones(documento_id,solicitud_id,recibido_por,fecha,estado,notas,created_at)
            VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH})""" + (" RETURNING id" if USE_PG else ""),
        (did, d0["solicitud_id"], username, (d.get("fecha") or _cp_today())[:10],
         estado, notas, now), returning_id=True)
    folio = f"REC-{datetime.now(TZ).year}-{int(rid):04d}"
    q_exec(f"UPDATE compras_recepciones SET folio={PH} WHERE id={PH}", (folio, rid))
    incidencias = estado != "completa"
    for it in items_in[:80]:
        item_id = _cp_int(it.get("item_id"), 0) or None
        cant = max(0.0, _cp_num(it.get("cantidad"), 0))
        est = it.get("estado") if it.get("estado") in ("ok", "danado", "faltante", "incorrecto") else "ok"
        if est != "ok":
            incidencias = True
        q_exec(
            f"""INSERT INTO compras_recepcion_items(recepcion_id,item_id,cantidad,estado,notas,created_at)
                VALUES({PH},{PH},{PH},{PH},{PH},{PH})""",
            (rid, item_id, cant, est, (it.get("notas") or "").strip()[:600], now))
    q_exec(f"UPDATE compras_documentos SET estado='recibida', updated_at={PH} WHERE id={PH}",
           (now, did))
    nuevo_sol = "con_incidencias" if incidencias else "recibida"
    q_exec(f"UPDATE compras_solicitudes SET estado={PH}, updated_at={PH} WHERE id={PH}",
           (nuevo_sol, now, d0["solicitud_id"]))
    _cp_event(solicitud_id=d0["solicitud_id"], documento_id=did, tipo="recepcion",
              despues=nuevo_sol, por=username, nota=f"{folio} · {estado}")
    _cp_log(me, username, "compra_recepcion",
            f"{d0['folio']} · {estado} · recibió {username} · {len(items_in)} partida(s)"
            + (f" · notas: {notas[:100]}" if notas else "")
            + (" · con incidencias" if incidencias else ""))
    _cp_notify({"tipo": "recepcion", "id": did, "estado": nuevo_sol,
                "folio": d0["folio"], "solicitud_id": d0["solicitud_id"]})
    return jsonify(_cp_doc_full(did)), 201


# ---------- devoluciones ----------
@app.get("/api/compras/devoluciones")
@jwt_required()
def cp_list_devoluciones():
    me, role, _ = _cp_me()
    mine = (request.args.get("mine") or "").lower() in ("1", "true", "si", "sí")
    conds, params = [], []
    if mine or not _cp_can_view(role):
        conds.append(f"s.user_id={PH}"); params.append(me)
    cond, vals = _cp_filter_estados("dv.estado", request.args.get("estado"), CP_ESTADOS_DEV)
    if cond:
        conds.append(cond); params.extend(vals)
    where = (" WHERE " + " AND ".join(conds)) if conds else ""
    rows = q_all(
        f"""SELECT dv.*, d.folio AS documento_folio, d.tipo AS documento_tipo,
                   s.folio AS solicitud_folio, s.titulo AS solicitud_titulo,
                   COALESCE(u.username,'') AS username
            FROM compras_devoluciones dv
            LEFT JOIN compras_documentos d ON d.id=dv.documento_id
            LEFT JOIN compras_solicitudes s ON s.id=dv.solicitud_id
            LEFT JOIN users u ON u.id=s.user_id
            {where} ORDER BY dv.created_at DESC LIMIT 300""", tuple(params))
    for r in rows:
        r["items"] = q_all(
            f"SELECT dvi.*, di.nombre AS item_nombre FROM compras_devolucion_items dvi "
            f"LEFT JOIN compras_documento_items di ON di.id=dvi.item_id "
            f"WHERE dvi.devolucion_id={PH} ORDER BY dvi.id", (r["id"],))
    return jsonify(rows)


@app.post("/api/compras/documentos/<int:did>/devolucion")
@jwt_required()
def cp_devolucion(did):
    me, role, username = _cp_me()
    if not _cp_can_manage(role):
        return jsonify({"msg": "Solo el gestor de compras puede registrar devoluciones"}), 403
    d0 = q_one(f"SELECT * FROM compras_documentos WHERE id={PH}", (did,))
    if not d0:
        return jsonify({"msg": "No existe el documento"}), 404
    d = request.get_json(force=True, silent=True) or {}
    motivo = (d.get("motivo") or "").strip()[:2000]
    if not motivo:
        return jsonify({"msg": "Escribe el motivo de la devolución"}), 400
    s, err = _cp_claim_gestor(d0["solicitud_id"], username)
    if err:
        return jsonify({"msg": err}), 403
    now = _cp_now()
    did_dev = q_exec(
        f"""INSERT INTO compras_devoluciones(documento_id,solicitud_id,motivo,estado,notas,
            creado_por,created_at,updated_at)
            VALUES({PH},{PH},{PH},'solicitada',{PH},{PH},{PH},{PH})""" +
        (" RETURNING id" if USE_PG else ""),
        (did, d0["solicitud_id"], motivo, (d.get("notas") or "").strip()[:2000],
         username, now, now), returning_id=True)
    folio = f"DEV-{datetime.now(TZ).year}-{int(did_dev):04d}"
    q_exec(f"UPDATE compras_devoluciones SET folio={PH} WHERE id={PH}", (folio, did_dev))
    for it in (d.get("items") or [])[:80]:
        item_id = _cp_int(it.get("item_id"), 0) or None
        cant = max(0.0, _cp_num(it.get("cantidad"), 0))
        q_exec(
            f"""INSERT INTO compras_devolucion_items(devolucion_id,item_id,cantidad,motivo,estado,created_at)
                VALUES({PH},{PH},{PH},{PH},'pendiente',{PH})""",
            (did_dev, item_id, cant, (it.get("motivo") or motivo)[:600], now))
    q_exec(f"UPDATE compras_solicitudes SET estado='devuelta', updated_at={PH} WHERE id={PH}",
           (now, d0["solicitud_id"]))
    _cp_event(solicitud_id=d0["solicitud_id"], documento_id=did, tipo="devolucion",
              despues="devuelta", por=username, nota=f"{folio} · {motivo[:300]}")
    _cp_log(me, username, "compra_devolucion",
            f"{d0['folio']} · {folio} · motivo: {(motivo or '—')[:150]}")
    _cp_notify({"tipo": "devolucion", "id": did_dev, "estado": "solicitada",
                "folio": folio, "solicitud_id": d0["solicitud_id"]})
    return jsonify(_cp_doc_full(did)), 201


@app.post("/api/compras/devoluciones/<int:dv_id>/accion")
@jwt_required()
def cp_accion_devolucion(dv_id):
    me, role, username = _cp_me()
    if not _cp_can_manage(role):
        return jsonify({"msg": "Solo el gestor de compras puede gestionar devoluciones"}), 403
    dv = q_one(f"SELECT * FROM compras_devoluciones WHERE id={PH}", (dv_id,))
    if not dv:
        return jsonify({"msg": "No existe la devolución"}), 404
    d = request.get_json(force=True, silent=True) or {}
    accion = (d.get("accion") or "").strip()
    antes = dv["estado"]
    nuevo = antes
    if accion == "aprobar":
        if antes != "solicitada":
            return jsonify({"msg": "Solo se puede aprobar una devolución solicitada"}), 400
        nuevo = "aprobada"
    elif accion == "rechazar":
        if antes not in ("solicitada", "aprobada"):
            return jsonify({"msg": "Esta devolución ya no se puede rechazar"}), 400
        nuevo = "rechazada"
    elif accion == "enviar":
        if antes != "aprobada":
            return jsonify({"msg": "Primero aprueba la devolución"}), 400
        nuevo = "enviada"
    elif accion == "reembolsar":
        if antes not in ("enviada", "aprobada"):
            return jsonify({"msg": "Primero envía el producto al proveedor"}), 400
        nuevo = "reembolsada"
    elif accion == "cerrar":
        if antes in ("cerrada", "rechazada"):
            return jsonify({"msg": "Esta devolución ya está cerrada"}), 400
        if not _cp_adjuntos(dv["solicitud_id"]):
            return jsonify({"msg": "Primero sube los documentos firmados que entrega cada área"}), 400
        nuevo = "cerrada"
    else:
        return jsonify({"msg": "Acción no válida"}), 400
    s, err = _cp_claim_gestor(dv["solicitud_id"], username)
    if err:
        return jsonify({"msg": err}), 403
    sets = [f"estado={PH}", f"updated_at={PH}"]
    params = [nuevo, _cp_now()]
    if accion in ("aprobar", "rechazar"):
        sets.append(f"aprobado_por={PH}"); params.append(username)
    if d.get("notas"):
        sets.append(f"notas={PH}"); params.append((d.get("notas") or "").strip()[:2000])
    q_exec(f"UPDATE compras_devoluciones SET {', '.join(sets)} WHERE id={PH}", tuple(params) + (dv_id,))
    if dv.get("solicitud_id"):
        if nuevo == "cerrada":
            if dv.get("documento_id"):
                abiertas = q_one(
                    f"""SELECT COUNT(*) AS n FROM compras_devoluciones
                        WHERE documento_id={PH} AND estado NOT IN ('cerrada','rechazada')""",
                    (dv["documento_id"],))["n"]
                if not abiertas:
                    q_exec(
                        f"""UPDATE compras_documentos SET estado='cerrada', updated_at={PH}
                            WHERE id={PH} AND estado='recibida'""",
                        (_cp_now(), dv["documento_id"]))
            q_exec(f"UPDATE compras_solicitudes SET estado='cerrada', updated_at={PH} WHERE id={PH}",
                   (_cp_now(), dv["solicitud_id"]))
        elif nuevo == "rechazada":
            q_exec(f"UPDATE compras_solicitudes SET estado='con_incidencias', updated_at={PH} WHERE id={PH}",
                   (_cp_now(), dv["solicitud_id"]))
    _cp_event(solicitud_id=dv.get("solicitud_id"), documento_id=dv.get("documento_id"),
              tipo=f"devolucion_{accion}", antes=antes, despues=nuevo, por=username,
              nota=(d.get("notas") or "")[:800])
    _cp_log(me, username, "compra_devolucion", f"{dv['folio']} · {antes} -> {nuevo}")
    _cp_notify({"tipo": "devolucion", "id": dv_id, "estado": nuevo, "folio": dv["folio"],
                "solicitud_id": dv.get("solicitud_id")})
    return jsonify({"ok": True, "estado": nuevo})


# ---------- proveedores ----------
@app.get("/api/compras/proveedores")
@jwt_required()
def cp_list_proveedores():
    me, role, _ = _cp_me()
    where, params = _cp_catalog_scope(me, role)
    sql = "SELECT * FROM proveedores"
    if where:
        sql += " WHERE " + where
    sql += " ORDER BY activo DESC, nombre"
    area_filter = None if role in ("admin", "super", "calidad") else _cp_area(me)
    return jsonify(_cp_catalog_enrich_providers(q_all(sql, tuple(params)), area_filter))


@app.post("/api/compras/proveedores")
@jwt_required()
def cp_create_proveedor():
    me, role, username = _cp_me()
    d = request.get_json(force=True, silent=True) or {}
    area, err = _cp_catalog_area_for(me, role, d.get("area"))
    if err:
        return jsonify({"msg": err}), 400
    nombre, err = _cp_text(d.get("nombre"), "El nombre", 3, 180, required=True)
    if err:
        return jsonify({"msg": err}), 400
    rfc, err = _cp_rfc_value(d.get("rfc"))
    if err:
        return jsonify({"msg": err}), 400
    email = (d.get("email") or "").strip().lower()
    if email and not _cp_email_ok(email):
        return jsonify({"msg": "El correo del proveedor no es válido"}), 400
    if len(email) > 120:
        return jsonify({"msg": "El correo no puede exceder 120 caracteres"}), 400
    telefono, err = _cp_phone(d.get("telefono"))
    if err:
        return jsonify({"msg": err}), 400
    razon, err = _cp_text(d.get("razon_social"), "La razón social", 0, 180)
    if err:
        return jsonify({"msg": err}), 400
    domicilio, err = _cp_longtext(d.get("domicilio"), "El domicilio", 400)
    if err:
        return jsonify({"msg": err}), 400
    contacto, err = _cp_text(d.get("contacto"), "El contacto", 0, 120)
    if err:
        return jsonify({"msg": err}), 400
    condiciones, err = _cp_text(d.get("condiciones_pago"), "Las condiciones de pago", 0, 120)
    if err:
        return jsonify({"msg": err}), 400
    existe = q_one(
        f"""SELECT id FROM proveedores
            WHERE LOWER(TRIM(nombre))=LOWER(TRIM({PH})) AND COALESCE(area,'')={PH}""",
        (nombre, area))
    if existe:
        return jsonify({"msg": "Ya existe un proveedor con ese nombre en esta área"}), 409
    if role in ("admin", "super", "calidad"):
        estado = (d.get("calidad_estado") or "aprobado").strip().lower()
        if estado not in CATALOGO_ESTADOS:
            estado = "aprobado"
    else:
        estado = "aprobado"
    nota = _cp_longtext(d.get("calidad_nota"), "La observación de Calidad", 1000)[0] if role in ("admin", "super", "calidad") else ""
    now = _cp_now()
    calidad_por = username if role in ("admin", "super", "calidad") and estado in ("aprobado", "rechazado") else ""
    calidad_at = now if calidad_por else None
    pid = q_exec(
        f"""INSERT INTO proveedores(nombre,rfc,razon_social,domicilio,contacto,email,telefono,
            condiciones_pago,area,calidad_estado,calidad_por,calidad_at,calidad_nota,
            created_by,updated_by,updated_at,activo,created_at)
            VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH})""" +
        (" RETURNING id" if USE_PG else ""),
        (nombre, rfc, razon, domicilio, contacto, email, telefono, condiciones,
         area, estado, calidad_por, calidad_at, nota, username, username, now,
         True, now), returning_id=True)
    _cp_log(me, username, "compra_proveedor", f"alta {nombre} · área {area} · {estado}")
    _cp_event(tipo="catalogo_alta", despues=estado, por=username,
              nota=f"proveedor: {nombre}", area=area)
    _cp_notify({"tipo": "catalogo", "catalogo": "proveedor", "id": pid, "area": area,
                "nombre": nombre, "estado": estado, "por": username})
    return jsonify(q_one(f"SELECT * FROM proveedores WHERE id={PH}", (pid,))), 201


@app.patch("/api/compras/proveedores/<int:pid>")
@jwt_required()
def cp_update_proveedor(pid):
    me, role, username = _cp_me()
    row = q_one(f"SELECT * FROM proveedores WHERE id={PH}", (pid,))
    if not row:
        return jsonify({"msg": "No existe el proveedor"}), 404
    if not _cp_catalog_can_view(row, me, role):
        return jsonify({"msg": "Ese proveedor no pertenece a tu área"}), 403
    if not _cp_catalog_can_edit(row, me, role):
        return jsonify({"msg": "Solo el área dueña, Calidad o administración pueden editar este proveedor"}), 403
    d = request.get_json(force=True, silent=True) or {}
    admin = role in ("admin", "super")
    quality = role == "calidad"
    aprobado = (row.get("calidad_estado") or "") == "aprobado"
    event_area = row.get("area") or ""
    sets, params = [], []

    def add(field, value):
        sets.append(f"{field}={PH}")
        params.append(value)

    if "nombre" in d:
        nombre, err = _cp_text(d.get("nombre"), "El nombre", 3, 180, required=True)
        if err:
            return jsonify({"msg": err}), 400
        if not (admin or quality) and aprobado and nombre != (row.get("nombre") or ""):
            return jsonify({"msg": "El nombre ya fue aprobado; pide a Calidad que lo modifique"}), 403
        add("nombre", nombre)
    if "rfc" in d:
        rfc, err = _cp_rfc_value(d.get("rfc"))
        if err:
            return jsonify({"msg": err}), 400
        if not (admin or quality) and aprobado and rfc != (row.get("rfc") or ""):
            return jsonify({"msg": "El RFC ya fue aprobado; pide a Calidad que lo modifique"}), 403
        add("rfc", rfc)
    if "razon_social" in d:
        razon, err = _cp_text(d.get("razon_social"), "La razón social", 0, 180)
        if err:
            return jsonify({"msg": err}), 400
        if not (admin or quality) and aprobado and razon != (row.get("razon_social") or ""):
            return jsonify({"msg": "La razón social ya fue aprobada; pide a Calidad que la modifique"}), 403
        add("razon_social", razon)
    if "domicilio" in d:
        domicilio, err = _cp_longtext(d.get("domicilio"), "El domicilio", 400)
        if err:
            return jsonify({"msg": err}), 400
        add("domicilio", domicilio)
    if "contacto" in d:
        contacto, err = _cp_text(d.get("contacto"), "El contacto", 0, 120)
        if err:
            return jsonify({"msg": err}), 400
        add("contacto", contacto)
    if "email" in d:
        email = str(d.get("email") or "").strip().lower()
        if email and not _cp_email_ok(email):
            return jsonify({"msg": "El correo del proveedor no es válido"}), 400
        if len(email) > 120:
            return jsonify({"msg": "El correo no puede exceder 120 caracteres"}), 400
        add("email", email)
    if "telefono" in d:
        telefono, err = _cp_phone(d.get("telefono"))
        if err:
            return jsonify({"msg": err}), 400
        add("telefono", telefono)
    if "condiciones_pago" in d:
        condiciones, err = _cp_text(d.get("condiciones_pago"), "Las condiciones de pago", 0, 120)
        if err:
            return jsonify({"msg": err}), 400
        add("condiciones_pago", condiciones)
    if "activo" in d:
        add("activo", bool(d.get("activo")))
    if "area" in d and (admin or quality):
        area, err = _cp_catalog_area_for(me, role, d.get("area"))
        if err:
            return jsonify({"msg": err}), 400
        add("area", area)
        event_area = area
    if "calidad_estado" in d and (admin or quality):
        estado = (d.get("calidad_estado") or "").strip().lower()
        if estado not in CATALOGO_ESTADOS:
            return jsonify({"msg": "Estado de Calidad no válido"}), 400
        add("calidad_estado", estado)
        add("calidad_por", username if estado in ("aprobado", "rechazado") else "")
        add("calidad_at", _cp_now() if estado in ("aprobado", "rechazado") else None)
    if "calidad_nota" in d and (admin or quality):
        nota, err = _cp_longtext(d.get("calidad_nota"), "La observación de Calidad", 1000)
        if err:
            return jsonify({"msg": err}), 400
        add("calidad_nota", nota)
    if not (admin or quality):
        # El área puede corregir un registro rechazado: vuelve a revisión.
        if (row.get("calidad_estado") or "") == "rechazado" and any(
                f in d for f in ("nombre", "rfc", "razon_social")):
            add("calidad_estado", "pendiente")
            add("calidad_por", "")
            add("calidad_at", None)
            add("calidad_nota", "")
    if not sets:
        return jsonify({"msg": "Nada que actualizar"}), 400
    add("updated_by", username)
    add("updated_at", _cp_now())
    q_exec(f"UPDATE proveedores SET {', '.join(sets)} WHERE id={PH}", tuple(params) + (pid,))
    _cp_log(me, username, "compra_proveedor", f"editado #{pid}")
    _cp_event(tipo="catalogo_edicion", por=username,
              nota=f"proveedor: {d.get('nombre') or row.get('nombre') or ''}", area=event_area)
    _cp_notify({"tipo": "catalogo", "catalogo": "proveedor", "id": pid, "area": event_area,
                "nombre": d.get("nombre") or row.get("nombre") or "", "por": username})
    return jsonify(q_one(f"SELECT * FROM proveedores WHERE id={PH}", (pid,)))


@app.delete("/api/compras/proveedores/<int:pid>")
@jwt_required()
def cp_delete_proveedor(pid):
    me, role, username = _cp_me()
    row = q_one(f"SELECT * FROM proveedores WHERE id={PH}", (pid,))
    if not row:
        return jsonify({"msg": "No existe el proveedor"}), 404
    if not _cp_catalog_can_edit(row, me, role):
        return jsonify({"msg": "Solo el área dueña, Calidad o administración pueden desactivar este proveedor"}), 403
    q_exec(f"UPDATE proveedores SET activo={PH}, updated_by={PH}, updated_at={PH} WHERE id={PH}",
           (False, username, _cp_now(), pid))
    _cp_log(me, username, "compra_proveedor", f"desactivado #{pid}")
    _cp_event(tipo="catalogo_baja", por=username,
              nota=f"proveedor: {row.get('nombre') or ''}", area=row.get("area") or "")
    _cp_notify({"tipo": "catalogo", "catalogo": "proveedor", "id": pid,
                "area": row.get("area") or "", "nombre": row.get("nombre") or "",
                "por": username})
    return jsonify({"ok": True})


# ---------- productos certificados por Calidad ----------
@app.get("/api/compras/productos-certificados")
@jwt_required()
def cp_list_productos_certificados():
    me, role, _ = _cp_me()
    where, params = _cp_catalog_scope(me, role)
    sql = "SELECT * FROM compras_productos_certificados"
    if where:
        sql += " WHERE " + where
    sql += " ORDER BY activo DESC, nombre"
    rows = q_all(sql, tuple(params))
    for r in rows:
        if not r.get("calidad_estado"):
            r["calidad_estado"] = "aprobado"
    area_filter = None if role in ("admin", "super", "calidad") else _cp_area(me)
    return jsonify(_cp_catalog_enrich_products(rows, area_filter))


@app.post("/api/compras/productos-certificados")
@jwt_required()
def cp_create_producto_certificado():
    me, role, username = _cp_me()
    d = request.get_json(force=True, silent=True) or {}
    area, err = _cp_catalog_area_for(me, role, d.get("area"))
    if err:
        return jsonify({"msg": err}), 400
    nombre, err = _cp_text(d.get("nombre"), "El nombre del producto", 3, 180, required=True)
    if err:
        return jsonify({"msg": err}), 400
    unidad, err = _cp_text(d.get("unidad") or "pza", "La unidad", 1, 20, required=True)
    if err:
        return jsonify({"msg": err}), 400
    id_fab, err = _cp_text(d.get("id_fabricacion"), "El ID de fabricación", 0, 120)
    if err:
        return jsonify({"msg": err}), 400
    categoria, err = _cp_text(d.get("categoria"), "La categoría", 0, 80)
    if err:
        return jsonify({"msg": err}), 400
    descripcion, err = _cp_longtext(d.get("descripcion"), "La descripción", 1000)
    if err:
        return jsonify({"msg": err}), 400
    requisitos, err = _cp_longtext(d.get("requisitos_calidad"), "Los requisitos de Calidad", 1000)
    if err:
        return jsonify({"msg": err}), 400
    proveedor_id = None
    if d.get("proveedor_id") not in (None, "", 0, "0"):
        proveedor_id = _cp_int(d.get("proveedor_id"), 0)
        prov = q_one(f"SELECT * FROM proveedores WHERE id={PH}", (proveedor_id,))
        if not prov or not _cp_catalog_can_view(prov, me, role):
            return jsonify({"msg": "El proveedor seleccionado no está disponible para tu área"}), 400
        if role not in ("admin", "super", "calidad") and (prov.get("calidad_estado") or "") != "aprobado":
            return jsonify({"msg": "El proveedor debe estar aprobado por Calidad"}), 400
    existe = q_one(
        f"""SELECT id FROM compras_productos_certificados
            WHERE LOWER(TRIM(nombre))=LOWER(TRIM({PH})) AND COALESCE(area,'')={PH}""",
        (nombre, area))
    if existe:
        return jsonify({"msg": "Ya existe un producto con ese nombre en esta área"}), 409
    if role in ("admin", "super", "calidad"):
        estado = (d.get("calidad_estado") or "aprobado").strip().lower()
        if estado not in CATALOGO_ESTADOS:
            estado = "aprobado"
    else:
        estado = "aprobado"
    nota = _cp_longtext(d.get("calidad_nota"), "La observación de Calidad", 1000)[0] if role in ("admin", "super", "calidad") else ""
    now = _cp_now()
    calidad_por = username if role in ("admin", "super", "calidad") and estado in ("aprobado", "rechazado") else ""
    pid = q_exec(
        f"""INSERT INTO compras_productos_certificados(nombre,descripcion,categoria,unidad,
            id_fabricacion,requisitos_calidad,proveedor_id,area,calidad_estado,
            calidad_por,calidad_at,calidad_nota,activo,created_by,updated_by,created_at,updated_at)
            VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH})"""
        + (" RETURNING id" if USE_PG else ""),
        (nombre, descripcion, categoria, unidad, id_fab, requisitos, proveedor_id,
         area, estado, calidad_por, now if calidad_por else None, nota,
         True, username, username, now, now), returning_id=True)
    _cp_log(me, username, "compra_producto_certificado", f"alta {nombre} · área {area} · {estado}")
    _cp_event(tipo="catalogo_alta", despues=estado, por=username,
              nota=f"producto: {nombre}", area=area)
    _cp_notify({"tipo": "catalogo", "catalogo": "producto", "id": pid, "area": area,
                "nombre": nombre, "estado": estado, "por": username})
    return jsonify(q_one(f"SELECT * FROM compras_productos_certificados WHERE id={PH}", (pid,))), 201


@app.patch("/api/compras/productos-certificados/<int:pid>")
@jwt_required()
def cp_update_producto_certificado(pid):
    me, role, username = _cp_me()
    row = q_one(f"SELECT * FROM compras_productos_certificados WHERE id={PH}", (pid,))
    if not row:
        return jsonify({"msg": "No existe el producto"}), 404
    if not _cp_catalog_can_view(row, me, role):
        return jsonify({"msg": "Ese producto no pertenece a tu área"}), 403
    if not _cp_catalog_can_edit(row, me, role):
        return jsonify({"msg": "Solo el área dueña, Calidad o administración pueden editar este producto"}), 403
    d = request.get_json(force=True, silent=True) or {}
    admin = role in ("admin", "super")
    quality = role == "calidad"
    aprobado = (row.get("calidad_estado") or "") == "aprobado"
    event_area = row.get("area") or ""
    sets, params = [], []

    def add(field, value):
        sets.append(f"{field}={PH}")
        params.append(value)

    sensibles = ("nombre", "id_fabricacion", "unidad", "requisitos_calidad")
    cambio_sensible = False
    if "nombre" in d:
        nombre, err = _cp_text(d.get("nombre"), "El nombre del producto", 3, 180, required=True)
        if err:
            return jsonify({"msg": err}), 400
        if not (admin or quality) and aprobado and nombre != (row.get("nombre") or ""):
            return jsonify({"msg": "El nombre ya fue aprobado; pide a Calidad que lo modifique"}), 403
        cambio_sensible = cambio_sensible or nombre != (row.get("nombre") or "")
        existe = q_one(
            f"""SELECT id FROM compras_productos_certificados
                WHERE id<>{PH} AND LOWER(TRIM(nombre))=LOWER(TRIM({PH}))
                  AND COALESCE(area,'')={PH}""",
            (pid, nombre, row.get("area") or ""))
        if existe:
            return jsonify({"msg": "Ya existe un producto con ese nombre en esta área"}), 409
        add("nombre", nombre)
    if "unidad" in d:
        unidad, err = _cp_text(d.get("unidad"), "La unidad", 1, 20, required=True)
        if err:
            return jsonify({"msg": err}), 400
        if not (admin or quality) and aprobado and unidad != (row.get("unidad") or ""):
            return jsonify({"msg": "La unidad ya fue aprobada; pide a Calidad que la modifique"}), 403
        cambio_sensible = cambio_sensible or unidad != (row.get("unidad") or "")
        add("unidad", unidad)
    if "id_fabricacion" in d:
        id_fab, err = _cp_text(d.get("id_fabricacion"), "El ID de fabricación", 0, 120)
        if err:
            return jsonify({"msg": err}), 400
        if not (admin or quality) and aprobado and id_fab != (row.get("id_fabricacion") or ""):
            return jsonify({"msg": "El ID de fabricación ya fue aprobado; pide a Calidad que lo modifique"}), 403
        cambio_sensible = cambio_sensible or id_fab != (row.get("id_fabricacion") or "")
        add("id_fabricacion", id_fab)
    if "requisitos_calidad" in d:
        req, err = _cp_longtext(d.get("requisitos_calidad"), "Los requisitos de Calidad", 1000)
        if err:
            return jsonify({"msg": err}), 400
        if not (admin or quality) and aprobado and req != (row.get("requisitos_calidad") or ""):
            return jsonify({"msg": "Los requisitos ya fueron aprobados; pide a Calidad que los modifique"}), 403
        cambio_sensible = cambio_sensible or req != (row.get("requisitos_calidad") or "")
        add("requisitos_calidad", req)
    if "descripcion" in d:
        desc, err = _cp_longtext(d.get("descripcion"), "La descripción", 1000)
        if err:
            return jsonify({"msg": err}), 400
        add("descripcion", desc)
    if "categoria" in d:
        categoria, err = _cp_text(d.get("categoria"), "La categoría", 0, 80)
        if err:
            return jsonify({"msg": err}), 400
        add("categoria", categoria)
    if "proveedor_id" in d:
        proveedor_id = None
        if d.get("proveedor_id") not in (None, "", 0, "0"):
            proveedor_id = _cp_int(d.get("proveedor_id"), 0)
            prov = q_one(f"SELECT * FROM proveedores WHERE id={PH}", (proveedor_id,))
            if not prov or not _cp_catalog_can_view(prov, me, role):
                return jsonify({"msg": "El proveedor seleccionado no está disponible para tu área"}), 400
            if (not (admin or quality) and (prov.get("calidad_estado") or "") != "aprobado"
                    and proveedor_id != row.get("proveedor_id")):
                return jsonify({"msg": "El proveedor debe estar aprobado por Calidad"}), 400
        add("proveedor_id", proveedor_id)
    if "activo" in d:
        add("activo", bool(d.get("activo")))
    if "area" in d and (admin or quality):
        area, err = _cp_catalog_area_for(me, role, d.get("area"))
        if err:
            return jsonify({"msg": err}), 400
        add("area", area)
        event_area = area
    if "calidad_estado" in d and (admin or quality):
        estado = (d.get("calidad_estado") or "").strip().lower()
        if estado not in CATALOGO_ESTADOS:
            return jsonify({"msg": "Estado de Calidad no válido"}), 400
        add("calidad_estado", estado)
        add("calidad_por", username if estado in ("aprobado", "rechazado") else "")
        add("calidad_at", _cp_now() if estado in ("aprobado", "rechazado") else None)
    if "calidad_nota" in d and (admin or quality):
        nota, err = _cp_longtext(d.get("calidad_nota"), "La observación de Calidad", 1000)
        if err:
            return jsonify({"msg": err}), 400
        add("calidad_nota", nota)
    if (admin or quality) and cambio_sensible and "calidad_estado" not in d:
        add("calidad_por", username)
        add("calidad_at", _cp_now())
    if not (admin or quality):
        # El área puede corregir un producto rechazado: vuelve a revisión.
        if (row.get("calidad_estado") or "") == "rechazado" and cambio_sensible:
            add("calidad_estado", "pendiente")
            add("calidad_por", "")
            add("calidad_at", None)
            add("calidad_nota", "")
    if not sets:
        return jsonify({"msg": "Nada que actualizar"}), 400
    add("updated_by", username)
    add("updated_at", _cp_now())
    q_exec(f"UPDATE compras_productos_certificados SET {', '.join(sets)} WHERE id={PH}",
           tuple(params) + (pid,))
    _cp_log(me, username, "compra_producto_certificado", f"editado #{pid}")
    _cp_event(tipo="catalogo_edicion", por=username,
              nota=f"producto: {d.get('nombre') or row.get('nombre') or ''}", area=event_area)
    _cp_notify({"tipo": "catalogo", "catalogo": "producto", "id": pid, "area": event_area,
                "nombre": d.get("nombre") or row.get("nombre") or "", "por": username})
    return jsonify(q_one(f"SELECT * FROM compras_productos_certificados WHERE id={PH}", (pid,)))


@app.delete("/api/compras/productos-certificados/<int:pid>")
@jwt_required()
def cp_delete_producto_certificado(pid):
    me, role, username = _cp_me()
    row = q_one(f"SELECT * FROM compras_productos_certificados WHERE id={PH}", (pid,))
    if not row:
        return jsonify({"msg": "No existe el producto"}), 404
    if not _cp_catalog_can_edit(row, me, role):
        return jsonify({"msg": "Solo el área dueña, Calidad o administración pueden desactivar este producto"}), 403
    q_exec(f"UPDATE compras_productos_certificados SET activo={PH}, updated_by={PH}, updated_at={PH} WHERE id={PH}",
           (False, username, _cp_now(), pid))
    _cp_log(me, username, "compra_producto_certificado", f"desactivado #{pid}")
    _cp_event(tipo="catalogo_baja", por=username,
              nota=f"producto: {row.get('nombre') or ''}", area=row.get("area") or "")
    _cp_notify({"tipo": "catalogo", "catalogo": "producto", "id": pid,
                "area": row.get("area") or "", "nombre": row.get("nombre") or "",
                "por": username})
    return jsonify({"ok": True})


# ---------- autorización de Calidad del catálogo ----------
def _cp_catalog_quality_action(table, pid, catalogo):
    me, role, username = _cp_me()
    if role not in ("calidad", "admin", "super"):
        return jsonify({"msg": "Solo Calidad o administración pueden autorizar el catálogo"}), 403
    row = q_one(f"SELECT * FROM {table} WHERE id={PH}", (pid,))
    if not row:
        return jsonify({"msg": "No existe el registro"}), 404
    d = request.get_json(force=True, silent=True) or {}
    accion = (d.get("accion") or "").strip().lower()
    mapa = {"aprobar": "aprobado", "rechazar": "rechazado", "reenviar": "pendiente", "pendiente": "pendiente"}
    nuevo = mapa.get(accion)
    if not nuevo:
        return jsonify({"msg": "Acción de Calidad no válida"}), 400
    nota, err = _cp_longtext(d.get("nota"), "La observación", 1000)
    if err:
        return jsonify({"msg": err}), 400
    if nuevo == "rechazado" and not nota:
        return jsonify({"msg": "Explica el motivo del rechazo"}), 400
    ahora = _cp_now() if nuevo in ("aprobado", "rechazado") else None
    if not nota and nuevo != "pendiente":
        nota = row.get("calidad_nota") or ""
    q_exec(
        f"""UPDATE {table} SET calidad_estado={PH}, calidad_por={PH}, calidad_at={PH},
            calidad_nota={PH}, updated_by={PH}, updated_at={PH} WHERE id={PH}""",
        (nuevo, username if ahora else "", ahora, nota, username, _cp_now(), pid))
    nombre = row.get("nombre") or ""
    _cp_log(me, username, f"catalogo_{catalogo}_calidad", f"{nombre} · {nuevo}")
    _cp_event(tipo=f"catalogo_calidad_{nuevo}", antes=row.get("calidad_estado") or "",
              despues=nuevo, por=username, nota=f"{catalogo}: {nombre}" + (f" · {nota}" if nota else ""),
              area=row.get("area") or "")
    _cp_notify({"tipo": "catalogo", "catalogo": catalogo, "id": pid, "area": row.get("area") or "",
                "nombre": nombre, "estado": nuevo, "por": username,
                "solicitud_id": None, "folio": ""})
    return jsonify(q_one(f"SELECT * FROM {table} WHERE id={PH}", (pid,)))


@app.post("/api/compras/proveedores/<int:pid>/calidad")
@jwt_required()
def cp_calidad_proveedor(pid):
    return _cp_catalog_quality_action("proveedores", pid, "proveedor")


@app.post("/api/compras/productos-certificados/<int:pid>/calidad")
@jwt_required()
def cp_calidad_producto(pid):
    return _cp_catalog_quality_action("compras_productos_certificados", pid, "producto")


# ---------- inventario por área ----------
@app.get("/api/inventario")
@jwt_required()
def inv_list():
    me, role, _ = _cp_me()
    q = (request.args.get("q") or "").strip()
    cat = (request.args.get("categoria") or "").strip()
    area_req = (request.args.get("area") or "").strip()
    bajo = _cp_bool(request.args.get("bajo"))
    conds, params = [], []
    if q:
        like = f"%{q.lower()}%"
        conds.append(
            "(LOWER(nombre) LIKE {ph} OR LOWER(descripcion) LIKE {ph} OR "
            "LOWER(categoria) LIKE {ph} OR LOWER(lote) LIKE {ph} OR "
            "LOWER(ubicacion) LIKE {ph} OR LOWER(proveedor) LIKE {ph})".format(ph=PH))
        params.extend([like] * 6)
    if cat:
        conds.append(f"LOWER(categoria)=LOWER({PH})")
        params.append(cat)
    sql = "SELECT * FROM inventario_items"
    if conds:
        sql += " WHERE " + " AND ".join(conds)
    sql += " ORDER BY area, nombre"
    rows = [_inv_row(r) for r in q_all(sql, tuple(params))]
    rows = [r for r in rows if _inv_visible(r, me, role)]
    if area_req and role in ("admin", "super"):
        rows = [r for r in rows if (r.get("area") or "") == area_req]
    if bajo:
        rows = [r for r in rows if r.get("bajo_stock")]
    if role not in ("admin", "super"):
        own = _cp_area(me)
        rows.sort(key=lambda r: (0 if (r.get("area") or "") == own else 1,
                                 (r.get("area") or "").lower(), (r.get("nombre") or "").lower()))
    return jsonify(rows)


@app.post("/api/inventario")
@jwt_required()
def inv_create():
    me, role, username = _cp_me()
    d = request.get_json(force=True, silent=True) or {}
    area, err = _inv_area_for(me, role, d.get("area"))
    if err:
        return jsonify({"msg": err}), 400
    nombre, err = _cp_text(d.get("nombre"), "El nombre del artículo", 2, 160, required=True)
    if err:
        return jsonify({"msg": err}), 400
    descripcion, err = _cp_longtext(d.get("descripcion"), "La descripción", 1000)
    if err:
        return jsonify({"msg": err}), 400
    categoria, err = _cp_text(d.get("categoria"), "La categoría", 0, 80)
    if err:
        return jsonify({"msg": err}), 400
    unidad, err = _cp_text(d.get("unidad") or "pza", "La unidad", 1, 20, required=True)
    if err:
        return jsonify({"msg": err}), 400
    ubicacion, err = _cp_text(d.get("ubicacion"), "La ubicación", 0, 120)
    if err:
        return jsonify({"msg": err}), 400
    lote, err = _cp_text(d.get("lote"), "El lote", 0, 80)
    if err:
        return jsonify({"msg": err}), 400
    proveedor, err = _cp_text(d.get("proveedor"), "El proveedor", 0, 160)
    if err:
        return jsonify({"msg": err}), 400
    notas, err = _cp_longtext(d.get("notas"), "Las notas", 1000)
    if err:
        return jsonify({"msg": err}), 400
    caducidad, err = _inv_date(d.get("caducidad"))
    if err:
        return jsonify({"msg": err}), 400
    cantidad = _cp_num(d.get("cantidad"), 0)
    minimo = _cp_num(d.get("minimo"), 0)
    costo = _cp_num(d.get("costo_unitario"), 0)
    if cantidad < 0:
        return jsonify({"msg": "La cantidad no puede ser negativa"}), 400
    if minimo < 0:
        return jsonify({"msg": "El mínimo no puede ser negativo"}), 400
    if costo < 0:
        return jsonify({"msg": "El costo no puede ser negativo"}), 400
    extras = []
    for raw in _inv_extra_list(d.get("areas_extra")):
        clean, err = _cp_text(raw, "El área involucrada", 2, 80)
        if err:
            return jsonify({"msg": err}), 400
        if clean != area and clean not in extras:
            extras.append(clean)
    now = _cp_now()
    pid = q_exec(
        f"""INSERT INTO inventario_items(area,nombre,descripcion,categoria,cantidad,unidad,
            minimo,ubicacion,lote,caducidad,costo_unitario,proveedor,areas_extra,notas,
            created_by,updated_by,created_at,updated_at)
            VALUES({PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH},{PH})"""
        + (" RETURNING id" if USE_PG else ""),
        (area, nombre, descripcion, categoria, cantidad, unidad, minimo, ubicacion, lote,
         caducidad, costo, proveedor, _inv_extra_dump(extras), notas, username, username,
         now, now), returning_id=True)
    _cp_log(me, username, "inventario_alta", f"{nombre} · {area} · {cantidad} {unidad}")
    _cp_event(tipo="inventario_alta", despues="alta", por=username,
              nota=f"{nombre} · {cantidad} {unidad}", area=area, areas_extra=extras)
    _cp_notify({"tipo": "inventario", "accion": "alta", "id": pid, "area": area,
                "areas_extra": extras, "nombre": nombre, "por": username})
    return jsonify(_inv_row(q_one(f"SELECT * FROM inventario_items WHERE id={PH}", (pid,)))), 201


@app.patch("/api/inventario/<int:pid>")
@jwt_required()
def inv_update(pid):
    me, role, username = _cp_me()
    row = q_one(f"SELECT * FROM inventario_items WHERE id={PH}", (pid,))
    if not row:
        return jsonify({"msg": "No existe el artículo"}), 404
    if not _inv_visible(row, me, role):
        return jsonify({"msg": "Ese artículo no pertenece a tu área"}), 403
    if not _inv_can_edit(row, me, role):
        return jsonify({"msg": "Solo el área dueña o administración pueden editar este artículo"}), 403
    d = request.get_json(force=True, silent=True) or {}
    admin = role in ("admin", "super")
    sets, params = [], []

    def add(field, value):
        sets.append(f"{field}={PH}")
        params.append(value)

    area = (row.get("area") or "").strip()
    if "area" in d and admin:
        area, err = _inv_area_for(me, role, d.get("area"))
        if err:
            return jsonify({"msg": err}), 400
        add("area", area)
    if "nombre" in d:
        nombre, err = _cp_text(d.get("nombre"), "El nombre del artículo", 2, 160, required=True)
        if err:
            return jsonify({"msg": err}), 400
        add("nombre", nombre)
    if "descripcion" in d:
        v, err = _cp_longtext(d.get("descripcion"), "La descripción", 1000)
        if err:
            return jsonify({"msg": err}), 400
        add("descripcion", v)
    if "categoria" in d:
        v, err = _cp_text(d.get("categoria"), "La categoría", 0, 80)
        if err:
            return jsonify({"msg": err}), 400
        add("categoria", v)
    if "unidad" in d:
        v, err = _cp_text(d.get("unidad"), "La unidad", 1, 20, required=True)
        if err:
            return jsonify({"msg": err}), 400
        add("unidad", v)
    if "ubicacion" in d:
        v, err = _cp_text(d.get("ubicacion"), "La ubicación", 0, 120)
        if err:
            return jsonify({"msg": err}), 400
        add("ubicacion", v)
    if "lote" in d:
        v, err = _cp_text(d.get("lote"), "El lote", 0, 80)
        if err:
            return jsonify({"msg": err}), 400
        add("lote", v)
    if "proveedor" in d:
        v, err = _cp_text(d.get("proveedor"), "El proveedor", 0, 160)
        if err:
            return jsonify({"msg": err}), 400
        add("proveedor", v)
    if "notas" in d:
        v, err = _cp_longtext(d.get("notas"), "Las notas", 1000)
        if err:
            return jsonify({"msg": err}), 400
        add("notas", v)
    if "caducidad" in d:
        v, err = _inv_date(d.get("caducidad"))
        if err:
            return jsonify({"msg": err}), 400
        add("caducidad", v)
    for field, label in (("cantidad", "La cantidad"), ("minimo", "El mínimo"),
                         ("costo_unitario", "El costo")):
        if field in d:
            v = _cp_num(d.get(field), 0)
            if v < 0:
                return jsonify({"msg": f"{label} no puede ser negativo"}), 400
            add(field, v)
    extras_evt = _inv_extra_list(row.get("areas_extra"))
    if "areas_extra" in d:
        extras = []
        for raw in _inv_extra_list(d.get("areas_extra")):
            clean, err = _cp_text(raw, "El área involucrada", 2, 80)
            if err:
                return jsonify({"msg": err}), 400
            if clean != area and clean not in extras:
                extras.append(clean)
        extras_evt = extras
        add("areas_extra", _inv_extra_dump(extras))
    if not sets:
        return jsonify({"msg": "Nada que actualizar"}), 400
    add("updated_by", username)
    add("updated_at", _cp_now())
    q_exec(f"UPDATE inventario_items SET {', '.join(sets)} WHERE id={PH}",
           tuple(params) + (pid,))
    _cp_log(me, username, "inventario_edicion", f"#{pid} {row.get('nombre') or ''}")
    extras_evt = [x for x in extras_evt if x != area]
    _cp_event(tipo="inventario_edicion", despues="edicion", por=username,
              nota=(d.get("nombre") or row.get("nombre") or ""), area=area, areas_extra=extras_evt)
    _cp_notify({"tipo": "inventario", "accion": "edicion", "id": pid, "area": area,
                "areas_extra": extras_evt, "nombre": (d.get("nombre") or row.get("nombre") or ""),
                "por": username})
    return jsonify(_inv_row(q_one(f"SELECT * FROM inventario_items WHERE id={PH}", (pid,))))


@app.delete("/api/inventario/<int:pid>")
@jwt_required()
def inv_delete(pid):
    me, role, username = _cp_me()
    row = q_one(f"SELECT * FROM inventario_items WHERE id={PH}", (pid,))
    if not row:
        return jsonify({"msg": "No existe el artículo"}), 404
    if not _inv_visible(row, me, role):
        return jsonify({"msg": "Ese artículo no pertenece a tu área"}), 403
    if not _inv_can_edit(row, me, role):
        return jsonify({"msg": "Solo el área dueña o administración pueden eliminar este artículo"}), 403
    q_exec(f"DELETE FROM inventario_items WHERE id={PH}", (pid,))
    _cp_log(me, username, "inventario_baja", f"{row.get('nombre') or ''} · {row.get('area') or ''}")
    extras_evt = _inv_extra_list(row.get("areas_extra"))
    _cp_event(tipo="inventario_baja", despues="baja", por=username,
              nota=row.get("nombre") or "", area=row.get("area") or "", areas_extra=extras_evt)
    _cp_notify({"tipo": "inventario", "accion": "baja", "id": pid,
                "area": row.get("area") or "", "areas_extra": extras_evt,
                "nombre": row.get("nombre") or "", "por": username})
    return jsonify({"ok": True})


# ---------- datos de la empresa ----------
@app.get("/api/compras/empresa")
@jwt_required()
def cp_get_empresa():
    return jsonify(_cp_empresa_public())


@app.patch("/api/compras/empresa")
@jwt_required()
def cp_update_empresa():
    me, role, username = _cp_me()
    if not _cp_can_manage(role):
        return jsonify({"msg": "Solo el gestor de compras puede editar los datos fiscales"}), 403
    d = request.get_json(force=True, silent=True) or {}
    if "rfc" in d:
        d["rfc"] = _cp_rfc(d.get("rfc"))
        if not _CP_RFC_RE.match(d["rfc"]):
            return jsonify({"msg": "El RFC de la empresa no tiene un formato válido"}), 400
    if "email" in d and d.get("email"):
        d["email"] = str(d.get("email") or "").strip().lower()
        if not _cp_email_ok(d["email"]):
            return jsonify({"msg": "El correo de la empresa no es válido"}), 400
    if "telefono" in d:
        d["telefono"] = _cp_digits(d.get("telefono"), 10)
    sets, params = [], []
    for f, lim in (("nombre", 180), ("rfc", 13), ("razon_social", 220),
                   ("domicilio", 400), ("telefono", 10), ("email", 140), ("logo", 300)):
        if f in d:
            sets.append(f"{f}={PH}"); params.append((d.get(f) or "").strip()[:lim])
    if not sets:
        return jsonify({"msg": "Nada que actualizar"}), 400
    sets.append(f"updated_at={PH}"); params.append(_cp_now())
    q_exec(f"UPDATE compras_empresa SET {', '.join(sets)} WHERE id=1", tuple(params))
    _cp_log(me, username, "compra_empresa", "datos fiscales actualizados")
    return jsonify(_cp_empresa_public())


if __name__ == "__main__":
    init_db()
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "5000"))
    print(f"Sylpack Tickets en http://{host}:{port} db={'postgres' if USE_PG else 'sqlite'}")
    try:
        from waitress import serve
        socketio.run(app, host=host, port=port)
    except Exception:
        app.run(host=host, port=port)
