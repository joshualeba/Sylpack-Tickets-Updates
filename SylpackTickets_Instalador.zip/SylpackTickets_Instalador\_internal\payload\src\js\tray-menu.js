/* Sylpack Tickets — menú de bandeja (ventana propia)
   El backend abre esta ventana junto al cursor. Se oculta al perder el foco,
   con Escape o al elegir una opción. */
(() => {
  "use strict";
  const api = () => (window.pywebview && window.pywebview.api) || null;
  const items = Array.from(document.querySelectorAll("[data-act]"));

  // Rol mostrado en la cabecera ("Sede · 192.168.1.100" / "Cliente · ...").
  const raw = String(window.SYLPACK_ROLE || "").trim();
  let sub = "Sede";
  if (/^cliente/i.test(raw)) {
    const m = raw.match(/->\s*(.+)$/);
    sub = "Cliente" + (m ? " · " + m[1].trim() : "");
  } else {
    const m = raw.match(/\(([^()]+)\)/);
    sub = "Sede" + (m ? " · " + m[1].trim() : "");
  }
  const roleEl = document.getElementById("role");
  if (roleEl) {
    roleEl.textContent = sub;
    roleEl.title = raw || sub;
  }

  let shownAt = 0;
  let closeTimer = 0;
  let choosing = false;

  function close() {
    const a = api();
    if (a && a.close) a.close();
  }

  function pick(act) {
    if (choosing) return;
    choosing = true;
    const a = api();
    if (a && a.pick) a.pick(act);
    else close();
  }

  function focusItem(index) {
    const item = items[(index + items.length) % items.length];
    if (item) item.focus();
  }

  items.forEach((btn, index) => {
    btn.addEventListener("click", () => pick(btn.dataset.act));
    btn.addEventListener("mouseenter", () => btn.focus());
    btn.addEventListener("keydown", (e) => {
      if (e.key === "ArrowDown" || e.key === "ArrowUp" || e.key === "Home" || e.key === "End") {
        e.preventDefault();
        if (e.key === "Home") focusItem(0);
        else if (e.key === "End") focusItem(items.length - 1);
        else focusItem(index + (e.key === "ArrowDown" ? 1 : -1));
      } else if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        pick(btn.dataset.act);
      }
    });
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      close();
    }
  });

  // Al perder el foco (clic fuera) se cierra; si el foco vuelve, se cancela.
  window.addEventListener("blur", () => {
    clearTimeout(closeTimer);
    if (Date.now() - shownAt < 450) return;
    closeTimer = setTimeout(close, 80);
  });
  window.addEventListener("focus", () => {
    clearTimeout(closeTimer);
    shownAt = Date.now();
  });

  // --- Ajuste a la pantalla / DPI -------------------------------------------
  // La ventana se crea con un tamaño base. En pantallas al 125%, 150%... el
  // contenido HTML se dibuja más grande y puede quedar recortado; aquí le
  // pedimos al backend el tamaño exacto (en píxeles físicos).
  function reportSize() {
    const card = document.getElementById("card");
    const a = api();
    if (!card || !a || !a.menu_size) return;
    // Solo avisamos si el contenido NO cabe. Así no crece sin control.
    const overW = card.scrollWidth - card.clientWidth;
    const overH = card.scrollHeight - card.clientHeight;
    if (overW <= 1 && overH <= 1) return;
    const dpr = window.devicePixelRatio || 1;
    const r = card.getBoundingClientRect();
    const w = Math.ceil((r.width + 10 + Math.max(0, overW) + 4) * dpr);
    const h = Math.ceil((r.height + 10 + Math.max(0, overH) + 4) * dpr);
    try { a.menu_size(w, h); } catch (_) { /* backend viejo */ }
  }
  window.__menuSize = reportSize;

  // El backend llama a esto cada vez que muestra el menú.
  window.__menuReset = () => {
    choosing = false;
    shownAt = Date.now();
    focusItem(0);
    requestAnimationFrame(reportSize);
  };

  // La ventana nace oculta; al mostrarse el backend la marca como tool window.
  const markReady = () => {
    const a = api();
    if (a && a.ready) a.ready();
    requestAnimationFrame(reportSize);
  };
  window.addEventListener("pywebviewready", markReady);
  if (window.pywebview) markReady();
  window.addEventListener("DOMContentLoaded", () => { shownAt = Date.now(); });
})();
