/* Campana global Sylpack: vista previa de mensajes y reportes nuevos.
   Lectura por notificación: cada aviso se marca como leído al abrirlo.
   "Marcar leídas" se habilita solo cuando hay pendientes y vuelve a
   deshabilitarse al no quedar ninguno; se reactiva con avisos nuevos. */
(() => {
  const KEY = "sylpack-notif-read-ids";
  const KEY_DEL = "sylpack-notif-deleted-ids";
  const OLD = "sylpack-notif-read";
  const MAX_IDS = 500;
  let readSet = new Set();
  let deletedSet = new Set();
  let migrated = false;
  let cache = [];
  let lastUnread = -1;

  try {
    const arr = JSON.parse(localStorage.getItem(KEY) || "[]");
    if (Array.isArray(arr)) arr.forEach(x => readSet.add(String(x)));
  } catch {}
  // Los avisos "borrados" se ocultan de la bandeja; el servidor los regenera,
  // por eso el borrado se recuerda en este equipo.
  try {
    const del = JSON.parse(localStorage.getItem(KEY_DEL) || "[]");
    if (Array.isArray(del)) del.forEach(x => deletedSet.add(String(x)));
  } catch {}

  const ID = n => (n && n.id != null ? String(n.id) : null);

  function persist() {
    try {
      let arr = Array.from(readSet);
      if (arr.length > MAX_IDS) { arr = arr.slice(arr.length - MAX_IDS); readSet = new Set(arr); }
      localStorage.setItem(KEY, JSON.stringify(arr));
      let del = Array.from(deletedSet);
      if (del.length > MAX_IDS) { del = del.slice(del.length - MAX_IDS); deletedSet = new Set(del); }
      localStorage.setItem(KEY_DEL, JSON.stringify(del));
    } catch {}
  }

  function isDeleted(n) {
    const k = ID(n);
    return k != null && deletedSet.has(k);
  }

  function legacyLast() {
    try { return localStorage.getItem(OLD) || ""; } catch { return ""; }
  }

  function isUnread(n) {
    const k = ID(n);
    if (k != null) return !readSet.has(k);
    const last = legacyLast();
    return !last || String(n.created_at) > last;
  }

  function migrate() {
    if (migrated) return;
    migrated = true;
    const old = legacyLast();
    if (!old) return;
    let changed = false;
    cache.forEach(n => {
      const k = ID(n);
      if (k && String(n.created_at) <= old && !readSet.has(k)) { readSet.add(k); changed = true; }
    });
    if (changed) persist();
    try { localStorage.removeItem(OLD); } catch {}
  }

  function fmtHora(iso) {
    const d = new Date(iso), p = n => String(n).padStart(2, "0");
    return `${p(d.getHours())}:${p(d.getMinutes())}`;
  }
  function rel(iso) {
    const m = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
    if (m < 1) return "ahora mismo";
    if (m < 60) return `hace ${m} min`;
    const h = Math.floor(m / 60);
    if (h < 24) return `hace ${h} h`;
    return `hace ${Math.floor(h / 24)} d`;
  }
  const ICONS = {
    chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
    report: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="13" y2="17"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.1V12a10 10 0 1 1-5.9-9.1"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
    cart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/></svg>',
    delete: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>'
  };
  const KIND = {
    mensaje: { t: "Mensaje", c: "k-msg", icon: ICONS.chat },
    ticket: { t: "Reporte nuevo", c: "k-ticket", icon: ICONS.report },
    cierre: { t: "Reporte cerrado", c: "k-close", icon: ICONS.check },
    compra_mensaje: { t: "Compra · mensaje", c: "k-msg", icon: ICONS.chat },
    compra_solicitud: { t: "Solicitud de compra", c: "k-buy", icon: ICONS.cart },
    compra_evento: { t: "Compra · novedad", c: "k-buy", icon: ICONS.check },
    catalogo: { t: "Catálogo", c: "k-buy", icon: ICONS.report },
    inventario: { t: "Inventario", c: "k-buy", icon: ICONS.report }
  };
  const EST_SOL = {
    pendiente: ["Pendiente", "warn"], en_revision: ["En revisión", "warn"],
    cambios_solicitados: ["Cambios", "danger"], aprobada: ["Aprobada", "ok"],
    rechazada: ["Rechazada", "danger"], en_compra: ["En compra", ""],
    recibida: ["Recibida", "ok"], con_incidencias: ["Incidencia", "danger"],
    devuelta: ["Devuelta", "danger"], cerrada: ["Cerrada", "ok"], cancelada: ["Cancelada", ""]
  };

  async function fetchItems() {
    const token = localStorage.getItem("access") || sessionStorage.getItem("access");
    if (!token) return [];
    try {
      const r = await fetch(`${API_BASE}/api/notificaciones?limit=20`, {
        headers: { Authorization: "Bearer " + token }, cache: "no-store"
      });
      if (!r.ok) return [];
      return await r.json();
    } catch { return []; }
  }

  function render(items) {
    const list = document.getElementById("notifList");
    const badge = document.getElementById("notifBadge");
    const btn = document.getElementById("notifRead");
    const clearBtn = document.getElementById("notifClear");
    const countLbl = document.getElementById("notifCountLabel");
    if (!list) return;
    // La bandeja muestra los últimos avisos: los no leídos resaltados y los
    // leídos atenuados. Solo "Borrar" los quita de la lista.
    const visibles = items.filter(n => !isDeleted(n));
    const pendientes = visibles.filter(isUnread);
    const unread = pendientes.length;

    if (badge) {
      badge.style.display = unread ? "" : "none";
      badge.textContent = unread > 9 ? "9+" : unread;
    }
    if (btn) {
      btn.disabled = unread === 0;
      btn.textContent = unread === 0 ? "Todo leído" : "Marcar leídas";
    }
    if (clearBtn) {
      clearBtn.disabled = visibles.length === 0;
      clearBtn.title = visibles.length ? "Eliminar todas las notificaciones de la bandeja" : "No hay notificaciones por eliminar";
    }
    if (countLbl) countLbl.textContent = unread ? `${unread} sin leer` : "Al día";

    list.innerHTML = visibles.length ? visibles.map((n, ix) => {
      const k = KIND[n.kind] || KIND.mensaje;
      const leida = !isUnread(n);
      const rawTitle = String(n.titulo || "");
      const title = n.compras && n.folio && rawTitle.startsWith(n.folio + " · ")
        ? rawTitle.slice(n.folio.length + 3) : rawTitle;
      const folio = n.compras ? esc(n.folio || "Compra") : (n.ticket_id != null ? "#" + esc(n.ticket_id) : "");
      const st = n.compras && n.estado && EST_SOL[n.estado] ? EST_SOL[n.estado] : null;
      const text = String(n.texto || "");
      const summary = [k.t, title, text].filter(Boolean).join(" · ");
      // El contenedor es un div con role=button: así el botón de eliminar
      // puede vivir dentro sin anidar dos <button> (HTML inválido que
      // recortaba el contenido de la notificación).
      return `<div class="nitem${leida ? " is-read" : " fresh"}" data-nix="${ix}" role="button" tabindex="0" aria-label="${esc((leida ? "Leída: " : "") + summary)}">
        <span class="nico ${k.c}" aria-hidden="true">${k.icon}</span>
        <span class="ntxt">
          <span class="nhead">
            <span class="nkind ${k.c}">${esc(k.t)}</span>
            ${folio ? `<span class="nfolio">${folio}</span>` : ""}
            ${st ? `<span class="nstat ${st[1]}">${esc(st[0])}</span>` : ""}
            <span class="nhora">${fmtHora(n.created_at)}</span>
            ${leida ? `<span class="nread" title="Marcada como leída">Leída</span>` : ""}
          </span>
          <span class="ntitle">${esc(title)}</span>
          ${text ? `<span class="nmsg">${esc(text)}</span>` : ""}
          <span class="nmeta">
            <span class="nby">por <b>${esc(n.de || "Sistema")}</b></span>
            ${n.tiene_imagen ? `<span class="nimg">Imagen</span>` : ""}
            <span class="nrel">${rel(n.created_at)}</span>
          </span>
        </span>
        <button class="ndel" type="button" data-delix="${ix}" aria-label="Eliminar notificación" title="Eliminar esta notificación">${ICONS.delete}</button>
      </div>`;
    }).join("") : `<div class="nempty"><div class="nempty-ico">${ICONS.check}</div><b>Todo al día</b>Aquí verás los mensajes, reportes y solicitudes nuevas.</div>`;

    // Click en notificación para abrir
    list.querySelectorAll("[data-nix]").forEach(b => {
      b.onclick = (e) => {
        // No hacer nada si se clickeó el botón eliminar
        if (e.target.closest(".ndel")) return;
        const n = visibles[Number(b.dataset.nix)];
        if (!n) return;
        markItems([n]);
        render(cache);
        hide();
        if (n.catalogo && window.SylpackNotif.onOpenCatalogo) {
          window.SylpackNotif.onOpenCatalogo(n);
        } else if (n.inventario && window.SylpackNotif.onOpenInventario) {
          window.SylpackNotif.onOpenInventario(n);
        } else if (n.compras && window.SylpackNotif.onOpenCompra) {
          window.SylpackNotif.onOpenCompra(n.solicitud_id, n);
        } else if (window.SylpackNotif.onOpen) {
          window.SylpackNotif.onOpen(n.ticket_id, n);
        }
      };
      b.onkeydown = (e) => {
        if (e.target.closest(".ndel")) return;
        if (e.key === "Enter" || e.key === " " || e.key === "Spacebar") {
          e.preventDefault();
          b.click();
        }
      };
    });

    // Botón eliminar individual
    list.querySelectorAll(".ndel").forEach(btnDel => {
      btnDel.onclick = (e) => {
        e.stopPropagation();
        const ix = Number(btnDel.dataset.delix);
        const n = visibles[ix];
        if (!n) return;
        const itemEl = btnDel.closest(".nitem");
        if (itemEl) itemEl.classList.add("removing");
        // Se quita de la lista en este equipo; el servidor regenera los avisos,
        // así que el id eliminado se recuerda para no volver a mostrarlo.
        try {
          const token = localStorage.getItem("access") || sessionStorage.getItem("access");
          if (token && n.id != null) {
            fetch(`${API_BASE}/api/notificaciones/${encodeURIComponent(n.id)}`, {
              method: "DELETE",
              headers: { Authorization: "Bearer " + token }
            }).catch(() => {});
          }
        } catch {}
        const k = ID(n);
        if (k != null) { deletedSet.add(k); persist(); }
        setTimeout(() => render(cache), 250);
      };
    });

    if (lastUnread >= 0 && unread > lastUnread && !window.SylpackSocketActive) {
      const body = `Tienes ${unread} aviso${unread === 1 ? "" : "s"} sin leer.`;
      window.SylpackToast?.show({
        kind: "info", title: "Notificaciones nuevas",
        body, sound: "notif", duration: 4600
      });
      desktop("Notificaciones nuevas", body, { tag: "sylpack-notif" });
    }
    lastUnread = unread;
  }

  function markItems(items) {
    let changed = false;
    items.forEach(n => {
      const k = ID(n);
      if (k && !readSet.has(k)) { readSet.add(k); changed = true; }
      else if (k == null) {
        try { localStorage.setItem(OLD, String(n.created_at || new Date().toISOString())); } catch {}
      }
    });
    if (changed) persist();
  }

  async function refresh() {
    cache = await fetchItems();
    migrate();
    render(cache);
  }
  function show() {
    const p = document.getElementById("notifPanel");
    if (p) {
      p.hidden = false;
      document.querySelector(".top")?.classList.add("notif-open");
      requestAnimationFrame(() => p.classList.add("show"));
    }
  }
  function hide() {
    const p = document.getElementById("notifPanel");
    if (p) {
      p.classList.remove("show");
      p.hidden = true;
      document.querySelector(".top")?.classList.remove("notif-open");
    }
  }
  function markAll() {
    if (!cache.filter(isUnread).length) return;
    markItems(cache);
    render(cache);
  }
  async function confirmClear() {
    const msg = "Se quitarán todas las notificaciones de la bandeja. Esta acción no se puede deshacer.";
    try {
      if (window.Modal?.show) {
        const r = await window.Modal.show({
          title: "¿Borrar todas las notificaciones?",
          msg,
          type: "error",
          buttons: [
            { label: "Cancelar", value: false },
            { label: "Borrar todas", value: true, primary: true, danger: true }
          ]
        });
        return r === true || !!(r && r.button);
      }
    } catch {}
    return window.confirm(msg);
  }

  async function clearAll() {
    const visibles = cache.filter(n => !isDeleted(n));
    if (!visibles.length) return;
    if (!(await confirmClear())) return;
    try {
      const token = localStorage.getItem("access") || sessionStorage.getItem("access");
      if (token) {
        // El servidor regenera los avisos; el borrado real es local.
        await fetch(`${API_BASE}/api/notificaciones`, {
          method: "DELETE",
          headers: { Authorization: "Bearer " + token }
        });
      }
    } catch {}
    // Se recuerdan todos los avisos borrados para que no reaparezcan.
    visibles.forEach(n => { const k = ID(n); if (k != null) deletedSet.add(k); });
    persist();
    render(cache);
  }
  function markTicket(tid) {
    let changed = false;
    cache.forEach(n => {
      const k = ID(n);
      if (k && String(n.ticket_id) === String(tid) && !readSet.has(k)) { readSet.add(k); changed = true; }
    });
    if (changed) { persist(); render(cache); }
  }
  function markCompra(sid) {
    let changed = false;
    cache.forEach(n => {
      const k = ID(n);
      if (k && n.compras && String(n.solicitud_id) === String(sid) && !readSet.has(k)) {
        readSet.add(k); changed = true;
      }
    });
    if (changed) { persist(); render(cache); }
  }
  function esc(s) { return String(s || "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }

  function nativeNotify(t, b, opts) {
    try {
      if (!("Notification" in window)) return;
      if (Notification.permission === "granted") {
        const n = new Notification(t, {
          body: b, tag: opts.tag || undefined, silent: true,
          icon: "assets/logo.png",
        });
        n.onclick = () => {
          try { window.focus(); } catch {}
          try { opts.onClick?.(); } catch {}
          try { n.close(); } catch {}
        };
      } else if (Notification.permission === "default") {
        Notification.requestPermission().catch?.(() => {});
      }
    } catch {}
  }

  function desktop(title, body, opts = {}) {
    const t = String(title || "Sylpack Tickets");
    const b = String(body || "");
    // En la app de escritorio se usa el globo de la bandeja (visible aunque
    // la ventana esté minimizada o se esté presentando un documento).
    try {
      const api = window.pywebview?.api;
      if (api?.notify) {
        const fallback = () => nativeNotify(t, b, opts);
        try {
          const r = api.notify(t, b);
          if (r && typeof r.then === "function") r.then(ok => { if (!ok) fallback(); }).catch(fallback);
          else if (!r) fallback();
        } catch { fallback(); }
        return;
      }
    } catch {}
    nativeNotify(t, b, opts);
  }

  function askPermission() {
    try {
      if ("Notification" in window && Notification.permission === "default") {
        Notification.requestPermission().catch?.(() => {});
      }
    } catch {}
  }

  function paintSound() {
    const b = document.getElementById("notifSound");
    if (!b) return;
    const m = !!(window.SylpackSound && window.SylpackSound.isMuted());
    b.classList.toggle("off", m);
    b.title = m ? "Activar sonidos" : "Silenciar sonidos";
    b.setAttribute("aria-label", b.title);
  }

  window.SylpackNotif = {
    onOpen: null,
    onOpenCompra: null,
    onOpenCatalogo: null,
    onOpenInventario: null,
    refresh,
    desktop,
    markTicket,
    markCompra,
    markAll,
    init(opts = {}) {
      window.SylpackNotif.onOpen = opts.onOpen || null;
      window.SylpackNotif.onOpenCompra = opts.onOpenCompra || null;
      window.SylpackNotif.onOpenCatalogo = opts.onOpenCatalogo || null;
      window.SylpackNotif.onOpenInventario = opts.onOpenInventario || null;
      window.addEventListener("sylpack:compras-event", refresh);
      window.addEventListener("sylpack:compras", refresh);
      const btn = document.getElementById("notifBtn");
      btn?.addEventListener("click", e => {
        e.stopPropagation();
        const p = document.getElementById("notifPanel");
        if (p && !p.hidden) hide(); else { refresh(); show(); }
      });
      document.addEventListener("click", e => {
        const p = document.getElementById("notifPanel");
        if (p && !p.hidden && !e.target.closest(".notifwrap")) hide();
      });
      document.getElementById("notifRead")?.addEventListener("click", markAll);
      document.getElementById("notifClear")?.addEventListener("click", clearAll);
      document.getElementById("notifSound")?.addEventListener("click", () => {
        window.SylpackSound?.toggleMuted();
        paintSound();
      });
      paintSound();
      askPermission();
      refresh();
      setInterval(() => { if (!document.hidden) refresh(); }, 20000);
    },
  };
})();
