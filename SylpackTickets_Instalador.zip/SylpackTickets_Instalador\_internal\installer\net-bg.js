/* Red de puntitos con líneas del instalador: reacciona al hover. */
(() => {
  const cv = document.getElementById("net");
  if (!cv) return;
  const ctx = cv.getContext("2d");
  let W = 0, H = 0, running = true;
  const mouse = { x: -9999, y: -9999 };
  const N = 75, LINK = 135;
  let pts = [];
  let pulses = [];

  function resize() {
    const r = cv.parentElement.getBoundingClientRect();
    W = Math.max(1, r.width); H = Math.max(1, r.height);
    cv.width = W; cv.height = H;
    pts = Array.from({ length: N }, () => ({
      x: Math.random() * W, y: Math.random() * H,
      vx: (Math.random() - 0.5) * 0.45, vy: (Math.random() - 0.5) * 0.45,
      r: 1.2 + Math.random() * 1.4
    }));
  }
  window.addEventListener("resize", resize);

  cv.parentElement.addEventListener("pointermove", e => {
    const r = cv.getBoundingClientRect();
    mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top;
  });
  cv.parentElement.addEventListener("pointerdown", e => {
    const r = cv.getBoundingClientRect();
    const x = e.clientX - r.left, y = e.clientY - r.top;
    mouse.x = x; mouse.y = y;
    pulses.push({ x, y, life: 0 });
    // Onda de choque: empuja los puntos cercanos al hacer clic.
    for (const p of pts) {
      const dx = p.x - x, dy = p.y - y;
      const d = Math.hypot(dx, dy);
      if (d < 220 && d > 0.5) {
        const force = (1 - d / 220) * 4.6;
        p.vx += (dx / d) * force;
        p.vy += (dy / d) * force;
      }
    }
  });
  cv.parentElement.addEventListener("pointerleave", () => { mouse.x = -9999; mouse.y = -9999; });
  document.addEventListener("visibilitychange", () => { running = !document.hidden; if (running) requestAnimationFrame(frame); });

  function frame() {
    if (!running) return;
    ctx.clearRect(0, 0, W, H);
    // Ondas del clic.
    pulses = pulses.filter(pu => pu.life < 55);
    for (const pu of pulses) {
      pu.life += 1.3;
      const radius = pu.life * 2.6;
      ctx.beginPath();
      ctx.arc(pu.x, pu.y, radius, 0, 6.2832);
      ctx.strokeStyle = `rgba(120,180,255,${(0.34 * (1 - pu.life / 55)).toFixed(3)})`;
      ctx.lineWidth = 1.4;
      ctx.stroke();
    }
    for (const p of pts) {
      p.x += p.vx; p.y += p.vy;
      const speed = Math.hypot(p.vx, p.vy);
      if (speed > 3.4) { p.vx = (p.vx / speed) * 3.4; p.vy = (p.vy / speed) * 3.4; }
      if (p.x < 0 || p.x > W) p.vx *= -1;
      if (p.y < 0 || p.y > H) p.vy *= -1;
      // el cursor atrae suavemente lo cercano
      const dx = p.x - mouse.x, dy = p.y - mouse.y;
      const d = Math.hypot(dx, dy);
      if (d < 170 && d > 0.5) { p.x -= (dx / d) * 0.7; p.y -= (dy / d) * 0.7; }
    }
    for (let i = 0; i < pts.length; i++) {
      for (let j = i + 1; j < pts.length; j++) {
        const a = pts[i], b = pts[j];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        if (d < LINK) {
          ctx.beginPath();
          ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
          ctx.strokeStyle = `rgba(90,140,220,${(0.20 * (1 - d / LINK)).toFixed(3)})`;
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }
    }
    for (const p of pts) {
      const d = Math.hypot(p.x - mouse.x, p.y - mouse.y);
      const hot = d < 170;
      ctx.beginPath();
      ctx.arc(p.x, p.y, hot ? p.r + 1.1 : p.r, 0, 6.2832);
      ctx.fillStyle = hot ? "rgba(150,195,255,0.9)" : "rgba(110,150,210,0.5)";
      ctx.fill();
    }
    requestAnimationFrame(frame);
  }
  resize();
  requestAnimationFrame(frame);
})();
