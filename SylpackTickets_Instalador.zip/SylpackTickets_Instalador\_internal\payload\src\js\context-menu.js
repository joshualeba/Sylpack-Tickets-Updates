/* Menú contextual 100% personalizado, distinto según la zona clicada. */
(() => {
  const menu = document.createElement("div");
  menu.id = "ctxmenu";
  document.body.appendChild(menu);

  const I = {
    cut: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/></svg>',
    copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
    paste: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/></svg>',
    sel: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3h7l9 9-7 7-9-9z"/><circle cx="8" cy="8" r="1.5"/></svg>',
    reload: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>',
    go: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><polyline points="12 5 19 12 12 19"/></svg>',
    out: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>',
    eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
    down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
    info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
    chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
    edit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>'
  };

  document.addEventListener("contextmenu", e => {
    e.preventDefault();
    build(e);
  });
  document.addEventListener("click", e => { if (!menu.contains(e.target)) hide(); });
  document.addEventListener("keydown", e => { if (e.key === "Escape") hide(); });
  window.addEventListener("blur", hide);
  window.addEventListener("resize", hide);
  function hide() { menu.classList.remove("show"); menu.innerHTML = ""; }

  function item(icon, label, fn, opts = {}) {
    const b = document.createElement("button");
    b.innerHTML = `${icon}<span>${label}</span>`;
    if (opts.danger) b.classList.add("danger");
    if (opts.disabled) b.disabled = true;
    else b.onclick = () => { hide(); fn?.(); };
    menu.appendChild(b);
  }
  function head(t) {
    const d = document.createElement("div");
    d.className = "ctx-head"; d.textContent = t;
    menu.appendChild(d);
  }
  function sep() { const d = document.createElement("div"); d.className = "sep"; menu.appendChild(d); }

  async function clip(text) {
    const t = String(text || "");
    if (!t) return;
    try { await navigator.clipboard.writeText(t); }
    catch (e) {
      const ta = document.createElement("textarea");
      ta.value = t; document.body.appendChild(ta); ta.select();
      try { document.execCommand("copy"); } catch {}
      ta.remove();
    }
  }

  const txt = el => String(el?.innerText || el?.textContent || "").replace(/\s+/g, " ").trim();
  const role = () => localStorage.getItem("role") || "user";
  const isStaff = () => ["admin", "super"].includes(role());
  const ticketId = el => el?.dataset?.ticketId || el?.dataset?.tid || (txt(el).match(/#(\d+)/)?.[1] || "");
  const ticketRow = id => (window.lastTickets || []).find(x => String(x.id) === String(id));
  const version = () => window.SYLPACK_VERSION || (typeof APP_VERSION !== "undefined" ? APP_VERSION : "1.0");

  function copyImage(path, name) {
    if (window.SylpackPreview && path) window.SylpackPreview.open(path, name);
  }

  function build(e) {
    menu.innerHTML = "";
    const t = e.target;
    const q = s => t.closest(s);

    const pv = q("[data-pv]");
    const galleryCard = q(".gcard");
    const galleryImg = q(".gimg[data-gpv]");
    const msg = q(".msg");
    const chatCard = q(".chat-card");
    const toast = q(".st-toast");
    const themeSwitch = q(".theme-switch");
    const opener = q("[data-a11y-open], #notifBtn, #accountBtn");
    const tab = q(".tabs button");
    const userRow = q("#userRows tr[data-uid]");
    const logRow = q("#logRows tr");
    const editable = q("input, textarea, select");
    const ticket = q("[data-ticket-id], .tcard");
    const kpi = q(".kpi");

    if (pv || galleryImg || galleryCard) {
      const galIndex = (galleryImg || galleryCard?.querySelector(".gimg[data-gpv]"))?.dataset.gpv;
      const g = galIndex !== undefined ? (window._glist || [])[Number(galIndex)] : null;
      const el = pv || galleryImg || galleryCard;
      const name = g?.nombre || el?.dataset?.name || el?.querySelector?.("img")?.alt || "imagen";
      const path = g?.path || el?.dataset?.pv || "";
      head(g?.origen === "compra" ? "Documento de compra" : g ? "Imagen de galería" : "Adjunto / evidencia");
      item(I.eye, "Vista previa", () => {
        if (g?.origen === "compra") (galleryImg || galleryCard?.querySelector(".gimg[data-gpv]"))?.click();
        else if (path) copyImage(path, name);
        else el.click?.();
      });
      item(I.copy, "Copiar nombre", () => clip(name));
      if (path) item(I.copy, "Copiar ruta del archivo", () => clip(path));
      const inTicket = el?.closest?.("[data-ticket-id]");
      const tid = g?.ticket_id || ticketId(inTicket);
      if (tid) {
        sep();
        item(I.copy, `Copiar reporte #${tid}`, () => clip(`#${tid}`));
        if (isStaff() && typeof window.goToTicket === "function") {
          item(I.go, `Ir al reporte #${tid}`, () => window.goToTicket(Number(tid)));
        }
      }
      if (g?.solicitud_folio || g?.solicitud_id) {
        sep();
        item(I.copy, `Copiar solicitud ${g.solicitud_folio || "#" + g.solicitud_id}`, () => clip(g.solicitud_folio || `#${g.solicitud_id}`));
      }
      if (g && isStaff() && galleryCard && galleryCard.querySelector("[data-gdel]")) {
        sep();
        item(I.trash, "Borrar imagen", () => galleryCard.querySelector("[data-gdel]")?.click(), { danger: true });
      }
    } else if (msg) {
      head("Mensaje");
      const body = txt(msg.querySelector(".mtext") || msg.querySelector(".mbody") || msg);
      item(I.copy, "Copiar mensaje", () => clip(body));
      const meta = txt(msg.querySelector(".mbody small"));
      if (meta) item(I.copy, "Copiar autor y hora", () => clip(meta));
      const thread = msg.closest(".thread");
      const input = thread?.querySelector(".msgbox input") || document.getElementById("chatInp");
      if (input && body) {
        sep();
        item(I.chat, "Citar en la respuesta", () => {
          const quote = body.split("\n").map(l => "> " + l).join("\n") + "\n";
          input.value = quote + input.value;
          input.focus();
          try { input.setSelectionRange(quote.length, quote.length); } catch {}
        });
      }
    } else if (chatCard) {
      head("Conversación");
      item(I.copy, "Copiar título", () => clip(txt(document.getElementById("chatTitle"))));
      item(I.copy, "Copiar conversación", () => clip(txt(document.getElementById("chatMsgs"))));
      if (window.chatTid && typeof window.goToTicket === "function") {
        item(I.go, `Ir al reporte #${window.chatTid}`, () => window.goToTicket(Number(window.chatTid)));
      }
      sep();
      item(I.close, "Cerrar conversación", () => document.getElementById("chatX")?.click());
    } else if (toast) {
      head("Aviso");
      item(I.copy, "Copiar aviso", () => clip(txt(toast)));
      item(I.close, "Cerrar aviso", () => toast.querySelector(".st-x")?.click());
    } else if (themeSwitch) {
      head("Apariencia");
      const light = document.documentElement.dataset.theme === "light";
      item(I.go, light ? "Cambiar a modo noche" : "Cambiar a modo día", () => window.SylpackTheme?.toggle());
    } else if (opener) {
      head("Acceso directo");
      const label = opener.hasAttribute("data-a11y-open") ? "Abrir accesibilidad"
        : opener.id === "notifBtn" ? "Ver notificaciones" : "Abrir mi cuenta";
      item(I.go, label, () => opener.click());
    } else if (tab) {
      head("Sección");
      item(I.go, `Ir a ${txt(tab)}`, () => tab.click());
      item(I.reload, "Recargar vista", () => location.reload());
    } else if (userRow) {
      head("Cuenta");
      const username = userRow.dataset.username || txt(userRow.cells?.[0]);
      const uid = Number(userRow.dataset.uid);
      item(I.copy, "Copiar usuario/a", () => clip(username));
      item(I.copy, "Copiar fila", () => clip(txt(userRow)));
      if (role() === "super" || !userRow.dataset.protected) {
        sep();
        item(I.edit, "Editar cuenta", () => window.editUser?.(uid), { disabled: !uid || !window.editUser });
        item(I.trash, "Eliminar cuenta", () => window.delUser?.(uid, username), {
          danger: true, disabled: !uid || !window.delUser || username === localStorage.getItem("username")
        });
      }
    } else if (logRow) {
      head("Evento de bitácora");
      item(I.copy, "Copiar evento", () => clip(txt(logRow)));
      const cells = logRow.cells || [];
      const actor = txt(cells[1]);
      const ticketMatch = txt(cells[4]).match(/#(\d+)/);
      if (actor) {
        sep();
        item(I.go, `Filtrar por ${actor}`, () => {
          const input = document.getElementById("logActor");
          if (input) input.value = actor;
          document.getElementById("logGo")?.click();
        });
      }
      if (ticketMatch) {
        item(I.go, `Filtrar por reporte #${ticketMatch[1]}`, () => {
          const input = document.getElementById("logTicket");
          if (input) input.value = ticketMatch[1];
          document.getElementById("logGo")?.click();
        });
      }
    } else if (editable) {
      head("Edición");
      const el = editable;
      const isSelect = el.tagName === "SELECT";
      const canEdit = !isSelect && !el.readOnly && !el.disabled;
      if (isSelect) {
        item(I.copy, "Copiar valor", () => clip(el.value));
        item(I.sel, "Abrir opciones", () => { el.focus(); el.click(); });
      } else {
        item(I.cut, "Cortar", () => { el.focus(); document.execCommand("cut"); }, { disabled: !canEdit });
        item(I.copy, "Copiar", async () => {
          const v = el.value ?? el.textContent ?? "";
          const a = el.selectionStart ?? 0, b = el.selectionEnd ?? v.length;
          await clip(a !== b ? v.slice(a, b) : v);
        });
        item(I.paste, "Pegar", async () => {
          try {
            const s = await navigator.clipboard.readText();
            el.focus(); document.execCommand("insertText", false, s);
          } catch { el.focus(); }
        }, { disabled: !canEdit });
        item(I.sel, "Seleccionar todo", () => { el.focus(); el.select?.(); });
        if (el.value) item(I.close, "Limpiar campo", () => { el.value = ""; el.dispatchEvent(new Event("input", { bubbles: true })); }, { disabled: !canEdit });
      }
      if (el.id === "prio") {
        sep();
        item(I.info, "Qué nivel elegir", () => document.getElementById("prioInfo")?.click());
      }
    } else if (ticket) {
      const id = ticketId(ticket);
      const row = ticketRow(id);
      const state = row?.estado || ["abierto", "en_proceso", "cerrado"].find(s => ticket.classList.contains(s)) || "";
      const title = txt(ticket.querySelector(".thead-txt b, h4, .rid"));
      const desc = txt(ticket.querySelector(".tdesc"));
      head(id ? `Reporte #${id}` : "Reporte");
      item(I.copy, "Copiar número", () => clip(`#${id}`), { disabled: !id });
      item(I.copy, "Copiar título", () => clip(title), { disabled: !title });
      if (desc) item(I.copy, "Copiar descripción", () => clip(desc));
      if (id) item(I.copy, "Copiar resumen", () => clip([`#${id}`, title, desc, row?.username ? `por ${row.username}` : "", state].filter(Boolean).join("\n")));
      const firstImg = ticket.querySelector("[data-pv]");
      if (firstImg) {
        item(I.eye, "Ver adjunto del reporte", () => window.SylpackPreview?.open(firstImg.dataset.pv, firstImg.dataset.name));
      }
      if (isStaff() && id) {
        sep();
        item(I.chat, "Abrir conversación", () => {
          const r = ticketRow(id);
          window.openChat?.(Number(id), r?.titulo || title, r?.username || "");
        }, { disabled: !window.openChat });
        if (state !== "en_proceso" && state !== "cerrado") {
          item(I.go, "Marcar en proceso", () => window.setSt?.(Number(id), "en_proceso"), { disabled: !window.setSt });
        }
        if (state !== "cerrado") {
          item(I.check, "Cerrar reporte…", () => window.askCierre?.(Number(id)), { disabled: !window.askCierre });
        } else {
          item(I.reload, "Reabrir reporte", () => window.setSt?.(Number(id), "abierto"), { disabled: !window.setSt });
        }
      } else if (!isStaff() && id) {
        sep();
        item(I.chat, "Abrir conversación", () => document.querySelector(`[data-chat="${id}"]`)?.click());
        const rate = ticket.querySelector("[data-rate]");
        if (rate) item(I.check, "Calificar el servicio", () => rate.click());
      }
    } else if (kpi) {
      head("Indicador");
      item(I.copy, "Copiar valor", () => clip(txt(kpi)));
    } else {
      head("Sylpack Tickets");
      item(I.reload, "Recargar vista", () => location.reload());
      if (isStaff()) item(I.go, "Ir al panel", () => { if (!location.href.includes("admin.html")) location.href = "admin.html"; });
      else item(I.go, "Ir a reportar", () => { if (!location.href.includes("user.html")) location.href = "user.html"; });
      if (!location.href.includes("login.html")) {
        sep();
        item(I.out, "Cerrar sesión", () => {
          if (window.sylpackLogout) window.sylpackLogout();
          else {
            if (window.SylpackAuth?.clear) window.SylpackAuth.clear();
            else { localStorage.removeItem("access"); sessionStorage.removeItem("access"); }
            location.replace("login.html");
          }
        }, { danger: true });
      }
      item(I.info, `Acerca de: Sylpack Tickets v${version()} · red local`, () => {
        if (window.Modal) window.Modal.info("Sylpack Tickets",
          `Sistema interno de reportes v${version()}.\nRed local segura · Horario Lun–Vie 10:00–18:00.`);
      });
    }

    menu.classList.add("show");
    const r = menu.getBoundingClientRect();
    let x = e.clientX, y = e.clientY;
    if (x + r.width > innerWidth - 8) x = innerWidth - r.width - 8;
    if (y + r.height > innerHeight - 8) y = innerHeight - r.height - 8;
    menu.style.left = Math.max(8, x) + "px";
    menu.style.top = Math.max(8, y) + "px";
  }
})();
