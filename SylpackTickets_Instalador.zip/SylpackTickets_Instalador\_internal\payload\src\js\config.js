// La IP se define en config.local.js (lo genera app_launcher.py al arrancar).
// Si no existe, se usa la sede de fábrica como respaldo.
const API_BASE = (window.SYLPACK_API && window.SYLPACK_API.length) ? window.SYLPACK_API : "http://192.168.0.146:5050";
const SYNC_INTERVAL_MS = 5000;
const APP_VERSION = "1.0";
window.SYLPACK_VERSION = APP_VERSION;

(() => {
  const KEYS = ["access", "refresh", "role", "username", "area", "puesto"];
  const loginPage = () => /(^|\/)login\.html$/i.test(location.pathname)
    || document.body?.dataset.page === "Acceso";
  const quietPage = () => loginPage() || /(^|\/)compras-doc\.html$/i.test(location.pathname);
  const token = () => localStorage.getItem("access") || sessionStorage.getItem("access");
  const clear = () => {
    KEYS.forEach(k => {
      try { localStorage.removeItem(k); } catch {}
      try { sessionStorage.removeItem(k); } catch {}
    });
  };
  const fail = () => {
    clear();
    if (quietPage() || window.__sylpackAuthRedirect) return;
    window.__sylpackAuthRedirect = true;
    location.replace("login.html");
  };
  const expiresAt = t => {
    try {
      const p = String(t || "").split(".")[1] || "";
      const b = p.replace(/-/g, "+").replace(/_/g, "/");
      const pad = b + "=".repeat((4 - b.length % 4) % 4);
      return (JSON.parse(atob(pad)).exp || 0) * 1000;
    } catch { return 0; }
  };
  let refreshing = null;
  const refresh = () => {
    if (refreshing) return refreshing;
    const rt = localStorage.getItem("refresh");
    if (!rt) return Promise.resolve(false);
    const store = sessionStorage.getItem("access") ? sessionStorage : localStorage;
    refreshing = nativeFetch(`${API_BASE}/api/refresh`, {
      method: "POST", headers: { Authorization: "Bearer " + rt }, cache: "no-store"
    }).then(async r => {
      if (!r.ok) {
        if ([400, 401, 403, 404, 422].includes(r.status)) fail();
        return false;
      }
      const d = await r.json().catch(() => ({}));
      if (!d.access) return false;
      store.setItem("access", d.access);
      localStorage.setItem("role", d.role || localStorage.getItem("role") || "");
      localStorage.setItem("username", d.username || localStorage.getItem("username") || "");
      return true;
    }).catch(() => false).finally(() => { refreshing = null; });
    return refreshing;
  };
  const ensureFresh = async () => {
    const t = token();
    if (!t) return false;
    const exp = expiresAt(t);
    if (!exp || exp - Date.now() < 120000) return refresh();
    return true;
  };
  window.SylpackAuth = { token, clear, fail, refresh, ensureFresh, expiresAt };

  if (!loginPage()) {
    setTimeout(ensureFresh, 800);
    setInterval(() => { if (!document.hidden) ensureFresh(); }, 60000);
    document.addEventListener("visibilitychange", () => { if (!document.hidden) ensureFresh(); });
  }

  const nativeFetch = window.fetch.bind(window);
  window.fetch = async (input, init) => {
    const url = typeof input === "string" ? input : (input?.url || "");
    const authCall = /\/api\/(login|refresh)(?:[?#]|$)/.test(url);
    let res = await nativeFetch(input, init);
    if (res.status !== 401 || authCall) return res;
    const oldToken = token();
    if (!oldToken) return res;
    if (!(await refresh())) return res;
    const next = token();
    if (!next) return res;
    const headers = new Headers(init?.headers || input?.headers || {});
    headers.set("Authorization", "Bearer " + next);
    return nativeFetch(input, Object.assign({}, init, { headers }));
  };
})();
