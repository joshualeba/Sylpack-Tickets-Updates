/* Sylpack Tickets — "City" — ciudad isométrica ligera.
   La ciudad base se pre-dibuja UNA vez; por frame se animan pocos edificios
   cercanos al cursor o al foco idle (+ ondas de clic), a ~60 fps. */
(() => {
  const host = document.querySelector(".visual");
  if (!host) return;
  const cv = document.createElement("canvas");
  cv.id = "city";
  host.prepend(cv);
  const ctx = cv.getContext("2d");
  let W = 0, H = 0, running = true, lastFrame = 0, lastRender = 0;
  const DPR = 1; // techo fijo: nítido suficiente, mitad de costo
  const mouse = { x: -9999, y: -9999 };
  const waves = [];
  let t = 0;

  const TW = 88, TH = 44, R = 220;
  let cells = [], order = [];
  let ox = 0, oy = 0;
  let P = null, fogG = null, glowG = null;
  const base = document.createElement("canvas");
  const bctx = base.getContext("2d");
  const glowSprite = document.createElement("canvas");

  function pal() {
    return document.documentElement.dataset.theme === "light" ? {
      top0: "#8fa5c6", top1: "#2f6df0",
      left: "#b9c7de", right: "#93a9cc",
      win: "#ffffff", winOff: "rgba(30,58,95,0.22)",
      fog: "rgba(230,236,245,0.9)",
      glow: "rgba(36,86,198,0.15)", edge: "rgba(30,58,95,0.4)"
    } : {
      top0: "#131e31", top1: "#3f7de0",
      left: "#070c15", right: "#0c1424",
      win: "#cfe2ff", winOff: "rgba(120,160,220,0.10)",
      fog: "rgba(4,6,11,0.92)",
      glow: "rgba(77,141,255,0.13)", edge: "rgba(120,170,255,0.22)"
    };
  }

  const mix = (c0, c1, f) => {
    const a = c0.match(/\w\w/g).map(h => parseInt(h, 16));
    const b = c1.match(/\w\w/g).map(h => parseInt(h, 16));
    return "#" + a.map((v, k) => Math.round(v + (b[k] - v) * f).toString(16).padStart(2, "0")).join("");
  };

  function seed() {
    P = pal();
    const NX = Math.ceil(W / 110) + 3, NY = Math.ceil(H / 80) + 3;
    ox = W / 2; oy = H * 0.30;
    const cx = (NX - 1) / 2, cy = (NY - 1) / 2, md = Math.hypot(cx, cy) || 1;
    let s = 42;
    const rnd = () => (s = (s * 16807) % 2147483647) / 2147483647;
    cells = [];
    for (let i = 0; i < NX; i++) for (let j = 0; j < NY; j++) {
      if (rnd() < 0.10) continue;
      const d = Math.hypot(i - cx, j - cy) / md;
      const baseH = Math.pow(Math.max(0, 1 - d), 1.4) * H * 0.30 * (0.45 + rnd() * 0.55) + rnd() * H * 0.02;
      cells.push({ i, j, base: baseH, h: baseH, ph: rnd() * 6.28 });
    }
    for (const c of cells) {
      c.sx = ox + (c.i - c.j) * (TW / 2);
      c.sy = oy + (c.i + c.j) * (TH / 2);
      c.idlePh = (c.i + c.j) * 0.55 + c.ph;
    }
    order = cells.slice().sort((a, b) => (a.i + a.j) - (b.i + b.j));
    fogG = ctx.createLinearGradient(0, H * 0.55, 0, H);
    fogG.addColorStop(0, "rgba(0,0,0,0)");
    fogG.addColorStop(1, P.fog);
    glowG = ctx.createRadialGradient(ox, H * 0.75, 0, ox, H * 0.75, W * 0.45);
    glowG.addColorStop(0, P.glow); glowG.addColorStop(1, "rgba(0,0,0,0)");
    // Sprite pre-renderizado: el halo del cursor no crea gradientes por frame.
    const GS = 340;
    glowSprite.width = GS; glowSprite.height = GS;
    const gctx = glowSprite.getContext("2d");
    const gg = gctx.createRadialGradient(GS / 2, GS / 2, 0, GS / 2, GS / 2, GS / 2);
    gg.addColorStop(0, P.glow); gg.addColorStop(1, "rgba(0,0,0,0)");
    gctx.fillStyle = gg; gctx.fillRect(0, 0, GS, GS);
    renderStatic();
  }

  function drawBuilding(g, c, h, hover) {
    const sx = c.sx ?? (ox + (c.i - c.j) * (TW / 2));
    const sy = c.sy ?? (oy + (c.i + c.j) * (TH / 2));
    const x0 = sx - TW / 2, x1 = sx + TW / 2;
    const yB = sy + TH / 2;
    g.beginPath();
    g.moveTo(x0, sy - h); g.lineTo(sx, yB - h); g.lineTo(sx, yB); g.lineTo(x0, sy);
    g.closePath(); g.fillStyle = P.left; g.fill();
    g.beginPath();
    g.moveTo(x1, sy - h); g.lineTo(sx, yB - h); g.lineTo(sx, yB); g.lineTo(x1, sy);
    g.closePath(); g.fillStyle = P.right; g.fill();
    const yT = sy - h;
    const hf = Math.min(1, h / (H * 0.30));
    g.beginPath();
    g.moveTo(x0, yT); g.lineTo(sx, yT - TH / 2); g.lineTo(x1, yT); g.lineTo(sx, yT + TH / 2);
    g.closePath();
    g.fillStyle = mix(P.top0.replace("#", ""), P.top1.replace("#", ""), Math.min(1, hf + (hover ? 0.3 : 0)));
    g.fill();
    g.strokeStyle = P.edge; g.lineWidth = 1; g.stroke();
    if (hover && h > 30) {
      const colsN = 2, rowsN = Math.min(4, Math.floor(h / 26));
      const pt = (u, v) => [sx + u * (x1 - sx), ((yB - h) + u * ((sy - h) - (yB - h))) + v * h];
      for (let a = 0; a < colsN; a++) for (let b = 0; b < rowsN; b++) {
        const lit = ((a * 7 + b * 3 + c.i * 5 + c.j) % 3) !== 0;
        const u0 = 0.20 + a * 0.40, v0 = 0.12 + b * (0.72 / Math.max(1, rowsN - 1));
        const p1 = pt(u0, v0), p2 = pt(u0 + 0.18, v0), p3 = pt(u0 + 0.18, v0 + 0.085), p4 = pt(u0, v0 + 0.085);
        g.beginPath();
        g.moveTo(p1[0], p1[1]); g.lineTo(p2[0], p2[1]); g.lineTo(p3[0], p3[1]); g.lineTo(p4[0], p4[1]);
        g.closePath();
        g.fillStyle = lit ? P.win : P.winOff;
        g.fill();
      }
    }
  }

  function renderStatic() {
    base.width = Math.max(1, W); base.height = Math.max(1, H);
    bctx.setTransform(1, 0, 0, 1, 0, 0);
    bctx.clearRect(0, 0, W, H);
    bctx.fillStyle = glowG;
    bctx.fillRect(0, 0, W, H);
    for (const c of order) drawBuilding(bctx, c, Math.max(2, c.base), false);
    bctx.fillStyle = fogG;
    bctx.fillRect(0, 0, W, H);
  }

  function resize() {
    const r = host.getBoundingClientRect();
    W = Math.max(1, r.width); H = Math.max(1, r.height);
    cv.width = W * DPR; cv.height = H * DPR;
    cv.style.cssText = "position:absolute;inset:0;width:100%;height:100%";
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    seed();
  }

  window.addEventListener("pointermove", e => {
    const r = cv.getBoundingClientRect();
    mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top;
  }, { passive: true });
  document.addEventListener("pointerleave", () => { mouse.x = -9999; mouse.y = -9999; });
  host.addEventListener("pointerdown", e => {
    const r = cv.getBoundingClientRect();
    waves.push({ x: e.clientX - r.left, y: e.clientY - r.top, r: 10 });
    if (waves.length > 3) waves.shift();
  });
  document.addEventListener("visibilitychange", () => { running = !document.hidden; if (running) { lastFrame = 0; lastRender = 0; requestAnimationFrame(frame); } });
  window.addEventListener("sylpack-theme", () => seed());

  function nearSet() {
    const set = [];
    // Punto de "respiración" que recorre la ciudad cuando el cursor está fuera.
    // Mueve un foco suave entre edificios para que la escena nunca quede inmóvil.
    const idleX = ox + Math.cos(t * 0.29) * W * 0.27 + Math.sin(t * 0.15) * W * 0.07;
    const idleY = oy + H * 0.22 + Math.sin(t * 0.24) * H * 0.10 + Math.cos(t * 0.10) * H * 0.035;
    const pointerActive = mouse.x > -100;
    for (const c of cells) {
      const sx = c.sx, sy = c.sy;
      const dMouse = pointerActive ? Math.hypot(sx - mouse.x, sy - mouse.y) : Infinity;
      const dIdle = Math.hypot(sx - idleX, sy - idleY) * 1.18;
      const d = Math.min(dMouse, dIdle);
      let wv = 0;
      for (const w of waves) {
        const wd = Math.hypot(sx - w.x, sy - w.y);
        wv = Math.max(wv, Math.max(0, 1 - Math.abs(wd - w.r) / 100));
      }
      if (d < R || wv > 0) set.push({ c, d, wv });
    }
    set.sort((a, b) => ((a.c.i + a.c.j) - (b.c.i + b.c.j)));
    return set;
  }

  function frame(now = 0) {
    if (!running) return;
    // En pantallas de 120 Hz no hace falta duplicar el trabajo: se mantiene
    // una cadencia estable cercana a 60 fps.
    if (now && now - lastRender < 15) { requestAnimationFrame(frame); return; }
    const dt = lastFrame ? Math.min(0.05, (now - lastFrame) / 1000) : 1 / 60;
    lastFrame = now; lastRender = now;
    const reduced = document.documentElement.dataset.aMotion === "1";
    if (!reduced) t += dt;
    ctx.clearRect(0, 0, W, H);
    if (!reduced) {
      // Respiración global: una escala mínima evita que la ciudad se sienta
      // congelada cuando nadie mueve el cursor.
      const breath = 1.002 + Math.sin(t * 0.42) * 0.0012;
      ctx.save();
      ctx.translate(W / 2, H * 0.72);
      ctx.scale(breath, breath);
      ctx.translate(-W / 2, -H * 0.72);
    }
    ctx.drawImage(base, 0, 0, W, H);
    if (!reduced) {
      for (const wv of waves) {
        wv.r += 360 * dt;
        if (wv.r < 460) {
          ctx.beginPath();
          ctx.ellipse(wv.x, wv.y, wv.r, wv.r * 0.45, 0, 0, 6.2832);
          ctx.strokeStyle = `rgba(140,185,255,${Math.max(0, 0.35 - wv.r / 1200).toFixed(3)})`;
          ctx.lineWidth = 2;
          ctx.stroke();
        }
      }
      for (let i = waves.length - 1; i >= 0; i--) if (waves[i].r >= 460) waves.splice(i, 1);
      const mx = mouse.x, my = mouse.y;
      if (mx > -100) {
        const rr = 170;
        ctx.drawImage(glowSprite, mx - rr, my - rr, rr * 2, rr * 2);
      }
      const ease = 1 - Math.exp(-dt * 20);
      for (const { c, d, wv } of nearSet()) {
        const boost = d < R ? (1 - d / R) * H * 0.09 : 0;
        const idle = Math.sin(t * 0.9 + c.idlePh) * H * 0.004;
        const target = Math.max(2, c.base + boost + wv * H * 0.08 + idle);
        c.h += (target - c.h) * ease;
        drawBuilding(ctx, c, c.h, boost > H * 0.012);
      }
      // niebla sobre lo dinámico para fundir bordes
      ctx.fillStyle = fogG;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }
    requestAnimationFrame(frame);
  }

  resize();
  window.addEventListener("resize", resize);
  requestAnimationFrame(frame);
})();