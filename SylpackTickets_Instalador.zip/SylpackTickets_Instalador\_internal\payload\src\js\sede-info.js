/* Muestra la SEDE actual (rol + IP) dentro de la app.
   La IP se toma en vivo de /api/health (login.js) y, si no hay red,
   se usa el rol/IP que definió app_launcher.py en config.local.js.
   Rellena cualquier elemento con [data-sede]. */
(() => {
  function ipConfig() {
    const role = window.SYLPACK_ROLE || "";
    let m = /sede\s*\(([^)]+)\)/i.exec(role);
    if (m) return { ip: m[1].trim(), este: true };
    m = /cliente\s*->\s*(\S+)/i.exec(role);
    if (m) return { ip: m[1].trim(), este: false };
    const api = window.SYLPACK_API || (typeof API_BASE !== "undefined" ? API_BASE : "");
    if (api) return { ip: String(api).replace(/^https?:\/\//i, "").replace(/:\d+\/?$/, ""), este: false };
    return null;
  }
  function esSedeLocal() {
    return /sede/i.test(window.SYLPACK_ROLE || "");
  }
  function pinta(ip, esSede) {
    const c = ipConfig() || {};
    // Nunca mostrar 127.0.0.1 si el rol ya conoce la IP real de la red.
    if ((!ip || /^127\./.test(ip)) && c.ip && !/^127\./.test(c.ip)) ip = c.ip;
    if (!ip) return;
    const txt = "Sede: " + ip + ((esSede || c.este) ? " (este equipo)" : "");
    document.querySelectorAll("[data-sede]").forEach(el => {
      el.textContent = txt;
      el.style.display = "";
    });
  }
  function fill() {
    const c = ipConfig();
    if (c) pinta(c.ip, c.este || esSedeLocal());
  }
  window.SylpackSede = {
    pinta,
    fill,
    // login.js la llama en vivo con la IP real que responde el servidor
    enVivo(ip) { pinta(ip, esSedeLocal()); }
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fill);
  else fill();
})();
