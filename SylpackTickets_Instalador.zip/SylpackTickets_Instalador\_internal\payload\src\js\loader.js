/* Loader Sylpack: el logo se forma y el % avanza con hitos reales
   (DOM listo, logo cargado, servidor local, ventana lista). */
(() => {
  const CIRC = 2 * Math.PI * 64; // r=64
  const overlay = document.createElement("div");
  overlay.id = "loader";
  const page = document.body.dataset.page || "Tickets";
  overlay.innerHTML = `
    <div class="loader-inner">
      <svg class="loader-cube" viewBox="0 0 60 54" aria-hidden="true">
        <polygon class="f-top" points="30,4 54,18 30,32 6,18"/>
        <polygon class="f-left" points="6,18 30,32 30,50 6,36"/>
        <polygon class="f-right" points="54,18 30,32 30,50 54,36"/>
      </svg>
      <div class="ld-stage">
        <svg class="ld-ring" viewBox="0 0 150 150">
          <defs><linearGradient id="loadGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#274d7d"/><stop offset="1" stop-color="#7ba7e0"/>
          </linearGradient></defs>
          <circle class="ring-track" cx="75" cy="75" r="64"/>
          <circle class="orbit-deco" cx="75" cy="75" r="71"/>
          <circle class="ring-fill" id="ringFill" cx="75" cy="75" r="64"
            stroke-dasharray="${CIRC.toFixed(1)}" stroke-dashoffset="${CIRC.toFixed(1)}"/>
        </svg>
        <img class="ld-logo" id="loaderLogo" src="assets/logo.png" alt="Sylpack Tickets" />
      </div>
      <div class="loader-pct"><span id="loadPct">0</span><small> %</small></div>
      <div class="loader-name">SYLPACK</div>
      <div class="loader-sub" id="loadSub">${page} · preparando tu espacio…</div>
      <div class="loader-bar"><span id="loadBar"></span></div>
    </div>`;
  document.body.appendChild(overlay);

  const pctEl = overlay.querySelector("#loadPct");
  const barEl = overlay.querySelector("#loadBar");
  const subEl = overlay.querySelector("#loadSub");
  const ringEl = overlay.querySelector("#ringFill");

  let target = 6, shown = 0, done = false;
  const bump = (v, label) => { if (v > target) target = v; if (label) subEl.textContent = label; };
  const apiBase = (typeof API_BASE !== "undefined" && API_BASE) ? API_BASE : "http://192.168.0.146:5050";

  if (document.readyState === "complete" || document.readyState === "interactive") bump(30, `${page} · cargando interfaz…`);
  else document.addEventListener("DOMContentLoaded", () => bump(30, `${page} · cargando interfaz…`), { once: true });

  const logo = overlay.querySelector("#loaderLogo");
  const logoDone = () => bump(56, `${page} · preparando imagen…`);
  if (logo.complete && logo.naturalWidth) logoDone();
  else { logo.addEventListener("load", logoDone, { once: true }); logo.addEventListener("error", logoDone, { once: true }); }

  const apiDone = ok => bump(82, ok ? "Local en línea · verificando sesión…" : "Sin conexión local · modo acumulado…");
  Promise.race([
    fetch(`${apiBase}/api/health`, { cache: "no-store" }).then(r => r.ok).catch(() => false),
    new Promise(res => setTimeout(() => res(false), 1200))
  ]).then(apiDone);

  window.addEventListener("load", () => bump(100, `${page} · listo`), { once: true });
  setTimeout(() => bump(100, `${page} · listo`), 2500); // seguridad

  function tick() {
    if (done) return;
    shown += (target - shown) * 0.22 + (target > shown ? 0.6 : 0);
    if (shown > target) shown = target;
    const v = Math.min(100, Math.floor(shown));
    pctEl.textContent = v;
    barEl.style.width = v + "%";
    ringEl.style.strokeDashoffset = (CIRC * (1 - v / 100)).toFixed(1);
    // el logo se materializa con el progreso: de fantasma borroso a nítido
    const lp = v / 100;
    logo.style.opacity = (0.3 + 0.7 * lp).toFixed(2);
    logo.style.filter = `blur(${((1 - lp) * 7).toFixed(1)}px) brightness(${(0.5 + 0.5 * lp).toFixed(2)}) saturate(${(0.4 + 0.6 * lp).toFixed(2)})`;
    if (v >= 100) {
      done = true;
      setTimeout(() => overlay.classList.add("hide"), 350);
      setTimeout(() => overlay.remove(), 950);
      return;
    }
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
})();
