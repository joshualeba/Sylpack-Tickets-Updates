/* Cola a prueba de todo:
   - REPORTES: sin red local o fuera de horario, se guardan y se reenvían solos
     cuando hay conexión y el horario abre (Lun–Vie 10:00–18:00).
   - MENSAJES de chat: si no hay conexión se guardan y se reenvían solos en cuanto
     vuelve la red (el chat no depende del horario de atención). */
(() => {
  const KEY = "ticket_queue_v1";
  const getQ = () => { try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { return []; } };
  const setQ = q => localStorage.setItem(KEY, JSON.stringify(q));

  window.queueTicket = function (item) {
    const q = getQ();
    // compat: convierte formato viejo (1 archivo) al nuevo (lista)
    if (item.fileDataUrl && !item.files) item.files = [{ dataUrl: item.fileDataUrl, name: item.fileName }];
    q.push({ ...item, kind: item.kind || "ticket", _ts: Date.now() });
    setQ(q);
    renderBadge();
  };
  window.queueCount = () => getQ().length;
  // Elementos aún no enviados (para mostrarlos en "Mis reportes" como pendientes).
  window.queueItems = () => getQ();

  // Mensaje de chat pendiente: se reenvía solo al recuperar la conexión.
  window.queueMsg = function (tid, mensaje) {
    const q = getQ();
    q.push({ kind: "msg", tid: String(tid), mensaje: String(mensaje), _ts: Date.now() });
    setQ(q);
    renderBadge();
  };

  async function recepcionEstado() {
    try {
      const r = await fetch(`${API_BASE}/api/horario`, { cache: "no-store" });
      if (!r.ok) return { abierto: true, pausado: false, aceptando: true };
      const d = await r.json();
      return { abierto: d.abierto !== false, pausado: !!d.pausado,
               aceptando: d.aceptando !== false, override: !!d.override,
               override_until: d.override_until || "",
               by: d.by || "", ventana: d.ventana || "" };
    } catch { return { abierto: true, pausado: false, aceptando: true }; }
  }
  window.recepcionEstado = recepcionEstado;
  async function horarioAbierto() {
    const st = await recepcionEstado();
    return st.aceptando;
  }
  window.horarioAbierto = horarioAbierto;

  async function enviarTicket(it, token) {
    const fd = new FormData();
    fd.append("titulo", it.titulo);
    fd.append("descripcion", it.descripcion);
    fd.append("prioridad", it.prioridad || "media");
    const files = it.files || ((it.fileDataUrl && it.fileName) ? [{ dataUrl: it.fileDataUrl, name: it.fileName }] : []);
    for (const f of files.slice(0, 4)) {
      const blob = await (await fetch(f.dataUrl)).blob();
      fd.append("adjuntos", blob, f.name);
    }
    const urls = (it.urls || []).filter(Boolean).slice(0, 4);
    if (urls.length) fd.append("adjuntos_url", JSON.stringify(urls));
    return fetch(`${API_BASE}/api/tickets`, {
      method: "POST", headers: { Authorization: "Bearer " + token }, body: fd
    });
  }

  window.flushQueue = async function () {
    const q = getQ();
    if (!q.length) return;
    const token = localStorage.getItem("access") || sessionStorage.getItem("access");
    if (!token) return;
    const st = await recepcionEstado();
    const puedeTickets = st.aceptando && !st.pausado;
    const rest = [];
    let enviados = 0, envTickets = 0, envMsgs = 0;
    for (const it of q) {
      try {
        if (it.kind === "msg") {
          const r = await fetch(`${API_BASE}/api/tickets/${it.tid}/mensajes`, {
            method: "POST",
            headers: { Authorization: "Bearer " + token, "Content-Type": "application/json" },
            body: JSON.stringify({ mensaje: it.mensaje })
          });
          if (r.ok) { enviados++; envMsgs++; continue; }
          if (r.status === 400 || r.status === 403) continue; // ya no se puede enviar: se descarta
          rest.push(it);
          continue;
        }
        // reportes: solo se intentan si el horario está abierto y la recepción no está pausada
        if (!puedeTickets) { rest.push(it); continue; }
        const r = await enviarTicket(it, token);
        if (r.status === 423) { rest.push(it); break; } // fuera de horario o pausado: se sigue acumulando
        if (!r.ok) { rest.push(it); continue; }
        enviados++; envTickets++;
      } catch { rest.push(it); break; }
    }
    setQ(rest);
    renderBadge();
    if (enviados && window.onQueueFlushed) window.onQueueFlushed(enviados, { tickets: envTickets, msgs: envMsgs });
  };

  function renderBadge() {
    const q = getQ();
    const n = q.length;
    const rep = q.filter(i => i.kind !== "msg").length;
    const men = q.filter(i => i.kind === "msg").length;
    let txt = "";
    if (n) {
      const partes = [];
      if (rep) partes.push(`${rep} reporte(s)`);
      if (men) partes.push(`${men} mensaje(s)`);
      txt = partes.join(" y ") + " en espera · se enviarán solos cuando administración reanude la recepción o al abrir el horario (Lun–Vie 10:00–18:00).";
    }
    document.querySelectorAll("[data-queue-count]").forEach(el => {
      el.textContent = txt;
      el.style.display = n ? "" : "none";
    });
  }
  window.renderQueueBadge = renderBadge;

  setInterval(window.flushQueue, SYNC_INTERVAL_MS);
  document.addEventListener("DOMContentLoaded", () => { renderBadge(); window.flushQueue(); });
})();
