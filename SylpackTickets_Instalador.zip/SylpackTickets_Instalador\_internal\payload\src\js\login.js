(() => {
  const form = document.getElementById("loginForm");
  const u = document.getElementById("username");
  const p = document.getElementById("password");
  const err = document.getElementById("error");
  const btn = document.getElementById("submitBtn");
  const status = document.getElementById("status");
  const remember = document.getElementById("remember");

  // ojo mostrar/ocultar (único: el nativo del navegador está oculto por CSS)
  const t = document.getElementById("togglePass");
  const eo = document.getElementById("eyeOpen");
  const ec = document.getElementById("eyeClosed");
  t.addEventListener("click", () => {
    const show = p.type === "password";
    p.type = show ? "text" : "password";
    eo.style.display = show ? "none" : "";
    ec.style.display = show ? "" : "none";
    t.setAttribute("aria-label", show ? "Ocultar contraseña" : "Mostrar contraseña");
    p.focus();
  });

  // estado del servidor local (un solo indicador)
  async function ping() {
    try {
      const r = await fetch(`${API_BASE}/api/health`, { cache: "no-store" });
      if (!r.ok) throw 0;
      status.textContent = "● Local en línea"; status.className = "status ok";
      const d = await r.json().catch(() => ({}));
      const ip = d.ip || String(API_BASE).replace(/^https?:\/\//i, "").split(":")[0];
      window.SylpackSede?.enVivo(ip);
    } catch {
      status.textContent = "● Local sin conexión"; status.className = "status bad";
    }
  }
  ping(); setInterval(ping, 8000);

  // sesión guardada: solo entra si el servidor confirma que sigue siendo válida
  const savedAccess = sessionStorage.getItem("access") || localStorage.getItem("access");
  const savedRole = localStorage.getItem("role");
  if (savedAccess && savedRole) {
    (async () => {
      try {
        await window.SylpackAuth?.ensureFresh?.();
        const tok = sessionStorage.getItem("access") || localStorage.getItem("access");
        if (!tok) return;
        const r = await fetch(`${API_BASE}/api/me`, {
          headers: { Authorization: "Bearer " + tok }, cache: "no-store"
        });
        if (!r.ok) { window.SylpackAuth?.clear?.(); return; }
        const me = await r.json().catch(() => null);
        if (!me || !me.role || me.active === false || me.active === 0) {
          window.SylpackAuth?.clear?.();
          return;
        }
        localStorage.setItem("role", me.role);
        localStorage.setItem("username", me.username || "");
        localStorage.setItem("area", me.area || "");
        localStorage.setItem("puesto", me.puesto || "");
        go(me.role);
      } catch {}
    })();
  }

  form.addEventListener("submit", async e => {
    e.preventDefault();
    err.textContent = "";
    btn.disabled = true;
    btn.classList.add("loading");
    const veil = document.createElement("div");
    veil.className = "auth-veil";
    veil.innerHTML = `<div class="auth-box"><span class="auth-spin"></span><span>Verificando credenciales…</span></div>`;
    document.body.appendChild(veil);
    const ctrl = new AbortController();
    const to = setTimeout(() => ctrl.abort(), 12000);
    try {
      const r = await fetch(`${API_BASE}/api/login`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: u.value.trim(), password: p.value.trim() }),
        signal: ctrl.signal
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.msg || "No se pudo ingresar");
      localStorage.setItem("refresh", d.refresh);
      localStorage.setItem("role", d.role);
      localStorage.setItem("username", d.username);
      localStorage.setItem("area", d.area || "");
      localStorage.setItem("puesto", d.puesto || "");
      if (remember.checked) localStorage.setItem("access", d.access);
      else { sessionStorage.setItem("access", d.access); localStorage.removeItem("access"); }
      veil.querySelector(".auth-box span:last-child").textContent = "Acceso correcto, abriendo…";
      go(d.role);
    } catch (e2) {
      veil.remove();
      const msg = (e2.name === "AbortError" || e2.message === "Failed to fetch")
        ? "No hay conexión con el servidor local. Revisa tu conexión a la red de oficina e inténtalo de nuevo."
        : e2.message;
      err.textContent = msg;
      window.Modal?.error("No se pudo ingresar", msg);
    } finally { clearTimeout(to); btn.disabled = false; btn.classList.remove("loading"); }
  });

  function go(role) {
    // La administración usa el panel; el gestor de compras usa el portal normal
    // con su pestaña extra "Gestionar compras"; el resto reporta.
    location.href = ["admin", "super"].includes(role) ? "admin.html" : "user.html";
  }
})();
