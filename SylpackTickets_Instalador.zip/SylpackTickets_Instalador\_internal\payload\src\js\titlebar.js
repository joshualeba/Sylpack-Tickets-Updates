/* Titlebar Sylpack: arrastre + min/max/close (pywebview, Tauri o navegador) */
(() => {
  document.body.classList.add("has-titlebar");
  const bar = document.createElement("header");
  bar.id = "titlebar";
  const page = document.body.dataset.page || document.title.replace("Sylpack · ", "").replace("Sylpack Tickets · ", "") || "Tickets";
  const mini = "miniBar" in document.body.dataset; // solo botones, sin logo ni texto
  bar.innerHTML = `
    <div class="tb-drag" id="tbDrag">
      ${mini ? "" : `<img class="tb-logo" src="assets/logo.png" alt="Sylpack" />
      <span class="tb-title"><b>SYLPACK</b> &nbsp;Tickets</span>
      <span class="tb-sub" id="tbSub">${page}</span>`}
    </div>
    <div class="tb-btns">
      <button class="tbtn" id="tbMin" title="Minimizar" aria-label="Minimizar">
        <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><line x1="1" y1="6" x2="11" y2="6"/></svg>
      </button>
      <button class="tbtn" id="tbMax" title="Maximizar / Restaurar" aria-label="Maximizar">
        <svg id="tbMaxIco" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.3"><rect x="1.5" y="1.5" width="9" height="9" rx="1"/></svg>
        <svg id="tbRestoreIco" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.3" style="display:none"><rect x="3.5" y="1" width="7" height="7" rx="1"/><path d="M1 3.5V10a1 1 0 0 0 1 1h6.5"/></svg>
      </button>
      <button class="tbtn close" id="tbClose" title="Cerrar" aria-label="Cerrar">
        <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><line x1="1.5" y1="1.5" x2="10.5" y2="10.5"/><line x1="10.5" y1="1.5" x2="1.5" y2="10.5"/></svg>
      </button>
    </div>`;
  document.body.prepend(bar);

  const isPy = () => !!window.pywebview;
  const isTauri = () => !!window.__TAURI__;

  async function tauriWin() {
    try {
      const { getCurrentWindow } = await import("@tauri-apps/api/window");
      return getCurrentWindow();
    } catch { return null; }
  }

  document.getElementById("tbMin").onclick = async () => {
    if (isPy()) window.pywebview.api.win_min();
    else if (isTauri()) (await tauriWin())?.minimize();
    else document.body.animate([{ opacity: 1 }, { opacity: 1 }], { duration: 1 });
  };
  document.getElementById("tbMax").onclick = async () => {
    if (isPy()) { window.pywebview.api.win_max(); setTimeout(syncMaxIcon, 350); }
    else if (isTauri()) (await tauriWin())?.toggleMaximize();
    else {
      if (!document.fullscreenElement) document.documentElement.requestFullscreen?.().catch(() => {});
      else document.exitFullscreen?.();
    }
  };
  document.getElementById("tbClose").onclick = async () => {
    if (isPy()) window.pywebview.api.win_close();
    else if (isTauri()) (await tauriWin())?.close();
    else window.close();
  };
  // icono maximizar/restaurar según estado real (pywebview expone is_maxed)
  async function syncMaxIcon() {
    try {
      const maxed = isPy() ? await window.pywebview.api.is_maxed() : false;
      document.getElementById("tbMaxIco").style.display = maxed ? "none" : "";
      document.getElementById("tbRestoreIco").style.display = maxed ? "" : "none";
      document.getElementById("tbMax").setAttribute("aria-label", maxed ? "Restaurar" : "Maximizar");
    } catch {}
  }
  setInterval(syncMaxIcon, 700);
  setTimeout(syncMaxIcon, 1500);

  // doble clic en la zona de arrastre = maximizar/restaurar
  document.getElementById("tbDrag").addEventListener("dblclick", () =>
    document.getElementById("tbMax").click());

  // Arrastrar ventana en pywebview frameless: implementado en Python (drag por coordenadas).
  // Aquí solo avisamos la posición para mover sin saltos.
  if (isPy()) {
    const drag = document.getElementById("tbDrag");
    let sx = 0, sy = 0, down = false;
    drag.addEventListener("mousedown", e => { down = true; sx = e.screenX; sy = e.screenY; });
    window.addEventListener("mouseup", () => down = false);
    drag.addEventListener("mousemove", e => {
      if (!down || e.buttons !== 1) return;
      const dx = e.screenX - sx, dy = e.screenY - sy;
      if (Math.abs(dx) + Math.abs(dy) > 2) {
        window.pywebview.api.win_drag(dx, dy);
        sx = e.screenX; sy = e.screenY;
      }
    });
  }

  window.setAppTitle = function(sub) {
    const el = document.getElementById("tbSub");
    if (el) el.textContent = sub;
  };
})();
