/* Navbar Sylpack: menú de cuenta desplegable + cierre de sesión con confirmación. */
(() => {
  const btn = document.getElementById("accountBtn");
  if (!btn) return;
  const menu = document.getElementById("accountMenu");
  const uname = localStorage.getItem("username") || "Cuenta";
  const role = localStorage.getItem("role") || "user";
  const who = document.getElementById("who");
  if (who) who.textContent = uname;
  const whoV = document.getElementById("whoVisible");
  if (whoV) whoV.textContent = uname;
  const ini = document.getElementById("avatarIni");
  if (ini) ini.textContent = (uname.trim()[0] || "U").toUpperCase();
  const nm = document.getElementById("amName");
  if (nm) nm.textContent = uname;
  const rl = document.getElementById("amRole");
  if (rl) rl.textContent = role === "super" ? "Super admin" : role === "admin" ? "Administración" : role === "compras" ? "Gestor de compras" : role === "calidad" ? "Calidad" : "Usuario/a";
  const ar = document.getElementById("amArea");
  const pu = document.getElementById("amPuesto");
  function pintarPerfil(puesto, area) {
    if (pu) { pu.textContent = puesto ? `Puesto: ${puesto}` : ""; pu.style.display = puesto ? "" : "none"; }
    if (ar) { ar.textContent = area ? `Área: ${area}` : ""; ar.style.display = area ? "" : "none"; }
  }
  pintarPerfil(localStorage.getItem("puesto") || "", localStorage.getItem("area") || "");

  /* Estado del servidor junto a la marca del navbar. */
  const apiBase = (typeof API_BASE !== "undefined" && API_BASE) || window.SYLPACK_API || "";
  const hostFromApi = String(apiBase).replace(/^https?:\/\//i, "").replace(/\/.*$/, "").replace(/:\d+$/, "");
  const roleText = window.SYLPACK_ROLE || "";
  const roleIp = /sede\s*\(([^)]+)\)/i.exec(roleText)?.[1] || /cliente\s*->\s*(\S+)/i.exec(roleText)?.[1] || "";
  const fallbackIp = roleIp.trim() || hostFromApi;
  const brand = document.querySelector(".credit-brand");
  if (brand && !brand.querySelector(".cb-conn")) {
    const el = document.createElement("span");
    el.className = "cb-conn";
    el.id = "cbConn";
    el.dataset.state = "checking";
    el.setAttribute("role", "status");
    el.setAttribute("aria-live", "polite");
    el.innerHTML = '<span class="cb-conn-dot" aria-hidden="true"></span><span class="cb-conn-copy"><b>Conectando…</b><small>Servidor</small></span>';
    brand.appendChild(el);
  }
  const conn = document.getElementById("cbConn");
  const connText = conn?.querySelector("b");
  const connIp = conn?.querySelector("small");
  const paintConn = (state, ip, label) => {
    if (!conn) return;
    conn.dataset.state = state;
    conn.title = `${label}${ip ? ` · ${ip}` : ""}${apiBase ? ` · ${apiBase}` : ""}`;
    if (connText) connText.textContent = label;
    if (connIp) connIp.textContent = ip || "IP desconocida";
  };
  let checkingConn = false;
  const checkConn = async () => {
    if (!conn || checkingConn) return;
    checkingConn = true;
    const ctrl = typeof AbortController !== "undefined" ? new AbortController() : null;
    const timer = setTimeout(() => ctrl?.abort(), 4500);
    try {
      if (navigator.onLine === false) throw new Error("sin-red");
      const r = await fetch(`${apiBase}/api/health`, { cache: "no-store", signal: ctrl?.signal });
      if (!r.ok) throw new Error("sin-respuesta");
      const d = await r.json().catch(() => ({}));
      const ip = d.ip || fallbackIp;
      paintConn("ok", ip, "En línea");
      window.SylpackSede?.enVivo?.(ip);
    } catch {
      paintConn("bad", fallbackIp, navigator.onLine === false ? "Sin red" : "Sin conexión");
    } finally {
      clearTimeout(timer);
      checkingConn = false;
    }
  };
  if (conn) {
    paintConn("checking", fallbackIp, "Conectando…");
    checkConn();
    setInterval(checkConn, 8000);
    window.addEventListener("online", checkConn);
    window.addEventListener("offline", () => paintConn("bad", fallbackIp, "Sin red"));
    document.addEventListener("visibilitychange", () => { if (!document.hidden) checkConn(); });
  }

  const tok = localStorage.getItem("access") || sessionStorage.getItem("access");
  if (tok) fetch(`${API_BASE}/api/me`, { headers: { Authorization: "Bearer " + tok } })
    .then(r => r.ok ? r.json() : null)
    .then(d => {
      if (!d) return;
      const puesto = d.puesto || "", area = d.area || "";
      localStorage.setItem("puesto", puesto);
      localStorage.setItem("area", area);
      pintarPerfil(puesto, area);
    }).catch(() => {});

  btn.addEventListener("click", e => {
    e.stopPropagation();
    const open = menu.classList.toggle("show");
    btn.setAttribute("aria-expanded", open ? "true" : "false");
  });
  document.addEventListener("click", e => {
    if (!menu.contains(e.target) && e.target !== btn && !btn.contains(e.target)) {
      menu.classList.remove("show");
      btn.setAttribute("aria-expanded", "false");
    }
  });
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") menu.classList.remove("show");
  });

  menu.addEventListener("click", async e => {
    const it = e.target.closest("[data-am]");
    if (!it || it.disabled) return;
    menu.classList.remove("show");
    const k = it.dataset.am;
    if (k === "a11y") window.SylpackA11y?.open();
    else if (k === "about") window.Modal?.info(
      "Sylpack Tickets",
      `Sistema interno de reportes v${window.SYLPACK_VERSION || APP_VERSION}.\nRed local segura · Horario Lun–Vie 10:00–18:00.`);
    else if (k === "logout") window.sylpackLogout?.();
  });

  window.sylpackLogout = async () => {
    const ok = await window.Modal?.show({
      title: "Cerrar sesión",
      msg: `¿Seguro que quieres cerrar la sesión de ${uname} en este equipo?`,
      type: "info",
      buttons: [
        { label: "Cancelar", value: false },
        { label: "Cerrar sesión", value: true, primary: true, danger: true }
      ]
    });
    if (ok) {
      if (window.SylpackAuth?.clear) window.SylpackAuth.clear();
      else { localStorage.removeItem("access"); sessionStorage.removeItem("access"); }
      location.replace("login.html");
    }
  };
})();
