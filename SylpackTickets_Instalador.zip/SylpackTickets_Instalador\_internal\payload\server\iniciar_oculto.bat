@echo off
REM Backend Sylpack Tickets - arranca oculto (sin ventana), se queda corriendo.
cd /d "%~dp0"
start "" pythonw app.py
