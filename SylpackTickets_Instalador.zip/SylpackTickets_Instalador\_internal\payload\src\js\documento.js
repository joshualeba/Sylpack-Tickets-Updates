/* Sylpack · Render del documento oficial de compra.
   Se alimenta en tiempo real de /api/compras/documentos/<id>. */
(() => {
  "use strict";
  const $ = (s) => document.querySelector(s);
  const params = new URLSearchParams(location.search);
  const queryToken = params.get("token") || "";
  const token = () => queryToken || localStorage.getItem("access") || sessionStorage.getItem("access");
  const id = params.get("id");
  const autoPrint = params.get("print") === "1";
  // digital=1 conserva enlaces, imágenes y variantes (PDF guardado en la BD).
  // La impresión usa la versión de texto útil, sin depender de enlaces.
  const digital = params.get("digital") === "1";
  document.body.classList.toggle("doc-digital", digital);
  // Dentro de la vista previa conservamos la hoja A4 tal como se imprime.
  if (window.self !== window.top) document.body.classList.add("doc-embed");
  let currentDoc = null;
  const API = () => String((typeof API_BASE !== "undefined" ? API_BASE : (window.API_BASE || ""))).replace(/\/$/, "");

  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const nl2br = (s) => esc(s).replace(/\n/g, "<br>");
  const money = (n) => new Intl.NumberFormat("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(n) || 0);
  const qty = (n) => new Intl.NumberFormat("es-MX", { maximumFractionDigits: 3 }).format(Number(n) || 0);
  const fdate = (s) => {
    if (!s) return "—";
    const m = String(s).match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) return `${m[3]}/${m[2]}/${m[1]}`;
    const d = new Date(s);
    return isNaN(d) ? "—" : d.toLocaleDateString("es-MX", { day: "2-digit", month: "2-digit", year: "numeric" });
  };
  const fdt = (s) => {
    if (!s) return "—";
    const plain = String(s).match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (plain) return `${plain[3]}/${plain[2]}/${plain[1]}`;
    const d = new Date(s);
    if (isNaN(d)) return "—";
    return d.toLocaleString("es-MX", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
  };
  const safeUrl = (u) => /^https?:\/\//i.test(String(u || "")) ? String(u) : "";
  const LINK_SITE_NAMES = {
    amazon: "Amazon", mercadolibre: "Mercado Libre", temu: "Temu", aliexpress: "AliExpress",
    walmart: "Walmart", liverpool: "Liverpool", homedepot: "Home Depot", officedepot: "Office Depot",
    coppel: "Coppel", sears: "Sears", costco: "Costco", sams: "Sam's Club", ebay: "eBay",
    sodimac: "Sodimac", shopify: "Shopify",
  };
  function linkSiteName(url) {
    const clean = safeUrl(url);
    if (!clean) return "";
    try {
      const host = new URL(clean).hostname.toLowerCase().replace(/^www\./, "");
      const parts = host.split(".");
      for (const part of parts) if (LINK_SITE_NAMES[part]) return LINK_SITE_NAMES[part];
      const base = parts.length > 1 ? parts[parts.length - 2] : parts[0];
      return base ? base.charAt(0).toUpperCase() + base.slice(1) : "";
    } catch { return ""; }
  }
  function productLinkText(url, fallback = "") {
    const site = linkSiteName(url) || String(fallback || "").trim();
    return site ? `Producto de ${site}` : "Ver producto";
  }
  const MESES_CORTOS = ["ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC"];
  function docFileName(d = {}) {
    const hoy = new Date();
    const raw = String(d.fecha || `${hoy.getFullYear()}-${String(hoy.getMonth() + 1).padStart(2, "0")}-${String(hoy.getDate()).padStart(2, "0")}`).slice(0, 10);
    const [y, m, day] = raw.split("-");
    const fecha = y && m && day ? `${day}${MESES_CORTOS[Number(m) - 1] || m}${y}` : "";
    const folio = String(d.folio || "");
    if (d.tipo === "requisicion" || /^REQ/i.test(folio)) {
      const hit = folio.match(/^REQ[-_]?(\d{4})[-_]?(\d+)/i);
      const anio = hit ? hit[1] : (y || hoy.getFullYear());
      const seq = hit ? String(hit[2]).padStart(4, "0") : String(d.id || "").padStart(4, "0");
      return `REQ_${anio}_${seq}_${fecha}.pdf`;
    }
    const hit = folio.match(/^(?:OC|ORDEN[-_ ]?COMPRA)[-_]?(\d{4})?[-_]?(\d+)/i);
    const seq = hit ? String(hit[2]).padStart(4, "0") : String(d.id || "").padStart(4, "0");
    return `OrdenCompra_${seq}_${fecha}.pdf`;
  }

  const EST = {
    borrador: ["BORRADOR", ""], emitida: ["EMITIDA", "warn"], autorizada: ["AUTORIZADA", "ok"],
    enviada: ["ENVIADA", "info"], recibida: ["RECIBIDA", "ok"], cerrada: ["CERRADA", ""],
    cancelada: ["CANCELADA", "danger"],
  };

  function hash(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return (h >>> 0).toString(16).toUpperCase().padStart(8, "0");
  }

  function letras(n) {
    const U = ["cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve",
      "diez", "once", "doce", "trece", "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve",
      "veinte", "veintiuno", "veintidós", "veintitrés", "veinticuatro", "veinticinco", "veintiséis", "veintisiete", "veintiocho", "veintinueve"];
    const D = ["", "", "veinte", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa"];
    const C = ["", "ciento", "doscientos", "trescientos", "cuatrocientos", "quinientos", "seiscientos", "setecientos", "ochocientos", "novecientos"];
    const u3 = (x) => {
      if (!x) return "";
      if (x === 100) return "cien";
      let out = "";
      const c = Math.floor(x / 100), r = x % 100;
      if (c) out += C[c] + " ";
      if (r < 30) out += U[r];
      else { const d = Math.floor(r / 10), u = r % 10; out += D[d] + (u ? " y " + U[u] : ""); }
      return out.trim();
    };
    const u6 = (x) => {
      if (!x) return "cero";
      const miles = Math.floor(x / 1000), resto = x % 1000;
      let out = "";
      if (miles) out += (miles === 1 ? "mil" : u3(miles) + " mil");
      if (resto) out += (out ? " " : "") + u3(resto);
      return out;
    };
    const u9 = (x) => {
      if (!x) return "cero";
      const millones = Math.floor(x / 1000000), resto = x % 1000000;
      let out = "";
      if (millones) out += (millones === 1 ? "un millón" : u6(millones) + " millones");
      if (resto) out += (out ? " " : "") + u6(resto);
      return out;
    };
    const abs = Math.abs(Number(n) || 0);
    const ent = Math.floor(abs);
    const cent = Math.round((abs - ent) * 100);
    const entTxt = ent === 1 ? "un" : u9(ent);
    return `${entTxt} pesos ${String(cent).padStart(2, "0")}/100 M.N.`;
  }

  function error(msg) {
    const box = $("#doc");
    if (!box) return;
    box.innerHTML = `<div class="doc-error"><b>No se pudo cargar el documento</b><p>${esc(msg)}</p>
      <p><button onclick="location.reload()" style="height:36px;padding:0 16px;border-radius:9px;border:1px solid #dbe3ee;background:#f7f9fc;cursor:pointer;font:inherit">Reintentar</button></p></div>`;
  }

  function render(d) {
    const tipo = d.tipo === "requisicion" ? "REQUISICIÓN DE MATERIAL" : "ORDEN DE COMPRA";
    const esReq = d.tipo === "requisicion";
    const e = Object.assign({}, d.empresa_snapshot || {}, d.empresa || {});
    const p = Object.assign({}, d.proveedor_snapshot || {});
    if (d.proveedor_nombre) p.nombre = d.proveedor_nombre;
    if (d.proveedor_rfc) p.rfc = d.proveedor_rfc;
    if (d.proveedor_razon) p.razon_social = d.proveedor_razon;
    if (d.proveedor_domicilio) p.domicilio = d.proveedor_domicilio;
    if (d.proveedor_contacto) p.contacto = d.proveedor_contacto;
    if (d.proveedor_email) p.email = d.proveedor_email;
    if (d.proveedor_telefono) p.telefono = d.proveedor_telefono;
    if (d.proveedor_condiciones) p.condiciones_pago = d.proveedor_condiciones;
    const s = d.solicitud || {};
    const optionCount = (s.items || []).reduce((n, r) => n + ((r.opciones || []).length), 0);
    const provName = p.nombre || s.proveedor_sugerido || "Por definir";
    const st = EST[d.estado] || [String(d.estado || "").toUpperCase(), ""];
    const reqItems = {};
    (s.items || []).forEach(x => { reqItems[x.id] = x; });
    const subtotal = Number(d.subtotal) || 0;
    const dp = Number(d.descuento_pct) || 0;
    const iv = d.iva_pct == null ? 16 : Number(d.iva_pct);
    const desc = subtotal * dp / 100;
    const base = subtotal - desc;
    // El backend expone iva_monto: si los precios ya incluían IVA vale 0 y no
    // se muestra una línea extra; si hay mezcla, refleja solo lo que sí grava.
    const iva = d.iva_monto != null ? Math.max(0, Number(d.iva_monto) || 0) : base * iv / 100;
    const total = Number(d.total) || (base + iva);
    const ivaModo = d.iva_modo || (iv === 0 ? "incluido" : "neto");
    const ivaLabel = ivaModo === "mixto" ? "IVA (partidas sin IVA incluido)" : `IVA (${iv}%)`;
    const val = "SYL-" + hash(`${d.folio}|${total}|${d.id}`) + "-" + String(d.id).padStart(4, "0");
    // Logo institucional de Sylpack (no el de Sylpack Tickets). Se usa el
    // archivo local para que los PDF también salgan bien sin internet.
    const logo = "assets/logo-sylpack.png";
    const logoRemoto = "https://res.cloudinary.com/dpvm2gro2/image/upload/v1790961568/favicon_huka8c.png";
    const EMPRESA_DOC = "Sylpack alimentos SA de CV";

    // Opciones capturadas por la persona solicitante: se imprimen completas en
    // la requisición oficial, con imagen y enlace amigable (nunca la URL cruda).
    // Cada producto genera un grupo que el paginador coloca completo en una
    // hoja cuando cabe; si no, reparte sus tarjetas sin cortar ninguna.
    const optionGroups = {};
    if (esReq && digital) {
      (s.items || []).forEach((r, i) => {
        const ops = r.opciones || [];
        if (!ops.length) return;
        optionGroups[i] = {
          idx: i,
          name: r.nombre || (d.items || [])[i]?.nombre || "Producto",
          total: ops.length,
          cards: ops.map((o, k) => {
            const link = safeUrl(o.link);
            const img = o.imagen || "";
            const costoNum = Number(o.costo_unitario) || 0;
            const impNum = costoNum ? costoNum * (Number(r.cantidad) || 0) : 0;
            const costo = costoNum
              ? `<span>Costo: $ ${money(costoNum)} ${o.precio_incluye_iva ? "IVA incl." : "+ IVA"}${impNum ? ` · Importe: $ ${money(impNum)}` : ""}</span>`
              : `<span>Precio pendiente de cotizar</span>`;
            return `<div class="doc-optcard">
              <span class="doc-optimg" data-docimg="${esc(img)}" data-doclink="${esc(link)}"><span class="doc-img-ph" aria-hidden="true"></span></span>
              <div class="doc-optbody">
                <b>${esc(o.etiqueta || `Opción ${k + 1}`)}</b>
                ${o.proveedor ? `<span>Proveedor: ${esc(o.proveedor)}</span>` : ""}
                ${o.diferencia ? `<span class="doc-optdesc">${esc(o.diferencia)}</span>` : ""}
                ${costo}
                ${link ? `<a href="${esc(link)}" target="_blank" rel="noopener">${esc(productLinkText(link))}</a>` : ""}
              </div>
            </div>`;
          }),
        };
      });
    }

    // Imagen del PRODUCTO (no el logo de la tienda): se resuelve de la imagen
    // guardada de la partida o, en su defecto, de la foto del producto en el enlace.
    const rowHTML = (it, i) => {
      const r = reqItems[it.item_id] || (s.items || [])[i] || {};
      const opciones = r.opciones || [];
      const opt = it.opcion_id ? opciones.find(o => String(o.id) === String(it.opcion_id)) : null;
      const link = safeUrl(it.link || opt?.link || r.link);
      const img = it.imagen || opt?.imagen || r.imagen || "";
      const prov = (it.opcion_etiqueta || opt?.etiqueta || r.proveedor)
        ? `<span class="doc-item-desc">Opción: ${esc(it.opcion_etiqueta || opt?.etiqueta || "")}${(it.diferencia || opt?.diferencia) ? ` · ${esc(it.diferencia || opt?.diferencia)}` : ""}${r.proveedor ? ` · ${esc(r.proveedor)}` : ""}</span>` : "";
      const cant = Number(it.cantidad) || 0;
      const importeProducto = Number(it.importe) || cant * (Number(it.costo_unitario) || 0);
      // Datos que se capturan al pedir el producto y que el documento debe
      // conservar para que nada se pierda al imprimir.
      const motivo = r.motivo || it.motivo || "";
      const requisitos = r.requisitos_calidad || it.requisitos_calidad || "";
      // Variantes capturadas por quien solicita: se listan dentro del propio
      // producto con su proveedor, diferencia, costo e importe. En digital
      // conservan el enlace; en la impresión el texto basta sin abrir nada.
      const variantes = esReq && opciones.length ? `
        <div class="doc-variants">
          <div class="doc-variants-head">
            <b>${opciones.length} variante${opciones.length === 1 ? "" : "s"} cotizada${opciones.length === 1 ? "" : "s"}</b>
            <span>${importeProducto ? `Total del producto: $ ${money(importeProducto)}` : "Precio pendiente de cotizar"}</span>
          </div>
          <ul class="doc-variant-list">
            ${opciones.map((o, k) => {
              const opLink = safeUrl(o.link);
              const costo = Number(o.costo_unitario) || 0;
              const opImporte = costo ? costo * cant : 0;
              return `<li class="doc-variant">
                <span class="doc-variant-name">${esc(o.etiqueta || `Variante ${k + 1}`)}</span>
                ${o.proveedor ? `<span class="doc-variant-prov">${esc(o.proveedor)}</span>` : ""}
                ${o.diferencia ? `<span class="doc-variant-desc">${esc(o.diferencia)}</span>` : ""}
                <span class="doc-variant-money">${costo
                  ? `$ ${money(costo)} ${o.precio_incluye_iva ? "IVA incl." : "+ IVA"}${opImporte ? ` · Importe por ${qty(cant)} ${esc(it.unidad || "pza")}: $ ${money(opImporte)}` : ""}`
                  : "Costo pendiente de cotizar"}</span>
                ${digital && opLink ? `<a class="doc-variant-link" href="${esc(opLink)}" target="_blank" rel="noopener">${esc(productLinkText(opLink))}</a>` : ""}
              </li>`;
            }).join("")}
          </ul>
          <span class="doc-variants-note">${digital
            ? "Cada variante conserva proveedor, importe, imagen y enlace en este PDF digital."
            : "Compras elegirá una variante al generar la orden de compra; este documento impreso no requiere abrir enlaces."}</span>
        </div>` : "";
      const imgAttrs = `data-docimg="${esc(img)}" data-doclink="${esc(link)}" data-docrow="${i}"`;
      return `<tr>
        <td class="c doc-imgcell"><span class="doc-item-img" ${imgAttrs}><span class="doc-img-ph" aria-hidden="true"></span></span></td>
        <td class="c">${i + 1}</td>
        <td class="r">${qty(it.cantidad)}</td>
        <td>${esc(it.unidad || "pza")}</td>
        <td class="c">${it.id_fabricacion ? `<span class="doc-code">${esc(it.id_fabricacion)}</span>` : "—"}</td>
        <td><span class="doc-item-name">${esc(it.nombre)}</span>
          ${(it.certificado || r.certificado) ? `<span class="doc-item-desc"><b>✓ Producto certificado por Calidad</b></span>` : ""}
          ${(it.descripcion || r.descripcion) ? `<span class="doc-item-desc">${nl2br(it.descripcion || r.descripcion)}</span>` : ""}
          ${motivo ? `<span class="doc-item-desc"><b>Para qué:</b> ${nl2br(motivo)}</span>` : ""}
          ${requisitos ? `<span class="doc-item-desc"><b>Requisitos de calidad:</b> ${nl2br(requisitos)}</span>` : ""}
          ${it.fecha_llegada ? `<span class="doc-item-desc"><b>Llegada comprometida:</b> ${esc(fdate(it.fecha_llegada))}</span>` : ""}
          ${prov}
          ${variantes}
        </td>
        <td class="r">$ ${money(it.costo_unitario)}</td>
        <td class="r">$ ${money(it.importe)}</td>
      </tr>`;
    };

    const totalRows = `
      <div><span>${ivaModo === "incluido" ? "Subtotal (IVA incluido)" : "Subtotal"}</span><b>$ ${money(subtotal)}</b></div>
      ${dp ? `<div><span>Descuento (${dp}%)</span><b>- $ ${money(desc)}</b></div>` : ""}
      ${iva > 0.004 ? `<div><span>${esc(ivaLabel)}</span><b>$ ${money(iva)}</b></div>` : ""}
      <div class="doc-total"><span>Total ${esc(d.moneda || "MXN")}</span><b>$ ${money(total)}</b></div>
      ${ivaModo === "incluido" ? `<div class="doc-iva-note">Los precios capturados ya incluyen IVA; no se agrega IVA adicional.</div>` : ""}`;

    const empresaBlock = `
      <div class="doc-box">
        <h2>Empresa</h2>
        <b>${esc(EMPRESA_DOC)}</b>
        <div class="doc-sub">${esc(e.nombre || "")}</div>
        <dl>
          <dt>RFC</dt><dd>${esc(e.rfc || "—")}</dd>
          <dt>Domicilio</dt><dd>${esc(e.domicilio || "—")}</dd>
          <dt>Contacto</dt><dd>${esc([e.telefono, e.email].filter(Boolean).join(" · ") || "—")}</dd>
        </dl>
      </div>`;

    const provBlock = `
      <div class="doc-box">
        <h2>${esReq ? "Proveedor sugerido" : "Proveedor"}</h2>
        <b>${esc(provName)}</b>
        <div class="doc-sub">${esc(p.razon_social || "")}</div>
        <dl>
          <dt>RFC</dt><dd>${esc(p.rfc || "—")}</dd>
          <dt>Domicilio</dt><dd>${esc(p.domicilio || "—")}</dd>
          <dt>Contacto</dt><dd>${esc([p.contacto, p.telefono].filter(Boolean).join(" · ") || "—")}</dd>
          <dt>Correo</dt><dd>${esc(p.email || "—")}</dd>
          <dt>Condiciones</dt><dd>${esc(p.condiciones_pago || "—")}</dd>
        </dl>
      </div>`;

    const docBlock = `
      <div class="doc-box">
        <h2>Documento</h2>
        <dl>
          <dt>Folio</dt><dd>${esc(d.folio || "—")}</dd>
          <dt>Fecha</dt><dd>${fdate(d.fecha)}</dd>
          ${d.fecha_entrega ? `<dt>Entrega comprometida</dt><dd>${fdate(d.fecha_entrega)}</dd>` : ""}
          <dt>Moneda</dt><dd>${esc(d.moneda || "MXN")}</dd>
          <dt>Solicitud</dt><dd>${esc(s.folio || "—")}</dd>
          <dt>Estado</dt><dd>${esc(st[0])}</dd>
        </dl>
      </div>`;

    const empresaReqBlock = `
      <div class="doc-box">
        <h2>Empresa</h2>
        <b>${esc(EMPRESA_DOC)}</b>
        ${e.rfc ? `<dl><dt>RFC</dt><dd>${esc(e.rfc)}</dd></dl>` : ""}
      </div>`;
    const reqSinProveedor = esReq && provName === "Por definir";
    const metaBlock = esReq
      ? empresaReqBlock + (reqSinProveedor ? "" : provBlock) + docBlock
      : empresaBlock + provBlock + docBlock;
    const flujoNuevo = (s.flujo || "legado") === "nuevo";
    const esCalidad = (d.tipo_compra || s.tipo_compra || "normal") === "calidad";
    const jefe = d.jefe_area || s.jefe_area || s.username || d.elaborado_por || "Jefatura de área";
    let signs = [];
    if (flujoNuevo && esReq) {
      signs = [
        { nombre: s.username || d.elaborado_por || "Solicitante", cargo: `Solicitó · ${s.user_area || s.area || "Área solicitante"}`, fecha: fdate(d.created_at) },
        { nombre: jefe, cargo: "Jefatura de área · Autorizó requisición" },
      ];
    } else if (flujoNuevo && esCalidad) {
      signs = [
        { nombre: jefe, cargo: "Jefatura de área · Autorizó" },
        { nombre: d.calidad_por || "Calidad", cargo: "Calidad · Revisó y firmó", fecha: d.calidad_at ? fdate(d.calidad_at) : "" },
        { nombre: "Sandra Limones", cargo: "Gestión de compras · Firmó" },
        { nombre: "Lucío Limones", cargo: "Gestión de compras · Firmó" },
      ];
    } else if (flujoNuevo) {
      signs = [
        { nombre: jefe, cargo: "Jefatura de área · Autorizó" },
        { nombre: "Sandra Limones", cargo: "Gestión de compras · Firmó" },
        { nombre: "Lucío Limones", cargo: "Gestión de compras · Firmó" },
      ];
    } else {
      signs = [
        { nombre: d.elaborado_por || "Gestor de compras", cargo: "Elaboró · Gestión de compras", fecha: fdate(d.created_at) },
        { nombre: d.autorizado_por || "Pendiente de autorización", cargo: "Autorizó · Gestión de compras", fecha: d.autorizado_at ? fdate(d.autorizado_at) : "" },
        { nombre: d.entregar_a || s.username || "", cargo: "Recibió · Almacén / solicitante" },
      ];
    }

    const itemCount = (d.items || []).length;
    const headerSection = `
      <header class="doc-header" data-doc-section data-order="1">
        <div class="doc-brand">
          <img class="doc-logo" src="${esc(logo)}" alt="Sylpack alimentos" onerror="this.onerror=null;this.src='${esc(logoRemoto)}'"/>
          <div class="doc-brand-txt">
            <b>${esc(EMPRESA_DOC)}</b>
            <small>${e.rfc ? `RFC ${esc(e.rfc)}` : "Departamento de compras"}</small>
          </div>
        </div>
        <div class="doc-title">
          <span class="doc-kicker">Documento oficial de compra</span>
          <h1>${tipo}</h1>
          <span class="doc-folio">${esc(d.folio || "")}</span>
          <span class="doc-status ${esc(st[1])}">${esc(st[0])}</span>
        </div>
      </header>`;
    const metaSection = `<section class="doc-meta${reqSinProveedor ? " two" : ""}" data-doc-section data-order="2">${metaBlock}</section>`;
    const shipSection = `
      <section class="doc-ship" data-doc-section data-order="3">
        <div><span>Entregar a</span><b>${esc(d.entregar_a || s.username || "Almacén general")}</b></div>
        <div><span>Almacén / destino</span><b>${esc(d.almacen || "Almacén general")}</b></div>
        <div><span>Solicitó</span><b>${esc([s.username, s.user_area].filter(Boolean).join(" · ") || "—")}</b></div>
      </section>`;
    const itemsSection = (rows) => `
      <section class="doc-items" data-doc-section>
        <div class="doc-sec-title"><h2>Detalle de materiales y servicios</h2></div>
        <table>
          <thead><tr>
            <th class="c">Imagen</th><th class="c">#</th><th class="r">Cantidad</th><th>Unidad</th><th class="c">ID fabricación</th>
            <th>Descripción</th><th class="r">Costo unitario</th><th class="r">Importe</th>
          </tr></thead>
          <tbody>${rows.join("")}</tbody>
        </table>
      </section>`;
    const optionsSection = (groups) => `
      <section class="doc-options" data-doc-section>
        <div class="doc-sec-title"><h2>Variantes y opciones por producto</h2></div>
        <p class="doc-optintro">Cada producto muestra las variantes cotizadas con su proveedor, costo, importe, imagen y enlace para que Compras elija la mejor opción.</p>
        ${groups.map(g => `
          <div class="doc-optgroup">
            <div class="doc-optgroup-head"><b>${g.idx + 1}. ${esc(g.name)}${g.cont ? " (continuación)" : ""}</b><span>${g.cards.length < g.total ? `Opciones ${g.start + 1}–${g.start + g.cards.length} de ${g.total}` : `${g.total} opción(es)`}</span></div>
            <div class="doc-optgrid" style="grid-template-columns:repeat(${Math.min(g.cards.length, 2)},minmax(0,1fr))">${g.cards.join("")}</div>
          </div>`).join("")}
      </section>`;
    // Bloques de cierre: se paginan como unidades independientes para que los
    // totales y las firmas nunca se monten sobre el contenido.
    const closingBlocks = [];
    if (s.justificacion) closingBlocks.push({ html: `<section class="doc-closing doc-notes" data-doc-section><h2>Justificación</h2><p>${nl2br(s.justificacion)}</p></section>` });
    if (d.condiciones) closingBlocks.push({ html: `<section class="doc-closing doc-conditions" data-doc-section><h2>Condiciones comerciales</h2><p>${nl2br(d.condiciones)}</p></section>` });
    if (d.notas) closingBlocks.push({ html: `<section class="doc-closing doc-notes" data-doc-section><h2>Notas</h2><p>${nl2br(d.notas)}</p></section>` });
    closingBlocks.push({ html: `<section class="doc-closing doc-totals-wrap" data-doc-section><div class="doc-totals">${totalRows}</div></section>` });
    closingBlocks.push({ html: `<p class="doc-words doc-closing" data-doc-section><b>Importe con letra</b>${esc(letras(total))}</p>` });
    const bottomBlock = `
      <div class="doc-page-bottom" data-doc-bottom>
        <section class="doc-signs${signs.length === 2 ? " two" : signs.length === 3 ? " three" : signs.length === 4 ? " four" : ""}">${signs.map(x => `<div class="doc-sign"><div class="doc-sign-line"></div><b>${esc(x.nombre)}</b><span>${esc(x.cargo)}</span><small>${esc(x.fecha || "Fecha: ____ / ____ / ______")}</small></div>`).join("")}
        </section>
        <footer class="doc-footer">
          <div><b>${esc(EMPRESA_DOC)}</b> · RFC ${esc(e.rfc || "—")}<br>
            ${esc(e.domicilio || "")}<br>${esc([e.telefono, e.email].filter(Boolean).join(" · ") || "")}</div>
          <div class="doc-valid">Documento generado por Sylpack<br>
            Actualizado: ${fdt(d.updated_at || d.created_at)}<br>
            Validación: <b>${esc(val)}</b></div>
        </footer>
      </div>`;
    const watermarks = `<div class="doc-watermarks" aria-hidden="true"><span>SYLPACK</span><span>SYLPACK</span><span>SYLPACK</span></div>`;
    const contHeader = n => `
      <header class="doc-cont-head">
        <div><span class="doc-kicker">${esc(tipo)}</span><b>${esc(d.folio || "")}</b><small>${esc(EMPRESA_DOC)}</small></div>
        <span>Hoja ${n}</span>
      </header>`;
    const rowPlaceholder = `<tr><td colspan="8" style="text-align:center;color:#64748b;padding:8mm">Sin partidas registradas</td></tr>`;
    const rows = (d.items || []).map((it, i) => rowHTML(it, i));
    _layout = {
      optionCount,
      itemCount,
      firstHead: headerSection + metaSection + shipSection,
      contHeader,
      watermarks,
      bottom: bottomBlock,
      rows: rows.length ? rows : [rowPlaceholder],
      groups: optionGroups,
      closing: closingBlocks,
      itemsSection,
      optionsSection,
    };
    paginate();
  }

  /* --- paginación real: mide cada hoja A4 y reparte el contenido --- */
  let _layout = null;
  let _fitTimer = 0;

  function blockHTML(model, isFirst) {
    const L = _layout;
    // La cabecera forma parte de la hoja: la primera lleva los datos completos
    // y las siguientes la cabecera de continuación. Debe medirse junto con el
    // contenido para que el reparto sea real.
    let html = isFirst ? L.firstHead : L.contHeader(2);
    if (model.rows.length) html += L.itemsSection(model.rows);
    if (model.groups.length) html += L.optionsSection(model.groups);
    html += model.closing.map(b => b.html).join("");
    return html;
  }

  function measurePage(contentHTML, withBottom) {
    // Se mide con la geometría exacta de impresión A4. `doc-embed` desactiva
    // las variantes responsivas de pantalla para que la medición coincida con
    // la hoja que se imprime.
    const body = document.body;
    const addEmbed = !body.classList.contains("doc-embed");
    if (addEmbed) body.classList.add("doc-embed");
    try {
      let m = document.getElementById("docMeasure");
      if (!m) {
        m = document.createElement("section");
        m.id = "docMeasure";
        m.className = "doc-page doc-measure";
        m.setAttribute("aria-hidden", "true");
        // Dentro de #doc para heredar su tipografía (tamaño, interlineado y
        // corte de palabras) y medir igual que la hoja impresa.
        ($("#doc") || document.body).appendChild(m);
      }
      m.innerHTML = `<div class="doc-page-content" data-doc-content>${contentHTML}</div>${withBottom ? _layout.bottom : ""}`;
      const c = m.querySelector("[data-doc-content]");
      // scrollHeight > clientHeight significa que el contenido ya no cabe en la
      // hoja; el bloque de firmas ocupa su propio espacio (flex none) y resta
      // altura disponible automáticamente.
      return c.scrollHeight <= c.clientHeight + 1.5;
    } finally {
      if (addEmbed) body.classList.remove("doc-embed");
    }
  }

  function renderPages(pages) {
    const doc = $("#doc");
    if (!doc) return;
    doc.dataset.optionCount = String(_layout.optionCount);
    doc.dataset.itemCount = String(_layout.itemCount);
    doc.innerHTML = pages.map((model, i) => {
      const last = i === pages.length - 1;
      return `<section class="doc-page${last ? " doc-page-last" : ""}" data-doc-page="${i + 1}">
        ${_layout.watermarks}
        <div class="doc-page-content" data-doc-content>${blockHTML(model, i === 0)}</div>
        ${last ? _layout.bottom : ""}
      </section>`;
    }).join("");
    const all = [...doc.querySelectorAll("[data-doc-page]")];
    all.forEach((p, i) => {
      const n = p.querySelector(".doc-cont-head > span");
      if (n) n.textContent = `Hoja ${i + 1} de ${all.length}`;
    });
    document.getElementById("docMeasure")?.remove();
    hydrateDocImages();
  }

  function paginate() {
    if (!_layout) return;
    const pages = [];
    let model = { rows: [], groups: [], closing: [] };
    pages.push(model);
    const hasContent = (m) => m.rows.length || m.groups.length || m.closing.length;
    const nextPage = () => { model = { rows: [], groups: [], closing: [] }; pages.push(model); };

    const addGroup = (g) => {
      let remaining = g.cards.slice();
      let placed = 0;
      while (remaining.length) {
        const cont = placed > 0;
        // Una tarjeta completa debe caber sin encimarse; si la hoja ya tiene
        // contenido, la opción baja a la siguiente hoja.
        if (hasContent(model)) {
          const probe = { rows: model.rows, groups: [...model.groups, { idx: g.idx, name: g.name, total: g.total, cards: [remaining[0]], cont, start: placed }], closing: [] };
          if (!measurePage(blockHTML(probe, model === pages[0]), false)) { nextPage(); continue; }
        }
        const group = { idx: g.idx, name: g.name, total: g.total, cards: [], cont, start: placed };
        model.groups.push(group);
        while (remaining.length) {
          group.cards.push(remaining[0]);
          if (!measurePage(blockHTML(model, model === pages[0]), false)) { group.cards.pop(); break; }
          remaining.shift();
          placed++;
        }
        if (!group.cards.length) { group.cards.push(remaining.shift()); placed++; }
        if (remaining.length) nextPage();
      }
    };

    _layout.rows.forEach((row, i) => {
      model.rows.push(row);
      if (!measurePage(blockHTML(model, model === pages[0]), false) && model.rows.length > 1) {
        model.rows.pop();
        nextPage();
        model.rows.push(row);
      }
      const g = _layout.groups[i];
      if (!g) return;
      model.groups.push({ idx: g.idx, name: g.name, total: g.total, cards: g.cards.slice(), cont: false, start: 0 });
      if (measurePage(blockHTML(model, model === pages[0]), false)) return;
      model.groups.pop();
      // El grupo no cabe completo: si al menos dos tarjetas caben en el espacio
      // restante, se aprovecha la hoja y el resto continúa en la siguiente.
      const probeCount = Math.min(2, g.cards.length);
      const probe = { rows: model.rows, groups: [{ idx: g.idx, name: g.name, total: g.total, cards: g.cards.slice(0, probeCount), cont: false, start: 0 }], closing: [] };
      const reusePage = hasContent(model) && measurePage(blockHTML(probe, model === pages[0]), false);
      if (!reusePage && hasContent(model)) nextPage();
      addGroup(g);
    });

    // Cierre: cada bloque se coloca completo. Si no cabe con las firmas, se
    // abre una hoja nueva sin reservarlas (las firmas pasan a la siguiente)
    // para que un texto largo nunca se recorte.
    _layout.closing.forEach((block) => {
      model.closing.push(block);
      if (measurePage(blockHTML(model, model === pages[0]), true)) return;
      model.closing.pop();
      model = { rows: [], groups: [], closing: [block] };
      pages.push(model);
    });
    // Las firmas necesitan su propio espacio: si la última hoja ya no lo tiene,
    // se agrega una hoja final solo para el cierre.
    if (!measurePage(blockHTML(model, model === pages[0]), true) && hasContent(model)) {
      model = { rows: [], groups: [], closing: [] };
      pages.push(model);
    }
    renderPages(pages);
  }

  function fitToPage() {
    clearTimeout(_fitTimer);
    _fitTimer = setTimeout(paginate, 60);
  }

  function logoReady() {
    const img = $(".doc-logo");
    if (!img || img.complete) return Promise.resolve();
    return new Promise(resolve => {
      const done = () => resolve();
      img.addEventListener("load", done, { once: true });
      img.addEventListener("error", done, { once: true });
      setTimeout(done, 2500);
    });
  }
  async function doPrint() {
    await logoReady();
    // Repagina con las fuentes definitivas y luego asegura las imágenes para
    // que el PDF salga completo y sin cortes.
    try { await document.fonts?.ready; } catch { /* sin soporte de fonts */ }
    paginate();
    await hydrateDocImages();
    const docId = currentDoc?.id || id;
    // Dentro de la vista previa, delega al contenedor para usar el mismo
    // puente de escritorio que abre Adobe (postMessage evita restricciones
    // de origen entre el iframe y la ventana principal).
    if (docId && window.parent && window.parent !== window) {
      try { window.parent.postMessage({ type: "sylpack:print-doc", id: String(docId) }, "*"); return; }
      catch { /* continúa con el puente o la impresión del navegador */ }
    }
    let bridge = null;
    try { bridge = window.pywebview?.api || window.parent?.pywebview?.api || window.top?.pywebview?.api; }
    catch { bridge = window.pywebview?.api; }
    if (bridge?.print_document && docId) {
      try {
        const r = await bridge.print_document(String(docId), token() || "", docFileName(currentDoc || {}));
        if (r === true || r?.ok || r?.success) return;
      } catch { /* sin puente: impresión del navegador */ }
    }
    window.print();
  }

  async function load() {
    if (!id) return error("Falta el identificador del documento.");
    try {
      const r = await fetch(`${API()}/api/compras/documentos/${encodeURIComponent(id)}`, {
        headers: { Authorization: "Bearer " + (token() || "") }
      });
      if (r.status === 401) return error("Tu sesión expiró. Cierra esta ventana e ingresa de nuevo.");
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.msg || "No se pudo cargar el documento.");
      currentDoc = d;
      render(d);
      document.fonts?.ready.then(fitToPage);
      // El título define el nombre sugerido al guardar como PDF desde el
      // navegador. Sin la extensión para no generar "....pdf.pdf".
      document.title = docFileName(d).replace(/\.pdf$/i, "");
      if (autoPrint) setTimeout(doPrint, 900);
    } catch (e) {
      error(e.message || "No se pudo cargar el documento.");
    }
  }

  /* --- imágenes del producto (nunca logos/favicon de tiendas) --- */
  const _imgCache = new Map();
  function imgSrc(url) {
    const clean = safeUrl(url);
    if (!clean) return Promise.resolve("");
    if (_imgCache.has(clean)) return _imgCache.get(clean);
    const p = fetch(`${API()}/api/compras/imagen?url=` + encodeURIComponent(clean), {
      headers: { Authorization: "Bearer " + (token() || "") }, cache: "force-cache",
    }).then(r => { if (!r.ok) throw 0; return r.blob(); })
      .then(b => URL.createObjectURL(b))
      .catch(() => { _imgCache.set(clean, Promise.resolve(clean)); return clean; });
    _imgCache.set(clean, p);
    return p;
  }
  async function hydrateDocImages() {
    const cells = [...document.querySelectorAll("[data-docimg]")].filter(el => el.dataset.done !== "1");
    await Promise.all(cells.map(async el => {
      el.dataset.done = "1";
      let remote = safeUrl(el.dataset.docimg || "");
      try {
        if (!remote) {
          const link = safeUrl(el.dataset.doclink || "");
          if (link) {
            const r = await fetch(`${API()}/api/compras/link-preview?url=` + encodeURIComponent(link), {
              headers: { Authorization: "Bearer " + (token() || "") }
            });
            if (r.ok) {
              const info = await r.json().catch(() => ({}));
              remote = safeUrl(info.image || ""); // foto del producto (og:image); sin favicon
            }
          }
        }
        if (!remote) { el.classList.add("empty"); return; }
        const src = await imgSrc(remote);
        if (!src) { el.classList.add("empty"); return; }
        el.innerHTML = `<img src="${src}" alt="Imagen del producto" referrerpolicy="no-referrer" onerror="this.onerror=null;this.style.display='none';this.parentElement.classList.add('empty')">`;
      } catch { el.classList.add("empty"); }
    }));
  }

  $("#printBtn")?.addEventListener("click", doPrint);
  $("#refreshBtn")?.addEventListener("click", load);
  window.addEventListener("load", fitToPage);
  if (token()) load();
  else error("Inicia sesión en Sylpack Tickets para ver este documento.");
  setInterval(() => { if (!document.hidden && token()) load(); }, 60000);
})();
