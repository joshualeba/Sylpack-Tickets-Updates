-- Sylpack Tickets · PostgreSQL schema
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(60) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(12) NOT NULL DEFAULT 'user' CHECK (role IN ('admin','user','super','compras','calidad')),
  area VARCHAR(80) NOT NULL DEFAULT '',
  puesto VARCHAR(80) NOT NULL DEFAULT '',
  jefe_area VARCHAR(120) NOT NULL DEFAULT '',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS tickets (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  titulo VARCHAR(140) NOT NULL,
  descripcion TEXT NOT NULL,
  prioridad VARCHAR(10) NOT NULL DEFAULT 'media' CHECK (prioridad IN ('baja','media','alta','critica')),
  estado VARCHAR(12) NOT NULL DEFAULT 'abierto' CHECK (estado IN ('abierto','en_proceso','cerrado')),
  adjunto_path VARCHAR(500),
  adjunto_nombre VARCHAR(255),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tickets_estado ON tickets(estado);
CREATE INDEX IF NOT EXISTS idx_tickets_created ON tickets(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_tickets_user ON tickets(user_id);

ALTER TABLE users ADD COLUMN IF NOT EXISTS area VARCHAR(80) DEFAULT '';
ALTER TABLE users ADD COLUMN IF NOT EXISTS puesto VARCHAR(80) DEFAULT '';
ALTER TABLE users ADD COLUMN IF NOT EXISTS jefe_area VARCHAR(120) DEFAULT '';

CREATE TABLE IF NOT EXISTS ticket_messages (
  id SERIAL PRIMARY KEY,
  ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  mensaje VARCHAR(500) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_msg_ticket ON ticket_messages(ticket_id);

CREATE TABLE IF NOT EXISTS ticket_valoraciones (
  ticket_id INTEGER PRIMARY KEY REFERENCES tickets(id) ON DELETE CASCADE,
  estrellas SMALLINT NOT NULL CHECK (estrellas BETWEEN 1 AND 5),
  comentario VARCHAR(500) NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ticket_cierres (
  ticket_id INTEGER PRIMARY KEY REFERENCES tickets(id) ON DELETE CASCADE,
  nota TEXT NOT NULL DEFAULT '',
  evidencia_path VARCHAR(500),
  evidencia_nombre VARCHAR(255),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ticket_adjuntos (
  id SERIAL PRIMARY KEY,
  ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  path VARCHAR(500) NOT NULL,
  nombre VARCHAR(255) NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_adj_ticket ON ticket_adjuntos(ticket_id);

CREATE TABLE IF NOT EXISTS ticket_eventos (
  id SERIAL PRIMARY KEY,
  ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  tipo VARCHAR(20) NOT NULL,
  por VARCHAR(60) NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_ev_ticket ON ticket_eventos(ticket_id);

CREATE TABLE IF NOT EXISTS audit_logs (
  id SERIAL PRIMARY KEY,
  actor_id INTEGER,
  actor VARCHAR(60) NOT NULL DEFAULT '',
  accion VARCHAR(40) NOT NULL,
  detalle TEXT NOT NULL DEFAULT '',
  ticket_id INTEGER,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_accion ON audit_logs(accion);

-- =====================================================================
-- Módulo de compras
-- Flujo: solicitud -> revisión -> aprobación/rechazo -> requisición ->
-- orden de compra -> autorización -> envío -> recepción -> devolución.
-- =====================================================================
CREATE TABLE IF NOT EXISTS proveedores (
  id SERIAL PRIMARY KEY,
  nombre TEXT NOT NULL,
  rfc TEXT NOT NULL DEFAULT '',
  razon_social TEXT NOT NULL DEFAULT '',
  domicilio TEXT NOT NULL DEFAULT '',
  contacto TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  telefono TEXT NOT NULL DEFAULT '',
  condiciones_pago TEXT NOT NULL DEFAULT '',
  area TEXT NOT NULL DEFAULT '',
  calidad_estado TEXT NOT NULL DEFAULT 'pendiente',
  calidad_por TEXT NOT NULL DEFAULT '',
  calidad_at TIMESTAMPTZ,
  calidad_nota TEXT NOT NULL DEFAULT '',
  created_by TEXT NOT NULL DEFAULT '',
  updated_by TEXT NOT NULL DEFAULT '',
  updated_at TIMESTAMPTZ,
  activo BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS compras_solicitudes (
  id SERIAL PRIMARY KEY,
  folio TEXT NOT NULL DEFAULT '',
  user_id INTEGER NOT NULL,
  area TEXT NOT NULL DEFAULT '',
  titulo TEXT NOT NULL,
  justificacion TEXT NOT NULL DEFAULT '',
  prioridad TEXT NOT NULL DEFAULT 'media',
  estado TEXT NOT NULL DEFAULT 'pendiente',
  tipo_compra TEXT NOT NULL DEFAULT 'normal',
  flujo TEXT NOT NULL DEFAULT 'legado',
  jefe_area TEXT NOT NULL DEFAULT '',
  calidad_estado TEXT NOT NULL DEFAULT 'no_requiere',
  calidad_por TEXT NOT NULL DEFAULT '',
  calidad_at TIMESTAMPTZ,
  calidad_nota TEXT NOT NULL DEFAULT '',
  proveedor_propuesto TEXT NOT NULL DEFAULT '',
  proveedor_sugerido TEXT NOT NULL DEFAULT '',
  notas TEXT NOT NULL DEFAULT '',
  revisado_por TEXT NOT NULL DEFAULT '',
  revisado_at TIMESTAMPTZ,
  gestor_por TEXT NOT NULL DEFAULT '',
  gestor_at TIMESTAMPTZ,
  motivo_rechazo TEXT NOT NULL DEFAULT '',
  motivo_cambios TEXT NOT NULL DEFAULT '',
  cambios_oc_motivo TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS compras_items (
  id SERIAL PRIMARY KEY,
  solicitud_id INTEGER NOT NULL,
  nombre TEXT NOT NULL,
  descripcion TEXT NOT NULL DEFAULT '',
  motivo TEXT NOT NULL DEFAULT '',
  requisitos_calidad TEXT NOT NULL DEFAULT '',
  id_fabricacion TEXT NOT NULL DEFAULT '',
  cantidad DOUBLE PRECISION NOT NULL DEFAULT 1,
  unidad TEXT NOT NULL DEFAULT 'pza',
  link TEXT NOT NULL DEFAULT '',
  imagen TEXT NOT NULL DEFAULT '',
  proveedor TEXT NOT NULL DEFAULT '',
  costo_unitario DOUBLE PRECISION NOT NULL DEFAULT 0,
  precio_incluye_iva BOOLEAN NOT NULL DEFAULT FALSE,
  orden INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS compras_item_opciones (
  id SERIAL PRIMARY KEY,
  item_id INTEGER NOT NULL,
  etiqueta TEXT NOT NULL DEFAULT '',
  diferencia TEXT NOT NULL DEFAULT '',
  link TEXT NOT NULL DEFAULT '',
  imagen TEXT NOT NULL DEFAULT '',
  proveedor TEXT NOT NULL DEFAULT '',
  costo_unitario DOUBLE PRECISION NOT NULL DEFAULT 0,
  precio_incluye_iva BOOLEAN NOT NULL DEFAULT FALSE,
  orden INTEGER NOT NULL DEFAULT 0,
  calidad_aprobada BOOLEAN NOT NULL DEFAULT FALSE,
  calidad_por TEXT NOT NULL DEFAULT '',
  calidad_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS compras_documentos (
  id SERIAL PRIMARY KEY,
  folio TEXT NOT NULL DEFAULT '',
  tipo TEXT NOT NULL DEFAULT 'requisicion',
  tipo_compra TEXT NOT NULL DEFAULT 'normal',
  solicitud_id INTEGER NOT NULL,
  origen_id INTEGER,
  proveedor_id INTEGER,
  estado TEXT NOT NULL DEFAULT 'borrador',
  jefe_area TEXT NOT NULL DEFAULT '',
  calidad_por TEXT NOT NULL DEFAULT '',
  calidad_at TIMESTAMPTZ,
  fecha TEXT NOT NULL DEFAULT '',
  moneda TEXT NOT NULL DEFAULT 'MXN',
  subtotal DOUBLE PRECISION NOT NULL DEFAULT 0,
  descuento_pct DOUBLE PRECISION NOT NULL DEFAULT 0,
  iva_pct DOUBLE PRECISION NOT NULL DEFAULT 16,
  total DOUBLE PRECISION NOT NULL DEFAULT 0,
  condiciones TEXT NOT NULL DEFAULT '',
  notas TEXT NOT NULL DEFAULT '',
  fecha_entrega TEXT NOT NULL DEFAULT '',
  misma_fecha_entrega BOOLEAN NOT NULL DEFAULT FALSE,
  almacen TEXT NOT NULL DEFAULT '',
  entregar_a TEXT NOT NULL DEFAULT '',
  elaborado_por TEXT NOT NULL DEFAULT '',
  autorizado_por TEXT NOT NULL DEFAULT '',
  autorizado_at TIMESTAMPTZ,
  empresa_snapshot TEXT NOT NULL DEFAULT '',
  proveedor_snapshot TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS compras_documento_items (
  id SERIAL PRIMARY KEY,
  documento_id INTEGER NOT NULL,
  item_id INTEGER,
  opcion_id INTEGER,
  opcion_etiqueta TEXT NOT NULL DEFAULT '',
  link TEXT NOT NULL DEFAULT '',
  diferencia TEXT NOT NULL DEFAULT '',
  nombre TEXT NOT NULL,
  descripcion TEXT NOT NULL DEFAULT '',
  id_fabricacion TEXT NOT NULL DEFAULT '',
  cantidad DOUBLE PRECISION NOT NULL DEFAULT 1,
  unidad TEXT NOT NULL DEFAULT 'pza',
  costo_unitario DOUBLE PRECISION NOT NULL DEFAULT 0,
  descuento_pct DOUBLE PRECISION NOT NULL DEFAULT 0,
  importe DOUBLE PRECISION NOT NULL DEFAULT 0,
  precio_incluye_iva BOOLEAN NOT NULL DEFAULT FALSE,
  fecha_llegada TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS compras_eventos (
  id SERIAL PRIMARY KEY,
  solicitud_id INTEGER,
  documento_id INTEGER,
  tipo TEXT NOT NULL,
  estado_anterior TEXT NOT NULL DEFAULT '',
  estado_nuevo TEXT NOT NULL DEFAULT '',
  por TEXT NOT NULL DEFAULT '',
  nota TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS compras_mensajes (
  id SERIAL PRIMARY KEY,
  solicitud_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  mensaje TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS compras_recepciones (
  id SERIAL PRIMARY KEY,
  folio TEXT NOT NULL DEFAULT '',
  documento_id INTEGER NOT NULL,
  solicitud_id INTEGER,
  recibido_por TEXT NOT NULL DEFAULT '',
  fecha TEXT NOT NULL DEFAULT '',
  estado TEXT NOT NULL DEFAULT 'completa',
  notas TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS compras_recepcion_items (
  id SERIAL PRIMARY KEY,
  recepcion_id INTEGER NOT NULL,
  item_id INTEGER,
  cantidad DOUBLE PRECISION NOT NULL DEFAULT 0,
  estado TEXT NOT NULL DEFAULT 'ok',
  notas TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS compras_devoluciones (
  id SERIAL PRIMARY KEY,
  folio TEXT NOT NULL DEFAULT '',
  documento_id INTEGER,
  recepcion_id INTEGER,
  solicitud_id INTEGER,
  motivo TEXT NOT NULL DEFAULT '',
  estado TEXT NOT NULL DEFAULT 'solicitada',
  notas TEXT NOT NULL DEFAULT '',
  creado_por TEXT NOT NULL DEFAULT '',
  aprobado_por TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS compras_devolucion_items (
  id SERIAL PRIMARY KEY,
  devolucion_id INTEGER NOT NULL,
  item_id INTEGER,
  cantidad DOUBLE PRECISION NOT NULL DEFAULT 0,
  motivo TEXT NOT NULL DEFAULT '',
  estado TEXT NOT NULL DEFAULT 'pendiente',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS compras_empresa (
  id INTEGER PRIMARY KEY,
  nombre TEXT NOT NULL DEFAULT '',
  rfc TEXT NOT NULL DEFAULT '',
  razon_social TEXT NOT NULL DEFAULT '',
  domicilio TEXT NOT NULL DEFAULT '',
  telefono TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  logo TEXT NOT NULL DEFAULT 'assets/logo.png',
  updated_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS compras_adjuntos (
  id SERIAL PRIMARY KEY,
  solicitud_id INTEGER NOT NULL,
  documento_id INTEGER,
  path TEXT NOT NULL,
  nombre TEXT NOT NULL,
  tipo TEXT NOT NULL DEFAULT 'firmado',
  subido_por TEXT NOT NULL DEFAULT '',
  vigente BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_cp_sol_user ON compras_solicitudes(user_id);
CREATE INDEX IF NOT EXISTS idx_cp_sol_estado ON compras_solicitudes(estado);
CREATE INDEX IF NOT EXISTS idx_cp_items_sol ON compras_items(solicitud_id);
CREATE INDEX IF NOT EXISTS idx_cp_opciones_item ON compras_item_opciones(item_id);
CREATE INDEX IF NOT EXISTS idx_cp_doc_sol ON compras_documentos(solicitud_id);
CREATE INDEX IF NOT EXISTS idx_cp_doc_estado ON compras_documentos(estado);
CREATE INDEX IF NOT EXISTS idx_cp_docitems_doc ON compras_documento_items(documento_id);
CREATE INDEX IF NOT EXISTS idx_cp_ev_sol ON compras_eventos(solicitud_id);
CREATE INDEX IF NOT EXISTS idx_cp_ev_doc ON compras_eventos(documento_id);
CREATE INDEX IF NOT EXISTS idx_cp_msg_sol ON compras_mensajes(solicitud_id);
CREATE INDEX IF NOT EXISTS idx_cp_rec_doc ON compras_recepciones(documento_id);
CREATE INDEX IF NOT EXISTS idx_cp_dev_doc ON compras_devoluciones(documento_id);
CREATE INDEX IF NOT EXISTS idx_cp_adj_sol ON compras_adjuntos(solicitud_id);
CREATE INDEX IF NOT EXISTS idx_cp_adj_tipo ON compras_adjuntos(solicitud_id,tipo,vigente);
