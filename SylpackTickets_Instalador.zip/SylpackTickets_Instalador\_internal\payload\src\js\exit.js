/* Sylpack Tickets — ventana de salida
   Pide credenciales de administrador/super admin. Enter: usuario -> contraseña
   -> enviar. Muestra el resultado dentro de la propia tarjeta. */
(() => {
  "use strict";
  const $ = (s) => document.querySelector(s);
  const api = () => (window.pywebview && window.pywebview.api) || null;

  const userEl = $("#user");
  const passEl = $("#pass");
  const errEl = $("#err");
  const errTxt = $("#errTxt");
  const btn = $("#exit");
  const btnTxt = btn.querySelector(".ex-btn-txt");
  const eye = $("#eye");
  const card = $(".ex-card");
  const form = $("#exForm");
  const note = $("#exNote");
  const success = $("#success");
  const foot = $("#exFoot");
  const cancelX = $("#cancelX");
  let busy = false;

  // Auto-ajuste de la ventana: si por DPI/escala de texto el contenido real no
  // cabe, avisa al backend para crecer y recentrar (nada se recorta).
  function reportSize() {
    const a = api();
    if (!card || !a || !a.exit_size) return;
    const dpr = window.devicePixelRatio || 1;
    const needW = Math.max(card.scrollWidth, card.clientWidth);
    const needH = Math.max(card.scrollHeight, card.clientHeight);
    const w = Math.ceil((needW + 18) * dpr);
    const h = Math.ceil((needH + 18) * dpr);
    try { a.exit_size(w, h); } catch (_) {}
  }
  window.__exitSize = reportSize;

  // Sede / Cliente en la cabecera.
  const raw = String(window.SYLPACK_ROLE || "").trim();
  const chip = $("#roleChip");
  if (chip) {
    let label = "Sede";
    if (/^cliente/i.test(raw)) {
      const m = raw.match(/->\s*(.+)$/);
      label = "Cliente" + (m ? " · " + m[1].trim() : "");
    } else {
      const m = raw.match(/\(([^()]+)\)/);
      label = "Sede" + (m ? " · " + m[1].trim() : "");
    }
    chip.lastChild.textContent = label;
    chip.title = raw || label;
  }

  function setErr(text) {
    errTxt.textContent = text || "";
    errEl.hidden = !text;
    userEl.setAttribute("aria-invalid", text ? "true" : "false");
    passEl.setAttribute("aria-invalid", text ? "true" : "false");
  }

  function setBusy(on) {
    busy = on;
    btn.disabled = on;
    btn.classList.toggle("loading", on);
    btnTxt.textContent = on ? "Verificando…" : "Cerrar aplicación";
    userEl.disabled = on;
    passEl.disabled = on;
    eye.disabled = on;
    const cancelBtn = $("#cancel");
    if (cancelBtn) cancelBtn.disabled = on;
    if (cancelX) cancelX.disabled = on;
  }

  function cancel() {
    if (busy) return;
    const a = api();
    if (a && a.cancel) a.cancel();
  }

  function showSuccess() {
    setBusy(true);
    card.classList.add("is-closing");
    if (cancelX) cancelX.hidden = true;
    form.hidden = true;
    note.hidden = true;
    foot.hidden = true;
    success.hidden = false;
    setTimeout(reportSize, 80);
  }

  async function submit() {
    if (busy) return;
    const u = (userEl.value || "").trim();
    const p = passEl.value || "";
    if (!u) {
      setErr("Ingresa tu usuario.");
      userEl.focus();
      return;
    }
    if (!p) {
      setErr("Ingresa tu contraseña.");
      passEl.focus();
      return;
    }
    setErr("");
    setBusy(true);
    let res = null;
    try {
      const a = api();
      if (!a || !a.verify) throw new Error("sin conexión");
      res = await a.verify(u, p);
    } catch {
      res = { ok: false, msg: "No se pudo verificar. Inténtalo de nuevo." };
    }

    if (res && res.ok) {
      showSuccess();
      return;
    }

    setBusy(false);
    setErr((res && res.msg) || "Credenciales de administrador inválidas.");
    card.classList.remove("shake");
    void card.offsetWidth;
    card.classList.add("shake");
    passEl.value = "";
    passEl.focus();
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    submit();
  });

  userEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      passEl.focus();
      passEl.select?.();
    }
  });

  passEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      submit();
    }
  });

  eye.addEventListener("click", () => {
    const show = passEl.type === "password";
    passEl.type = show ? "text" : "password";
    eye.classList.toggle("off", show);
    eye.setAttribute("aria-pressed", show ? "true" : "false");
    eye.setAttribute("aria-label", show ? "Ocultar contraseña" : "Mostrar contraseña");
    passEl.focus();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      cancel();
    }
  });

  $("#cancel").addEventListener("click", cancel);
  if (cancelX) cancelX.addEventListener("click", cancel);

  // Arrastre desde la cabecera.
  const drag = $("#drag");
  let dragging = false;
  let lx = 0;
  let ly = 0;
  drag.addEventListener("mousedown", (e) => {
    if (e.target.closest("button")) return;
    dragging = true;
    lx = e.screenX;
    ly = e.screenY;
    e.preventDefault();
  });
  window.addEventListener("mousemove", (e) => {
    if (!dragging) return;
    const dx = e.screenX - lx;
    const dy = e.screenY - ly;
    lx = e.screenX;
    ly = e.screenY;
    const a = api();
    if (a && a.win_drag) a.win_drag(dx, dy);
  });
  window.addEventListener("mouseup", () => { dragging = false; });

  function ready() {
    const a = api();
    if (a && a.ready) a.ready();
    userEl.focus();
    setTimeout(reportSize, 60);
    setTimeout(reportSize, 350);
  }
  window.addEventListener("pywebviewready", ready);
  if (window.pywebview) ready();
  window.addEventListener("load", () => setTimeout(reportSize, 120));
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(() => setTimeout(reportSize, 60)).catch(() => {});
  }
})();
