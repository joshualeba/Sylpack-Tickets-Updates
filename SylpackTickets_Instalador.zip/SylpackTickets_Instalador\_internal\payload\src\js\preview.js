/* Visor de archivos Sylpack: imágenes y PDF dentro de la app. */
(() => {
  const authToken = () => localStorage.getItem("access") || sessionStorage.getItem("access");
  const isImage = name => /\.(png|jpe?g|webp)$/i.test(name || "");
  const isPdf = name => /\.pdf$/i.test(name || "");

  function ensure() {
    let root = document.getElementById("pvRoot");
    if (root) return root;
    root = document.createElement("div");
    root.id = "pvRoot";
    root.innerHTML = `
      <div class="modal-veil" data-pv-x></div>
      <figure class="pv-card">
        <div class="pv-imgwrap">
          <span class="auth-spin" data-pv-load></span>
          <img data-pv-img alt="Vista previa" style="display:none"/>
          <iframe data-pv-frame title="Vista previa del documento" style="display:none"></iframe>
        </div>
        <figcaption><b data-pv-name></b>
          <div class="pv-btns">
            <button class="mbtn ghost" data-pv-dl>Descargar</button>
            <button class="mbtn" data-pv-x>Cerrar</button>
          </div>
        </figcaption>
      </figure>`;
    document.body.appendChild(root);
    root.addEventListener("click", e => { if (e.target.closest("[data-pv-x]")) close(); });
    document.addEventListener("keydown", e => { if (e.key === "Escape" && root.classList.contains("show")) close(); });
    return root;
  }

  let objUrl = null, curName = "", curUrl = "", curPdf = false;
  function close() {
    const root = document.getElementById("pvRoot");
    if (root) {
      root.classList.remove("show");
      const frame = root.querySelector("[data-pv-frame]");
      if (frame) { frame.src = "about:blank"; frame.style.display = "none"; }
      const img = root.querySelector("[data-pv-img]");
      if (img) { img.removeAttribute("src"); img.style.display = "none"; }
      const spin = root.querySelector("[data-pv-load]");
      if (spin) spin.style.display = "";
    }
    window.SylpackScroll?.unlock();
    if (objUrl) { URL.revokeObjectURL(objUrl); objUrl = null; }
  }

  async function saveBlob(blob, name, pdf) {
    const ext = (name.match(/\.[a-z0-9]+$/i) || [""])[0].toLowerCase();
    try {
      if (window.showSaveFilePicker) {
        const types = pdf
          ? [{ description: "Documento PDF", accept: { "application/pdf": [".pdf"] } }]
          : [{ description: "Imagen", accept: { "image/*": [ext || ".png", ".jpg", ".jpeg", ".webp"] } }];
        const handle = await window.showSaveFilePicker({ suggestedName: name || (pdf ? "documento.pdf" : "imagen"), types });
        const w = await handle.createWritable();
        await w.write(blob);
        await w.close();
        return;
      }
      throw 0;
    } catch (err) {
      if (err && err.name === "AbortError") return;
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = name || (pdf ? "documento.pdf" : "archivo");
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 60000);
    }
  }

  async function download(url, name) {
    const pdf = isPdf(name);
    try {
      const r = await fetch(url, { headers: { Authorization: "Bearer " + authToken() } });
      if (!r.ok) throw new Error("No disponible");
      await saveBlob(await r.blob(), name || (pdf ? "documento.pdf" : "archivo"), pdf || (r.headers.get("content-type") || "").includes("pdf"));
    } catch {
      window.Modal?.error("No se pudo descargar", "El archivo ya no está disponible en el servidor.");
    }
  }

  async function open(path, name, opts = {}) {
    const url = opts.url || `${API_BASE}/api/uploads/${encodeURIComponent(path)}`;
    const label = name || path || "archivo";
    const pdf = isPdf(label) || !!opts.pdf;
    const img = !pdf && (opts.image !== undefined ? !!opts.image : isImage(label));
    if (!pdf && !img) { await download(url, label); return; }

    const root = ensure();
    const imgEl = root.querySelector("[data-pv-img]");
    const frame = root.querySelector("[data-pv-frame]");
    const spin = root.querySelector("[data-pv-load]");
    root.querySelector("[data-pv-name]").textContent = label;
    imgEl.style.display = "none";
    imgEl.removeAttribute("src");
    frame.style.display = "none";
    frame.src = "about:blank";
    spin.style.display = "";
    root.classList.add("show");
    window.SylpackScroll?.lock();
    curName = label;
    curUrl = url;
    curPdf = pdf;
    try {
      const r = await fetch(url, { headers: { Authorization: "Bearer " + authToken() } });
      if (!r.ok) throw new Error("No disponible");
      if (objUrl) { URL.revokeObjectURL(objUrl); objUrl = null; }
      const blob = await r.blob();
      objUrl = URL.createObjectURL(pdf ? new Blob([blob], { type: "application/pdf" }) : blob);
      if (pdf) {
        frame.src = objUrl;
        frame.style.display = "block";
      } else {
        imgEl.src = objUrl;
        await imgEl.decode().catch(() => {});
        imgEl.style.display = "";
      }
      spin.style.display = "none";
    } catch {
      close();
      window.Modal?.error("No se pudo mostrar", "El archivo ya no está disponible en el servidor.");
      return;
    }
    root.querySelector("[data-pv-dl]").onclick = async () => {
      try {
        const r = await fetch(objUrl);
        const blob = await r.blob();
        await saveBlob(blob, curName, curPdf);
      } catch {
        await download(curUrl, curName);
      }
    };
  }

  window.SylpackPreview = { open, close, download };
})();
